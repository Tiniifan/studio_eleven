attribute vec4 atr_pos;
attribute vec4 atr_clr;
attribute vec3 atr_nrm;
attribute vec4 atr_pr0;
attribute vec4 atr_pr1;
attribute vec4 atr_pr2;
varying vec4 var_clr;
varying vec4 var_nrm;
varying vec4 var_tng;
varying vec4 var_tx0;
varying vec4 var_tx1;
varying vec4 var_tx2;
varying vec4 var_prm;
varying vec4 var_gen;
uniform vec4 unf_vtx_cmr_prj[4];
uniform vec4 unf_vtx_glb_cmr[3];
uniform vec4 unf_vtx_lcl_glb[3];
uniform vec4 unf_vtx_txt[6];
uniform vec4 unf_vtx_clr;

void main() {
    vec4 w_pos;
    w_pos.x = dot(atr_pos, unf_vtx_lcl_glb[0]);
    w_pos.y = dot(atr_pos, unf_vtx_lcl_glb[1]);
    w_pos.z = dot(atr_pos, unf_vtx_lcl_glb[2]);
    w_pos.w = 1.000000;
    vec4 w_cnt;
    w_cnt.x = unf_vtx_lcl_glb[0].w;
    w_cnt.y = unf_vtx_lcl_glb[1].w;
    w_cnt.z = unf_vtx_lcl_glb[2].w;
    w_cnt.w = 1.000000;
    vec3 w_dir[3];
    w_dir[0] = normalize(unf_vtx_lcl_glb[0].xyz);
    w_dir[1] = normalize(unf_vtx_lcl_glb[1].xyz);
    w_dir[2] = normalize(unf_vtx_lcl_glb[2].xyz);
    vec3 w_nrm;
    w_nrm.x = dot(atr_nrm.xyz, w_dir[0]);
    w_nrm.y = dot(atr_nrm.xyz, w_dir[1]);
    w_nrm.z = dot(atr_nrm.xyz, w_dir[2]);
    vec4 v_pos;
    v_pos.x = dot(w_pos, unf_vtx_glb_cmr[0]);
    v_pos.y = dot(w_pos, unf_vtx_glb_cmr[1]);
    v_pos.z = dot(w_pos, unf_vtx_glb_cmr[2]);
    v_pos.w = 1.000000;
    vec4 v_cnt;
    v_cnt.x = dot(w_cnt, unf_vtx_glb_cmr[0]);
    v_cnt.y = dot(w_cnt, unf_vtx_glb_cmr[1]);
    v_cnt.z = dot(w_cnt, unf_vtx_glb_cmr[2]);
    v_cnt.w = 1.000000;
    vec4 v_clr;
    v_clr = atr_clr * unf_vtx_clr;
    vec3 v_nrm;
    v_nrm.x = dot(w_nrm.xyz, unf_vtx_glb_cmr[0].xyz);
    v_nrm.y = dot(w_nrm.xyz, unf_vtx_glb_cmr[1].xyz);
    v_nrm.z = dot(w_nrm.xyz, unf_vtx_glb_cmr[2].xyz) - 1.000000;
    v_nrm.xy *= v_clr.xy;
    v_nrm = normalize(v_nrm.xyz);
    v_nrm *= (atr_pr2.x * v_clr.z + v_cnt.z - v_pos.z) * atr_pr2.y / v_nrm.z;
    gl_Position.x = dot(v_pos, unf_vtx_cmr_prj[0]);
    gl_Position.y = dot(v_pos, unf_vtx_cmr_prj[1]);
    gl_Position.z = dot(v_pos, unf_vtx_cmr_prj[2]);
    gl_Position.w = dot(v_pos, unf_vtx_cmr_prj[3]);
    var_clr.x = 0.500000;
    var_clr.y = 0.500000;
    var_clr.z = 0.500000;
    var_clr.w = 0.500000 * v_clr.w;
    vec2 v_tx0;
    v_tx0.x = v_pos.x + v_nrm.x;
    v_tx0.y = v_pos.y + v_nrm.y;
    if (v_nrm.x < 0.000000) {
        v_tx0.x = max(v_tx0.x, 0.000000);
    }
    if (v_nrm.y < 0.000000) {
        v_tx0.y = max(v_tx0.y, 0.000000);
    }
    if (v_nrm.x > 0.000000) {
        v_tx0.x = min(v_tx0.x, atr_pr0.x - 1.000000);
    }
    if (v_nrm.y > 0.000000) {
        v_tx0.y = min(v_tx0.y, atr_pr0.y - 1.000000);
    }
    v_tx0.xy *= atr_pr1.zw;
    var_tx0.x = dot(v_tx0.xy, unf_vtx_txt[0].xy) + unf_vtx_txt[0].w;
    var_tx0.y = dot(v_tx0.xy, unf_vtx_txt[1].xy) + unf_vtx_txt[1].w;
    var_tx0.z = 0.000000;
    var_tx0.w = 0.000000;
    var_tx1 = vec4(0.000000, 0.000000, 0.000000, 0.000000);
    var_tx2 = vec4(0.000000, 0.000000, 0.000000, 0.000000);
    var_nrm = vec4(0.000000, 0.000000, 0.000000, 0.000000);
    var_tng = vec4(0.000000, 0.000000, 0.000000, 0.000000);
    var_prm = vec4(0.000000, 0.000000, 0.000000, 0.000000);
    var_gen = var_nrm;
}
