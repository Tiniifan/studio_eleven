uniform sampler2D unf_frg_txt_2d_0;
uniform sampler2D unf_frg_txt_2d_1;
varying vec4 var_clr;
varying vec4 var_tx0;
varying vec4 var_tx1;
out vec4 outFragColor;

void main() {
    vec4 diff = texture2D(unf_frg_txt_2d_0, var_tx0.xy);
    vec4 mask = texture2D(unf_frg_txt_2d_1, var_tx1.xy);
    outFragColor = 2.000000 * vec4(var_clr.xyz, var_clr.w * dot(diff.xyz, mask.xyz));
}
