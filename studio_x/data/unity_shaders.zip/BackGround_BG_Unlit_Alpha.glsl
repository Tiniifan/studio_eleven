// BackGround/BG_Unlit_Alpha (Shader path ID -8597374433173351131, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
out highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec4 u_xlat16_0;
bvec3 u_xlatb0;
mediump float u_xlat16_1;
vec3 u_xlat2;
vec3 u_xlat3;
mediump vec4 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_9;
mediump float u_xlat16_12;
float u_xlat24;
bool u_xlatb24;
void main()
{
    u_xlat0.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlatb24 = unity_OrthoParams.w==0.0;
    u_xlat16_1 = (u_xlatb24) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat2.xyz = vec3(u_xlat16_1) * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat16_1 = (u_xlatb24) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat16_9.x = (u_xlatb24) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vec3(u_xlat16_1) + u_xlat2.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_9.xxx + u_xlat0.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlat24 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat24 = sqrt(u_xlat24);
    u_xlat24 = float(1.0) / u_xlat24;
    u_xlat2.xyz = vec3(u_xlat24) * vs_INTERP3.xyz;
    u_xlat3.x = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat3.y = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat3.z = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_1 = dot(_MainLightPosition.xyz, u_xlat2.xyz);
    u_xlat16_1 = u_xlat16_1 * 0.5 + 0.5;
    u_xlat24 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat3.xyz;
    u_xlat24 = dot((-u_xlat0.xyz), u_xlat2.xyz);
    u_xlat24 = u_xlat24 + u_xlat24;
    u_xlat0.xyz = u_xlat2.xyz * (-vec3(u_xlat24)) + (-u_xlat0.xyz);
    u_xlat16_0 = textureLod(unity_SpecCube0, u_xlat0.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_0.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_0.xyz * u_xlat16_9.xxx;
    u_xlat16_4.x = sqrt(u_xlat16_1);
    u_xlat16_12 = u_xlat16_1 + u_xlat16_1;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_1;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_12) * u_xlat16_5.xyz;
    u_xlat16_6.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_4.xzw = u_xlat16_4.xxx * u_xlat16_6.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_1) * u_xlat16_5.xyz;
    u_xlat16_5.xyz = vec3(u_xlat16_12) * _ShadowColor.xyz + u_xlat16_5.xyz;
    u_xlatb0.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_6.x = (u_xlatb0.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb0.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb0.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb0.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb0.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb0.z) ? float(1.0) : float(0.0);
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xzw * u_xlat16_7.xyz + u_xlat16_5.xyz;
    u_xlat16_0.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = u_xlat16_0.xyz * u_xlat16_4.xyz + (-u_xlat16_0.xyz);
    u_xlat16_4.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_4.xyz + u_xlat16_0.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * _Color.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * vs_INTERP1.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xyz * _Color.xyz + (-u_xlat16_5.xyz);
    u_xlat16_4.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_5.xyz;
    SV_Target0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_4.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec4 u_xlat16_0;
bvec3 u_xlatb0;
mediump float u_xlat16_1;
vec3 u_xlat2;
vec3 u_xlat3;
mediump vec4 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_9;
mediump float u_xlat16_12;
float u_xlat24;
bool u_xlatb24;
void main()
{
    u_xlat0.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlatb24 = unity_OrthoParams.w==0.0;
    u_xlat16_1 = (u_xlatb24) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat2.xyz = vec3(u_xlat16_1) * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat16_1 = (u_xlatb24) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat16_9.x = (u_xlatb24) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vec3(u_xlat16_1) + u_xlat2.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_9.xxx + u_xlat0.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlat24 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat24 = sqrt(u_xlat24);
    u_xlat24 = float(1.0) / u_xlat24;
    u_xlat2.xyz = vec3(u_xlat24) * vs_INTERP3.xyz;
    u_xlat3.x = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat3.y = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat3.z = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_1 = dot(_MainLightPosition.xyz, u_xlat2.xyz);
    u_xlat16_1 = u_xlat16_1 * 0.5 + 0.5;
    u_xlat24 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat3.xyz;
    u_xlat24 = dot((-u_xlat0.xyz), u_xlat2.xyz);
    u_xlat24 = u_xlat24 + u_xlat24;
    u_xlat0.xyz = u_xlat2.xyz * (-vec3(u_xlat24)) + (-u_xlat0.xyz);
    u_xlat16_0 = textureLod(unity_SpecCube0, u_xlat0.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_0.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_0.xyz * u_xlat16_9.xxx;
    u_xlat16_4.x = sqrt(u_xlat16_1);
    u_xlat16_12 = u_xlat16_1 + u_xlat16_1;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_1;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_12) * u_xlat16_5.xyz;
    u_xlat16_6.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_4.xzw = u_xlat16_4.xxx * u_xlat16_6.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_1) * u_xlat16_5.xyz;
    u_xlat16_5.xyz = vec3(u_xlat16_12) * _ShadowColor.xyz + u_xlat16_5.xyz;
    u_xlatb0.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_6.x = (u_xlatb0.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb0.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb0.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb0.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb0.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb0.z) ? float(1.0) : float(0.0);
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xzw * u_xlat16_7.xyz + u_xlat16_5.xyz;
    u_xlat16_0.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = u_xlat16_0.xyz * u_xlat16_4.xyz + (-u_xlat16_0.xyz);
    u_xlat16_4.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_4.xyz + u_xlat16_0.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * _Color.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * vs_INTERP1.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xyz * _Color.xyz + (-u_xlat16_5.xyz);
    u_xlat16_4.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_5.xyz;
    SV_Target0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_4.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 2: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
out highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec4 u_xlat16_0;
bvec3 u_xlatb0;
mediump float u_xlat16_1;
vec3 u_xlat2;
vec3 u_xlat3;
mediump vec4 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_9;
mediump float u_xlat16_12;
float u_xlat24;
bool u_xlatb24;
void main()
{
    u_xlat0.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlatb24 = unity_OrthoParams.w==0.0;
    u_xlat16_1 = (u_xlatb24) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat2.xyz = vec3(u_xlat16_1) * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat16_1 = (u_xlatb24) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat16_9.x = (u_xlatb24) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vec3(u_xlat16_1) + u_xlat2.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_9.xxx + u_xlat0.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlat24 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat24 = sqrt(u_xlat24);
    u_xlat24 = float(1.0) / u_xlat24;
    u_xlat2.xyz = vec3(u_xlat24) * vs_INTERP3.xyz;
    u_xlat3.x = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat3.y = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat3.z = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_1 = dot(_MainLightPosition.xyz, u_xlat2.xyz);
    u_xlat16_1 = u_xlat16_1 * 0.5 + 0.5;
    u_xlat24 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat3.xyz;
    u_xlat24 = dot((-u_xlat0.xyz), u_xlat2.xyz);
    u_xlat24 = u_xlat24 + u_xlat24;
    u_xlat0.xyz = u_xlat2.xyz * (-vec3(u_xlat24)) + (-u_xlat0.xyz);
    u_xlat16_0 = textureLod(unity_SpecCube0, u_xlat0.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_0.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_0.xyz * u_xlat16_9.xxx;
    u_xlat16_4.x = sqrt(u_xlat16_1);
    u_xlat16_12 = u_xlat16_1 + u_xlat16_1;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_1;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_12) * u_xlat16_5.xyz;
    u_xlat16_6.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_4.xzw = u_xlat16_4.xxx * u_xlat16_6.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_1) * u_xlat16_5.xyz;
    u_xlat16_5.xyz = vec3(u_xlat16_12) * _ShadowColor.xyz + u_xlat16_5.xyz;
    u_xlatb0.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_6.x = (u_xlatb0.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb0.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb0.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb0.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb0.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb0.z) ? float(1.0) : float(0.0);
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xzw * u_xlat16_7.xyz + u_xlat16_5.xyz;
    u_xlat16_0 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_4.xyz = u_xlat16_0.xyz * u_xlat16_4.xyz + (-u_xlat16_0.xyz);
    u_xlat16_4.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_4.xyz + u_xlat16_0.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * _Color.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * vs_INTERP1.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xyz * _Color.xyz + (-u_xlat16_5.xyz);
    u_xlat16_4.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_5.xyz;
    SV_Target0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_4.xyz;
    u_xlat16_0.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_1 = (-u_xlat16_0.w) + u_xlat16_0.x;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_0.w;
    u_xlat16_9.x = vs_INTERP1.w + -1.0;
    u_xlat16_9.x = _VC_AlphaOnOff * u_xlat16_9.x + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_9.x;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    SV_Target0.w = u_xlat16_1 * _BakeAlpha;
    return;
}

#endif


// ===== program 3: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec4 u_xlat16_0;
bvec3 u_xlatb0;
mediump float u_xlat16_1;
vec3 u_xlat2;
vec3 u_xlat3;
mediump vec4 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_9;
mediump float u_xlat16_12;
float u_xlat24;
bool u_xlatb24;
void main()
{
    u_xlat0.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlatb24 = unity_OrthoParams.w==0.0;
    u_xlat16_1 = (u_xlatb24) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat2.xyz = vec3(u_xlat16_1) * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat16_1 = (u_xlatb24) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat16_9.x = (u_xlatb24) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vec3(u_xlat16_1) + u_xlat2.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_9.xxx + u_xlat0.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlat24 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat24 = sqrt(u_xlat24);
    u_xlat24 = float(1.0) / u_xlat24;
    u_xlat2.xyz = vec3(u_xlat24) * vs_INTERP3.xyz;
    u_xlat3.x = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat3.y = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat3.z = dot(u_xlat2.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_1 = dot(_MainLightPosition.xyz, u_xlat2.xyz);
    u_xlat16_1 = u_xlat16_1 * 0.5 + 0.5;
    u_xlat24 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat3.xyz;
    u_xlat24 = dot((-u_xlat0.xyz), u_xlat2.xyz);
    u_xlat24 = u_xlat24 + u_xlat24;
    u_xlat0.xyz = u_xlat2.xyz * (-vec3(u_xlat24)) + (-u_xlat0.xyz);
    u_xlat16_0 = textureLod(unity_SpecCube0, u_xlat0.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_0.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_0.xyz * u_xlat16_9.xxx;
    u_xlat16_4.x = sqrt(u_xlat16_1);
    u_xlat16_12 = u_xlat16_1 + u_xlat16_1;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_1;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_12) * u_xlat16_5.xyz;
    u_xlat16_6.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_4.xzw = u_xlat16_4.xxx * u_xlat16_6.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_1) * u_xlat16_5.xyz;
    u_xlat16_5.xyz = vec3(u_xlat16_12) * _ShadowColor.xyz + u_xlat16_5.xyz;
    u_xlatb0.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_6.x = (u_xlatb0.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb0.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb0.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb0.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb0.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb0.z) ? float(1.0) : float(0.0);
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xzw * u_xlat16_7.xyz + u_xlat16_5.xyz;
    u_xlat16_0 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_4.xyz = u_xlat16_0.xyz * u_xlat16_4.xyz + (-u_xlat16_0.xyz);
    u_xlat16_4.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_4.xyz + u_xlat16_0.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * _Color.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * vs_INTERP1.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xyz * _Color.xyz + (-u_xlat16_5.xyz);
    u_xlat16_4.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_5.xyz;
    SV_Target0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_4.xyz;
    u_xlat16_0.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_1 = (-u_xlat16_0.w) + u_xlat16_0.x;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_0.w;
    u_xlat16_9.x = vs_INTERP1.w + -1.0;
    u_xlat16_9.x = _VC_AlphaOnOff * u_xlat16_9.x + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_9.x;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    SV_Target0.w = u_xlat16_1 * _BakeAlpha;
    return;
}

#endif


// ===== program 4: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
out highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
mediump float u_xlat16_0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
vec3 u_xlat4;
mediump vec4 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_8;
mediump vec3 u_xlat16_9;
mediump float u_xlat16_14;
mediump float u_xlat16_18;
float u_xlat28;
bool u_xlatb28;
void main()
{
    u_xlat16_0 = vs_INTERP1.w + -1.0;
    u_xlat16_0 = _VC_AlphaOnOff * u_xlat16_0 + 1.0;
    u_xlat16_1.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_9.x = u_xlat16_1.x + (-u_xlat16_2.w);
    u_xlat16_9.x = _BaseA0_AlphaR1 * u_xlat16_9.x + u_xlat16_2.w;
    u_xlat16_0 = u_xlat16_9.x * u_xlat16_0;
    u_xlat16_0 = u_xlat16_0 * _Color.w;
    u_xlat16_9.x = u_xlat16_0 * _BakeAlpha;
    u_xlat16_0 = _BakeAlpha * u_xlat16_0 + -0.5;
    u_xlat16_18 = dFdx(u_xlat16_9.x);
    u_xlat16_9.x = dFdy(u_xlat16_9.x);
    u_xlat16_9.x = abs(u_xlat16_9.x) + abs(u_xlat16_18);
    u_xlat16_18 = (-u_xlat16_9.x) * 0.5 + u_xlat16_0;
    u_xlat16_9.x = max(u_xlat16_9.x, 9.99999975e-05);
    u_xlat16_9.x = u_xlat16_18 / u_xlat16_9.x;
    u_xlat16_9.x = u_xlat16_9.x + 1.0;
    u_xlat16_9.x = clamp(u_xlat16_9.x, 0.0, 1.0);
    u_xlat16_18 = u_xlat16_9.x + -9.99999975e-05;
    u_xlatb1.x = _AlphaToMaskAvailable!=0.0;
    u_xlat16_0 = (u_xlatb1.x) ? u_xlat16_18 : u_xlat16_0;
    SV_Target0.w = (u_xlatb1.x) ? u_xlat16_9.x : 1.0;
    u_xlatb1.x = u_xlat16_0<0.0;
    if(u_xlatb1.x){discard;}
    u_xlat1.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlatb28 = unity_OrthoParams.w==0.0;
    u_xlat16_0 = (u_xlatb28) ? u_xlat1.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat3.xyz = vec3(u_xlat16_0) * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat16_0 = (u_xlatb28) ? u_xlat1.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat16_9.x = (u_xlatb28) ? u_xlat1.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vec3(u_xlat16_0) + u_xlat3.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_9.xxx + u_xlat1.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat28 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat28 = sqrt(u_xlat28);
    u_xlat28 = float(1.0) / u_xlat28;
    u_xlat3.xyz = vec3(u_xlat28) * vs_INTERP3.xyz;
    u_xlat4.x = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat4.y = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.z = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_0 = dot(_MainLightPosition.xyz, u_xlat3.xyz);
    u_xlat16_0 = u_xlat16_0 * 0.5 + 0.5;
    u_xlat28 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat3.xyz = vec3(u_xlat28) * u_xlat4.xyz;
    u_xlat28 = dot((-u_xlat1.xyz), u_xlat3.xyz);
    u_xlat28 = u_xlat28 + u_xlat28;
    u_xlat1.xyz = u_xlat3.xyz * (-vec3(u_xlat28)) + (-u_xlat1.xyz);
    u_xlat16_1 = textureLod(unity_SpecCube0, u_xlat1.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_1.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_1.xyz * u_xlat16_9.xxx;
    u_xlat16_5.x = sqrt(u_xlat16_0);
    u_xlat16_14 = u_xlat16_0 + u_xlat16_0;
    u_xlat16_0 = u_xlat16_0 * u_xlat16_0;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_14) * u_xlat16_6.xyz;
    u_xlat16_7.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_5.xzw = u_xlat16_5.xxx * u_xlat16_7.xyz + u_xlat16_6.xyz;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_0) * u_xlat16_6.xyz;
    u_xlat16_6.xyz = vec3(u_xlat16_14) * _ShadowColor.xyz + u_xlat16_6.xyz;
    u_xlatb1.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_7.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_7.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_7.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_8.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_8.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_8.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_6.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xzw * u_xlat16_8.xyz + u_xlat16_6.xyz;
    u_xlat16_5.xyz = u_xlat16_2.xyz * u_xlat16_5.xyz + (-u_xlat16_2.xyz);
    u_xlat16_5.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_5.xyz + u_xlat16_2.xyz;
    u_xlat16_6.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz * vs_INTERP1.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * _Color.xyz + (-u_xlat16_6.xyz);
    u_xlat16_5.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_5.xyz + u_xlat16_6.xyz;
    SV_Target0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_5.xyz;
    return;
}

#endif


// ===== program 5: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
mediump float u_xlat16_0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
vec3 u_xlat4;
mediump vec4 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_8;
mediump vec3 u_xlat16_9;
mediump float u_xlat16_14;
mediump float u_xlat16_18;
float u_xlat28;
bool u_xlatb28;
void main()
{
    u_xlat16_0 = vs_INTERP1.w + -1.0;
    u_xlat16_0 = _VC_AlphaOnOff * u_xlat16_0 + 1.0;
    u_xlat16_1.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_9.x = u_xlat16_1.x + (-u_xlat16_2.w);
    u_xlat16_9.x = _BaseA0_AlphaR1 * u_xlat16_9.x + u_xlat16_2.w;
    u_xlat16_0 = u_xlat16_9.x * u_xlat16_0;
    u_xlat16_0 = u_xlat16_0 * _Color.w;
    u_xlat16_9.x = u_xlat16_0 * _BakeAlpha;
    u_xlat16_0 = _BakeAlpha * u_xlat16_0 + -0.5;
    u_xlat16_18 = dFdx(u_xlat16_9.x);
    u_xlat16_9.x = dFdy(u_xlat16_9.x);
    u_xlat16_9.x = abs(u_xlat16_9.x) + abs(u_xlat16_18);
    u_xlat16_18 = (-u_xlat16_9.x) * 0.5 + u_xlat16_0;
    u_xlat16_9.x = max(u_xlat16_9.x, 9.99999975e-05);
    u_xlat16_9.x = u_xlat16_18 / u_xlat16_9.x;
    u_xlat16_9.x = u_xlat16_9.x + 1.0;
    u_xlat16_9.x = clamp(u_xlat16_9.x, 0.0, 1.0);
    u_xlat16_18 = u_xlat16_9.x + -9.99999975e-05;
    u_xlatb1.x = _AlphaToMaskAvailable!=0.0;
    u_xlat16_0 = (u_xlatb1.x) ? u_xlat16_18 : u_xlat16_0;
    SV_Target0.w = (u_xlatb1.x) ? u_xlat16_9.x : 1.0;
    u_xlatb1.x = u_xlat16_0<0.0;
    if(u_xlatb1.x){discard;}
    u_xlat1.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlatb28 = unity_OrthoParams.w==0.0;
    u_xlat16_0 = (u_xlatb28) ? u_xlat1.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat3.xyz = vec3(u_xlat16_0) * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat16_0 = (u_xlatb28) ? u_xlat1.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat16_9.x = (u_xlatb28) ? u_xlat1.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vec3(u_xlat16_0) + u_xlat3.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_9.xxx + u_xlat1.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat28 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat28 = sqrt(u_xlat28);
    u_xlat28 = float(1.0) / u_xlat28;
    u_xlat3.xyz = vec3(u_xlat28) * vs_INTERP3.xyz;
    u_xlat4.x = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat4.y = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.z = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_0 = dot(_MainLightPosition.xyz, u_xlat3.xyz);
    u_xlat16_0 = u_xlat16_0 * 0.5 + 0.5;
    u_xlat28 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat3.xyz = vec3(u_xlat28) * u_xlat4.xyz;
    u_xlat28 = dot((-u_xlat1.xyz), u_xlat3.xyz);
    u_xlat28 = u_xlat28 + u_xlat28;
    u_xlat1.xyz = u_xlat3.xyz * (-vec3(u_xlat28)) + (-u_xlat1.xyz);
    u_xlat16_1 = textureLod(unity_SpecCube0, u_xlat1.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_1.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_1.xyz * u_xlat16_9.xxx;
    u_xlat16_5.x = sqrt(u_xlat16_0);
    u_xlat16_14 = u_xlat16_0 + u_xlat16_0;
    u_xlat16_0 = u_xlat16_0 * u_xlat16_0;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_14) * u_xlat16_6.xyz;
    u_xlat16_7.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_5.xzw = u_xlat16_5.xxx * u_xlat16_7.xyz + u_xlat16_6.xyz;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_0) * u_xlat16_6.xyz;
    u_xlat16_6.xyz = vec3(u_xlat16_14) * _ShadowColor.xyz + u_xlat16_6.xyz;
    u_xlatb1.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_7.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_7.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_7.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_8.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_8.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_8.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_6.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xzw * u_xlat16_8.xyz + u_xlat16_6.xyz;
    u_xlat16_5.xyz = u_xlat16_2.xyz * u_xlat16_5.xyz + (-u_xlat16_2.xyz);
    u_xlat16_5.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_5.xyz + u_xlat16_2.xyz;
    u_xlat16_6.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz * vs_INTERP1.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * _Color.xyz + (-u_xlat16_6.xyz);
    u_xlat16_5.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_5.xyz + u_xlat16_6.xyz;
    SV_Target0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_5.xyz;
    return;
}

#endif


// ===== program 6: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
out highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
mediump float u_xlat16_0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
vec3 u_xlat4;
mediump vec4 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_8;
mediump vec3 u_xlat16_9;
mediump float u_xlat16_14;
mediump float u_xlat16_18;
mediump float u_xlat16_27;
float u_xlat28;
bool u_xlatb28;
void main()
{
    u_xlat16_0 = vs_INTERP1.w + -1.0;
    u_xlat16_0 = _VC_AlphaOnOff * u_xlat16_0 + 1.0;
    u_xlat16_1.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_9.x = u_xlat16_1.x + (-u_xlat16_2.w);
    u_xlat16_9.x = _BaseA0_AlphaR1 * u_xlat16_9.x + u_xlat16_2.w;
    u_xlat16_0 = u_xlat16_9.x * u_xlat16_0;
    u_xlat16_0 = u_xlat16_0 * _Color.w;
    u_xlat16_9.x = u_xlat16_0 * _BakeAlpha;
    u_xlat16_0 = _BakeAlpha * u_xlat16_0 + -0.5;
    u_xlat16_18 = dFdx(u_xlat16_9.x);
    u_xlat16_27 = dFdy(u_xlat16_9.x);
    u_xlat16_18 = abs(u_xlat16_27) + abs(u_xlat16_18);
    u_xlat16_27 = (-u_xlat16_18) * 0.5 + u_xlat16_0;
    u_xlat16_18 = max(u_xlat16_18, 9.99999975e-05);
    u_xlat16_18 = u_xlat16_27 / u_xlat16_18;
    u_xlat16_18 = u_xlat16_18 + 1.0;
    u_xlat16_18 = clamp(u_xlat16_18, 0.0, 1.0);
    u_xlat16_27 = u_xlat16_18 + -9.99999975e-05;
    u_xlatb1.x = _AlphaToMaskAvailable!=0.0;
    u_xlat16_0 = (u_xlatb1.x) ? u_xlat16_27 : u_xlat16_0;
    SV_Target0.w = (u_xlatb1.x) ? u_xlat16_18 : u_xlat16_9.x;
    u_xlatb1.x = u_xlat16_0<0.0;
    if(u_xlatb1.x){discard;}
    u_xlat1.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlatb28 = unity_OrthoParams.w==0.0;
    u_xlat16_0 = (u_xlatb28) ? u_xlat1.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat3.xyz = vec3(u_xlat16_0) * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat16_0 = (u_xlatb28) ? u_xlat1.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat16_9.x = (u_xlatb28) ? u_xlat1.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vec3(u_xlat16_0) + u_xlat3.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_9.xxx + u_xlat1.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat28 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat28 = sqrt(u_xlat28);
    u_xlat28 = float(1.0) / u_xlat28;
    u_xlat3.xyz = vec3(u_xlat28) * vs_INTERP3.xyz;
    u_xlat4.x = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat4.y = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.z = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_0 = dot(_MainLightPosition.xyz, u_xlat3.xyz);
    u_xlat16_0 = u_xlat16_0 * 0.5 + 0.5;
    u_xlat28 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat3.xyz = vec3(u_xlat28) * u_xlat4.xyz;
    u_xlat28 = dot((-u_xlat1.xyz), u_xlat3.xyz);
    u_xlat28 = u_xlat28 + u_xlat28;
    u_xlat1.xyz = u_xlat3.xyz * (-vec3(u_xlat28)) + (-u_xlat1.xyz);
    u_xlat16_1 = textureLod(unity_SpecCube0, u_xlat1.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_1.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_1.xyz * u_xlat16_9.xxx;
    u_xlat16_5.x = sqrt(u_xlat16_0);
    u_xlat16_14 = u_xlat16_0 + u_xlat16_0;
    u_xlat16_0 = u_xlat16_0 * u_xlat16_0;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_14) * u_xlat16_6.xyz;
    u_xlat16_7.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_5.xzw = u_xlat16_5.xxx * u_xlat16_7.xyz + u_xlat16_6.xyz;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_0) * u_xlat16_6.xyz;
    u_xlat16_6.xyz = vec3(u_xlat16_14) * _ShadowColor.xyz + u_xlat16_6.xyz;
    u_xlatb1.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_7.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_7.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_7.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_8.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_8.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_8.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_6.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xzw * u_xlat16_8.xyz + u_xlat16_6.xyz;
    u_xlat16_5.xyz = u_xlat16_2.xyz * u_xlat16_5.xyz + (-u_xlat16_2.xyz);
    u_xlat16_5.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_5.xyz + u_xlat16_2.xyz;
    u_xlat16_6.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz * vs_INTERP1.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * _Color.xyz + (-u_xlat16_6.xyz);
    u_xlat16_5.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_5.xyz + u_xlat16_6.xyz;
    SV_Target0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_5.xyz;
    return;
}

#endif


// ===== program 7: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
mediump float u_xlat16_0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
vec3 u_xlat4;
mediump vec4 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_8;
mediump vec3 u_xlat16_9;
mediump float u_xlat16_14;
mediump float u_xlat16_18;
mediump float u_xlat16_27;
float u_xlat28;
bool u_xlatb28;
void main()
{
    u_xlat16_0 = vs_INTERP1.w + -1.0;
    u_xlat16_0 = _VC_AlphaOnOff * u_xlat16_0 + 1.0;
    u_xlat16_1.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_9.x = u_xlat16_1.x + (-u_xlat16_2.w);
    u_xlat16_9.x = _BaseA0_AlphaR1 * u_xlat16_9.x + u_xlat16_2.w;
    u_xlat16_0 = u_xlat16_9.x * u_xlat16_0;
    u_xlat16_0 = u_xlat16_0 * _Color.w;
    u_xlat16_9.x = u_xlat16_0 * _BakeAlpha;
    u_xlat16_0 = _BakeAlpha * u_xlat16_0 + -0.5;
    u_xlat16_18 = dFdx(u_xlat16_9.x);
    u_xlat16_27 = dFdy(u_xlat16_9.x);
    u_xlat16_18 = abs(u_xlat16_27) + abs(u_xlat16_18);
    u_xlat16_27 = (-u_xlat16_18) * 0.5 + u_xlat16_0;
    u_xlat16_18 = max(u_xlat16_18, 9.99999975e-05);
    u_xlat16_18 = u_xlat16_27 / u_xlat16_18;
    u_xlat16_18 = u_xlat16_18 + 1.0;
    u_xlat16_18 = clamp(u_xlat16_18, 0.0, 1.0);
    u_xlat16_27 = u_xlat16_18 + -9.99999975e-05;
    u_xlatb1.x = _AlphaToMaskAvailable!=0.0;
    u_xlat16_0 = (u_xlatb1.x) ? u_xlat16_27 : u_xlat16_0;
    SV_Target0.w = (u_xlatb1.x) ? u_xlat16_18 : u_xlat16_9.x;
    u_xlatb1.x = u_xlat16_0<0.0;
    if(u_xlatb1.x){discard;}
    u_xlat1.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlatb28 = unity_OrthoParams.w==0.0;
    u_xlat16_0 = (u_xlatb28) ? u_xlat1.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat3.xyz = vec3(u_xlat16_0) * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat16_0 = (u_xlatb28) ? u_xlat1.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat16_9.x = (u_xlatb28) ? u_xlat1.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vec3(u_xlat16_0) + u_xlat3.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_9.xxx + u_xlat1.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat28 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat28 = sqrt(u_xlat28);
    u_xlat28 = float(1.0) / u_xlat28;
    u_xlat3.xyz = vec3(u_xlat28) * vs_INTERP3.xyz;
    u_xlat4.x = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat4.y = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.z = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_0 = dot(_MainLightPosition.xyz, u_xlat3.xyz);
    u_xlat16_0 = u_xlat16_0 * 0.5 + 0.5;
    u_xlat28 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat3.xyz = vec3(u_xlat28) * u_xlat4.xyz;
    u_xlat28 = dot((-u_xlat1.xyz), u_xlat3.xyz);
    u_xlat28 = u_xlat28 + u_xlat28;
    u_xlat1.xyz = u_xlat3.xyz * (-vec3(u_xlat28)) + (-u_xlat1.xyz);
    u_xlat16_1 = textureLod(unity_SpecCube0, u_xlat1.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_1.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_1.xyz * u_xlat16_9.xxx;
    u_xlat16_5.x = sqrt(u_xlat16_0);
    u_xlat16_14 = u_xlat16_0 + u_xlat16_0;
    u_xlat16_0 = u_xlat16_0 * u_xlat16_0;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_14) * u_xlat16_6.xyz;
    u_xlat16_7.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_5.xzw = u_xlat16_5.xxx * u_xlat16_7.xyz + u_xlat16_6.xyz;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_0) * u_xlat16_6.xyz;
    u_xlat16_6.xyz = vec3(u_xlat16_14) * _ShadowColor.xyz + u_xlat16_6.xyz;
    u_xlatb1.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_7.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_7.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_7.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_8.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_8.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_8.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_6.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xzw * u_xlat16_8.xyz + u_xlat16_6.xyz;
    u_xlat16_5.xyz = u_xlat16_2.xyz * u_xlat16_5.xyz + (-u_xlat16_2.xyz);
    u_xlat16_5.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_5.xyz + u_xlat16_2.xyz;
    u_xlat16_6.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz * vs_INTERP1.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * _Color.xyz + (-u_xlat16_6.xyz);
    u_xlat16_5.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_5.xyz + u_xlat16_6.xyz;
    SV_Target0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_5.xyz;
    return;
}

#endif


// ===== program 8: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
out highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
bvec3 u_xlatb0;
vec3 u_xlat1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec4 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
float u_xlat8;
mediump vec3 u_xlat16_10;
mediump float u_xlat16_12;
float u_xlat24;
bool u_xlatb24;
void main()
{
    u_xlat0.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlatb24 = unity_OrthoParams.w==0.0;
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat1.y = hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat1.z = hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat16_2.xyz = (bool(u_xlatb24)) ? u_xlat0.xyz : u_xlat1.xyz;
    u_xlat0.xyz = u_xlat16_2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * u_xlat16_2.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_2.zzz + u_xlat0.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlat24 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat24 = sqrt(u_xlat24);
    u_xlat24 = float(1.0) / u_xlat24;
    u_xlat1.xyz = vec3(u_xlat24) * vs_INTERP3.xyz;
    u_xlat3.x = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat3.y = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat3.z = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_2.x = dot(_MainLightPosition.xyz, u_xlat1.xyz);
    u_xlat16_2.x = u_xlat16_2.x * 0.5 + 0.5;
    u_xlat24 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat1.xyz = vec3(u_xlat24) * u_xlat3.xyz;
    u_xlat24 = dot((-u_xlat0.xyz), u_xlat1.xyz);
    u_xlat24 = u_xlat24 + u_xlat24;
    u_xlat0.xyz = u_xlat1.xyz * (-vec3(u_xlat24)) + (-u_xlat0.xyz);
    u_xlat16_0 = textureLod(unity_SpecCube0, u_xlat0.xyz, 0.0);
    u_xlat16_10.x = u_xlat16_0.w + -1.0;
    u_xlat16_10.x = unity_SpecCube0_HDR.w * u_xlat16_10.x + 1.0;
    u_xlat16_10.x = max(u_xlat16_10.x, 0.0);
    u_xlat16_10.x = log2(u_xlat16_10.x);
    u_xlat16_10.x = u_xlat16_10.x * unity_SpecCube0_HDR.y;
    u_xlat16_10.x = exp2(u_xlat16_10.x);
    u_xlat16_10.x = u_xlat16_10.x * unity_SpecCube0_HDR.x;
    u_xlat16_10.xyz = u_xlat16_0.xyz * u_xlat16_10.xxx;
    u_xlat16_4.x = sqrt(u_xlat16_2.x);
    u_xlat16_12 = u_xlat16_2.x + u_xlat16_2.x;
    u_xlat16_2.x = u_xlat16_2.x * u_xlat16_2.x;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_12) * u_xlat16_5.xyz;
    u_xlat16_6.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_4.xzw = u_xlat16_4.xxx * u_xlat16_6.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = u_xlat16_2.xxx * u_xlat16_5.xyz;
    u_xlat16_5.xyz = vec3(u_xlat16_12) * _ShadowColor.xyz + u_xlat16_5.xyz;
    u_xlatb0.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_6.x = (u_xlatb0.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb0.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb0.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb0.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb0.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb0.z) ? float(1.0) : float(0.0);
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xzw * u_xlat16_7.xyz + u_xlat16_5.xyz;
    u_xlat16_0.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = u_xlat16_0.xyz * u_xlat16_4.xyz + (-u_xlat16_0.xyz);
    u_xlat16_4.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_4.xyz + u_xlat16_0.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * _Color.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * vs_INTERP1.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xyz * _Color.xyz + (-u_xlat16_5.xyz);
    u_xlat16_4.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_5.xyz;
    u_xlat16_2.xyz = u_xlat16_10.xyz * _Reflection_ProbeColor.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_2.xyz) + unity_FogColor.xyz;
    u_xlat0.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat8 = u_xlat0.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat0.x + u_xlat8;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat0.z + u_xlat0.x;
    u_xlat0.x = u_xlat0.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0.x = (-u_xlat0.x) + (-_ProjectionParams.y);
    u_xlat0.x = max(u_xlat0.x, 0.0);
    u_xlat0.x = u_xlat0.x * unity_FogParams.z + unity_FogParams.w;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_4.xyz = u_xlat16_4.xyz * u_xlat0.xxx;
    SV_Target0.xyz = vec3(vec3(_Fog_Intensity, _Fog_Intensity, _Fog_Intensity)) * u_xlat16_4.xyz + u_xlat16_2.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 9: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
bvec3 u_xlatb0;
vec3 u_xlat1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec4 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
float u_xlat8;
mediump vec3 u_xlat16_10;
mediump float u_xlat16_12;
float u_xlat24;
bool u_xlatb24;
void main()
{
    u_xlat0.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlatb24 = unity_OrthoParams.w==0.0;
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat1.y = hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat1.z = hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat16_2.xyz = (bool(u_xlatb24)) ? u_xlat0.xyz : u_xlat1.xyz;
    u_xlat0.xyz = u_xlat16_2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * u_xlat16_2.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_2.zzz + u_xlat0.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlat24 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat24 = sqrt(u_xlat24);
    u_xlat24 = float(1.0) / u_xlat24;
    u_xlat1.xyz = vec3(u_xlat24) * vs_INTERP3.xyz;
    u_xlat3.x = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat3.y = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat3.z = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_2.x = dot(_MainLightPosition.xyz, u_xlat1.xyz);
    u_xlat16_2.x = u_xlat16_2.x * 0.5 + 0.5;
    u_xlat24 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat1.xyz = vec3(u_xlat24) * u_xlat3.xyz;
    u_xlat24 = dot((-u_xlat0.xyz), u_xlat1.xyz);
    u_xlat24 = u_xlat24 + u_xlat24;
    u_xlat0.xyz = u_xlat1.xyz * (-vec3(u_xlat24)) + (-u_xlat0.xyz);
    u_xlat16_0 = textureLod(unity_SpecCube0, u_xlat0.xyz, 0.0);
    u_xlat16_10.x = u_xlat16_0.w + -1.0;
    u_xlat16_10.x = unity_SpecCube0_HDR.w * u_xlat16_10.x + 1.0;
    u_xlat16_10.x = max(u_xlat16_10.x, 0.0);
    u_xlat16_10.x = log2(u_xlat16_10.x);
    u_xlat16_10.x = u_xlat16_10.x * unity_SpecCube0_HDR.y;
    u_xlat16_10.x = exp2(u_xlat16_10.x);
    u_xlat16_10.x = u_xlat16_10.x * unity_SpecCube0_HDR.x;
    u_xlat16_10.xyz = u_xlat16_0.xyz * u_xlat16_10.xxx;
    u_xlat16_4.x = sqrt(u_xlat16_2.x);
    u_xlat16_12 = u_xlat16_2.x + u_xlat16_2.x;
    u_xlat16_2.x = u_xlat16_2.x * u_xlat16_2.x;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_12) * u_xlat16_5.xyz;
    u_xlat16_6.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_4.xzw = u_xlat16_4.xxx * u_xlat16_6.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = u_xlat16_2.xxx * u_xlat16_5.xyz;
    u_xlat16_5.xyz = vec3(u_xlat16_12) * _ShadowColor.xyz + u_xlat16_5.xyz;
    u_xlatb0.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_6.x = (u_xlatb0.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb0.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb0.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb0.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb0.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb0.z) ? float(1.0) : float(0.0);
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xzw * u_xlat16_7.xyz + u_xlat16_5.xyz;
    u_xlat16_0.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = u_xlat16_0.xyz * u_xlat16_4.xyz + (-u_xlat16_0.xyz);
    u_xlat16_4.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_4.xyz + u_xlat16_0.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * _Color.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * vs_INTERP1.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xyz * _Color.xyz + (-u_xlat16_5.xyz);
    u_xlat16_4.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_5.xyz;
    u_xlat16_2.xyz = u_xlat16_10.xyz * _Reflection_ProbeColor.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_2.xyz) + unity_FogColor.xyz;
    u_xlat0.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat8 = u_xlat0.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat0.x + u_xlat8;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat0.z + u_xlat0.x;
    u_xlat0.x = u_xlat0.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0.x = (-u_xlat0.x) + (-_ProjectionParams.y);
    u_xlat0.x = max(u_xlat0.x, 0.0);
    u_xlat0.x = u_xlat0.x * unity_FogParams.z + unity_FogParams.w;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_4.xyz = u_xlat16_4.xyz * u_xlat0.xxx;
    SV_Target0.xyz = vec3(vec3(_Fog_Intensity, _Fog_Intensity, _Fog_Intensity)) * u_xlat16_4.xyz + u_xlat16_2.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 10: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
out highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump float u_xlat16_0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
bool u_xlatb1;
vec3 u_xlat2;
mediump vec3 u_xlat16_3;
mediump vec4 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
vec3 u_xlat8;
bvec3 u_xlatb8;
mediump vec3 u_xlat16_11;
mediump float u_xlat16_12;
float u_xlat25;
void main()
{
    u_xlat0.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat8.x = u_xlat0.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat0.x + u_xlat8.x;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat0.z + u_xlat0.x;
    u_xlat0.x = u_xlat0.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0.x = (-u_xlat0.x) + (-_ProjectionParams.y);
    u_xlat0.x = max(u_xlat0.x, 0.0);
    u_xlat0.x = u_xlat0.x * unity_FogParams.z + unity_FogParams.w;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat8.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat1.x = dot(u_xlat8.xyz, u_xlat8.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat1.xxx;
    u_xlatb1 = unity_OrthoParams.w==0.0;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat2.y = hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat2.z = hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat16_3.xyz = (bool(u_xlatb1)) ? u_xlat8.xyz : u_xlat2.xyz;
    u_xlat8.xyz = u_xlat16_3.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat8.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * u_xlat16_3.xxx + u_xlat8.xyz;
    u_xlat8.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_3.zzz + u_xlat8.xyz;
    u_xlat1.x = dot(u_xlat8.xyz, u_xlat8.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat1.xxx;
    u_xlat1.x = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat1.x = sqrt(u_xlat1.x);
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat1.xyz = u_xlat1.xxx * vs_INTERP3.xyz;
    u_xlat2.x = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat2.y = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat2.z = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_3.x = dot(_MainLightPosition.xyz, u_xlat1.xyz);
    u_xlat16_3.x = u_xlat16_3.x * 0.5 + 0.5;
    u_xlat1.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * u_xlat2.xyz;
    u_xlat25 = dot((-u_xlat8.xyz), u_xlat1.xyz);
    u_xlat25 = u_xlat25 + u_xlat25;
    u_xlat8.xyz = u_xlat1.xyz * (-vec3(u_xlat25)) + (-u_xlat8.xyz);
    u_xlat16_1 = textureLod(unity_SpecCube0, u_xlat8.xyz, 0.0);
    u_xlat16_11.x = u_xlat16_1.w + -1.0;
    u_xlat16_11.x = unity_SpecCube0_HDR.w * u_xlat16_11.x + 1.0;
    u_xlat16_11.x = max(u_xlat16_11.x, 0.0);
    u_xlat16_11.x = log2(u_xlat16_11.x);
    u_xlat16_11.x = u_xlat16_11.x * unity_SpecCube0_HDR.y;
    u_xlat16_11.x = exp2(u_xlat16_11.x);
    u_xlat16_11.x = u_xlat16_11.x * unity_SpecCube0_HDR.x;
    u_xlat16_11.xyz = u_xlat16_1.xyz * u_xlat16_11.xxx;
    u_xlat16_4.x = sqrt(u_xlat16_3.x);
    u_xlat16_12 = u_xlat16_3.x + u_xlat16_3.x;
    u_xlat16_3.x = u_xlat16_3.x * u_xlat16_3.x;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_12) * u_xlat16_5.xyz;
    u_xlat16_6.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_4.xzw = u_xlat16_4.xxx * u_xlat16_6.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = u_xlat16_3.xxx * u_xlat16_5.xyz;
    u_xlat16_5.xyz = vec3(u_xlat16_12) * _ShadowColor.xyz + u_xlat16_5.xyz;
    u_xlatb8.xyz = greaterThanEqual(_ShadowColor.xyzz, vec4(0.5, 0.5, 0.5, 0.5)).xyz;
    u_xlat16_6.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb8.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb8.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb8.z) ? float(1.0) : float(0.0);
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xzw * u_xlat16_7.xyz + u_xlat16_5.xyz;
    u_xlat16_1 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_4.xyz = u_xlat16_1.xyz * u_xlat16_4.xyz + (-u_xlat16_1.xyz);
    u_xlat16_4.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_4.xyz + u_xlat16_1.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * _Color.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * vs_INTERP1.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xyz * _Color.xyz + (-u_xlat16_5.xyz);
    u_xlat16_4.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_5.xyz;
    u_xlat16_3.xyz = u_xlat16_11.xyz * _Reflection_ProbeColor.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + unity_FogColor.xyz;
    u_xlat16_4.xyz = u_xlat0.xxx * u_xlat16_4.xyz;
    SV_Target0.xyz = vec3(vec3(_Fog_Intensity, _Fog_Intensity, _Fog_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_3.x = (-u_xlat16_1.w) + u_xlat16_0;
    u_xlat16_3.x = _BaseA0_AlphaR1 * u_xlat16_3.x + u_xlat16_1.w;
    u_xlat16_11.x = vs_INTERP1.w + -1.0;
    u_xlat16_11.x = _VC_AlphaOnOff * u_xlat16_11.x + 1.0;
    u_xlat16_3.x = u_xlat16_3.x * u_xlat16_11.x;
    u_xlat16_3.x = u_xlat16_3.x * _Color.w;
    SV_Target0.w = u_xlat16_3.x * _BakeAlpha;
    return;
}

#endif


// ===== program 11: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump float u_xlat16_0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
bool u_xlatb1;
vec3 u_xlat2;
mediump vec3 u_xlat16_3;
mediump vec4 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
vec3 u_xlat8;
bvec3 u_xlatb8;
mediump vec3 u_xlat16_11;
mediump float u_xlat16_12;
float u_xlat25;
void main()
{
    u_xlat0.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat8.x = u_xlat0.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat0.x + u_xlat8.x;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat0.z + u_xlat0.x;
    u_xlat0.x = u_xlat0.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0.x = (-u_xlat0.x) + (-_ProjectionParams.y);
    u_xlat0.x = max(u_xlat0.x, 0.0);
    u_xlat0.x = u_xlat0.x * unity_FogParams.z + unity_FogParams.w;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat8.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat1.x = dot(u_xlat8.xyz, u_xlat8.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat1.xxx;
    u_xlatb1 = unity_OrthoParams.w==0.0;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat2.y = hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat2.z = hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat16_3.xyz = (bool(u_xlatb1)) ? u_xlat8.xyz : u_xlat2.xyz;
    u_xlat8.xyz = u_xlat16_3.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat8.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * u_xlat16_3.xxx + u_xlat8.xyz;
    u_xlat8.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_3.zzz + u_xlat8.xyz;
    u_xlat1.x = dot(u_xlat8.xyz, u_xlat8.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat1.xxx;
    u_xlat1.x = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat1.x = sqrt(u_xlat1.x);
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat1.xyz = u_xlat1.xxx * vs_INTERP3.xyz;
    u_xlat2.x = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat2.y = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat2.z = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_3.x = dot(_MainLightPosition.xyz, u_xlat1.xyz);
    u_xlat16_3.x = u_xlat16_3.x * 0.5 + 0.5;
    u_xlat1.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * u_xlat2.xyz;
    u_xlat25 = dot((-u_xlat8.xyz), u_xlat1.xyz);
    u_xlat25 = u_xlat25 + u_xlat25;
    u_xlat8.xyz = u_xlat1.xyz * (-vec3(u_xlat25)) + (-u_xlat8.xyz);
    u_xlat16_1 = textureLod(unity_SpecCube0, u_xlat8.xyz, 0.0);
    u_xlat16_11.x = u_xlat16_1.w + -1.0;
    u_xlat16_11.x = unity_SpecCube0_HDR.w * u_xlat16_11.x + 1.0;
    u_xlat16_11.x = max(u_xlat16_11.x, 0.0);
    u_xlat16_11.x = log2(u_xlat16_11.x);
    u_xlat16_11.x = u_xlat16_11.x * unity_SpecCube0_HDR.y;
    u_xlat16_11.x = exp2(u_xlat16_11.x);
    u_xlat16_11.x = u_xlat16_11.x * unity_SpecCube0_HDR.x;
    u_xlat16_11.xyz = u_xlat16_1.xyz * u_xlat16_11.xxx;
    u_xlat16_4.x = sqrt(u_xlat16_3.x);
    u_xlat16_12 = u_xlat16_3.x + u_xlat16_3.x;
    u_xlat16_3.x = u_xlat16_3.x * u_xlat16_3.x;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = vec3(u_xlat16_12) * u_xlat16_5.xyz;
    u_xlat16_6.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_4.xzw = u_xlat16_4.xxx * u_xlat16_6.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_5.xyz = u_xlat16_3.xxx * u_xlat16_5.xyz;
    u_xlat16_5.xyz = vec3(u_xlat16_12) * _ShadowColor.xyz + u_xlat16_5.xyz;
    u_xlatb8.xyz = greaterThanEqual(_ShadowColor.xyzz, vec4(0.5, 0.5, 0.5, 0.5)).xyz;
    u_xlat16_6.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb8.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb8.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb8.z) ? float(1.0) : float(0.0);
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xzw * u_xlat16_7.xyz + u_xlat16_5.xyz;
    u_xlat16_1 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_4.xyz = u_xlat16_1.xyz * u_xlat16_4.xyz + (-u_xlat16_1.xyz);
    u_xlat16_4.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_4.xyz + u_xlat16_1.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * _Color.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * vs_INTERP1.xyz;
    u_xlat16_4.xyz = u_xlat16_4.xyz * _Color.xyz + (-u_xlat16_5.xyz);
    u_xlat16_4.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_5.xyz;
    u_xlat16_3.xyz = u_xlat16_11.xyz * _Reflection_ProbeColor.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + unity_FogColor.xyz;
    u_xlat16_4.xyz = u_xlat0.xxx * u_xlat16_4.xyz;
    SV_Target0.xyz = vec3(vec3(_Fog_Intensity, _Fog_Intensity, _Fog_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_3.x = (-u_xlat16_1.w) + u_xlat16_0;
    u_xlat16_3.x = _BaseA0_AlphaR1 * u_xlat16_3.x + u_xlat16_1.w;
    u_xlat16_11.x = vs_INTERP1.w + -1.0;
    u_xlat16_11.x = _VC_AlphaOnOff * u_xlat16_11.x + 1.0;
    u_xlat16_3.x = u_xlat16_3.x * u_xlat16_11.x;
    u_xlat16_3.x = u_xlat16_3.x * _Color.w;
    SV_Target0.w = u_xlat16_3.x * _BakeAlpha;
    return;
}

#endif


// ===== program 12: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
out highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec3 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
vec3 u_xlat2;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
vec3 u_xlat4;
mediump vec4 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_8;
mediump vec3 u_xlat16_9;
float u_xlat10;
mediump float u_xlat16_14;
mediump float u_xlat16_18;
float u_xlat28;
bool u_xlatb28;
void main()
{
    u_xlat16_0.x = vs_INTERP1.w + -1.0;
    u_xlat16_0.x = _VC_AlphaOnOff * u_xlat16_0.x + 1.0;
    u_xlat16_1.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_9.x = u_xlat16_1.x + (-u_xlat16_2.w);
    u_xlat16_9.x = _BaseA0_AlphaR1 * u_xlat16_9.x + u_xlat16_2.w;
    u_xlat16_0.x = u_xlat16_9.x * u_xlat16_0.x;
    u_xlat16_0.x = u_xlat16_0.x * _Color.w;
    u_xlat16_9.x = u_xlat16_0.x * _BakeAlpha;
    u_xlat16_0.x = _BakeAlpha * u_xlat16_0.x + -0.5;
    u_xlat16_18 = dFdx(u_xlat16_9.x);
    u_xlat16_9.x = dFdy(u_xlat16_9.x);
    u_xlat16_9.x = abs(u_xlat16_9.x) + abs(u_xlat16_18);
    u_xlat16_18 = (-u_xlat16_9.x) * 0.5 + u_xlat16_0.x;
    u_xlat16_9.x = max(u_xlat16_9.x, 9.99999975e-05);
    u_xlat16_9.x = u_xlat16_18 / u_xlat16_9.x;
    u_xlat16_9.x = u_xlat16_9.x + 1.0;
    u_xlat16_9.x = clamp(u_xlat16_9.x, 0.0, 1.0);
    u_xlat16_18 = u_xlat16_9.x + -9.99999975e-05;
    u_xlatb1.x = _AlphaToMaskAvailable!=0.0;
    u_xlat16_0.x = (u_xlatb1.x) ? u_xlat16_18 : u_xlat16_0.x;
    SV_Target0.w = (u_xlatb1.x) ? u_xlat16_9.x : 1.0;
    u_xlatb1.x = u_xlat16_0.x<0.0;
    if(u_xlatb1.x){discard;}
    u_xlat1.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlatb28 = unity_OrthoParams.w==0.0;
    u_xlat3.x = hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat3.y = hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat3.z = hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat16_0.xyz = (bool(u_xlatb28)) ? u_xlat1.xyz : u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * u_xlat16_0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_0.zzz + u_xlat1.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat28 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat28 = sqrt(u_xlat28);
    u_xlat28 = float(1.0) / u_xlat28;
    u_xlat3.xyz = vec3(u_xlat28) * vs_INTERP3.xyz;
    u_xlat4.x = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat4.y = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.z = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_0.x = dot(_MainLightPosition.xyz, u_xlat3.xyz);
    u_xlat16_0.x = u_xlat16_0.x * 0.5 + 0.5;
    u_xlat28 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat3.xyz = vec3(u_xlat28) * u_xlat4.xyz;
    u_xlat28 = dot((-u_xlat1.xyz), u_xlat3.xyz);
    u_xlat28 = u_xlat28 + u_xlat28;
    u_xlat1.xyz = u_xlat3.xyz * (-vec3(u_xlat28)) + (-u_xlat1.xyz);
    u_xlat16_1 = textureLod(unity_SpecCube0, u_xlat1.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_1.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_1.xyz * u_xlat16_9.xxx;
    u_xlat16_5.x = sqrt(u_xlat16_0.x);
    u_xlat16_14 = u_xlat16_0.x + u_xlat16_0.x;
    u_xlat16_0.x = u_xlat16_0.x * u_xlat16_0.x;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_14) * u_xlat16_6.xyz;
    u_xlat16_7.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_5.xzw = u_xlat16_5.xxx * u_xlat16_7.xyz + u_xlat16_6.xyz;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = u_xlat16_0.xxx * u_xlat16_6.xyz;
    u_xlat16_6.xyz = vec3(u_xlat16_14) * _ShadowColor.xyz + u_xlat16_6.xyz;
    u_xlatb1.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_7.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_7.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_7.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_8.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_8.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_8.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_6.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xzw * u_xlat16_8.xyz + u_xlat16_6.xyz;
    u_xlat16_5.xyz = u_xlat16_2.xyz * u_xlat16_5.xyz + (-u_xlat16_2.xyz);
    u_xlat16_5.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_5.xyz + u_xlat16_2.xyz;
    u_xlat16_6.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz * vs_INTERP1.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * _Color.xyz + (-u_xlat16_6.xyz);
    u_xlat16_5.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_5.xyz + u_xlat16_6.xyz;
    u_xlat16_0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-u_xlat16_0.xyz) + unity_FogColor.xyz;
    u_xlat1.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat2.xyz = u_xlat1.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat1.xxx + u_xlat2.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat1.zzz + u_xlat1.xyw;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat10 = u_xlat1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat1.x + u_xlat10;
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat1.z + u_xlat1.x;
    u_xlat1.x = u_xlat1.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat1.x = (-u_xlat1.x) + (-_ProjectionParams.y);
    u_xlat1.x = max(u_xlat1.x, 0.0);
    u_xlat1.x = u_xlat1.x * unity_FogParams.z + unity_FogParams.w;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat1.xxx;
    SV_Target0.xyz = vec3(vec3(_Fog_Intensity, _Fog_Intensity, _Fog_Intensity)) * u_xlat16_5.xyz + u_xlat16_0.xyz;
    return;
}

#endif


// ===== program 13: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec3 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
vec3 u_xlat2;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
vec3 u_xlat4;
mediump vec4 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_8;
mediump vec3 u_xlat16_9;
float u_xlat10;
mediump float u_xlat16_14;
mediump float u_xlat16_18;
float u_xlat28;
bool u_xlatb28;
void main()
{
    u_xlat16_0.x = vs_INTERP1.w + -1.0;
    u_xlat16_0.x = _VC_AlphaOnOff * u_xlat16_0.x + 1.0;
    u_xlat16_1.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_9.x = u_xlat16_1.x + (-u_xlat16_2.w);
    u_xlat16_9.x = _BaseA0_AlphaR1 * u_xlat16_9.x + u_xlat16_2.w;
    u_xlat16_0.x = u_xlat16_9.x * u_xlat16_0.x;
    u_xlat16_0.x = u_xlat16_0.x * _Color.w;
    u_xlat16_9.x = u_xlat16_0.x * _BakeAlpha;
    u_xlat16_0.x = _BakeAlpha * u_xlat16_0.x + -0.5;
    u_xlat16_18 = dFdx(u_xlat16_9.x);
    u_xlat16_9.x = dFdy(u_xlat16_9.x);
    u_xlat16_9.x = abs(u_xlat16_9.x) + abs(u_xlat16_18);
    u_xlat16_18 = (-u_xlat16_9.x) * 0.5 + u_xlat16_0.x;
    u_xlat16_9.x = max(u_xlat16_9.x, 9.99999975e-05);
    u_xlat16_9.x = u_xlat16_18 / u_xlat16_9.x;
    u_xlat16_9.x = u_xlat16_9.x + 1.0;
    u_xlat16_9.x = clamp(u_xlat16_9.x, 0.0, 1.0);
    u_xlat16_18 = u_xlat16_9.x + -9.99999975e-05;
    u_xlatb1.x = _AlphaToMaskAvailable!=0.0;
    u_xlat16_0.x = (u_xlatb1.x) ? u_xlat16_18 : u_xlat16_0.x;
    SV_Target0.w = (u_xlatb1.x) ? u_xlat16_9.x : 1.0;
    u_xlatb1.x = u_xlat16_0.x<0.0;
    if(u_xlatb1.x){discard;}
    u_xlat1.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlatb28 = unity_OrthoParams.w==0.0;
    u_xlat3.x = hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat3.y = hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat3.z = hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat16_0.xyz = (bool(u_xlatb28)) ? u_xlat1.xyz : u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * u_xlat16_0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_0.zzz + u_xlat1.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat28 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat28 = sqrt(u_xlat28);
    u_xlat28 = float(1.0) / u_xlat28;
    u_xlat3.xyz = vec3(u_xlat28) * vs_INTERP3.xyz;
    u_xlat4.x = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat4.y = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.z = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_0.x = dot(_MainLightPosition.xyz, u_xlat3.xyz);
    u_xlat16_0.x = u_xlat16_0.x * 0.5 + 0.5;
    u_xlat28 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat3.xyz = vec3(u_xlat28) * u_xlat4.xyz;
    u_xlat28 = dot((-u_xlat1.xyz), u_xlat3.xyz);
    u_xlat28 = u_xlat28 + u_xlat28;
    u_xlat1.xyz = u_xlat3.xyz * (-vec3(u_xlat28)) + (-u_xlat1.xyz);
    u_xlat16_1 = textureLod(unity_SpecCube0, u_xlat1.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_1.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_1.xyz * u_xlat16_9.xxx;
    u_xlat16_5.x = sqrt(u_xlat16_0.x);
    u_xlat16_14 = u_xlat16_0.x + u_xlat16_0.x;
    u_xlat16_0.x = u_xlat16_0.x * u_xlat16_0.x;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_14) * u_xlat16_6.xyz;
    u_xlat16_7.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_5.xzw = u_xlat16_5.xxx * u_xlat16_7.xyz + u_xlat16_6.xyz;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = u_xlat16_0.xxx * u_xlat16_6.xyz;
    u_xlat16_6.xyz = vec3(u_xlat16_14) * _ShadowColor.xyz + u_xlat16_6.xyz;
    u_xlatb1.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_7.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_7.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_7.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_8.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_8.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_8.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_6.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xzw * u_xlat16_8.xyz + u_xlat16_6.xyz;
    u_xlat16_5.xyz = u_xlat16_2.xyz * u_xlat16_5.xyz + (-u_xlat16_2.xyz);
    u_xlat16_5.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_5.xyz + u_xlat16_2.xyz;
    u_xlat16_6.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz * vs_INTERP1.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * _Color.xyz + (-u_xlat16_6.xyz);
    u_xlat16_5.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_5.xyz + u_xlat16_6.xyz;
    u_xlat16_0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-u_xlat16_0.xyz) + unity_FogColor.xyz;
    u_xlat1.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat2.xyz = u_xlat1.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat1.xxx + u_xlat2.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat1.zzz + u_xlat1.xyw;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat10 = u_xlat1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat1.x + u_xlat10;
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat1.z + u_xlat1.x;
    u_xlat1.x = u_xlat1.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat1.x = (-u_xlat1.x) + (-_ProjectionParams.y);
    u_xlat1.x = max(u_xlat1.x, 0.0);
    u_xlat1.x = u_xlat1.x * unity_FogParams.z + unity_FogParams.w;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat1.xxx;
    SV_Target0.xyz = vec3(vec3(_Fog_Intensity, _Fog_Intensity, _Fog_Intensity)) * u_xlat16_5.xyz + u_xlat16_0.xyz;
    return;
}

#endif


// ===== program 14: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
out highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec3 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
vec3 u_xlat2;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
vec3 u_xlat4;
mediump vec4 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_8;
mediump vec3 u_xlat16_9;
float u_xlat10;
mediump float u_xlat16_14;
mediump float u_xlat16_18;
mediump float u_xlat16_27;
float u_xlat28;
bool u_xlatb28;
void main()
{
    u_xlat16_0.x = vs_INTERP1.w + -1.0;
    u_xlat16_0.x = _VC_AlphaOnOff * u_xlat16_0.x + 1.0;
    u_xlat16_1.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_9.x = u_xlat16_1.x + (-u_xlat16_2.w);
    u_xlat16_9.x = _BaseA0_AlphaR1 * u_xlat16_9.x + u_xlat16_2.w;
    u_xlat16_0.x = u_xlat16_9.x * u_xlat16_0.x;
    u_xlat16_0.x = u_xlat16_0.x * _Color.w;
    u_xlat16_9.x = u_xlat16_0.x * _BakeAlpha;
    u_xlat16_0.x = _BakeAlpha * u_xlat16_0.x + -0.5;
    u_xlat16_18 = dFdx(u_xlat16_9.x);
    u_xlat16_27 = dFdy(u_xlat16_9.x);
    u_xlat16_18 = abs(u_xlat16_27) + abs(u_xlat16_18);
    u_xlat16_27 = (-u_xlat16_18) * 0.5 + u_xlat16_0.x;
    u_xlat16_18 = max(u_xlat16_18, 9.99999975e-05);
    u_xlat16_18 = u_xlat16_27 / u_xlat16_18;
    u_xlat16_18 = u_xlat16_18 + 1.0;
    u_xlat16_18 = clamp(u_xlat16_18, 0.0, 1.0);
    u_xlat16_27 = u_xlat16_18 + -9.99999975e-05;
    u_xlatb1.x = _AlphaToMaskAvailable!=0.0;
    u_xlat16_0.x = (u_xlatb1.x) ? u_xlat16_27 : u_xlat16_0.x;
    SV_Target0.w = (u_xlatb1.x) ? u_xlat16_18 : u_xlat16_9.x;
    u_xlatb1.x = u_xlat16_0.x<0.0;
    if(u_xlatb1.x){discard;}
    u_xlat1.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlatb28 = unity_OrthoParams.w==0.0;
    u_xlat3.x = hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat3.y = hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat3.z = hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat16_0.xyz = (bool(u_xlatb28)) ? u_xlat1.xyz : u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * u_xlat16_0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_0.zzz + u_xlat1.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat28 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat28 = sqrt(u_xlat28);
    u_xlat28 = float(1.0) / u_xlat28;
    u_xlat3.xyz = vec3(u_xlat28) * vs_INTERP3.xyz;
    u_xlat4.x = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat4.y = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.z = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_0.x = dot(_MainLightPosition.xyz, u_xlat3.xyz);
    u_xlat16_0.x = u_xlat16_0.x * 0.5 + 0.5;
    u_xlat28 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat3.xyz = vec3(u_xlat28) * u_xlat4.xyz;
    u_xlat28 = dot((-u_xlat1.xyz), u_xlat3.xyz);
    u_xlat28 = u_xlat28 + u_xlat28;
    u_xlat1.xyz = u_xlat3.xyz * (-vec3(u_xlat28)) + (-u_xlat1.xyz);
    u_xlat16_1 = textureLod(unity_SpecCube0, u_xlat1.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_1.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_1.xyz * u_xlat16_9.xxx;
    u_xlat16_5.x = sqrt(u_xlat16_0.x);
    u_xlat16_14 = u_xlat16_0.x + u_xlat16_0.x;
    u_xlat16_0.x = u_xlat16_0.x * u_xlat16_0.x;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_14) * u_xlat16_6.xyz;
    u_xlat16_7.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_5.xzw = u_xlat16_5.xxx * u_xlat16_7.xyz + u_xlat16_6.xyz;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = u_xlat16_0.xxx * u_xlat16_6.xyz;
    u_xlat16_6.xyz = vec3(u_xlat16_14) * _ShadowColor.xyz + u_xlat16_6.xyz;
    u_xlatb1.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_7.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_7.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_7.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_8.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_8.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_8.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_6.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xzw * u_xlat16_8.xyz + u_xlat16_6.xyz;
    u_xlat16_5.xyz = u_xlat16_2.xyz * u_xlat16_5.xyz + (-u_xlat16_2.xyz);
    u_xlat16_5.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_5.xyz + u_xlat16_2.xyz;
    u_xlat16_6.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz * vs_INTERP1.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * _Color.xyz + (-u_xlat16_6.xyz);
    u_xlat16_5.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_5.xyz + u_xlat16_6.xyz;
    u_xlat16_0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-u_xlat16_0.xyz) + unity_FogColor.xyz;
    u_xlat1.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat2.xyz = u_xlat1.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat1.xxx + u_xlat2.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat1.zzz + u_xlat1.xyw;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat10 = u_xlat1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat1.x + u_xlat10;
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat1.z + u_xlat1.x;
    u_xlat1.x = u_xlat1.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat1.x = (-u_xlat1.x) + (-_ProjectionParams.y);
    u_xlat1.x = max(u_xlat1.x, 0.0);
    u_xlat1.x = u_xlat1.x * unity_FogParams.z + unity_FogParams.w;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat1.xxx;
    SV_Target0.xyz = vec3(vec3(_Fog_Intensity, _Fog_Intensity, _Fog_Intensity)) * u_xlat16_5.xyz + u_xlat16_0.xyz;
    return;
}

#endif


// ===== program 15: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es
#ifdef GL_EXT_shader_texture_lod
#extension GL_EXT_shader_texture_lod : enable
#endif

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4                unity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Shadow_Intensity;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4                _Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump samplerCube unity_SpecCube0;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
in highp  vec3 vs_INTERP3;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec3 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
vec3 u_xlat2;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
vec3 u_xlat4;
mediump vec4 u_xlat16_5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
mediump vec3 u_xlat16_8;
mediump vec3 u_xlat16_9;
float u_xlat10;
mediump float u_xlat16_14;
mediump float u_xlat16_18;
mediump float u_xlat16_27;
float u_xlat28;
bool u_xlatb28;
void main()
{
    u_xlat16_0.x = vs_INTERP1.w + -1.0;
    u_xlat16_0.x = _VC_AlphaOnOff * u_xlat16_0.x + 1.0;
    u_xlat16_1.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_9.x = u_xlat16_1.x + (-u_xlat16_2.w);
    u_xlat16_9.x = _BaseA0_AlphaR1 * u_xlat16_9.x + u_xlat16_2.w;
    u_xlat16_0.x = u_xlat16_9.x * u_xlat16_0.x;
    u_xlat16_0.x = u_xlat16_0.x * _Color.w;
    u_xlat16_9.x = u_xlat16_0.x * _BakeAlpha;
    u_xlat16_0.x = _BakeAlpha * u_xlat16_0.x + -0.5;
    u_xlat16_18 = dFdx(u_xlat16_9.x);
    u_xlat16_27 = dFdy(u_xlat16_9.x);
    u_xlat16_18 = abs(u_xlat16_27) + abs(u_xlat16_18);
    u_xlat16_27 = (-u_xlat16_18) * 0.5 + u_xlat16_0.x;
    u_xlat16_18 = max(u_xlat16_18, 9.99999975e-05);
    u_xlat16_18 = u_xlat16_27 / u_xlat16_18;
    u_xlat16_18 = u_xlat16_18 + 1.0;
    u_xlat16_18 = clamp(u_xlat16_18, 0.0, 1.0);
    u_xlat16_27 = u_xlat16_18 + -9.99999975e-05;
    u_xlatb1.x = _AlphaToMaskAvailable!=0.0;
    u_xlat16_0.x = (u_xlatb1.x) ? u_xlat16_27 : u_xlat16_0.x;
    SV_Target0.w = (u_xlatb1.x) ? u_xlat16_18 : u_xlat16_9.x;
    u_xlatb1.x = u_xlat16_0.x<0.0;
    if(u_xlatb1.x){discard;}
    u_xlat1.xyz = (-vs_INTERP2.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlatb28 = unity_OrthoParams.w==0.0;
    u_xlat3.x = hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat3.y = hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat3.z = hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat16_0.xyz = (bool(u_xlatb28)) ? u_xlat1.xyz : u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * u_xlat16_0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * u_xlat16_0.zzz + u_xlat1.xyz;
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat28 = dot(vs_INTERP3.xyz, vs_INTERP3.xyz);
    u_xlat28 = sqrt(u_xlat28);
    u_xlat28 = float(1.0) / u_xlat28;
    u_xlat3.xyz = vec3(u_xlat28) * vs_INTERP3.xyz;
    u_xlat4.x = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat4.y = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.z = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_0.x = dot(_MainLightPosition.xyz, u_xlat3.xyz);
    u_xlat16_0.x = u_xlat16_0.x * 0.5 + 0.5;
    u_xlat28 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat3.xyz = vec3(u_xlat28) * u_xlat4.xyz;
    u_xlat28 = dot((-u_xlat1.xyz), u_xlat3.xyz);
    u_xlat28 = u_xlat28 + u_xlat28;
    u_xlat1.xyz = u_xlat3.xyz * (-vec3(u_xlat28)) + (-u_xlat1.xyz);
    u_xlat16_1 = textureLod(unity_SpecCube0, u_xlat1.xyz, 0.0);
    u_xlat16_9.x = u_xlat16_1.w + -1.0;
    u_xlat16_9.x = unity_SpecCube0_HDR.w * u_xlat16_9.x + 1.0;
    u_xlat16_9.x = max(u_xlat16_9.x, 0.0);
    u_xlat16_9.x = log2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.y;
    u_xlat16_9.x = exp2(u_xlat16_9.x);
    u_xlat16_9.x = u_xlat16_9.x * unity_SpecCube0_HDR.x;
    u_xlat16_9.xyz = u_xlat16_1.xyz * u_xlat16_9.xxx;
    u_xlat16_5.x = sqrt(u_xlat16_0.x);
    u_xlat16_14 = u_xlat16_0.x + u_xlat16_0.x;
    u_xlat16_0.x = u_xlat16_0.x * u_xlat16_0.x;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = vec3(u_xlat16_14) * u_xlat16_6.xyz;
    u_xlat16_7.xyz = _ShadowColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat16_5.xzw = u_xlat16_5.xxx * u_xlat16_7.xyz + u_xlat16_6.xyz;
    u_xlat16_6.xyz = (-_ShadowColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat16_6.xyz = u_xlat16_0.xxx * u_xlat16_6.xyz;
    u_xlat16_6.xyz = vec3(u_xlat16_14) * _ShadowColor.xyz + u_xlat16_6.xyz;
    u_xlatb1.xyz = greaterThanEqual(_ShadowColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat16_7.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_7.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_7.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_8.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_8.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_8.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_6.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xzw * u_xlat16_8.xyz + u_xlat16_6.xyz;
    u_xlat16_5.xyz = u_xlat16_2.xyz * u_xlat16_5.xyz + (-u_xlat16_2.xyz);
    u_xlat16_5.xyz = vec3(vec3(_Shadow_Intensity, _Shadow_Intensity, _Shadow_Intensity)) * u_xlat16_5.xyz + u_xlat16_2.xyz;
    u_xlat16_6.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz * vs_INTERP1.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz * _Color.xyz + (-u_xlat16_6.xyz);
    u_xlat16_5.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_5.xyz + u_xlat16_6.xyz;
    u_xlat16_0.xyz = u_xlat16_9.xyz * _Reflection_ProbeColor.xyz + u_xlat16_5.xyz;
    u_xlat16_5.xyz = (-u_xlat16_0.xyz) + unity_FogColor.xyz;
    u_xlat1.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat2.xyz = u_xlat1.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat1.xxx + u_xlat2.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat1.zzz + u_xlat1.xyw;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat10 = u_xlat1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat1.x + u_xlat10;
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat1.z + u_xlat1.x;
    u_xlat1.x = u_xlat1.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat1.x = (-u_xlat1.x) + (-_ProjectionParams.y);
    u_xlat1.x = max(u_xlat1.x, 0.0);
    u_xlat1.x = u_xlat1.x * unity_FogParams.z + unity_FogParams.w;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat16_5.xyz = u_xlat16_5.xyz * u_xlat1.xxx;
    SV_Target0.xyz = vec3(vec3(_Fog_Intensity, _Fog_Intensity, _Fog_Intensity)) * u_xlat16_5.xyz + u_xlat16_0.xyz;
    return;
}

#endif


// ===== program 16: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
highp vec4 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 17: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 18: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Shadow_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
mediump float u_xlat16_3;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_3 = vs_INTERP1.w + -1.0;
    u_xlat16_3 = _VC_AlphaOnOff * u_xlat16_3 + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_3;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    u_xlat16_1 = _BakeAlpha * u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 19: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Shadow_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
mediump float u_xlat16_3;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_3 = vs_INTERP1.w + -1.0;
    u_xlat16_3 = _VC_AlphaOnOff * u_xlat16_3 + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_3;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    u_xlat16_1 = _BakeAlpha * u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 20: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 hlslcc_mtx4x4_PrevViewProjMatrix[4];
uniform 	vec4 hlslcc_mtx4x4_NonJitteredViewProjMatrix[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
in highp vec3 in_TEXCOORD4;
out highp vec3 vs_CLIP_POSITION_NO_JITTER0;
out highp vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
highp vec4 vs_INTERP0;
highp vec4 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
bool u_xlatb9;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlatb9 = unity_MotionVectorsParams.y!=0.0;
    if(u_xlatb9){
        u_xlatb9 = unity_MotionVectorsParams.x==1.0;
        u_xlat1.xyz = (bool(u_xlatb9)) ? in_TEXCOORD4.xyz : in_POSITION0.xyz;
        u_xlat2.xyz = u_xlat0.yyy * hlslcc_mtx4x4_NonJitteredViewProjMatrix[1].xyw;
        u_xlat0.xyw = hlslcc_mtx4x4_NonJitteredViewProjMatrix[0].xyw * u_xlat0.xxx + u_xlat2.xyz;
        u_xlat0.xyz = hlslcc_mtx4x4_NonJitteredViewProjMatrix[2].xyw * u_xlat0.zzz + u_xlat0.xyw;
        vs_CLIP_POSITION_NO_JITTER0.xyz = u_xlat0.xyz + hlslcc_mtx4x4_NonJitteredViewProjMatrix[3].xyw;
        u_xlat0 = u_xlat1.yyyy * hlslcc_mtx4x4unity_MatrixPreviousM[1];
        u_xlat0 = hlslcc_mtx4x4unity_MatrixPreviousM[0] * u_xlat1.xxxx + u_xlat0;
        u_xlat0 = hlslcc_mtx4x4unity_MatrixPreviousM[2] * u_xlat1.zzzz + u_xlat0;
        u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixPreviousM[3];
        u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4_PrevViewProjMatrix[1].xyw;
        u_xlat1.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[0].xyw * u_xlat0.xxx + u_xlat1.xyz;
        u_xlat0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[2].xyw * u_xlat0.zzz + u_xlat1.xyz;
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[3].xyw * u_xlat0.www + u_xlat0.xyz;
    } else {
        vs_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
    }
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
float u_xlat2;
bool u_xlatb2;
void main()
{
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat2 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat2) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb2 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb2) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 21: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
float u_xlat2;
bool u_xlatb2;
void main()
{
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat2 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat2) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb2 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb2) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 22: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 hlslcc_mtx4x4_PrevViewProjMatrix[4];
uniform 	vec4 hlslcc_mtx4x4_NonJitteredViewProjMatrix[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
in highp vec3 in_TEXCOORD4;
out highp vec3 vs_CLIP_POSITION_NO_JITTER0;
out highp vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
bool u_xlatb9;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlatb9 = unity_MotionVectorsParams.y!=0.0;
    if(u_xlatb9){
        u_xlatb9 = unity_MotionVectorsParams.x==1.0;
        u_xlat1.xyz = (bool(u_xlatb9)) ? in_TEXCOORD4.xyz : in_POSITION0.xyz;
        u_xlat2.xyz = u_xlat0.yyy * hlslcc_mtx4x4_NonJitteredViewProjMatrix[1].xyw;
        u_xlat0.xyw = hlslcc_mtx4x4_NonJitteredViewProjMatrix[0].xyw * u_xlat0.xxx + u_xlat2.xyz;
        u_xlat0.xyz = hlslcc_mtx4x4_NonJitteredViewProjMatrix[2].xyw * u_xlat0.zzz + u_xlat0.xyw;
        vs_CLIP_POSITION_NO_JITTER0.xyz = u_xlat0.xyz + hlslcc_mtx4x4_NonJitteredViewProjMatrix[3].xyw;
        u_xlat0 = u_xlat1.yyyy * hlslcc_mtx4x4unity_MatrixPreviousM[1];
        u_xlat0 = hlslcc_mtx4x4unity_MatrixPreviousM[0] * u_xlat1.xxxx + u_xlat0;
        u_xlat0 = hlslcc_mtx4x4unity_MatrixPreviousM[2] * u_xlat1.zzzz + u_xlat0;
        u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixPreviousM[3];
        u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4_PrevViewProjMatrix[1].xyw;
        u_xlat1.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[0].xyw * u_xlat0.xxx + u_xlat1.xyz;
        u_xlat0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[2].xyw * u_xlat0.zzz + u_xlat1.xyz;
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[3].xyw * u_xlat0.www + u_xlat0.xyz;
    } else {
        vs_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
    }
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Shadow_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
mediump float u_xlat16_3;
float u_xlat4;
bool u_xlatb4;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_3 = vs_INTERP1.w + -1.0;
    u_xlat16_3 = _VC_AlphaOnOff * u_xlat16_3 + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_3;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    u_xlat16_1 = _BakeAlpha * u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat4 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat4) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb4 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb4) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 23: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Shadow_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
mediump float u_xlat16_3;
float u_xlat4;
bool u_xlatb4;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_3 = vs_INTERP1.w + -1.0;
    u_xlat16_3 = _VC_AlphaOnOff * u_xlat16_3 + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_3;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    u_xlat16_1 = _BakeAlpha * u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat4 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat4) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb4 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb4) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 24: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP2.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
in highp  vec3 vs_INTERP2;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_INTERP2.xyz, vs_INTERP2.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP2.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 25: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
in highp  vec3 vs_INTERP2;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_INTERP2.xyz, vs_INTERP2.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP2.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 26: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP2.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Shadow_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
mediump float u_xlat16_3;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_3 = vs_INTERP1.w + -1.0;
    u_xlat16_3 = _VC_AlphaOnOff * u_xlat16_3 + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_3;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    u_xlat16_1 = _BakeAlpha * u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.x = dot(vs_INTERP2.xyz, vs_INTERP2.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP2.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 27: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Shadow_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
mediump float u_xlat16_3;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_3 = vs_INTERP1.w + -1.0;
    u_xlat16_3 = _VC_AlphaOnOff * u_xlat16_3 + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_3;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    u_xlat16_1 = _BakeAlpha * u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.x = dot(vs_INTERP2.xyz, vs_INTERP2.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP2.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 28: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightDirection;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
highp vec4 vs_INTERP1;
highp vec3 vs_INTERP2;
vec4 u_xlat0;
vec4 u_xlat1;
mediump float u_xlat16_2;
float u_xlat4;
bool u_xlatb4;
float u_xlat9;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat0.xyz = vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z) * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat9 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat9 = max(u_xlat9, 1.17549435e-38);
    u_xlat9 = inversesqrt(u_xlat9);
    u_xlat1.xyz = vec3(u_xlat9) * u_xlat1.xyz;
    u_xlat9 = dot(vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z), u_xlat1.xyz);
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat9 = (-u_xlat9) + 1.0;
    u_xlat9 = u_xlat9 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat1.xyz * vec3(u_xlat9) + u_xlat0.xyz;
    vs_INTERP2.xyz = u_xlat1.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat4 = roundEven(_ShadowBias.z);
    u_xlatb4 = u_xlat4==1.0;
    u_xlat16_2 = (u_xlatb4) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_2 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 29: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 30: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightDirection;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
highp vec3 vs_INTERP2;
vec4 u_xlat0;
vec4 u_xlat1;
mediump float u_xlat16_2;
float u_xlat4;
bool u_xlatb4;
float u_xlat9;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat0.xyz = vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z) * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat9 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat9 = max(u_xlat9, 1.17549435e-38);
    u_xlat9 = inversesqrt(u_xlat9);
    u_xlat1.xyz = vec3(u_xlat9) * u_xlat1.xyz;
    u_xlat9 = dot(vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z), u_xlat1.xyz);
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat9 = (-u_xlat9) + 1.0;
    u_xlat9 = u_xlat9 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat1.xyz * vec3(u_xlat9) + u_xlat0.xyz;
    vs_INTERP2.xyz = u_xlat1.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat4 = roundEven(_ShadowBias.z);
    u_xlatb4 = u_xlat4==1.0;
    u_xlat16_2 = (u_xlatb4) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_2 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Shadow_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
mediump float u_xlat16_3;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_3 = vs_INTERP1.w + -1.0;
    u_xlat16_3 = _VC_AlphaOnOff * u_xlat16_3 + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_3;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    u_xlat16_1 = _BakeAlpha * u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 31: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Shadow_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
mediump float u_xlat16_3;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_3 = vs_INTERP1.w + -1.0;
    u_xlat16_3 = _VC_AlphaOnOff * u_xlat16_3 + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_3;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    u_xlat16_1 = _BakeAlpha * u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 32: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightPosition;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
highp vec4 vs_INTERP1;
highp vec3 vs_INTERP2;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat5;
bool u_xlatb5;
float u_xlat12;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + _LightPosition.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat1.xyz = vec3(u_xlat12) * u_xlat1.xyz;
    u_xlat0.xyz = u_xlat1.xyz * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat2.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat2.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat2.xyz = vec3(u_xlat12) * u_xlat2.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat2.xyz);
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat12 = (-u_xlat12) + 1.0;
    u_xlat12 = u_xlat12 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat2.xyz * vec3(u_xlat12) + u_xlat0.xyz;
    vs_INTERP2.xyz = u_xlat2.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat5 = roundEven(_ShadowBias.z);
    u_xlatb5 = u_xlat5==1.0;
    u_xlat16_3 = (u_xlatb5) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_3 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 33: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightPosition;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
highp vec3 vs_INTERP2;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat5;
bool u_xlatb5;
float u_xlat12;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + _LightPosition.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat1.xyz = vec3(u_xlat12) * u_xlat1.xyz;
    u_xlat0.xyz = u_xlat1.xyz * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat2.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat2.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat2.xyz = vec3(u_xlat12) * u_xlat2.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat2.xyz);
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat12 = (-u_xlat12) + 1.0;
    u_xlat12 = u_xlat12 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat2.xyz * vec3(u_xlat12) + u_xlat0.xyz;
    vs_INTERP2.xyz = u_xlat2.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat5 = roundEven(_ShadowBias.z);
    u_xlatb5 = u_xlat5==1.0;
    u_xlat16_3 = (u_xlatb5) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_3 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Shadow_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
mediump float u_xlat16_3;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_3 = vs_INTERP1.w + -1.0;
    u_xlat16_3 = _VC_AlphaOnOff * u_xlat16_3 + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_3;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    u_xlat16_1 = _BakeAlpha * u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 34: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShadowColor;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Shadow_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _VC_AlphaOnOff;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Reflection_ProbeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
mediump float u_xlat16_3;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_3 = vs_INTERP1.w + -1.0;
    u_xlat16_3 = _VC_AlphaOnOff * u_xlat16_3 + 1.0;
    u_xlat16_1 = u_xlat16_1 * u_xlat16_3;
    u_xlat16_1 = u_xlat16_1 * _Color.w;
    u_xlat16_1 = _BakeAlpha * u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif

