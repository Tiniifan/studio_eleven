// Soccer/Effect/T3ThresholdF (Shader path ID 2057163477493348147, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex0_ST;
	UNITY_UNIFORM float                _ColorTex0_R;
	UNITY_UNIFORM int                _ColorTex0Index;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex1_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorTex1_R;
	UNITY_UNIFORM int Xhlslcc_UnusedX_ColorTex1Index;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex2_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorTex2_R;
	UNITY_UNIFORM int Xhlslcc_UnusedX_ColorTex2Index;
	UNITY_UNIFORM vec4                _MaskTex0_ST;
	UNITY_UNIFORM float                _MaskTex0_R;
	UNITY_UNIFORM int                _MaskTex0Index;
	UNITY_UNIFORM vec4                _MaskTex1_ST;
	UNITY_UNIFORM float                _MaskTex1_R;
	UNITY_UNIFORM int                _MaskTex1Index;
	UNITY_UNIFORM vec4                _FlowTex_ST;
	UNITY_UNIFORM float                _FlowTex_R;
	UNITY_UNIFORM int                _FlowTexIndex;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM vec4                _SecondColor;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorRGIndex;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorBAIndex;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM float                _VertexAlphaThresholdMode;
	UNITY_UNIFORM float                _ColorBorderMin0;
	UNITY_UNIFORM float                _ColorBorderMax0;
	UNITY_UNIFORM float                _ColorBorderMin1;
	UNITY_UNIFORM float                _ColorBorderMax1;
	UNITY_UNIFORM float                _ColorBorderMin2;
	UNITY_UNIFORM float                _ColorBorderMax2;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParThresholdMode;
	UNITY_UNIFORM float                _M0PatternX;
	UNITY_UNIFORM float                _M0PatternY;
	UNITY_UNIFORM float                _M0PatternFadeAnime;
	UNITY_UNIFORM float                _M0FlowScale0;
	UNITY_UNIFORM float                _M0FlowScale2;
	UNITY_UNIFORM float                _FlowScale0;
	UNITY_UNIFORM float                _FlowScale1;
	UNITY_UNIFORM float                _FlowScale2;
	UNITY_UNIFORM float                _ColorProjType;
	UNITY_UNIFORM float                _EdgeMaskWidth;
	UNITY_UNIFORM float                _EdgeMaskOffset;
	UNITY_UNIFORM float                _Luminance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec4 in_COLOR0;
in highp vec3 in_NORMAL0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
in highp vec2 in_TEXCOORD2;
in highp vec2 in_TEXCOORD3;
in highp vec2 in_TEXCOORD4;
in highp vec2 in_TEXCOORD5;
out highp vec4 vs_COLOR0;
out highp vec2 vs_TEXCOORD0;
out highp vec2 vs_TEXCOORD4;
out highp vec3 vs_TEXCOORD1;
out highp vec3 vs_TEXCOORD2;
out highp vec4 vs_TEXCOORD3;
out highp vec2 vs_TEXCOORD5;
out highp vec3 vs_TEXCOORD6;
vec3 u_xlat0;
int u_xlati0;
bvec2 u_xlatb0;
vec4 u_xlat1;
ivec2 u_xlati1;
uvec2 u_xlatu1;
vec4 u_xlat2;
uint u_xlatu2;
vec3 u_xlat3;
uint u_xlatu3;
bvec3 u_xlatb4;
vec3 u_xlat5;
mediump float u_xlat16_6;
float u_xlat7;
uint u_xlatu8;
uint u_xlatu9;
vec2 u_xlat14;
ivec2 u_xlati14;
uint u_xlatu14;
vec2 u_xlat15;
uint u_xlatu15;
vec2 u_xlat16;
uint u_xlatu16;
float u_xlat21;
int u_xlati21;
uint u_xlatu21;
uint u_xlatu22;
vec4 TempArray0[7];
void main()
{
    TempArray0[0].xy = in_TEXCOORD0.xy;
    TempArray0[1].xy = in_TEXCOORD1.xy;
    TempArray0[2].xy = in_TEXCOORD2.xy;
    TempArray0[3].xy = in_TEXCOORD3.xy;
    TempArray0[4].xy = in_TEXCOORD4.xy;
    TempArray0[5].xy = in_TEXCOORD5.xy;
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat1 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat1;
    u_xlat2.xyz = in_COLOR0.xyz * _Color.xyz;
    u_xlat3.xyz = max(u_xlat2.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat3.xyz = u_xlat3.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat3.xyz = log2(u_xlat3.xyz);
    u_xlat3.xyz = u_xlat3.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat3.xyz = exp2(u_xlat3.xyz);
    u_xlatb4.xyz = lessThan(u_xlat2.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    {
        vec4 hlslcc_movcTemp = u_xlat2;
        hlslcc_movcTemp.x = (u_xlatb4.x) ? u_xlat2.x : u_xlat3.x;
        hlslcc_movcTemp.y = (u_xlatb4.y) ? u_xlat2.y : u_xlat3.y;
        hlslcc_movcTemp.z = (u_xlatb4.z) ? u_xlat2.z : u_xlat3.z;
        u_xlat2 = hlslcc_movcTemp;
    }
    u_xlat3.xyz = max(in_COLOR0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat3.xyz = u_xlat3.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat3.xyz = log2(u_xlat3.xyz);
    u_xlat3.xyz = u_xlat3.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat3.xyz = exp2(u_xlat3.xyz);
    u_xlatb4.xyz = lessThan(in_COLOR0.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat5.xyz = in_COLOR0.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    {
        vec3 hlslcc_movcTemp = u_xlat3;
        hlslcc_movcTemp.x = (u_xlatb4.x) ? u_xlat5.x : u_xlat3.x;
        hlslcc_movcTemp.y = (u_xlatb4.y) ? u_xlat5.y : u_xlat3.y;
        hlslcc_movcTemp.z = (u_xlatb4.z) ? u_xlat5.z : u_xlat3.z;
        u_xlat3 = hlslcc_movcTemp;
    }
    u_xlat2.xyz = (-u_xlat3.xyz) * _Color.xyz + u_xlat2.xyz;
    u_xlat3.xyz = u_xlat3.xyz * _Color.xyz;
    u_xlat2.xyz = vec3(vec3(_IsGammaColor, _IsGammaColor, _IsGammaColor)) * u_xlat2.xyz + u_xlat3.xyz;
    u_xlat21 = _Luminance + 1.0;
    vs_COLOR0.xyz = vec3(u_xlat21) * u_xlat2.xyz;
    u_xlat21 = (-in_COLOR0.w) + 1.0;
    vs_COLOR0.w = _VertexAlphaThresholdMode * u_xlat21 + in_COLOR0.w;
    u_xlat21 = u_xlat1.y * _ProjectionParams.x;
    u_xlat2.w = u_xlat21 * 0.5;
    u_xlat2.xz = u_xlat1.xw * vec2(0.5, 0.5);
    u_xlat1.xy = u_xlat2.zz + u_xlat2.xw;
    u_xlat1.xy = u_xlat1.xy / u_xlat1.ww;
    u_xlati21 = _ColorTex0Index;
    u_xlat15.xy = TempArray0[u_xlati21].xy;
    u_xlat1.xy = (-u_xlat15.xy) + u_xlat1.xy;
    vs_TEXCOORD0.xy = vec2(_ColorProjType) * u_xlat1.xy + u_xlat15.xy;
    u_xlati21 = _MaskTex1Index;
    vs_TEXCOORD4.xy = TempArray0[u_xlati21].xy;
    u_xlat21 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat21 = inversesqrt(u_xlat21);
    u_xlat0.xyz = vec3(u_xlat21) * u_xlat0.xyz;
    u_xlat21 = dot(hlslcc_mtx4x4unity_ObjectToWorld[0].xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat1.x = sqrt(u_xlat21);
    u_xlat21 = dot(hlslcc_mtx4x4unity_ObjectToWorld[1].xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat1.y = sqrt(u_xlat21);
    u_xlat21 = dot(hlslcc_mtx4x4unity_ObjectToWorld[2].xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat1.z = sqrt(u_xlat21);
    u_xlat1.xyz = in_NORMAL0.xyz / u_xlat1.xyz;
    u_xlat2.xyz = u_xlat1.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat1.xxx + u_xlat2.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat1.zzz + u_xlat1.xyw;
    u_xlat0.x = dot(u_xlat1.xyz, u_xlat0.xyz);
    u_xlat7 = _EdgeMaskWidth + _EdgeMaskOffset;
    u_xlat7 = clamp(u_xlat7, 0.0, 1.0);
    u_xlat7 = float(1.0) / u_xlat7;
    u_xlat0.x = u_xlat7 * abs(u_xlat0.x);
    u_xlat0.x = min(u_xlat0.x, 1.0);
    u_xlat0.x = u_xlat0.x + (-_EdgeMaskOffset);
    u_xlat7 = (-_EdgeMaskOffset) + 1.0;
    u_xlat7 = float(1.0) / u_xlat7;
    u_xlat0.x = u_xlat7 * u_xlat0.x;
    u_xlat0.x = max(u_xlat0.x, 0.0);
    u_xlat7 = _ColorBorderMax2 * in_COLOR0.w + (-_ColorBorderMax2);
    u_xlat7 = _VertexAlphaThresholdMode * u_xlat7 + _ColorBorderMax2;
    u_xlat0.x = u_xlat0.x * u_xlat7;
    vs_TEXCOORD1.xyz = u_xlat0.xxx * _SecondColor.xyz;
    u_xlatb0.x = _M0PatternFadeAnime>=(-_M0PatternFadeAnime);
    u_xlat0.x = (u_xlatb0.x) ? 1.0 : -1.0;
    u_xlat7 = u_xlat0.x * _M0PatternFadeAnime;
    u_xlat7 = fract(u_xlat7);
    vs_TEXCOORD2.x = u_xlat7 * u_xlat0.x;
    vs_TEXCOORD2.y = _M0FlowScale0;
    vs_TEXCOORD2.z = _M0FlowScale2;
    u_xlatb0.xy = greaterThanEqual(_MaskTex0_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = (u_xlatb0.x) ? float(1.0) : float(-1.0);
    u_xlat0.y = (u_xlatb0.y) ? float(1.0) : float(-1.0);
    u_xlat14.xy = max(abs(_MaskTex0_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat14.xy;
    u_xlati14.x = _MaskTex0Index;
    u_xlat14.xy = TempArray0[u_xlati14.x].xy;
    u_xlat14.xy = u_xlat14.xy + (-_MaskTex0_ST.zw);
    u_xlat1.x = _MaskTex0_R * 0.0174532924;
    u_xlat2.x = cos(u_xlat1.x);
    u_xlat1.x = sin(u_xlat1.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat15.y = dot(u_xlat14.xy, u_xlat3.xy);
    u_xlat15.x = dot(u_xlat14.xy, u_xlat3.yz);
    u_xlat0.xy = u_xlat15.xy / u_xlat0.xy;
    u_xlat16_6 = trunc(_M0PatternFadeAnime);
    u_xlati14.x = int(u_xlat16_6);
    u_xlati1.xy = ivec2(vec2(_M0PatternX, _M0PatternY));
    u_xlatu1.xy =  uvec2(max(u_xlati1.xy, ivec2(1, 1)));
    u_xlati21 = int(uint(uint(u_xlati14.x) ^ u_xlatu1.x));
    u_xlati21 = int(uint(uint(u_xlati21) & 2147483648u));
    u_xlatu15 =  uint(max(u_xlati14.x, (-u_xlati14.x)));
    {
        uint quo = u_xlatu15 / u_xlatu1.x;
        uint rem = u_xlatu15 % u_xlatu1.x;
        u_xlatu2 = quo;
        u_xlatu3 = rem;
    }
    u_xlatu15 =  uint(0 - int(u_xlatu2));
    u_xlatu21 = (u_xlati21 != 0) ? u_xlatu15 : u_xlatu2;
    u_xlatu15 =  uint(max(int(u_xlatu21), (-int(u_xlatu21))));
    u_xlati21 = int(uint(u_xlatu21 & 2147483648u));
    {
        uint rem = u_xlatu15 % u_xlatu1.y;
        u_xlatu15 = rem;
    }
    u_xlatu22 =  uint(0 - int(u_xlatu15));
    u_xlatu21 = (u_xlati21 != 0) ? u_xlatu22 : u_xlatu15;
    u_xlat21 = float(int(u_xlatu21));
    u_xlat15.xy = vec2(ivec2(u_xlatu1.xy));
    u_xlat15.xy = vec2(1.0, 1.0) / u_xlat15.xy;
    u_xlat16_6 = (-u_xlat15.y) + 1.0;
    u_xlat2.y = (-u_xlat15.y) * u_xlat21 + u_xlat16_6;
    u_xlati21 = int(uint(uint(u_xlati14.x) & 2147483648u));
    u_xlati14.x = u_xlati14.x + 1;
    u_xlatu16 =  uint(0 - int(u_xlatu3));
    u_xlatu21 = (u_xlati21 != 0) ? u_xlatu16 : u_xlatu3;
    u_xlat21 = float(int(u_xlatu21));
    u_xlat2.x = u_xlat21 * u_xlat15.x;
    vs_TEXCOORD3.xy = u_xlat0.xy * u_xlat15.xy + u_xlat2.xy;
    u_xlati14.y = int(uint(u_xlatu1.x ^ uint(u_xlati14.x)));
    u_xlatu2 =  uint(max(u_xlati14.x, (-u_xlati14.x)));
    u_xlati14.xy = ivec2(uvec2(uint(u_xlati14.x) & uint(2147483648u), uint(u_xlati14.y) & uint(2147483648u)));
    {
        uint quo = u_xlatu2 / u_xlatu1.x;
        uint rem = u_xlatu2 % u_xlatu1.x;
        u_xlatu1.x = quo;
        u_xlatu2 = rem;
    }
    u_xlatu9 =  uint(0 - int(u_xlatu1.x));
    u_xlatu21 = (u_xlati14.y != 0) ? u_xlatu9 : u_xlatu1.x;
    u_xlatu1.x =  uint(max(int(u_xlatu21), (-int(u_xlatu21))));
    u_xlati21 = int(uint(u_xlatu21 & 2147483648u));
    {
        uint rem = u_xlatu1.x % u_xlatu1.y;
        u_xlatu1.x = rem;
    }
    u_xlatu8 =  uint(0 - int(u_xlatu1.x));
    u_xlatu21 = (u_xlati21 != 0) ? u_xlatu8 : u_xlatu1.x;
    u_xlat21 = float(int(u_xlatu21));
    u_xlat16.y = (-u_xlat15.y) * u_xlat21 + u_xlat16_6;
    u_xlatu21 =  uint(0 - int(u_xlatu2));
    u_xlatu14 = (u_xlati14.x != 0) ? u_xlatu21 : u_xlatu2;
    u_xlat14.x = float(int(u_xlatu14));
    u_xlat16.x = u_xlat14.x * u_xlat15.x;
    vs_TEXCOORD3.zw = u_xlat0.xy * u_xlat15.xy + u_xlat16.xy;
    u_xlati0 = _FlowTexIndex;
    u_xlat0.xy = TempArray0[u_xlati0].xy;
    u_xlat0.xy = u_xlat0.xy + (-_FlowTex_ST.zw);
    u_xlat14.x = _FlowTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat14.x);
    u_xlat2.x = cos(u_xlat14.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat0.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat0.xy, u_xlat3.yz);
    u_xlatb0.xy = greaterThanEqual(_FlowTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = (u_xlatb0.x) ? float(1.0) : float(-1.0);
    u_xlat0.y = (u_xlatb0.y) ? float(1.0) : float(-1.0);
    u_xlat14.xy = max(abs(_FlowTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat14.xy;
    vs_TEXCOORD5.xy = u_xlat1.xy / u_xlat0.xy;
    vs_TEXCOORD6.xyz = _SecondColor.www * vec3(_FlowScale0, _FlowScale1, _FlowScale2);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex0_ST;
	UNITY_UNIFORM float                _ColorTex0_R;
	UNITY_UNIFORM int                _ColorTex0Index;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex1_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorTex1_R;
	UNITY_UNIFORM int Xhlslcc_UnusedX_ColorTex1Index;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex2_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorTex2_R;
	UNITY_UNIFORM int Xhlslcc_UnusedX_ColorTex2Index;
	UNITY_UNIFORM vec4                _MaskTex0_ST;
	UNITY_UNIFORM float                _MaskTex0_R;
	UNITY_UNIFORM int                _MaskTex0Index;
	UNITY_UNIFORM vec4                _MaskTex1_ST;
	UNITY_UNIFORM float                _MaskTex1_R;
	UNITY_UNIFORM int                _MaskTex1Index;
	UNITY_UNIFORM vec4                _FlowTex_ST;
	UNITY_UNIFORM float                _FlowTex_R;
	UNITY_UNIFORM int                _FlowTexIndex;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM vec4                _SecondColor;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorRGIndex;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorBAIndex;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM float                _VertexAlphaThresholdMode;
	UNITY_UNIFORM float                _ColorBorderMin0;
	UNITY_UNIFORM float                _ColorBorderMax0;
	UNITY_UNIFORM float                _ColorBorderMin1;
	UNITY_UNIFORM float                _ColorBorderMax1;
	UNITY_UNIFORM float                _ColorBorderMin2;
	UNITY_UNIFORM float                _ColorBorderMax2;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParThresholdMode;
	UNITY_UNIFORM float                _M0PatternX;
	UNITY_UNIFORM float                _M0PatternY;
	UNITY_UNIFORM float                _M0PatternFadeAnime;
	UNITY_UNIFORM float                _M0FlowScale0;
	UNITY_UNIFORM float                _M0FlowScale2;
	UNITY_UNIFORM float                _FlowScale0;
	UNITY_UNIFORM float                _FlowScale1;
	UNITY_UNIFORM float                _FlowScale2;
	UNITY_UNIFORM float                _ColorProjType;
	UNITY_UNIFORM float                _EdgeMaskWidth;
	UNITY_UNIFORM float                _EdgeMaskOffset;
	UNITY_UNIFORM float                _Luminance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex0;
UNITY_LOCATION(1) uniform mediump sampler2D _ColorTex1;
UNITY_LOCATION(2) uniform mediump sampler2D _ColorTex2;
UNITY_LOCATION(3) uniform mediump sampler2D _MaskTex0;
UNITY_LOCATION(4) uniform mediump sampler2D _MaskTex1;
UNITY_LOCATION(5) uniform mediump sampler2D _FlowTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD4;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD3;
in highp  vec2 vs_TEXCOORD5;
in highp  vec3 vs_TEXCOORD6;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
mediump float u_xlat16_0;
bvec2 u_xlatb0;
vec4 u_xlat1;
mediump vec3 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
mediump vec4 u_xlat16_3;
vec3 u_xlat4;
mediump vec4 u_xlat16_4;
float u_xlat5;
float u_xlat6;
vec2 u_xlat10;
mediump vec2 u_xlat16_10;
bvec2 u_xlatb10;
vec2 u_xlat11;
float u_xlat16;
void main()
{
    u_xlatb0.xy = greaterThanEqual(_MaskTex1_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = (u_xlatb0.x) ? float(1.0) : float(-1.0);
    u_xlat0.y = (u_xlatb0.y) ? float(1.0) : float(-1.0);
    u_xlat10.xy = max(abs(_MaskTex1_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat10.xy;
    u_xlat16_10.xy = texture(_FlowTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).xy;
    u_xlat10.xy = u_xlat16_10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat1 = u_xlat10.xyxy * vs_TEXCOORD6.yyyy + vs_TEXCOORD3;
    u_xlat16_2.xyz = texture(_MaskTex0, u_xlat1.zw, _GlobalMipBias.x).xyw;
    u_xlat16_1.xyz = texture(_MaskTex0, u_xlat1.xy, _GlobalMipBias.x).xyw;
    u_xlat2.xyz = (-u_xlat16_1.xyz) + u_xlat16_2.xyz;
    u_xlat1.xyz = vs_TEXCOORD2.xxx * u_xlat2.xyz + u_xlat16_1.xyz;
    u_xlat2 = u_xlat1.xyxy * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat1.xy = u_xlat2.zw * vs_TEXCOORD2.zz + vs_TEXCOORD4.xy;
    u_xlat1.xy = u_xlat10.xy * vs_TEXCOORD6.zz + u_xlat1.xy;
    u_xlat10.xy = u_xlat10.xy * vs_TEXCOORD6.xx + vs_TEXCOORD0.xy;
    u_xlat10.xy = u_xlat2.xy * vs_TEXCOORD2.yy + u_xlat10.xy;
    u_xlat10.xy = u_xlat10.xy + (-_ColorTex0_ST.zw);
    u_xlat1.xy = u_xlat1.xy + (-_MaskTex1_ST.zw);
    u_xlat16 = _MaskTex1_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat16);
    u_xlat3.x = cos(u_xlat16);
    u_xlat4.z = u_xlat2.x;
    u_xlat4.y = u_xlat3.x;
    u_xlat4.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat1.xy, u_xlat4.xy);
    u_xlat2.x = dot(u_xlat1.xy, u_xlat4.yz);
    u_xlat0.xy = u_xlat2.xy / u_xlat0.xy;
    u_xlat16_0 = texture(_MaskTex1, u_xlat0.xy, _GlobalMipBias.x).x;
    u_xlat2 = (-vec4(_ColorBorderMax0, _ColorBorderMin1, _ColorBorderMax1, _ColorBorderMin2)) + vec4(1.0, 1.0, 1.0, 1.0);
    u_xlat1.xy = (-vs_TEXCOORD1.xy) * u_xlat1.zz + u_xlat2.xz;
    u_xlat5 = (-vs_TEXCOORD1.z) * u_xlat1.z + 1.0;
    u_xlat11.xy = max(u_xlat2.yw, vec2(0.00999999978, 0.00999999978));
    u_xlat11.xy = min(u_xlat11.xy, vec2(1.0, 1.0));
    u_xlat1.xy = u_xlat1.xy + vec2(1.0, 1.0);
    u_xlat2.xy = max(vec2(u_xlat16_0), u_xlat1.xy);
    u_xlat0.x = max(u_xlat5, u_xlat16_0);
    u_xlat0.x = (-u_xlat5) + u_xlat0.x;
    u_xlat0.x = min(u_xlat11.y, u_xlat0.x);
    u_xlat0.x = u_xlat0.x / u_xlat11.y;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat1.xy = (-u_xlat1.xy) + u_xlat2.xy;
    u_xlat5 = (-_ColorBorderMin0) + 1.0;
    u_xlat5 = max(u_xlat5, 0.00999999978);
    u_xlat5 = min(u_xlat5, 1.0);
    u_xlat1.x = min(u_xlat5, u_xlat1.x);
    u_xlat6 = min(u_xlat11.x, u_xlat1.y);
    u_xlat6 = u_xlat6 / u_xlat11.x;
    u_xlat6 = clamp(u_xlat6, 0.0, 1.0);
    u_xlat5 = u_xlat1.x / u_xlat5;
    u_xlat5 = clamp(u_xlat5, 0.0, 1.0);
    u_xlat1.x = _ColorTex0_R * 0.0174532924;
    u_xlat2.x = cos(u_xlat1.x);
    u_xlat1.x = sin(u_xlat1.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat2.y = dot(u_xlat10.xy, u_xlat3.xy);
    u_xlat2.x = dot(u_xlat10.xy, u_xlat3.yz);
    u_xlatb10.xy = greaterThanEqual(_ColorTex0_ST.xyxy, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat10.x = (u_xlatb10.x) ? float(1.0) : float(-1.0);
    u_xlat10.y = (u_xlatb10.y) ? float(1.0) : float(-1.0);
    u_xlat1.xz = max(abs(_ColorTex0_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat10.xy = u_xlat10.xy * u_xlat1.xz;
    u_xlat10.xy = u_xlat2.xy / u_xlat10.xy;
    u_xlat16_2 = texture(_ColorTex0, u_xlat10.xy, _GlobalMipBias.x);
    u_xlat16_3 = texture(_ColorTex1, u_xlat10.xy, _GlobalMipBias.x);
    u_xlat16_4 = texture(_ColorTex2, u_xlat10.xy, _GlobalMipBias.x);
    u_xlat2 = u_xlat16_2 + (-u_xlat16_3);
    u_xlat2 = vec4(u_xlat5) * u_xlat2 + u_xlat16_3;
    u_xlat2 = (-u_xlat16_4) + u_xlat2;
    u_xlat1 = vec4(u_xlat6) * u_xlat2 + u_xlat16_4;
    u_xlat5 = _Transparency * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat5 = (-u_xlat5) + 1.0;
    u_xlat0.x = u_xlat5 * u_xlat0.x;
    u_xlat1.w = u_xlat0.x * u_xlat1.w;
    u_xlat0 = u_xlat1 * vs_COLOR0;
    SV_Target0.xyz = u_xlat0.www * u_xlat0.xyz;
    SV_Target0.w = u_xlat0.w;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex0_ST;
	UNITY_UNIFORM float                _ColorTex0_R;
	UNITY_UNIFORM int                _ColorTex0Index;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex1_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorTex1_R;
	UNITY_UNIFORM int Xhlslcc_UnusedX_ColorTex1Index;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex2_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorTex2_R;
	UNITY_UNIFORM int Xhlslcc_UnusedX_ColorTex2Index;
	UNITY_UNIFORM vec4                _MaskTex0_ST;
	UNITY_UNIFORM float                _MaskTex0_R;
	UNITY_UNIFORM int                _MaskTex0Index;
	UNITY_UNIFORM vec4                _MaskTex1_ST;
	UNITY_UNIFORM float                _MaskTex1_R;
	UNITY_UNIFORM int                _MaskTex1Index;
	UNITY_UNIFORM vec4                _FlowTex_ST;
	UNITY_UNIFORM float                _FlowTex_R;
	UNITY_UNIFORM int                _FlowTexIndex;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM vec4                _SecondColor;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorRGIndex;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorBAIndex;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM float                _VertexAlphaThresholdMode;
	UNITY_UNIFORM float                _ColorBorderMin0;
	UNITY_UNIFORM float                _ColorBorderMax0;
	UNITY_UNIFORM float                _ColorBorderMin1;
	UNITY_UNIFORM float                _ColorBorderMax1;
	UNITY_UNIFORM float                _ColorBorderMin2;
	UNITY_UNIFORM float                _ColorBorderMax2;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParThresholdMode;
	UNITY_UNIFORM float                _M0PatternX;
	UNITY_UNIFORM float                _M0PatternY;
	UNITY_UNIFORM float                _M0PatternFadeAnime;
	UNITY_UNIFORM float                _M0FlowScale0;
	UNITY_UNIFORM float                _M0FlowScale2;
	UNITY_UNIFORM float                _FlowScale0;
	UNITY_UNIFORM float                _FlowScale1;
	UNITY_UNIFORM float                _FlowScale2;
	UNITY_UNIFORM float                _ColorProjType;
	UNITY_UNIFORM float                _EdgeMaskWidth;
	UNITY_UNIFORM float                _EdgeMaskOffset;
	UNITY_UNIFORM float                _Luminance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex0;
UNITY_LOCATION(1) uniform mediump sampler2D _ColorTex1;
UNITY_LOCATION(2) uniform mediump sampler2D _ColorTex2;
UNITY_LOCATION(3) uniform mediump sampler2D _MaskTex0;
UNITY_LOCATION(4) uniform mediump sampler2D _MaskTex1;
UNITY_LOCATION(5) uniform mediump sampler2D _FlowTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD4;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD3;
in highp  vec2 vs_TEXCOORD5;
in highp  vec3 vs_TEXCOORD6;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
mediump float u_xlat16_0;
bvec2 u_xlatb0;
vec4 u_xlat1;
mediump vec3 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
mediump vec4 u_xlat16_3;
vec3 u_xlat4;
mediump vec4 u_xlat16_4;
float u_xlat5;
float u_xlat6;
vec2 u_xlat10;
mediump vec2 u_xlat16_10;
bvec2 u_xlatb10;
vec2 u_xlat11;
float u_xlat16;
void main()
{
    u_xlatb0.xy = greaterThanEqual(_MaskTex1_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = (u_xlatb0.x) ? float(1.0) : float(-1.0);
    u_xlat0.y = (u_xlatb0.y) ? float(1.0) : float(-1.0);
    u_xlat10.xy = max(abs(_MaskTex1_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat10.xy;
    u_xlat16_10.xy = texture(_FlowTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).xy;
    u_xlat10.xy = u_xlat16_10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat1 = u_xlat10.xyxy * vs_TEXCOORD6.yyyy + vs_TEXCOORD3;
    u_xlat16_2.xyz = texture(_MaskTex0, u_xlat1.zw, _GlobalMipBias.x).xyw;
    u_xlat16_1.xyz = texture(_MaskTex0, u_xlat1.xy, _GlobalMipBias.x).xyw;
    u_xlat2.xyz = (-u_xlat16_1.xyz) + u_xlat16_2.xyz;
    u_xlat1.xyz = vs_TEXCOORD2.xxx * u_xlat2.xyz + u_xlat16_1.xyz;
    u_xlat2 = u_xlat1.xyxy * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat1.xy = u_xlat2.zw * vs_TEXCOORD2.zz + vs_TEXCOORD4.xy;
    u_xlat1.xy = u_xlat10.xy * vs_TEXCOORD6.zz + u_xlat1.xy;
    u_xlat10.xy = u_xlat10.xy * vs_TEXCOORD6.xx + vs_TEXCOORD0.xy;
    u_xlat10.xy = u_xlat2.xy * vs_TEXCOORD2.yy + u_xlat10.xy;
    u_xlat10.xy = u_xlat10.xy + (-_ColorTex0_ST.zw);
    u_xlat1.xy = u_xlat1.xy + (-_MaskTex1_ST.zw);
    u_xlat16 = _MaskTex1_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat16);
    u_xlat3.x = cos(u_xlat16);
    u_xlat4.z = u_xlat2.x;
    u_xlat4.y = u_xlat3.x;
    u_xlat4.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat1.xy, u_xlat4.xy);
    u_xlat2.x = dot(u_xlat1.xy, u_xlat4.yz);
    u_xlat0.xy = u_xlat2.xy / u_xlat0.xy;
    u_xlat16_0 = texture(_MaskTex1, u_xlat0.xy, _GlobalMipBias.x).x;
    u_xlat2 = (-vec4(_ColorBorderMax0, _ColorBorderMin1, _ColorBorderMax1, _ColorBorderMin2)) + vec4(1.0, 1.0, 1.0, 1.0);
    u_xlat1.xy = (-vs_TEXCOORD1.xy) * u_xlat1.zz + u_xlat2.xz;
    u_xlat5 = (-vs_TEXCOORD1.z) * u_xlat1.z + 1.0;
    u_xlat11.xy = max(u_xlat2.yw, vec2(0.00999999978, 0.00999999978));
    u_xlat11.xy = min(u_xlat11.xy, vec2(1.0, 1.0));
    u_xlat1.xy = u_xlat1.xy + vec2(1.0, 1.0);
    u_xlat2.xy = max(vec2(u_xlat16_0), u_xlat1.xy);
    u_xlat0.x = max(u_xlat5, u_xlat16_0);
    u_xlat0.x = (-u_xlat5) + u_xlat0.x;
    u_xlat0.x = min(u_xlat11.y, u_xlat0.x);
    u_xlat0.x = u_xlat0.x / u_xlat11.y;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat1.xy = (-u_xlat1.xy) + u_xlat2.xy;
    u_xlat5 = (-_ColorBorderMin0) + 1.0;
    u_xlat5 = max(u_xlat5, 0.00999999978);
    u_xlat5 = min(u_xlat5, 1.0);
    u_xlat1.x = min(u_xlat5, u_xlat1.x);
    u_xlat6 = min(u_xlat11.x, u_xlat1.y);
    u_xlat6 = u_xlat6 / u_xlat11.x;
    u_xlat6 = clamp(u_xlat6, 0.0, 1.0);
    u_xlat5 = u_xlat1.x / u_xlat5;
    u_xlat5 = clamp(u_xlat5, 0.0, 1.0);
    u_xlat1.x = _ColorTex0_R * 0.0174532924;
    u_xlat2.x = cos(u_xlat1.x);
    u_xlat1.x = sin(u_xlat1.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat2.y = dot(u_xlat10.xy, u_xlat3.xy);
    u_xlat2.x = dot(u_xlat10.xy, u_xlat3.yz);
    u_xlatb10.xy = greaterThanEqual(_ColorTex0_ST.xyxy, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat10.x = (u_xlatb10.x) ? float(1.0) : float(-1.0);
    u_xlat10.y = (u_xlatb10.y) ? float(1.0) : float(-1.0);
    u_xlat1.xz = max(abs(_ColorTex0_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat10.xy = u_xlat10.xy * u_xlat1.xz;
    u_xlat10.xy = u_xlat2.xy / u_xlat10.xy;
    u_xlat16_2 = texture(_ColorTex0, u_xlat10.xy, _GlobalMipBias.x);
    u_xlat16_3 = texture(_ColorTex1, u_xlat10.xy, _GlobalMipBias.x);
    u_xlat16_4 = texture(_ColorTex2, u_xlat10.xy, _GlobalMipBias.x);
    u_xlat2 = u_xlat16_2 + (-u_xlat16_3);
    u_xlat2 = vec4(u_xlat5) * u_xlat2 + u_xlat16_3;
    u_xlat2 = (-u_xlat16_4) + u_xlat2;
    u_xlat1 = vec4(u_xlat6) * u_xlat2 + u_xlat16_4;
    u_xlat5 = _Transparency * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat5 = (-u_xlat5) + 1.0;
    u_xlat0.x = u_xlat5 * u_xlat0.x;
    u_xlat1.w = u_xlat0.x * u_xlat1.w;
    u_xlat0 = u_xlat1 * vs_COLOR0;
    SV_Target0.xyz = u_xlat0.www * u_xlat0.xyz;
    SV_Target0.w = u_xlat0.w;
    return;
}

#endif

