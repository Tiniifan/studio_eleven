// Soccer/Effect/Distortion (Shader path ID 7027363713090433755, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurStep;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurWeightType;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorOffset;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorPow;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorReverse;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade2;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
out highp vec4 vs_COLOR0;
out highp vec2 vs_TEXCOORD0;
out highp vec2 vs_TEXCOORD1;
out highp vec2 vs_TEXCOORD2;
out highp vec3 vs_TEXCOORD3;
out highp vec3 vs_TEXCOORD4;
vec4 u_xlat0;
vec4 u_xlat1;
bvec2 u_xlatb1;
vec3 u_xlat2;
float u_xlat3;
bvec3 u_xlatb3;
vec3 u_xlat4;
vec2 u_xlat10;
vec2 u_xlat11;
vec2 u_xlat12;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    u_xlat1.xyz = in_COLOR0.xyz * _Color.xyz;
    u_xlat2.xyz = max(u_xlat1.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat2.xyz = log2(u_xlat2.xyz);
    u_xlat2.xyz = u_xlat2.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat2.xyz = exp2(u_xlat2.xyz);
    u_xlatb3.xyz = lessThan(u_xlat1.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat1.xyz = u_xlat1.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    {
        vec4 hlslcc_movcTemp = u_xlat1;
        hlslcc_movcTemp.x = (u_xlatb3.x) ? u_xlat1.x : u_xlat2.x;
        hlslcc_movcTemp.y = (u_xlatb3.y) ? u_xlat1.y : u_xlat2.y;
        hlslcc_movcTemp.z = (u_xlatb3.z) ? u_xlat1.z : u_xlat2.z;
        u_xlat1 = hlslcc_movcTemp;
    }
    u_xlat2.xyz = max(in_COLOR0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat2.xyz = log2(u_xlat2.xyz);
    u_xlat2.xyz = u_xlat2.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat2.xyz = exp2(u_xlat2.xyz);
    u_xlatb3.xyz = lessThan(in_COLOR0.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat4.xyz = in_COLOR0.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    {
        vec3 hlslcc_movcTemp = u_xlat2;
        hlslcc_movcTemp.x = (u_xlatb3.x) ? u_xlat4.x : u_xlat2.x;
        hlslcc_movcTemp.y = (u_xlatb3.y) ? u_xlat4.y : u_xlat2.y;
        hlslcc_movcTemp.z = (u_xlatb3.z) ? u_xlat4.z : u_xlat2.z;
        u_xlat2 = hlslcc_movcTemp;
    }
    u_xlat1.xyz = (-u_xlat2.xyz) * _Color.xyz + u_xlat1.xyz;
    u_xlat2.xyz = u_xlat2.xyz * _Color.xyz;
    u_xlat1.xyz = vec3(_IsGammaColor) * u_xlat1.xyz + u_xlat2.xyz;
    u_xlat10.x = _Luminance + 1.0;
    vs_COLOR0.xyz = u_xlat10.xxx * u_xlat1.xyz;
    u_xlat10.x = _Transparency * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat10.x = (-u_xlat10.x) + 1.0;
    vs_COLOR0.w = u_xlat10.x * in_COLOR0.w;
    u_xlatb1.xy = greaterThanEqual(_DistortionTex0_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = (u_xlatb1.x) ? float(1.0) : float(-1.0);
    u_xlat1.y = (u_xlatb1.y) ? float(1.0) : float(-1.0);
    u_xlat11.xy = max(abs(_DistortionTex0_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat11.xy;
    u_xlat10.x = _DistortionTex0_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat10.x);
    u_xlat3 = cos(u_xlat10.x);
    u_xlat4.z = u_xlat2.x;
    u_xlat11.xy = in_TEXCOORD0.xy + (-_DistortionTex0_ST.zw);
    u_xlat4.y = u_xlat3;
    u_xlat4.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat11.xy, u_xlat4.xy);
    u_xlat2.x = dot(u_xlat11.xy, u_xlat4.yz);
    vs_TEXCOORD0.xy = u_xlat2.xy / u_xlat1.xy;
    u_xlatb1.xy = greaterThanEqual(_MaskTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = (u_xlatb1.x) ? float(1.0) : float(-1.0);
    u_xlat1.y = (u_xlatb1.y) ? float(1.0) : float(-1.0);
    u_xlat11.xy = max(abs(_MaskTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat11.xy;
    u_xlat10.x = _MaskTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat10.x);
    u_xlat3 = cos(u_xlat10.x);
    u_xlat4.z = u_xlat2.x;
    u_xlat11.xy = in_TEXCOORD1.xy + (-_MaskTex_ST.zw);
    u_xlat4.y = u_xlat3;
    u_xlat4.x = (-u_xlat2.x);
    u_xlat12.y = dot(u_xlat11.xy, u_xlat4.xy);
    u_xlat12.x = dot(u_xlat11.xy, u_xlat4.yz);
    vs_TEXCOORD1.xy = u_xlat12.xy / u_xlat1.xy;
    u_xlat0.y = u_xlat0.y * _ProjectionParams.x;
    u_xlat1.xzw = u_xlat0.xwy * vec3(0.5, 0.5, 0.5);
    u_xlat0.xy = u_xlat1.zz + u_xlat1.xw;
    u_xlat0.xy = u_xlat0.xy / u_xlat0.ww;
    u_xlat10.xy = u_xlat0.xy + vec2(-0.5, -0.5);
    vs_TEXCOORD2.xy = (-u_xlat10.xy) * vec2(vec2(_Expansion, _Expansion)) + u_xlat0.xy;
    u_xlat0.z = hlslcc_mtx4x4unity_ObjectToWorld[2].y;
    u_xlat0.x = hlslcc_mtx4x4unity_ObjectToWorld[0].y;
    u_xlat0.y = hlslcc_mtx4x4unity_ObjectToWorld[1].y;
    u_xlat10.x = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat10.x = sqrt(u_xlat10.x);
    u_xlat10.x = max(u_xlat10.x, 9.99999997e-07);
    u_xlat0.xy = u_xlat0.xy / u_xlat10.xx;
    u_xlat1 = u_xlat0.xyxy * hlslcc_mtx4x4unity_MatrixV[1].xxyy;
    u_xlat0.xy = u_xlat0.xy * hlslcc_mtx4x4unity_MatrixV[1].zz;
    u_xlat2.z = hlslcc_mtx4x4unity_ObjectToWorld[2].x;
    u_xlat2.x = hlslcc_mtx4x4unity_ObjectToWorld[0].x;
    u_xlat2.y = hlslcc_mtx4x4unity_ObjectToWorld[1].x;
    u_xlat10.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat10.x = sqrt(u_xlat10.x);
    u_xlat10.x = max(u_xlat10.x, 9.99999997e-07);
    u_xlat10.xy = u_xlat2.xy / u_xlat10.xx;
    u_xlat1 = u_xlat10.xyxy * hlslcc_mtx4x4unity_MatrixV[0].xxyy + u_xlat1;
    u_xlat0.xy = u_xlat10.xy * hlslcc_mtx4x4unity_MatrixV[0].zz + u_xlat0.xy;
    u_xlat2.z = hlslcc_mtx4x4unity_ObjectToWorld[2].z;
    u_xlat2.x = hlslcc_mtx4x4unity_ObjectToWorld[0].z;
    u_xlat2.y = hlslcc_mtx4x4unity_ObjectToWorld[1].z;
    u_xlat10.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat10.x = sqrt(u_xlat10.x);
    u_xlat10.x = max(u_xlat10.x, 9.99999997e-07);
    u_xlat10.xy = u_xlat2.xy / u_xlat10.xx;
    u_xlat1 = u_xlat10.xyxy * hlslcc_mtx4x4unity_MatrixV[2].xxyy + u_xlat1;
    u_xlat0.xy = u_xlat10.xy * hlslcc_mtx4x4unity_MatrixV[2].zz + u_xlat0.xy;
    u_xlat0.zw = u_xlat1.xz;
    vs_TEXCOORD4.xy = u_xlat1.yw;
    vs_TEXCOORD3.xyz = u_xlat0.zwx;
    vs_TEXCOORD4.z = u_xlat0.y;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurStep;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurWeightType;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorOffset;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorPow;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorReverse;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade2;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(2) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
mediump vec2 u_xlat16_1;
vec2 u_xlat2;
mediump vec2 u_xlat16_2;
vec2 u_xlat4;
float u_xlat6;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.x = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat0.x = u_xlat0.x * 0.5 + 0.5;
    u_xlat0.x = u_xlat0.x * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat0.x = u_xlat0.x * 0.300000012;
    u_xlat16_2.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat2.xy = u_xlat16_2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat4.xy = u_xlat2.yy * vs_TEXCOORD4.xy;
    u_xlat2.xy = u_xlat2.xx * vs_TEXCOORD3.xy + u_xlat4.xy;
    u_xlat16_1.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat2.xy = u_xlat2.xy * u_xlat16_1.xx;
    u_xlat0.xy = u_xlat0.xx * u_xlat2.xy;
    u_xlat0.xy = u_xlat0.xy * vec2(vec2(_DistortionScale0, _DistortionScale0)) + vs_TEXCOORD2.xy;
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlat0.xy = fract(u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
    u_xlat16_0.xyz = texture(_CameraTransparentTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_0.w = 1.0;
    u_xlat0 = u_xlat16_0 * vs_COLOR0;
    u_xlat6 = u_xlat16_1.y * u_xlat0.w;
    SV_Target0.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    SV_Target0.w = u_xlat6;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurStep;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurWeightType;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorOffset;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorPow;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorReverse;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade2;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(2) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
mediump vec2 u_xlat16_1;
vec2 u_xlat2;
mediump vec2 u_xlat16_2;
vec2 u_xlat4;
float u_xlat6;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.x = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat0.x = u_xlat0.x * 0.5 + 0.5;
    u_xlat0.x = u_xlat0.x * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat0.x = u_xlat0.x * 0.300000012;
    u_xlat16_2.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat2.xy = u_xlat16_2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat4.xy = u_xlat2.yy * vs_TEXCOORD4.xy;
    u_xlat2.xy = u_xlat2.xx * vs_TEXCOORD3.xy + u_xlat4.xy;
    u_xlat16_1.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat2.xy = u_xlat2.xy * u_xlat16_1.xx;
    u_xlat0.xy = u_xlat0.xx * u_xlat2.xy;
    u_xlat0.xy = u_xlat0.xy * vec2(vec2(_DistortionScale0, _DistortionScale0)) + vs_TEXCOORD2.xy;
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlat0.xy = fract(u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
    u_xlat16_0.xyz = texture(_CameraTransparentTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_0.w = 1.0;
    u_xlat0 = u_xlat16_0 * vs_COLOR0;
    u_xlat6 = u_xlat16_1.y * u_xlat0.w;
    SV_Target0.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    SV_Target0.w = u_xlat6;
    return;
}

#endif


// ===== program 2: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _BlurStep;
	UNITY_UNIFORM float                _BlurWeightType;
	UNITY_UNIFORM float                _ColorOffset;
	UNITY_UNIFORM float                _ColorPow;
	UNITY_UNIFORM float                _ColorReverse;
	UNITY_UNIFORM float                _ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade2;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
out highp vec4 vs_COLOR0;
out highp vec2 vs_TEXCOORD0;
out highp vec2 vs_TEXCOORD1;
out highp vec2 vs_TEXCOORD2;
out highp vec3 vs_TEXCOORD3;
out highp vec3 vs_TEXCOORD4;
vec4 u_xlat0;
vec4 u_xlat1;
bvec2 u_xlatb1;
vec3 u_xlat2;
float u_xlat3;
bvec3 u_xlatb3;
vec3 u_xlat4;
vec2 u_xlat10;
vec2 u_xlat11;
vec2 u_xlat12;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    u_xlat1.xyz = in_COLOR0.xyz * _Color.xyz;
    u_xlat2.xyz = max(u_xlat1.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat2.xyz = log2(u_xlat2.xyz);
    u_xlat2.xyz = u_xlat2.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat2.xyz = exp2(u_xlat2.xyz);
    u_xlatb3.xyz = lessThan(u_xlat1.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat1.xyz = u_xlat1.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    {
        vec4 hlslcc_movcTemp = u_xlat1;
        hlslcc_movcTemp.x = (u_xlatb3.x) ? u_xlat1.x : u_xlat2.x;
        hlslcc_movcTemp.y = (u_xlatb3.y) ? u_xlat1.y : u_xlat2.y;
        hlslcc_movcTemp.z = (u_xlatb3.z) ? u_xlat1.z : u_xlat2.z;
        u_xlat1 = hlslcc_movcTemp;
    }
    u_xlat2.xyz = max(in_COLOR0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat2.xyz = log2(u_xlat2.xyz);
    u_xlat2.xyz = u_xlat2.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat2.xyz = exp2(u_xlat2.xyz);
    u_xlatb3.xyz = lessThan(in_COLOR0.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat4.xyz = in_COLOR0.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    {
        vec3 hlslcc_movcTemp = u_xlat2;
        hlslcc_movcTemp.x = (u_xlatb3.x) ? u_xlat4.x : u_xlat2.x;
        hlslcc_movcTemp.y = (u_xlatb3.y) ? u_xlat4.y : u_xlat2.y;
        hlslcc_movcTemp.z = (u_xlatb3.z) ? u_xlat4.z : u_xlat2.z;
        u_xlat2 = hlslcc_movcTemp;
    }
    u_xlat1.xyz = (-u_xlat2.xyz) * _Color.xyz + u_xlat1.xyz;
    u_xlat2.xyz = u_xlat2.xyz * _Color.xyz;
    u_xlat1.xyz = vec3(_IsGammaColor) * u_xlat1.xyz + u_xlat2.xyz;
    u_xlat10.x = _Luminance + 1.0;
    vs_COLOR0.xyz = u_xlat10.xxx * u_xlat1.xyz;
    u_xlat10.x = _Transparency * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat10.x = (-u_xlat10.x) + 1.0;
    vs_COLOR0.w = u_xlat10.x * in_COLOR0.w;
    u_xlatb1.xy = greaterThanEqual(_DistortionTex0_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = (u_xlatb1.x) ? float(1.0) : float(-1.0);
    u_xlat1.y = (u_xlatb1.y) ? float(1.0) : float(-1.0);
    u_xlat11.xy = max(abs(_DistortionTex0_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat11.xy;
    u_xlat10.x = _DistortionTex0_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat10.x);
    u_xlat3 = cos(u_xlat10.x);
    u_xlat4.z = u_xlat2.x;
    u_xlat11.xy = in_TEXCOORD0.xy + (-_DistortionTex0_ST.zw);
    u_xlat4.y = u_xlat3;
    u_xlat4.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat11.xy, u_xlat4.xy);
    u_xlat2.x = dot(u_xlat11.xy, u_xlat4.yz);
    vs_TEXCOORD0.xy = u_xlat2.xy / u_xlat1.xy;
    u_xlatb1.xy = greaterThanEqual(_MaskTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = (u_xlatb1.x) ? float(1.0) : float(-1.0);
    u_xlat1.y = (u_xlatb1.y) ? float(1.0) : float(-1.0);
    u_xlat11.xy = max(abs(_MaskTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat11.xy;
    u_xlat10.x = _MaskTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat10.x);
    u_xlat3 = cos(u_xlat10.x);
    u_xlat4.z = u_xlat2.x;
    u_xlat11.xy = in_TEXCOORD1.xy + (-_MaskTex_ST.zw);
    u_xlat4.y = u_xlat3;
    u_xlat4.x = (-u_xlat2.x);
    u_xlat12.y = dot(u_xlat11.xy, u_xlat4.xy);
    u_xlat12.x = dot(u_xlat11.xy, u_xlat4.yz);
    vs_TEXCOORD1.xy = u_xlat12.xy / u_xlat1.xy;
    u_xlat0.y = u_xlat0.y * _ProjectionParams.x;
    u_xlat1.xzw = u_xlat0.xwy * vec3(0.5, 0.5, 0.5);
    u_xlat0.xy = u_xlat1.zz + u_xlat1.xw;
    u_xlat0.xy = u_xlat0.xy / u_xlat0.ww;
    u_xlat10.xy = u_xlat0.xy + vec2(-0.5, -0.5);
    vs_TEXCOORD2.xy = (-u_xlat10.xy) * vec2(vec2(_Expansion, _Expansion)) + u_xlat0.xy;
    u_xlat0.z = hlslcc_mtx4x4unity_ObjectToWorld[2].y;
    u_xlat0.x = hlslcc_mtx4x4unity_ObjectToWorld[0].y;
    u_xlat0.y = hlslcc_mtx4x4unity_ObjectToWorld[1].y;
    u_xlat10.x = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat10.x = sqrt(u_xlat10.x);
    u_xlat10.x = max(u_xlat10.x, 9.99999997e-07);
    u_xlat0.xy = u_xlat0.xy / u_xlat10.xx;
    u_xlat1 = u_xlat0.xyxy * hlslcc_mtx4x4unity_MatrixV[1].xxyy;
    u_xlat0.xy = u_xlat0.xy * hlslcc_mtx4x4unity_MatrixV[1].zz;
    u_xlat2.z = hlslcc_mtx4x4unity_ObjectToWorld[2].x;
    u_xlat2.x = hlslcc_mtx4x4unity_ObjectToWorld[0].x;
    u_xlat2.y = hlslcc_mtx4x4unity_ObjectToWorld[1].x;
    u_xlat10.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat10.x = sqrt(u_xlat10.x);
    u_xlat10.x = max(u_xlat10.x, 9.99999997e-07);
    u_xlat10.xy = u_xlat2.xy / u_xlat10.xx;
    u_xlat1 = u_xlat10.xyxy * hlslcc_mtx4x4unity_MatrixV[0].xxyy + u_xlat1;
    u_xlat0.xy = u_xlat10.xy * hlslcc_mtx4x4unity_MatrixV[0].zz + u_xlat0.xy;
    u_xlat2.z = hlslcc_mtx4x4unity_ObjectToWorld[2].z;
    u_xlat2.x = hlslcc_mtx4x4unity_ObjectToWorld[0].z;
    u_xlat2.y = hlslcc_mtx4x4unity_ObjectToWorld[1].z;
    u_xlat10.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat10.x = sqrt(u_xlat10.x);
    u_xlat10.x = max(u_xlat10.x, 9.99999997e-07);
    u_xlat10.xy = u_xlat2.xy / u_xlat10.xx;
    u_xlat1 = u_xlat10.xyxy * hlslcc_mtx4x4unity_MatrixV[2].xxyy + u_xlat1;
    u_xlat0.xy = u_xlat10.xy * hlslcc_mtx4x4unity_MatrixV[2].zz + u_xlat0.xy;
    u_xlat0.zw = u_xlat1.xz;
    vs_TEXCOORD4.xy = u_xlat1.yw;
    vs_TEXCOORD3.xyz = u_xlat0.zwx;
    vs_TEXCOORD4.z = u_xlat0.y;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _BlurStep;
	UNITY_UNIFORM float                _BlurWeightType;
	UNITY_UNIFORM float                _ColorOffset;
	UNITY_UNIFORM float                _ColorPow;
	UNITY_UNIFORM float                _ColorReverse;
	UNITY_UNIFORM float                _ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade2;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(2) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
mediump vec3 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec3 u_xlat2;
vec4 u_xlat3;
mediump vec3 u_xlat16_3;
vec4 u_xlat4;
mediump vec3 u_xlat16_4;
vec2 u_xlat5;
mediump vec2 u_xlat16_5;
vec2 u_xlat10;
float u_xlat15;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.x = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat0.x = u_xlat0.x * 0.5 + 0.5;
    u_xlat0.x = u_xlat0.x * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat0.x = u_xlat0.x * 0.300000012;
    u_xlat16_5.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat5.xy = u_xlat16_5.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = u_xlat5.yy * vs_TEXCOORD4.xy;
    u_xlat5.xy = u_xlat5.xx * vs_TEXCOORD3.xy + u_xlat10.xy;
    u_xlat16_1.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat5.xy = u_xlat5.xy * u_xlat16_1.xx;
    u_xlat0.xy = u_xlat0.xx * u_xlat5.xy;
    u_xlat10.x = _BlurStep + _DistortionScale0;
    u_xlat10.xy = u_xlat0.xy * u_xlat10.xx + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_1.xzw = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_1.xzw * vec3(0.238095239, 0.238095239, 0.238095239);
    u_xlat10.xy = u_xlat0.xy * vec2(vec2(_DistortionScale0, _DistortionScale0)) + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.285714298, 0.285714298, 0.285714298) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat16_1.xzw + u_xlat16_3.xyz;
    u_xlat10.x = _BlurStep * 2.0 + _DistortionScale0;
    u_xlat10.xy = u_xlat0.xy * u_xlat10.xx + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.190476194, 0.190476194, 0.190476194) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat1.xzw + u_xlat16_3.xyz;
    u_xlat3.xyz = vec3(vec3(_BlurStep, _BlurStep, _BlurStep)) * vec3(3.0, 4.0, 5.0) + vec3(vec3(_DistortionScale0, _DistortionScale0, _DistortionScale0));
    u_xlat4 = u_xlat0.xyxy * u_xlat3.xxyy + vs_TEXCOORD2.xyxy;
    u_xlat0.xy = u_xlat0.xy * u_xlat3.zz + vs_TEXCOORD2.xy;
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlat0.xy = fract(u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
    u_xlat16_0.xyz = texture(_CameraTransparentTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat3 = u_xlat4 * vec4(0.5, 0.5, 0.5, 0.5);
    u_xlat3 = fract(u_xlat3);
    u_xlat3 = u_xlat3 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat3 = -abs(u_xlat3) + vec4(1.0, 1.0, 1.0, 1.0);
    u_xlat16_4.xyz = texture(_CameraTransparentTexture, u_xlat3.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat3.zw, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_4.xyz * vec3(0.142857149, 0.142857149, 0.142857149) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat1.xzw + u_xlat16_4.xyz;
    u_xlat1.xzw = u_xlat16_3.xyz + u_xlat1.xzw;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.095238097, 0.095238097, 0.095238097) + u_xlat2.xyz;
    u_xlat2.xyz = u_xlat16_0.xyz * vec3(0.0476190485, 0.0476190485, 0.0476190485) + u_xlat2.xyz;
    u_xlat0.xyz = u_xlat16_0.xyz + u_xlat1.xzw;
    u_xlat1.xzw = (-u_xlat0.xyz) * vec3(0.166666657, 0.166666657, 0.166666657) + u_xlat2.xyz;
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.166666657, 0.166666657, 0.166666657);
    u_xlat0.xyz = vec3(_BlurWeightType) * u_xlat1.xzw + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + vec3(vec3(_ColorOffset, _ColorOffset, _ColorOffset));
    u_xlat0.xyz = max(u_xlat0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat0.xyz = log2(u_xlat0.xyz);
    u_xlat0.xyz = u_xlat0.xyz * vec3(vec3(_ColorPow, _ColorPow, _ColorPow));
    u_xlat0.xyz = exp2(u_xlat0.xyz);
    u_xlat1.xzw = u_xlat0.xyz * vec3(-2.0, -2.0, -2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = vec3(vec3(_ColorReverse, _ColorReverse, _ColorReverse)) * u_xlat1.xzw + u_xlat0.xyz;
    u_xlat15 = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat0.xyz = (-vec3(u_xlat15)) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ColorSaturation) * u_xlat0.xyz + vec3(u_xlat15);
    u_xlat0.w = 1.0;
    u_xlat0 = u_xlat0 * vs_COLOR0;
    u_xlat15 = u_xlat16_1.y * u_xlat0.w;
    SV_Target0.xyz = vec3(u_xlat15) * u_xlat0.xyz;
    SV_Target0.w = u_xlat15;
    return;
}

#endif


// ===== program 3: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _BlurStep;
	UNITY_UNIFORM float                _BlurWeightType;
	UNITY_UNIFORM float                _ColorOffset;
	UNITY_UNIFORM float                _ColorPow;
	UNITY_UNIFORM float                _ColorReverse;
	UNITY_UNIFORM float                _ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade2;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(2) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
mediump vec3 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec3 u_xlat2;
vec4 u_xlat3;
mediump vec3 u_xlat16_3;
vec4 u_xlat4;
mediump vec3 u_xlat16_4;
vec2 u_xlat5;
mediump vec2 u_xlat16_5;
vec2 u_xlat10;
float u_xlat15;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.x = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat0.x = u_xlat0.x * 0.5 + 0.5;
    u_xlat0.x = u_xlat0.x * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat0.x = u_xlat0.x * 0.300000012;
    u_xlat16_5.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat5.xy = u_xlat16_5.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = u_xlat5.yy * vs_TEXCOORD4.xy;
    u_xlat5.xy = u_xlat5.xx * vs_TEXCOORD3.xy + u_xlat10.xy;
    u_xlat16_1.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat5.xy = u_xlat5.xy * u_xlat16_1.xx;
    u_xlat0.xy = u_xlat0.xx * u_xlat5.xy;
    u_xlat10.x = _BlurStep + _DistortionScale0;
    u_xlat10.xy = u_xlat0.xy * u_xlat10.xx + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_1.xzw = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_1.xzw * vec3(0.238095239, 0.238095239, 0.238095239);
    u_xlat10.xy = u_xlat0.xy * vec2(vec2(_DistortionScale0, _DistortionScale0)) + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.285714298, 0.285714298, 0.285714298) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat16_1.xzw + u_xlat16_3.xyz;
    u_xlat10.x = _BlurStep * 2.0 + _DistortionScale0;
    u_xlat10.xy = u_xlat0.xy * u_xlat10.xx + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.190476194, 0.190476194, 0.190476194) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat1.xzw + u_xlat16_3.xyz;
    u_xlat3.xyz = vec3(vec3(_BlurStep, _BlurStep, _BlurStep)) * vec3(3.0, 4.0, 5.0) + vec3(vec3(_DistortionScale0, _DistortionScale0, _DistortionScale0));
    u_xlat4 = u_xlat0.xyxy * u_xlat3.xxyy + vs_TEXCOORD2.xyxy;
    u_xlat0.xy = u_xlat0.xy * u_xlat3.zz + vs_TEXCOORD2.xy;
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlat0.xy = fract(u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
    u_xlat16_0.xyz = texture(_CameraTransparentTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat3 = u_xlat4 * vec4(0.5, 0.5, 0.5, 0.5);
    u_xlat3 = fract(u_xlat3);
    u_xlat3 = u_xlat3 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat3 = -abs(u_xlat3) + vec4(1.0, 1.0, 1.0, 1.0);
    u_xlat16_4.xyz = texture(_CameraTransparentTexture, u_xlat3.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat3.zw, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_4.xyz * vec3(0.142857149, 0.142857149, 0.142857149) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat1.xzw + u_xlat16_4.xyz;
    u_xlat1.xzw = u_xlat16_3.xyz + u_xlat1.xzw;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.095238097, 0.095238097, 0.095238097) + u_xlat2.xyz;
    u_xlat2.xyz = u_xlat16_0.xyz * vec3(0.0476190485, 0.0476190485, 0.0476190485) + u_xlat2.xyz;
    u_xlat0.xyz = u_xlat16_0.xyz + u_xlat1.xzw;
    u_xlat1.xzw = (-u_xlat0.xyz) * vec3(0.166666657, 0.166666657, 0.166666657) + u_xlat2.xyz;
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.166666657, 0.166666657, 0.166666657);
    u_xlat0.xyz = vec3(_BlurWeightType) * u_xlat1.xzw + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + vec3(vec3(_ColorOffset, _ColorOffset, _ColorOffset));
    u_xlat0.xyz = max(u_xlat0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat0.xyz = log2(u_xlat0.xyz);
    u_xlat0.xyz = u_xlat0.xyz * vec3(vec3(_ColorPow, _ColorPow, _ColorPow));
    u_xlat0.xyz = exp2(u_xlat0.xyz);
    u_xlat1.xzw = u_xlat0.xyz * vec3(-2.0, -2.0, -2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = vec3(vec3(_ColorReverse, _ColorReverse, _ColorReverse)) * u_xlat1.xzw + u_xlat0.xyz;
    u_xlat15 = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat0.xyz = (-vec3(u_xlat15)) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ColorSaturation) * u_xlat0.xyz + vec3(u_xlat15);
    u_xlat0.w = 1.0;
    u_xlat0 = u_xlat0 * vs_COLOR0;
    u_xlat15 = u_xlat16_1.y * u_xlat0.w;
    SV_Target0.xyz = vec3(u_xlat15) * u_xlat0.xyz;
    SV_Target0.w = u_xlat15;
    return;
}

#endif


// ===== program 4: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurStep;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurWeightType;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorOffset;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorPow;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorReverse;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float                _SoftParticleFade;
	UNITY_UNIFORM float                _SoftParticleFade2;
	UNITY_UNIFORM mediump float                _SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
out highp vec4 vs_COLOR0;
out highp vec2 vs_TEXCOORD0;
out highp vec2 vs_TEXCOORD1;
out highp vec2 vs_TEXCOORD2;
out highp vec3 vs_TEXCOORD3;
out highp vec3 vs_TEXCOORD4;
out highp vec3 vs_TEXCOORD14;
out highp vec4 vs_TEXCOORD15;
vec3 u_xlat0;
vec4 u_xlat1;
vec4 u_xlat2;
bvec2 u_xlatb2;
vec3 u_xlat3;
float u_xlat4;
bvec3 u_xlatb4;
vec3 u_xlat5;
float u_xlat6;
vec2 u_xlat13;
vec2 u_xlat14;
vec2 u_xlat15;
float u_xlat18;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat1 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat1;
    u_xlat2.xyz = in_COLOR0.xyz * _Color.xyz;
    u_xlat3.xyz = max(u_xlat2.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat3.xyz = u_xlat3.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat3.xyz = log2(u_xlat3.xyz);
    u_xlat3.xyz = u_xlat3.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat3.xyz = exp2(u_xlat3.xyz);
    u_xlatb4.xyz = lessThan(u_xlat2.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    {
        vec4 hlslcc_movcTemp = u_xlat2;
        hlslcc_movcTemp.x = (u_xlatb4.x) ? u_xlat2.x : u_xlat3.x;
        hlslcc_movcTemp.y = (u_xlatb4.y) ? u_xlat2.y : u_xlat3.y;
        hlslcc_movcTemp.z = (u_xlatb4.z) ? u_xlat2.z : u_xlat3.z;
        u_xlat2 = hlslcc_movcTemp;
    }
    u_xlat3.xyz = max(in_COLOR0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat3.xyz = u_xlat3.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat3.xyz = log2(u_xlat3.xyz);
    u_xlat3.xyz = u_xlat3.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat3.xyz = exp2(u_xlat3.xyz);
    u_xlatb4.xyz = lessThan(in_COLOR0.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat5.xyz = in_COLOR0.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    {
        vec3 hlslcc_movcTemp = u_xlat3;
        hlslcc_movcTemp.x = (u_xlatb4.x) ? u_xlat5.x : u_xlat3.x;
        hlslcc_movcTemp.y = (u_xlatb4.y) ? u_xlat5.y : u_xlat3.y;
        hlslcc_movcTemp.z = (u_xlatb4.z) ? u_xlat5.z : u_xlat3.z;
        u_xlat3 = hlslcc_movcTemp;
    }
    u_xlat2.xyz = (-u_xlat3.xyz) * _Color.xyz + u_xlat2.xyz;
    u_xlat3.xyz = u_xlat3.xyz * _Color.xyz;
    u_xlat2.xyz = vec3(_IsGammaColor) * u_xlat2.xyz + u_xlat3.xyz;
    u_xlat18 = _Luminance + 1.0;
    vs_COLOR0.xyz = vec3(u_xlat18) * u_xlat2.xyz;
    u_xlat18 = _Transparency * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat18 = (-u_xlat18) + 1.0;
    vs_COLOR0.w = u_xlat18 * in_COLOR0.w;
    u_xlatb2.xy = greaterThanEqual(_DistortionTex0_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat2.x = (u_xlatb2.x) ? float(1.0) : float(-1.0);
    u_xlat2.y = (u_xlatb2.y) ? float(1.0) : float(-1.0);
    u_xlat14.xy = max(abs(_DistortionTex0_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat2.xy = u_xlat2.xy * u_xlat14.xy;
    u_xlat18 = _DistortionTex0_R * 0.0174532924;
    u_xlat3.x = sin(u_xlat18);
    u_xlat4 = cos(u_xlat18);
    u_xlat5.z = u_xlat3.x;
    u_xlat14.xy = in_TEXCOORD0.xy + (-_DistortionTex0_ST.zw);
    u_xlat5.y = u_xlat4;
    u_xlat5.x = (-u_xlat3.x);
    u_xlat3.y = dot(u_xlat14.xy, u_xlat5.xy);
    u_xlat3.x = dot(u_xlat14.xy, u_xlat5.yz);
    vs_TEXCOORD0.xy = u_xlat3.xy / u_xlat2.xy;
    u_xlatb2.xy = greaterThanEqual(_MaskTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat2.x = (u_xlatb2.x) ? float(1.0) : float(-1.0);
    u_xlat2.y = (u_xlatb2.y) ? float(1.0) : float(-1.0);
    u_xlat14.xy = max(abs(_MaskTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat2.xy = u_xlat2.xy * u_xlat14.xy;
    u_xlat18 = _MaskTex_R * 0.0174532924;
    u_xlat3.x = sin(u_xlat18);
    u_xlat4 = cos(u_xlat18);
    u_xlat5.z = u_xlat3.x;
    u_xlat14.xy = in_TEXCOORD1.xy + (-_MaskTex_ST.zw);
    u_xlat5.y = u_xlat4;
    u_xlat5.x = (-u_xlat3.x);
    u_xlat15.y = dot(u_xlat14.xy, u_xlat5.xy);
    u_xlat15.x = dot(u_xlat14.xy, u_xlat5.yz);
    vs_TEXCOORD1.xy = u_xlat15.xy / u_xlat2.xy;
    u_xlat18 = u_xlat1.y * _ProjectionParams.x;
    u_xlat2.w = u_xlat18 * 0.5;
    u_xlat2.xz = u_xlat1.xw * vec2(0.5, 0.5);
    u_xlat1.xy = u_xlat2.zz + u_xlat2.xw;
    u_xlat2.xy = u_xlat1.xy / u_xlat1.ww;
    vs_TEXCOORD15 = u_xlat1;
    u_xlat1.xy = u_xlat2.xy + vec2(-0.5, -0.5);
    vs_TEXCOORD2.xy = (-u_xlat1.xy) * vec2(vec2(_Expansion, _Expansion)) + u_xlat2.xy;
    u_xlat1.z = hlslcc_mtx4x4unity_ObjectToWorld[2].y;
    u_xlat1.x = hlslcc_mtx4x4unity_ObjectToWorld[0].y;
    u_xlat1.y = hlslcc_mtx4x4unity_ObjectToWorld[1].y;
    u_xlat18 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat18 = sqrt(u_xlat18);
    u_xlat18 = max(u_xlat18, 9.99999997e-07);
    u_xlat1.xy = u_xlat1.xy / vec2(u_xlat18);
    u_xlat2 = u_xlat1.xyxy * hlslcc_mtx4x4unity_MatrixV[1].xxyy;
    u_xlat1.xy = u_xlat1.xy * hlslcc_mtx4x4unity_MatrixV[1].zz;
    u_xlat3.z = hlslcc_mtx4x4unity_ObjectToWorld[2].x;
    u_xlat3.x = hlslcc_mtx4x4unity_ObjectToWorld[0].x;
    u_xlat3.y = hlslcc_mtx4x4unity_ObjectToWorld[1].x;
    u_xlat18 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat18 = sqrt(u_xlat18);
    u_xlat18 = max(u_xlat18, 9.99999997e-07);
    u_xlat13.xy = u_xlat3.xy / vec2(u_xlat18);
    u_xlat2 = u_xlat13.xyxy * hlslcc_mtx4x4unity_MatrixV[0].xxyy + u_xlat2;
    u_xlat1.xy = u_xlat13.xy * hlslcc_mtx4x4unity_MatrixV[0].zz + u_xlat1.xy;
    u_xlat3.z = hlslcc_mtx4x4unity_ObjectToWorld[2].z;
    u_xlat3.x = hlslcc_mtx4x4unity_ObjectToWorld[0].z;
    u_xlat3.y = hlslcc_mtx4x4unity_ObjectToWorld[1].z;
    u_xlat18 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat18 = sqrt(u_xlat18);
    u_xlat18 = max(u_xlat18, 9.99999997e-07);
    u_xlat13.xy = u_xlat3.xy / vec2(u_xlat18);
    u_xlat2 = u_xlat13.xyxy * hlslcc_mtx4x4unity_MatrixV[2].xxyy + u_xlat2;
    u_xlat1.xy = u_xlat13.xy * hlslcc_mtx4x4unity_MatrixV[2].zz + u_xlat1.xy;
    u_xlat1.zw = u_xlat2.xz;
    vs_TEXCOORD4.xy = u_xlat2.yw;
    vs_TEXCOORD3.xyz = u_xlat1.zwx;
    vs_TEXCOORD4.z = u_xlat1.y;
    u_xlat6 = u_xlat0.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat0.x + u_xlat6;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat0.z + u_xlat0.x;
    u_xlat0.x = u_xlat0.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    vs_TEXCOORD14.z = abs(u_xlat0.x);
    u_xlat0.x = (-_SoftParticleFade) + 1.0;
    u_xlat0.x = u_xlat0.x * _SoftParDistance;
    u_xlat0.x = max(u_xlat0.x, 9.99999975e-05);
    u_xlat6 = (-u_xlat0.x) + _SoftParDistance;
    u_xlat6 = _SoftParticleFade2 * u_xlat6 + u_xlat0.x;
    vs_TEXCOORD14.x = float(1.0) / u_xlat0.x;
    vs_TEXCOORD14.y = float(1.0) / u_xlat6;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ZBufferParams;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurStep;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurWeightType;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorOffset;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorPow;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorReverse;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float                _SoftParticleFade;
	UNITY_UNIFORM float                _SoftParticleFade2;
	UNITY_UNIFORM mediump float                _SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform highp sampler2D _CameraDepthTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(2) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(3) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
in highp  vec3 vs_TEXCOORD14;
in highp  vec4 vs_TEXCOORD15;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
vec2 u_xlat1;
mediump vec4 u_xlat16_1;
mediump vec2 u_xlat16_2;
float u_xlat3;
vec2 u_xlat4;
mediump vec2 u_xlat16_4;
vec2 u_xlat7;
float u_xlat9;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = vs_TEXCOORD15.xy / vs_TEXCOORD15.ww;
    u_xlat0.x = texture(_CameraDepthTexture, u_xlat0.xy, _GlobalMipBias.x).x;
    u_xlat0.x = _ZBufferParams.z * u_xlat0.x + _ZBufferParams.w;
    u_xlat0.x = float(1.0) / u_xlat0.x;
    u_xlat0.x = u_xlat0.x + (-vs_TEXCOORD14.z);
    u_xlat3 = (-vs_TEXCOORD14.y) + vs_TEXCOORD14.x;
    u_xlat3 = vs_COLOR0.w * u_xlat3 + vs_TEXCOORD14.y;
    u_xlat0.x = u_xlat0.x * u_xlat3;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.w = u_xlat0.x * vs_COLOR0.w;
    u_xlat1.x = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat1.x = u_xlat1.x * 0.5 + 0.5;
    u_xlat1.x = u_xlat1.x * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat1.x = u_xlat1.x * 0.300000012;
    u_xlat16_4.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat4.xy = u_xlat16_4.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat7.xy = u_xlat4.yy * vs_TEXCOORD4.xy;
    u_xlat4.xy = u_xlat4.xx * vs_TEXCOORD3.xy + u_xlat7.xy;
    u_xlat16_2.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat4.xy = u_xlat4.xy * u_xlat16_2.xx;
    u_xlat1.xy = u_xlat1.xx * u_xlat4.xy;
    u_xlat1.xy = u_xlat1.xy * vec2(vec2(_DistortionScale0, _DistortionScale0)) + vs_TEXCOORD2.xy;
    u_xlat1.xy = u_xlat1.xy * vec2(0.5, 0.5);
    u_xlat1.xy = fract(u_xlat1.xy);
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat1.xy = -abs(u_xlat1.xy) + vec2(1.0, 1.0);
    u_xlat16_1.xyz = texture(_CameraTransparentTexture, u_xlat1.xy, _GlobalMipBias.x).xyz;
    u_xlat16_1.w = 1.0;
    u_xlat0.xyz = vs_COLOR0.xyz;
    u_xlat0 = u_xlat0 * u_xlat16_1;
    u_xlat9 = u_xlat16_2.y * u_xlat0.w;
    SV_Target0.xyz = vec3(u_xlat9) * u_xlat0.xyz;
    SV_Target0.w = u_xlat9;
    return;
}

#endif
9

// ===== program 5: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ZBufferParams;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurStep;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurWeightType;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorOffset;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorPow;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorReverse;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float                _SoftParticleFade;
	UNITY_UNIFORM float                _SoftParticleFade2;
	UNITY_UNIFORM mediump float                _SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform highp sampler2D _CameraDepthTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(2) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(3) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
in highp  vec3 vs_TEXCOORD14;
in highp  vec4 vs_TEXCOORD15;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
vec2 u_xlat1;
mediump vec4 u_xlat16_1;
mediump vec2 u_xlat16_2;
float u_xlat3;
vec2 u_xlat4;
mediump vec2 u_xlat16_4;
vec2 u_xlat7;
float u_xlat9;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = vs_TEXCOORD15.xy / vs_TEXCOORD15.ww;
    u_xlat0.x = texture(_CameraDepthTexture, u_xlat0.xy, _GlobalMipBias.x).x;
    u_xlat0.x = _ZBufferParams.z * u_xlat0.x + _ZBufferParams.w;
    u_xlat0.x = float(1.0) / u_xlat0.x;
    u_xlat0.x = u_xlat0.x + (-vs_TEXCOORD14.z);
    u_xlat3 = (-vs_TEXCOORD14.y) + vs_TEXCOORD14.x;
    u_xlat3 = vs_COLOR0.w * u_xlat3 + vs_TEXCOORD14.y;
    u_xlat0.x = u_xlat0.x * u_xlat3;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.w = u_xlat0.x * vs_COLOR0.w;
    u_xlat1.x = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat1.x = u_xlat1.x * 0.5 + 0.5;
    u_xlat1.x = u_xlat1.x * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat1.x = u_xlat1.x * 0.300000012;
    u_xlat16_4.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat4.xy = u_xlat16_4.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat7.xy = u_xlat4.yy * vs_TEXCOORD4.xy;
    u_xlat4.xy = u_xlat4.xx * vs_TEXCOORD3.xy + u_xlat7.xy;
    u_xlat16_2.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat4.xy = u_xlat4.xy * u_xlat16_2.xx;
    u_xlat1.xy = u_xlat1.xx * u_xlat4.xy;
    u_xlat1.xy = u_xlat1.xy * vec2(vec2(_DistortionScale0, _DistortionScale0)) + vs_TEXCOORD2.xy;
    u_xlat1.xy = u_xlat1.xy * vec2(0.5, 0.5);
    u_xlat1.xy = fract(u_xlat1.xy);
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat1.xy = -abs(u_xlat1.xy) + vec2(1.0, 1.0);
    u_xlat16_1.xyz = texture(_CameraTransparentTexture, u_xlat1.xy, _GlobalMipBias.x).xyz;
    u_xlat16_1.w = 1.0;
    u_xlat0.xyz = vs_COLOR0.xyz;
    u_xlat0 = u_xlat0 * u_xlat16_1;
    u_xlat9 = u_xlat16_2.y * u_xlat0.w;
    SV_Target0.xyz = vec3(u_xlat9) * u_xlat0.xyz;
    SV_Target0.w = u_xlat9;
    return;
}

#endif
9

// ===== program 6: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _BlurStep;
	UNITY_UNIFORM float                _BlurWeightType;
	UNITY_UNIFORM float                _ColorOffset;
	UNITY_UNIFORM float                _ColorPow;
	UNITY_UNIFORM float                _ColorReverse;
	UNITY_UNIFORM float                _ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float                _SoftParticleFade;
	UNITY_UNIFORM float                _SoftParticleFade2;
	UNITY_UNIFORM mediump float                _SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
out highp vec4 vs_COLOR0;
out highp vec2 vs_TEXCOORD0;
out highp vec2 vs_TEXCOORD1;
out highp vec2 vs_TEXCOORD2;
out highp vec3 vs_TEXCOORD3;
out highp vec3 vs_TEXCOORD4;
out highp vec3 vs_TEXCOORD14;
out highp vec4 vs_TEXCOORD15;
vec3 u_xlat0;
vec4 u_xlat1;
vec4 u_xlat2;
bvec2 u_xlatb2;
vec3 u_xlat3;
float u_xlat4;
bvec3 u_xlatb4;
vec3 u_xlat5;
float u_xlat6;
vec2 u_xlat13;
vec2 u_xlat14;
vec2 u_xlat15;
float u_xlat18;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat1 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat1;
    u_xlat2.xyz = in_COLOR0.xyz * _Color.xyz;
    u_xlat3.xyz = max(u_xlat2.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat3.xyz = u_xlat3.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat3.xyz = log2(u_xlat3.xyz);
    u_xlat3.xyz = u_xlat3.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat3.xyz = exp2(u_xlat3.xyz);
    u_xlatb4.xyz = lessThan(u_xlat2.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    {
        vec4 hlslcc_movcTemp = u_xlat2;
        hlslcc_movcTemp.x = (u_xlatb4.x) ? u_xlat2.x : u_xlat3.x;
        hlslcc_movcTemp.y = (u_xlatb4.y) ? u_xlat2.y : u_xlat3.y;
        hlslcc_movcTemp.z = (u_xlatb4.z) ? u_xlat2.z : u_xlat3.z;
        u_xlat2 = hlslcc_movcTemp;
    }
    u_xlat3.xyz = max(in_COLOR0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat3.xyz = u_xlat3.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat3.xyz = log2(u_xlat3.xyz);
    u_xlat3.xyz = u_xlat3.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat3.xyz = exp2(u_xlat3.xyz);
    u_xlatb4.xyz = lessThan(in_COLOR0.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat5.xyz = in_COLOR0.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    {
        vec3 hlslcc_movcTemp = u_xlat3;
        hlslcc_movcTemp.x = (u_xlatb4.x) ? u_xlat5.x : u_xlat3.x;
        hlslcc_movcTemp.y = (u_xlatb4.y) ? u_xlat5.y : u_xlat3.y;
        hlslcc_movcTemp.z = (u_xlatb4.z) ? u_xlat5.z : u_xlat3.z;
        u_xlat3 = hlslcc_movcTemp;
    }
    u_xlat2.xyz = (-u_xlat3.xyz) * _Color.xyz + u_xlat2.xyz;
    u_xlat3.xyz = u_xlat3.xyz * _Color.xyz;
    u_xlat2.xyz = vec3(_IsGammaColor) * u_xlat2.xyz + u_xlat3.xyz;
    u_xlat18 = _Luminance + 1.0;
    vs_COLOR0.xyz = vec3(u_xlat18) * u_xlat2.xyz;
    u_xlat18 = _Transparency * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat18 = (-u_xlat18) + 1.0;
    vs_COLOR0.w = u_xlat18 * in_COLOR0.w;
    u_xlatb2.xy = greaterThanEqual(_DistortionTex0_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat2.x = (u_xlatb2.x) ? float(1.0) : float(-1.0);
    u_xlat2.y = (u_xlatb2.y) ? float(1.0) : float(-1.0);
    u_xlat14.xy = max(abs(_DistortionTex0_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat2.xy = u_xlat2.xy * u_xlat14.xy;
    u_xlat18 = _DistortionTex0_R * 0.0174532924;
    u_xlat3.x = sin(u_xlat18);
    u_xlat4 = cos(u_xlat18);
    u_xlat5.z = u_xlat3.x;
    u_xlat14.xy = in_TEXCOORD0.xy + (-_DistortionTex0_ST.zw);
    u_xlat5.y = u_xlat4;
    u_xlat5.x = (-u_xlat3.x);
    u_xlat3.y = dot(u_xlat14.xy, u_xlat5.xy);
    u_xlat3.x = dot(u_xlat14.xy, u_xlat5.yz);
    vs_TEXCOORD0.xy = u_xlat3.xy / u_xlat2.xy;
    u_xlatb2.xy = greaterThanEqual(_MaskTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat2.x = (u_xlatb2.x) ? float(1.0) : float(-1.0);
    u_xlat2.y = (u_xlatb2.y) ? float(1.0) : float(-1.0);
    u_xlat14.xy = max(abs(_MaskTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat2.xy = u_xlat2.xy * u_xlat14.xy;
    u_xlat18 = _MaskTex_R * 0.0174532924;
    u_xlat3.x = sin(u_xlat18);
    u_xlat4 = cos(u_xlat18);
    u_xlat5.z = u_xlat3.x;
    u_xlat14.xy = in_TEXCOORD1.xy + (-_MaskTex_ST.zw);
    u_xlat5.y = u_xlat4;
    u_xlat5.x = (-u_xlat3.x);
    u_xlat15.y = dot(u_xlat14.xy, u_xlat5.xy);
    u_xlat15.x = dot(u_xlat14.xy, u_xlat5.yz);
    vs_TEXCOORD1.xy = u_xlat15.xy / u_xlat2.xy;
    u_xlat18 = u_xlat1.y * _ProjectionParams.x;
    u_xlat2.w = u_xlat18 * 0.5;
    u_xlat2.xz = u_xlat1.xw * vec2(0.5, 0.5);
    u_xlat1.xy = u_xlat2.zz + u_xlat2.xw;
    u_xlat2.xy = u_xlat1.xy / u_xlat1.ww;
    vs_TEXCOORD15 = u_xlat1;
    u_xlat1.xy = u_xlat2.xy + vec2(-0.5, -0.5);
    vs_TEXCOORD2.xy = (-u_xlat1.xy) * vec2(vec2(_Expansion, _Expansion)) + u_xlat2.xy;
    u_xlat1.z = hlslcc_mtx4x4unity_ObjectToWorld[2].y;
    u_xlat1.x = hlslcc_mtx4x4unity_ObjectToWorld[0].y;
    u_xlat1.y = hlslcc_mtx4x4unity_ObjectToWorld[1].y;
    u_xlat18 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat18 = sqrt(u_xlat18);
    u_xlat18 = max(u_xlat18, 9.99999997e-07);
    u_xlat1.xy = u_xlat1.xy / vec2(u_xlat18);
    u_xlat2 = u_xlat1.xyxy * hlslcc_mtx4x4unity_MatrixV[1].xxyy;
    u_xlat1.xy = u_xlat1.xy * hlslcc_mtx4x4unity_MatrixV[1].zz;
    u_xlat3.z = hlslcc_mtx4x4unity_ObjectToWorld[2].x;
    u_xlat3.x = hlslcc_mtx4x4unity_ObjectToWorld[0].x;
    u_xlat3.y = hlslcc_mtx4x4unity_ObjectToWorld[1].x;
    u_xlat18 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat18 = sqrt(u_xlat18);
    u_xlat18 = max(u_xlat18, 9.99999997e-07);
    u_xlat13.xy = u_xlat3.xy / vec2(u_xlat18);
    u_xlat2 = u_xlat13.xyxy * hlslcc_mtx4x4unity_MatrixV[0].xxyy + u_xlat2;
    u_xlat1.xy = u_xlat13.xy * hlslcc_mtx4x4unity_MatrixV[0].zz + u_xlat1.xy;
    u_xlat3.z = hlslcc_mtx4x4unity_ObjectToWorld[2].z;
    u_xlat3.x = hlslcc_mtx4x4unity_ObjectToWorld[0].z;
    u_xlat3.y = hlslcc_mtx4x4unity_ObjectToWorld[1].z;
    u_xlat18 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat18 = sqrt(u_xlat18);
    u_xlat18 = max(u_xlat18, 9.99999997e-07);
    u_xlat13.xy = u_xlat3.xy / vec2(u_xlat18);
    u_xlat2 = u_xlat13.xyxy * hlslcc_mtx4x4unity_MatrixV[2].xxyy + u_xlat2;
    u_xlat1.xy = u_xlat13.xy * hlslcc_mtx4x4unity_MatrixV[2].zz + u_xlat1.xy;
    u_xlat1.zw = u_xlat2.xz;
    vs_TEXCOORD4.xy = u_xlat2.yw;
    vs_TEXCOORD3.xyz = u_xlat1.zwx;
    vs_TEXCOORD4.z = u_xlat1.y;
    u_xlat6 = u_xlat0.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat0.x + u_xlat6;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat0.z + u_xlat0.x;
    u_xlat0.x = u_xlat0.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    vs_TEXCOORD14.z = abs(u_xlat0.x);
    u_xlat0.x = (-_SoftParticleFade) + 1.0;
    u_xlat0.x = u_xlat0.x * _SoftParDistance;
    u_xlat0.x = max(u_xlat0.x, 9.99999975e-05);
    u_xlat6 = (-u_xlat0.x) + _SoftParDistance;
    u_xlat6 = _SoftParticleFade2 * u_xlat6 + u_xlat0.x;
    vs_TEXCOORD14.x = float(1.0) / u_xlat0.x;
    vs_TEXCOORD14.y = float(1.0) / u_xlat6;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ZBufferParams;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _BlurStep;
	UNITY_UNIFORM float                _BlurWeightType;
	UNITY_UNIFORM float                _ColorOffset;
	UNITY_UNIFORM float                _ColorPow;
	UNITY_UNIFORM float                _ColorReverse;
	UNITY_UNIFORM float                _ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float                _SoftParticleFade;
	UNITY_UNIFORM float                _SoftParticleFade2;
	UNITY_UNIFORM mediump float                _SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform highp sampler2D _CameraDepthTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(2) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(3) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
in highp  vec3 vs_TEXCOORD14;
in highp  vec4 vs_TEXCOORD15;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
mediump vec3 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
vec4 u_xlat3;
mediump vec3 u_xlat16_3;
vec4 u_xlat4;
mediump vec3 u_xlat16_4;
vec2 u_xlat5;
mediump vec2 u_xlat16_5;
vec2 u_xlat10;
float u_xlat11;
float u_xlat15;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.x = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat0.x = u_xlat0.x * 0.5 + 0.5;
    u_xlat0.x = u_xlat0.x * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat0.x = u_xlat0.x * 0.300000012;
    u_xlat16_5.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat5.xy = u_xlat16_5.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = u_xlat5.yy * vs_TEXCOORD4.xy;
    u_xlat5.xy = u_xlat5.xx * vs_TEXCOORD3.xy + u_xlat10.xy;
    u_xlat16_1.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat5.xy = u_xlat5.xy * u_xlat16_1.xx;
    u_xlat0.xy = u_xlat0.xx * u_xlat5.xy;
    u_xlat10.x = _BlurStep + _DistortionScale0;
    u_xlat10.xy = u_xlat0.xy * u_xlat10.xx + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_1.xzw = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_1.xzw * vec3(0.238095239, 0.238095239, 0.238095239);
    u_xlat10.xy = u_xlat0.xy * vec2(vec2(_DistortionScale0, _DistortionScale0)) + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.285714298, 0.285714298, 0.285714298) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat16_1.xzw + u_xlat16_3.xyz;
    u_xlat10.x = _BlurStep * 2.0 + _DistortionScale0;
    u_xlat10.xy = u_xlat0.xy * u_xlat10.xx + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.190476194, 0.190476194, 0.190476194) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat1.xzw + u_xlat16_3.xyz;
    u_xlat3.xyz = vec3(vec3(_BlurStep, _BlurStep, _BlurStep)) * vec3(3.0, 4.0, 5.0) + vec3(vec3(_DistortionScale0, _DistortionScale0, _DistortionScale0));
    u_xlat4 = u_xlat0.xyxy * u_xlat3.xxyy + vs_TEXCOORD2.xyxy;
    u_xlat0.xy = u_xlat0.xy * u_xlat3.zz + vs_TEXCOORD2.xy;
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlat0.xy = fract(u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
    u_xlat16_0.xyz = texture(_CameraTransparentTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat3 = u_xlat4 * vec4(0.5, 0.5, 0.5, 0.5);
    u_xlat3 = fract(u_xlat3);
    u_xlat3 = u_xlat3 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat3 = -abs(u_xlat3) + vec4(1.0, 1.0, 1.0, 1.0);
    u_xlat16_4.xyz = texture(_CameraTransparentTexture, u_xlat3.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat3.zw, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_4.xyz * vec3(0.142857149, 0.142857149, 0.142857149) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat1.xzw + u_xlat16_4.xyz;
    u_xlat1.xzw = u_xlat16_3.xyz + u_xlat1.xzw;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.095238097, 0.095238097, 0.095238097) + u_xlat2.xyz;
    u_xlat2.xyz = u_xlat16_0.xyz * vec3(0.0476190485, 0.0476190485, 0.0476190485) + u_xlat2.xyz;
    u_xlat0.xyz = u_xlat16_0.xyz + u_xlat1.xzw;
    u_xlat1.xzw = (-u_xlat0.xyz) * vec3(0.166666657, 0.166666657, 0.166666657) + u_xlat2.xyz;
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.166666657, 0.166666657, 0.166666657);
    u_xlat0.xyz = vec3(_BlurWeightType) * u_xlat1.xzw + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + vec3(vec3(_ColorOffset, _ColorOffset, _ColorOffset));
    u_xlat0.xyz = max(u_xlat0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat0.xyz = log2(u_xlat0.xyz);
    u_xlat0.xyz = u_xlat0.xyz * vec3(vec3(_ColorPow, _ColorPow, _ColorPow));
    u_xlat0.xyz = exp2(u_xlat0.xyz);
    u_xlat1.xzw = u_xlat0.xyz * vec3(-2.0, -2.0, -2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = vec3(vec3(_ColorReverse, _ColorReverse, _ColorReverse)) * u_xlat1.xzw + u_xlat0.xyz;
    u_xlat15 = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat0.xyz = (-vec3(u_xlat15)) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ColorSaturation) * u_xlat0.xyz + vec3(u_xlat15);
    u_xlat1.xz = vs_TEXCOORD15.xy / vs_TEXCOORD15.ww;
    u_xlat1.x = texture(_CameraDepthTexture, u_xlat1.xz, _GlobalMipBias.x).x;
    u_xlat1.x = _ZBufferParams.z * u_xlat1.x + _ZBufferParams.w;
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat1.x = u_xlat1.x + (-vs_TEXCOORD14.z);
    u_xlat11 = (-vs_TEXCOORD14.y) + vs_TEXCOORD14.x;
    u_xlat11 = vs_COLOR0.w * u_xlat11 + vs_TEXCOORD14.y;
    u_xlat1.x = u_xlat1.x * u_xlat11;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat2.w = u_xlat1.x * vs_COLOR0.w;
    u_xlat0.w = 1.0;
    u_xlat2.xyz = vs_COLOR0.xyz;
    u_xlat0 = u_xlat0 * u_xlat2;
    u_xlat15 = u_xlat16_1.y * u_xlat0.w;
    SV_Target0.xyz = vec3(u_xlat15) * u_xlat0.xyz;
    SV_Target0.w = u_xlat15;
    return;
}

#endif
9

// ===== program 7: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ZBufferParams;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _BlurStep;
	UNITY_UNIFORM float                _BlurWeightType;
	UNITY_UNIFORM float                _ColorOffset;
	UNITY_UNIFORM float                _ColorPow;
	UNITY_UNIFORM float                _ColorReverse;
	UNITY_UNIFORM float                _ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float Xhlslcc_UnusedX_UseSoftParticle;
	UNITY_UNIFORM float                _SoftParticleFade;
	UNITY_UNIFORM float                _SoftParticleFade2;
	UNITY_UNIFORM mediump float                _SoftParDistance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform highp sampler2D _CameraDepthTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(2) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(3) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
in highp  vec3 vs_TEXCOORD14;
in highp  vec4 vs_TEXCOORD15;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
mediump vec3 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
vec4 u_xlat3;
mediump vec3 u_xlat16_3;
vec4 u_xlat4;
mediump vec3 u_xlat16_4;
vec2 u_xlat5;
mediump vec2 u_xlat16_5;
vec2 u_xlat10;
float u_xlat11;
float u_xlat15;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.x = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat0.x = u_xlat0.x * 0.5 + 0.5;
    u_xlat0.x = u_xlat0.x * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat0.x = u_xlat0.x * 0.300000012;
    u_xlat16_5.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat5.xy = u_xlat16_5.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = u_xlat5.yy * vs_TEXCOORD4.xy;
    u_xlat5.xy = u_xlat5.xx * vs_TEXCOORD3.xy + u_xlat10.xy;
    u_xlat16_1.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat5.xy = u_xlat5.xy * u_xlat16_1.xx;
    u_xlat0.xy = u_xlat0.xx * u_xlat5.xy;
    u_xlat10.x = _BlurStep + _DistortionScale0;
    u_xlat10.xy = u_xlat0.xy * u_xlat10.xx + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_1.xzw = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_1.xzw * vec3(0.238095239, 0.238095239, 0.238095239);
    u_xlat10.xy = u_xlat0.xy * vec2(vec2(_DistortionScale0, _DistortionScale0)) + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.285714298, 0.285714298, 0.285714298) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat16_1.xzw + u_xlat16_3.xyz;
    u_xlat10.x = _BlurStep * 2.0 + _DistortionScale0;
    u_xlat10.xy = u_xlat0.xy * u_xlat10.xx + vs_TEXCOORD2.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(0.5, 0.5);
    u_xlat10.xy = fract(u_xlat10.xy);
    u_xlat10.xy = u_xlat10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = -abs(u_xlat10.xy) + vec2(1.0, 1.0);
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat10.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.190476194, 0.190476194, 0.190476194) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat1.xzw + u_xlat16_3.xyz;
    u_xlat3.xyz = vec3(vec3(_BlurStep, _BlurStep, _BlurStep)) * vec3(3.0, 4.0, 5.0) + vec3(vec3(_DistortionScale0, _DistortionScale0, _DistortionScale0));
    u_xlat4 = u_xlat0.xyxy * u_xlat3.xxyy + vs_TEXCOORD2.xyxy;
    u_xlat0.xy = u_xlat0.xy * u_xlat3.zz + vs_TEXCOORD2.xy;
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlat0.xy = fract(u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
    u_xlat16_0.xyz = texture(_CameraTransparentTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat3 = u_xlat4 * vec4(0.5, 0.5, 0.5, 0.5);
    u_xlat3 = fract(u_xlat3);
    u_xlat3 = u_xlat3 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat3 = -abs(u_xlat3) + vec4(1.0, 1.0, 1.0, 1.0);
    u_xlat16_4.xyz = texture(_CameraTransparentTexture, u_xlat3.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat3.zw, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_4.xyz * vec3(0.142857149, 0.142857149, 0.142857149) + u_xlat2.xyz;
    u_xlat1.xzw = u_xlat1.xzw + u_xlat16_4.xyz;
    u_xlat1.xzw = u_xlat16_3.xyz + u_xlat1.xzw;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.095238097, 0.095238097, 0.095238097) + u_xlat2.xyz;
    u_xlat2.xyz = u_xlat16_0.xyz * vec3(0.0476190485, 0.0476190485, 0.0476190485) + u_xlat2.xyz;
    u_xlat0.xyz = u_xlat16_0.xyz + u_xlat1.xzw;
    u_xlat1.xzw = (-u_xlat0.xyz) * vec3(0.166666657, 0.166666657, 0.166666657) + u_xlat2.xyz;
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.166666657, 0.166666657, 0.166666657);
    u_xlat0.xyz = vec3(_BlurWeightType) * u_xlat1.xzw + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + vec3(vec3(_ColorOffset, _ColorOffset, _ColorOffset));
    u_xlat0.xyz = max(u_xlat0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat0.xyz = log2(u_xlat0.xyz);
    u_xlat0.xyz = u_xlat0.xyz * vec3(vec3(_ColorPow, _ColorPow, _ColorPow));
    u_xlat0.xyz = exp2(u_xlat0.xyz);
    u_xlat1.xzw = u_xlat0.xyz * vec3(-2.0, -2.0, -2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = vec3(vec3(_ColorReverse, _ColorReverse, _ColorReverse)) * u_xlat1.xzw + u_xlat0.xyz;
    u_xlat15 = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat0.xyz = (-vec3(u_xlat15)) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ColorSaturation) * u_xlat0.xyz + vec3(u_xlat15);
    u_xlat1.xz = vs_TEXCOORD15.xy / vs_TEXCOORD15.ww;
    u_xlat1.x = texture(_CameraDepthTexture, u_xlat1.xz, _GlobalMipBias.x).x;
    u_xlat1.x = _ZBufferParams.z * u_xlat1.x + _ZBufferParams.w;
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat1.x = u_xlat1.x + (-vs_TEXCOORD14.z);
    u_xlat11 = (-vs_TEXCOORD14.y) + vs_TEXCOORD14.x;
    u_xlat11 = vs_COLOR0.w * u_xlat11 + vs_TEXCOORD14.y;
    u_xlat1.x = u_xlat1.x * u_xlat11;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat2.w = u_xlat1.x * vs_COLOR0.w;
    u_xlat0.w = 1.0;
    u_xlat2.xyz = vs_COLOR0.xyz;
    u_xlat0 = u_xlat0 * u_xlat2;
    u_xlat15 = u_xlat16_1.y * u_xlat0.w;
    SV_Target0.xyz = vec3(u_xlat15) * u_xlat0.xyz;
    SV_Target0.w = u_xlat15;
    return;
}

#endif
9
