// Soccer/ScreenDistortion (Shader path ID 2483037877761757641, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_1[4];
uniform 	vec4 _Time;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _DistortionScroll;
	UNITY_UNIFORM vec4                _DistortionTexUVTileController;
	UNITY_UNIFORM float                _DistortionTexUVAutoOffset;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM vec4                _MaskScroll;
	UNITY_UNIFORM vec4                _MaskTexUVTileController;
	UNITY_UNIFORM float                _MaskTexUVAutoOffset;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _DistortionScaleController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPower;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRangeController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPowerController;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_FresnelColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelBlendMode;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FlipFresnelColorRange;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensity;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensityController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveEdgeWidth;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveEdgeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTexUVTileController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurStep;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurWeightType;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorOffset;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorPow;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorReverse;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float                _UsePackedStreams;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_COLOR0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
in highp vec4 in_TEXCOORD3;
out highp vec4 vs_COLOR0;
out highp vec2 vs_TEXCOORD0;
out highp vec2 vs_TEXCOORD1;
out highp vec2 vs_TEXCOORD2;
out highp vec3 vs_TEXCOORD3;
out highp vec3 vs_TEXCOORD4;
highp vec4 vs_TEXCOORD5;
highp vec3 vs_TEXCOORD6;
highp vec3 vs_TEXCOORD7;
out highp vec4 vs_TEXCOORD8;
out highp vec4 vs_TEXCOORD9;
vec3 u_xlat0;
vec4 u_xlat1;
vec4 u_xlat2;
bvec3 u_xlatb2;
vec4 u_xlat3;
vec4 u_xlat4;
vec4 u_xlat5;
int u_xlati5;
bvec4 u_xlatb5;
vec4 u_xlat6;
vec3 u_xlat7;
vec3 u_xlat8;
bool u_xlatb14;
vec2 u_xlat20;
int u_xlati20;
bvec2 u_xlatb20;
vec2 u_xlat23;
float u_xlat27;
int u_xlati27;
bool u_xlatb27;
bool u_xlatb29;
void main()
{
ImmCB_1[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_1[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_1[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_1[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat1 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlatb2.xyz = lessThan(in_COLOR0.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat3.xyz = in_COLOR0.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    u_xlat4.xyz = max(in_COLOR0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat4.xyz = u_xlat4.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat4.xyz = log2(u_xlat4.xyz);
    u_xlat4.xyz = u_xlat4.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat4.xyz = exp2(u_xlat4.xyz);
    u_xlat2.x = (u_xlatb2.x) ? u_xlat3.x : u_xlat4.x;
    u_xlat2.y = (u_xlatb2.y) ? u_xlat3.y : u_xlat4.y;
    u_xlat2.z = (u_xlatb2.z) ? u_xlat3.z : u_xlat4.z;
    u_xlat3.xyz = u_xlat2.xyz * _Color.xyz;
    u_xlat4.xyz = in_COLOR0.xyz * _Color.xyz;
    u_xlatb5.xyz = lessThan(u_xlat4.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat6.xyz = u_xlat4.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    u_xlat4.xyz = max(u_xlat4.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat4.xyz = u_xlat4.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat4.xyz = log2(u_xlat4.xyz);
    u_xlat4.xyz = u_xlat4.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat4.xyz = exp2(u_xlat4.xyz);
    {
        vec4 hlslcc_movcTemp = u_xlat4;
        hlslcc_movcTemp.x = (u_xlatb5.x) ? u_xlat6.x : u_xlat4.x;
        hlslcc_movcTemp.y = (u_xlatb5.y) ? u_xlat6.y : u_xlat4.y;
        hlslcc_movcTemp.z = (u_xlatb5.z) ? u_xlat6.z : u_xlat4.z;
        u_xlat4 = hlslcc_movcTemp;
    }
    u_xlat2.xyz = (-u_xlat2.xyz) * _Color.xyz + u_xlat4.xyz;
    u_xlat2.xyz = vec3(_IsGammaColor) * u_xlat2.xyz + u_xlat3.xyz;
    u_xlat27 = _Luminance + 1.0;
    vs_COLOR0.xyz = vec3(u_xlat27) * u_xlat2.xyz;
    u_xlat27 = _Transparency * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat27 = (-u_xlat27) + 1.0;
    vs_COLOR0.w = u_xlat27 * in_COLOR0.w;
    u_xlatb27 = 0.5<_UsePackedStreams;
    u_xlat2.xy = (bool(u_xlatb27)) ? in_TEXCOORD0.zw : in_TEXCOORD1.xy;
    u_xlat3 = (bool(u_xlatb27)) ? in_TEXCOORD1 : in_TEXCOORD2;
    u_xlat4 = (bool(u_xlatb27)) ? in_TEXCOORD2 : in_TEXCOORD3;
    u_xlatb5 = greaterThanEqual(_DistortionTexUVTileController, vec4(1.0, 1.0, 1.0, 1.0));
    if(u_xlatb5.x){
        u_xlati27 = int(_DistortionTexUVTileController.x);
        u_xlati20 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb29 = u_xlati20<4;
        if(u_xlatb29){
            u_xlat6.x = dot(u_xlat3, ImmCB_1[u_xlati20]);
        } else {
            u_xlat6.x = 0.0;
        }
        if(!u_xlatb29){
            u_xlatb20.x = u_xlati20<8;
            if(u_xlatb20.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.x = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.x = u_xlatb20.x ? u_xlat6.x : float(0.0);
        }
    } else {
        u_xlat6.x = 0.0;
    }
    if(u_xlatb5.y){
        u_xlati27 = int(_DistortionTexUVTileController.y);
        u_xlati20 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb29 = u_xlati20<4;
        if(u_xlatb29){
            u_xlat6.y = dot(u_xlat3, ImmCB_1[u_xlati20]);
        } else {
            u_xlat6.y = 0.0;
        }
        if(!u_xlatb29){
            u_xlatb20.x = u_xlati20<8;
            if(u_xlatb20.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.y = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.y = u_xlatb20.x ? u_xlat6.y : float(0.0);
        }
    } else {
        u_xlat6.y = 0.0;
    }
    u_xlat20.xy = u_xlat6.xy + _DistortionTex0_ST.xy;
    if(u_xlatb5.z){
        u_xlati27 = int(_DistortionTexUVTileController.z);
        u_xlati5 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb14 = u_xlati5<4;
        if(u_xlatb14){
            u_xlat6.x = dot(u_xlat3, ImmCB_1[u_xlati5]);
        } else {
            u_xlat6.x = 0.0;
        }
        if(!u_xlatb14){
            u_xlatb5.x = u_xlati5<8;
            if(u_xlatb5.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.x = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.x = u_xlatb5.x ? u_xlat6.x : float(0.0);
        }
    } else {
        u_xlat6.x = 0.0;
    }
    if(u_xlatb5.w){
        u_xlati27 = int(_DistortionTexUVTileController.w);
        u_xlati5 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb14 = u_xlati5<4;
        if(u_xlatb14){
            u_xlat6.y = dot(u_xlat3, ImmCB_1[u_xlati5]);
        } else {
            u_xlat6.y = 0.0;
        }
        if(!u_xlatb14){
            u_xlatb5.x = u_xlati5<8;
            if(u_xlatb5.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.y = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.y = u_xlatb5.x ? u_xlat6.y : float(0.0);
        }
    } else {
        u_xlat6.y = 0.0;
    }
    u_xlat5.xy = u_xlat6.xy + _DistortionTex0_ST.zw;
    u_xlatb27 = 0.5<_DistortionTexUVAutoOffset;
    u_xlat23.xy = u_xlat5.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat5.xy = (bool(u_xlatb27)) ? u_xlat23.xy : u_xlat5.xy;
    u_xlat5.xy = (-u_xlat5.xy) + in_TEXCOORD0.xy;
    u_xlat27 = _DistortionTex0_R * 0.0174532924;
    u_xlat6.x = sin(u_xlat27);
    u_xlat7.x = cos(u_xlat27);
    u_xlat8.x = (-u_xlat6.x);
    u_xlat8.y = u_xlat7.x;
    u_xlat8.z = u_xlat6.x;
    u_xlat6.x = dot(u_xlat5.xy, u_xlat8.yz);
    u_xlat6.y = dot(u_xlat5.xy, u_xlat8.xy);
    u_xlat5.xy = max(abs(u_xlat20.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlatb20.xy = greaterThanEqual(u_xlat20.xyxy, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat20.x = (u_xlatb20.x) ? float(1.0) : float(-1.0);
    u_xlat20.y = (u_xlatb20.y) ? float(1.0) : float(-1.0);
    u_xlat20.xy = u_xlat20.xy * u_xlat5.xy;
    u_xlat20.xy = u_xlat6.xy / u_xlat20.xy;
    vs_TEXCOORD0.xy = _DistortionScroll.xy * _Time.yy + u_xlat20.xy;
    u_xlatb5 = greaterThanEqual(_MaskTexUVTileController, vec4(1.0, 1.0, 1.0, 1.0));
    if(u_xlatb5.x){
        u_xlati27 = int(_MaskTexUVTileController.x);
        u_xlati20 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb29 = u_xlati20<4;
        if(u_xlatb29){
            u_xlat6.x = dot(u_xlat3, ImmCB_1[u_xlati20]);
        } else {
            u_xlat6.x = 0.0;
        }
        if(!u_xlatb29){
            u_xlatb20.x = u_xlati20<8;
            if(u_xlatb20.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.x = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.x = u_xlatb20.x ? u_xlat6.x : float(0.0);
        }
    } else {
        u_xlat6.x = 0.0;
    }
    if(u_xlatb5.y){
        u_xlati27 = int(_MaskTexUVTileController.y);
        u_xlati20 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb29 = u_xlati20<4;
        if(u_xlatb29){
            u_xlat6.y = dot(u_xlat3, ImmCB_1[u_xlati20]);
        } else {
            u_xlat6.y = 0.0;
        }
        if(!u_xlatb29){
            u_xlatb20.x = u_xlati20<8;
            if(u_xlatb20.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.y = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.y = u_xlatb20.x ? u_xlat6.y : float(0.0);
        }
    } else {
        u_xlat6.y = 0.0;
    }
    u_xlat20.xy = u_xlat6.xy + _MaskTex_ST.xy;
    if(u_xlatb5.z){
        u_xlati27 = int(_MaskTexUVTileController.z);
        u_xlati5 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb14 = u_xlati5<4;
        if(u_xlatb14){
            u_xlat6.x = dot(u_xlat3, ImmCB_1[u_xlati5]);
        } else {
            u_xlat6.x = 0.0;
        }
        if(!u_xlatb14){
            u_xlatb5.x = u_xlati5<8;
            if(u_xlatb5.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.x = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.x = u_xlatb5.x ? u_xlat6.x : float(0.0);
        }
    } else {
        u_xlat6.x = 0.0;
    }
    if(u_xlatb5.w){
        u_xlati27 = int(_MaskTexUVTileController.w);
        u_xlati5 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb14 = u_xlati5<4;
        if(u_xlatb14){
            u_xlat6.y = dot(u_xlat3, ImmCB_1[u_xlati5]);
        } else {
            u_xlat6.y = 0.0;
        }
        if(!u_xlatb14){
            u_xlatb5.x = u_xlati5<8;
            if(u_xlatb5.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.y = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.y = u_xlatb5.x ? u_xlat6.y : float(0.0);
        }
    } else {
        u_xlat6.y = 0.0;
    }
    u_xlat5.xy = u_xlat6.xy + _MaskTex_ST.zw;
    u_xlatb27 = 0.5<_MaskTexUVAutoOffset;
    u_xlat23.xy = u_xlat5.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat5.xy = (bool(u_xlatb27)) ? u_xlat23.xy : u_xlat5.xy;
    u_xlat2.xy = u_xlat2.xy + (-u_xlat5.xy);
    u_xlat27 = _MaskTex_R * 0.0174532924;
    u_xlat5.x = sin(u_xlat27);
    u_xlat6.x = cos(u_xlat27);
    u_xlat7.x = (-u_xlat5.x);
    u_xlat7.y = u_xlat6.x;
    u_xlat7.z = u_xlat5.x;
    u_xlat23.x = dot(u_xlat2.xy, u_xlat7.yz);
    u_xlat23.y = dot(u_xlat2.xy, u_xlat7.xy);
    u_xlat2.xy = max(abs(u_xlat20.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlatb20.xy = greaterThanEqual(u_xlat20.xyxy, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat20.x = (u_xlatb20.x) ? float(1.0) : float(-1.0);
    u_xlat20.y = (u_xlatb20.y) ? float(1.0) : float(-1.0);
    u_xlat2.xy = u_xlat20.xy * u_xlat2.xy;
    u_xlat2.xy = u_xlat23.xy / u_xlat2.xy;
    vs_TEXCOORD1.xy = _MaskScroll.xy * _Time.yy + u_xlat2.xy;
    u_xlat2.xz = u_xlat1.xw * vec2(0.5, 0.5);
    u_xlat27 = u_xlat1.y * _ProjectionParams.x;
    u_xlat2.w = u_xlat27 * 0.5;
    u_xlat2.xy = u_xlat2.zz + u_xlat2.xw;
    u_xlat20.xy = u_xlat2.xy / u_xlat1.ww;
    u_xlat5.xy = u_xlat20.xy + vec2(-0.5, -0.5);
    vs_TEXCOORD2.xy = (-u_xlat5.xy) * vec2(vec2(_Expansion, _Expansion)) + u_xlat20.xy;
    u_xlat5.x = hlslcc_mtx4x4unity_ObjectToWorld[0].x;
    u_xlat5.y = hlslcc_mtx4x4unity_ObjectToWorld[1].x;
    u_xlat5.z = hlslcc_mtx4x4unity_ObjectToWorld[2].x;
    u_xlat27 = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat27 = sqrt(u_xlat27);
    u_xlat27 = max(u_xlat27, 9.99999997e-07);
    u_xlat20.xy = u_xlat5.xy / vec2(u_xlat27);
    u_xlat5.x = hlslcc_mtx4x4unity_ObjectToWorld[0].y;
    u_xlat5.y = hlslcc_mtx4x4unity_ObjectToWorld[1].y;
    u_xlat5.z = hlslcc_mtx4x4unity_ObjectToWorld[2].y;
    u_xlat27 = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat27 = sqrt(u_xlat27);
    u_xlat27 = max(u_xlat27, 9.99999997e-07);
    u_xlat5.xy = u_xlat5.xy / vec2(u_xlat27);
    u_xlat6.x = hlslcc_mtx4x4unity_ObjectToWorld[0].z;
    u_xlat6.y = hlslcc_mtx4x4unity_ObjectToWorld[1].z;
    u_xlat6.z = hlslcc_mtx4x4unity_ObjectToWorld[2].z;
    u_xlat27 = dot(u_xlat6.xyz, u_xlat6.xyz);
    u_xlat27 = sqrt(u_xlat27);
    u_xlat27 = max(u_xlat27, 9.99999997e-07);
    u_xlat23.xy = u_xlat6.xy / vec2(u_xlat27);
    u_xlat6 = u_xlat5.xyxy * hlslcc_mtx4x4unity_MatrixV[1].xxyy;
    u_xlat6 = u_xlat20.xyxy * hlslcc_mtx4x4unity_MatrixV[0].xxyy + u_xlat6;
    u_xlat6 = u_xlat23.xyxy * hlslcc_mtx4x4unity_MatrixV[2].xxyy + u_xlat6;
    u_xlat5.xy = u_xlat5.xy * hlslcc_mtx4x4unity_MatrixV[1].zz;
    u_xlat20.xy = u_xlat20.xy * hlslcc_mtx4x4unity_MatrixV[0].zz + u_xlat5.xy;
    u_xlat5.xy = u_xlat23.xy * hlslcc_mtx4x4unity_MatrixV[2].zz + u_xlat20.xy;
    u_xlat7.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat7.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat7.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat27 = dot(u_xlat7.xyz, u_xlat7.xyz);
    u_xlat27 = max(u_xlat27, 1.17549435e-38);
    u_xlat27 = inversesqrt(u_xlat27);
    vs_TEXCOORD6.xyz = vec3(u_xlat27) * u_xlat7.xyz;
    gl_Position = u_xlat1;
    vs_TEXCOORD5.zw = u_xlat1.zw;
    vs_TEXCOORD5.xy = u_xlat2.xy;
    vs_TEXCOORD8 = u_xlat3;
    vs_TEXCOORD9 = u_xlat4;
    u_xlat5.zw = u_xlat6.xz;
    vs_TEXCOORD3.xyz = u_xlat5.zwx;
    vs_TEXCOORD4.xy = u_xlat6.yw;
    vs_TEXCOORD4.z = u_xlat5.y;
    vs_TEXCOORD7.xyz = u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _DistortionScroll;
	UNITY_UNIFORM vec4                _DistortionTexUVTileController;
	UNITY_UNIFORM float                _DistortionTexUVAutoOffset;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM vec4                _MaskScroll;
	UNITY_UNIFORM vec4                _MaskTexUVTileController;
	UNITY_UNIFORM float                _MaskTexUVAutoOffset;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _DistortionScaleController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPower;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRangeController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPowerController;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_FresnelColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelBlendMode;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FlipFresnelColorRange;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensity;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensityController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveEdgeWidth;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveEdgeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTexUVTileController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurStep;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurWeightType;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorOffset;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorPow;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorReverse;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float                _UsePackedStreams;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(2) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
in highp  vec4 vs_TEXCOORD8;
in highp  vec4 vs_TEXCOORD9;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
mediump vec2 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
int u_xlati1;
bool u_xlatb1;
vec2 u_xlat2;
bool u_xlatb3;
float u_xlat4;
mediump vec2 u_xlat16_4;
int u_xlati4;
bool u_xlatb4;
float u_xlat5;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat16_0.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat0.xy = u_xlat16_0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat2.xy = u_xlat0.yy * vs_TEXCOORD4.xy;
    u_xlat0.xy = u_xlat0.xx * vs_TEXCOORD3.xy + u_xlat2.xy;
    u_xlat16_4.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat0.xy = u_xlat16_4.xx * u_xlat0.xy;
    u_xlat4 = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat4 = u_xlat4 * 0.5 + 0.5;
    u_xlat4 = u_xlat4 * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat4 = u_xlat4 * 0.300000012;
    u_xlat0.xy = vec2(u_xlat4) * u_xlat0.xy;
    u_xlatb4 = 0.0<_DistortionScaleController;
    if(u_xlatb4){
        u_xlatb4 = _DistortionScaleController>=1.0;
        if(u_xlatb4){
            u_xlati4 = int(_DistortionScaleController);
            u_xlati1 = u_xlati4 + int(0xFFFFFFFFu);
            u_xlatb3 = u_xlati1<4;
            if(u_xlatb3){
                u_xlat5 = dot(vs_TEXCOORD8, ImmCB_0[u_xlati1]);
            } else {
                u_xlat5 = 0.0;
            }
            if(!u_xlatb3){
                u_xlatb1 = u_xlati1<8;
                if(u_xlatb1){
                    u_xlati4 = u_xlati4 + int(0xFFFFFFFBu);
                    u_xlat5 = dot(vs_TEXCOORD9, ImmCB_0[u_xlati4]);
                }
                u_xlat5 = u_xlatb1 ? u_xlat5 : float(0.0);
            }
        } else {
            u_xlat5 = 0.0;
        }
        u_xlat4 = u_xlat5 + _DistortionScale0;
    } else {
        u_xlat4 = _DistortionScale0;
    }
    u_xlat0.xy = u_xlat0.xy * vec2(u_xlat4) + vs_TEXCOORD2.xy;
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlat0.xy = fract(u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
    u_xlat16_1.xyz = texture(_CameraTransparentTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_1.w = 1.0;
    u_xlat1 = u_xlat16_1 * vs_COLOR0;
    u_xlat0.x = u_xlat16_4.y * u_xlat1.w;
    SV_Target0.xyz = u_xlat0.xxx * u_xlat1.xyz;
    SV_Target0.w = u_xlat0.x;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _DistortionScroll;
	UNITY_UNIFORM vec4                _DistortionTexUVTileController;
	UNITY_UNIFORM float                _DistortionTexUVAutoOffset;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM vec4                _MaskScroll;
	UNITY_UNIFORM vec4                _MaskTexUVTileController;
	UNITY_UNIFORM float                _MaskTexUVAutoOffset;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _DistortionScaleController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPower;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRangeController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPowerController;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_FresnelColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelBlendMode;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FlipFresnelColorRange;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensity;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensityController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveEdgeWidth;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveEdgeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTexUVTileController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurStep;
	UNITY_UNIFORM float Xhlslcc_UnusedX_BlurWeightType;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorOffset;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorPow;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorReverse;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float                _UsePackedStreams;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(2) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
in highp  vec4 vs_TEXCOORD8;
in highp  vec4 vs_TEXCOORD9;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
mediump vec2 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
int u_xlati1;
bool u_xlatb1;
vec2 u_xlat2;
bool u_xlatb3;
float u_xlat4;
mediump vec2 u_xlat16_4;
int u_xlati4;
bool u_xlatb4;
float u_xlat5;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat16_0.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat0.xy = u_xlat16_0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat2.xy = u_xlat0.yy * vs_TEXCOORD4.xy;
    u_xlat0.xy = u_xlat0.xx * vs_TEXCOORD3.xy + u_xlat2.xy;
    u_xlat16_4.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat0.xy = u_xlat16_4.xx * u_xlat0.xy;
    u_xlat4 = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat4 = u_xlat4 * 0.5 + 0.5;
    u_xlat4 = u_xlat4 * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat4 = u_xlat4 * 0.300000012;
    u_xlat0.xy = vec2(u_xlat4) * u_xlat0.xy;
    u_xlatb4 = 0.0<_DistortionScaleController;
    if(u_xlatb4){
        u_xlatb4 = _DistortionScaleController>=1.0;
        if(u_xlatb4){
            u_xlati4 = int(_DistortionScaleController);
            u_xlati1 = u_xlati4 + int(0xFFFFFFFFu);
            u_xlatb3 = u_xlati1<4;
            if(u_xlatb3){
                u_xlat5 = dot(vs_TEXCOORD8, ImmCB_0[u_xlati1]);
            } else {
                u_xlat5 = 0.0;
            }
            if(!u_xlatb3){
                u_xlatb1 = u_xlati1<8;
                if(u_xlatb1){
                    u_xlati4 = u_xlati4 + int(0xFFFFFFFBu);
                    u_xlat5 = dot(vs_TEXCOORD9, ImmCB_0[u_xlati4]);
                }
                u_xlat5 = u_xlatb1 ? u_xlat5 : float(0.0);
            }
        } else {
            u_xlat5 = 0.0;
        }
        u_xlat4 = u_xlat5 + _DistortionScale0;
    } else {
        u_xlat4 = _DistortionScale0;
    }
    u_xlat0.xy = u_xlat0.xy * vec2(u_xlat4) + vs_TEXCOORD2.xy;
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlat0.xy = fract(u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
    u_xlat16_1.xyz = texture(_CameraTransparentTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_1.w = 1.0;
    u_xlat1 = u_xlat16_1 * vs_COLOR0;
    u_xlat0.x = u_xlat16_4.y * u_xlat1.w;
    SV_Target0.xyz = u_xlat0.xxx * u_xlat1.xyz;
    SV_Target0.w = u_xlat0.x;
    return;
}

#endif


// ===== program 2: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_1[4];
uniform 	vec4 _Time;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _DistortionScroll;
	UNITY_UNIFORM vec4                _DistortionTexUVTileController;
	UNITY_UNIFORM float                _DistortionTexUVAutoOffset;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM vec4                _MaskScroll;
	UNITY_UNIFORM vec4                _MaskTexUVTileController;
	UNITY_UNIFORM float                _MaskTexUVAutoOffset;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _DistortionScaleController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPower;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRangeController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPowerController;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_FresnelColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelBlendMode;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FlipFresnelColorRange;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensity;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensityController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveEdgeWidth;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveEdgeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTexUVTileController;
	UNITY_UNIFORM float                _BlurStep;
	UNITY_UNIFORM float                _BlurWeightType;
	UNITY_UNIFORM float                _ColorOffset;
	UNITY_UNIFORM float                _ColorPow;
	UNITY_UNIFORM float                _ColorReverse;
	UNITY_UNIFORM float                _ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float                _UsePackedStreams;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_COLOR0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
in highp vec4 in_TEXCOORD3;
out highp vec4 vs_COLOR0;
out highp vec2 vs_TEXCOORD0;
out highp vec2 vs_TEXCOORD1;
out highp vec2 vs_TEXCOORD2;
out highp vec3 vs_TEXCOORD3;
out highp vec3 vs_TEXCOORD4;
highp vec4 vs_TEXCOORD5;
highp vec3 vs_TEXCOORD6;
highp vec3 vs_TEXCOORD7;
out highp vec4 vs_TEXCOORD8;
out highp vec4 vs_TEXCOORD9;
vec3 u_xlat0;
vec4 u_xlat1;
vec4 u_xlat2;
bvec3 u_xlatb2;
vec4 u_xlat3;
vec4 u_xlat4;
vec4 u_xlat5;
int u_xlati5;
bvec4 u_xlatb5;
vec4 u_xlat6;
vec3 u_xlat7;
vec3 u_xlat8;
bool u_xlatb14;
vec2 u_xlat20;
int u_xlati20;
bvec2 u_xlatb20;
vec2 u_xlat23;
float u_xlat27;
int u_xlati27;
bool u_xlatb27;
bool u_xlatb29;
void main()
{
ImmCB_1[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_1[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_1[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_1[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat1 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlatb2.xyz = lessThan(in_COLOR0.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat3.xyz = in_COLOR0.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    u_xlat4.xyz = max(in_COLOR0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat4.xyz = u_xlat4.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat4.xyz = log2(u_xlat4.xyz);
    u_xlat4.xyz = u_xlat4.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat4.xyz = exp2(u_xlat4.xyz);
    u_xlat2.x = (u_xlatb2.x) ? u_xlat3.x : u_xlat4.x;
    u_xlat2.y = (u_xlatb2.y) ? u_xlat3.y : u_xlat4.y;
    u_xlat2.z = (u_xlatb2.z) ? u_xlat3.z : u_xlat4.z;
    u_xlat3.xyz = u_xlat2.xyz * _Color.xyz;
    u_xlat4.xyz = in_COLOR0.xyz * _Color.xyz;
    u_xlatb5.xyz = lessThan(u_xlat4.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat6.xyz = u_xlat4.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    u_xlat4.xyz = max(u_xlat4.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat4.xyz = u_xlat4.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat4.xyz = log2(u_xlat4.xyz);
    u_xlat4.xyz = u_xlat4.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat4.xyz = exp2(u_xlat4.xyz);
    {
        vec4 hlslcc_movcTemp = u_xlat4;
        hlslcc_movcTemp.x = (u_xlatb5.x) ? u_xlat6.x : u_xlat4.x;
        hlslcc_movcTemp.y = (u_xlatb5.y) ? u_xlat6.y : u_xlat4.y;
        hlslcc_movcTemp.z = (u_xlatb5.z) ? u_xlat6.z : u_xlat4.z;
        u_xlat4 = hlslcc_movcTemp;
    }
    u_xlat2.xyz = (-u_xlat2.xyz) * _Color.xyz + u_xlat4.xyz;
    u_xlat2.xyz = vec3(_IsGammaColor) * u_xlat2.xyz + u_xlat3.xyz;
    u_xlat27 = _Luminance + 1.0;
    vs_COLOR0.xyz = vec3(u_xlat27) * u_xlat2.xyz;
    u_xlat27 = _Transparency * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat27 = (-u_xlat27) + 1.0;
    vs_COLOR0.w = u_xlat27 * in_COLOR0.w;
    u_xlatb27 = 0.5<_UsePackedStreams;
    u_xlat2.xy = (bool(u_xlatb27)) ? in_TEXCOORD0.zw : in_TEXCOORD1.xy;
    u_xlat3 = (bool(u_xlatb27)) ? in_TEXCOORD1 : in_TEXCOORD2;
    u_xlat4 = (bool(u_xlatb27)) ? in_TEXCOORD2 : in_TEXCOORD3;
    u_xlatb5 = greaterThanEqual(_DistortionTexUVTileController, vec4(1.0, 1.0, 1.0, 1.0));
    if(u_xlatb5.x){
        u_xlati27 = int(_DistortionTexUVTileController.x);
        u_xlati20 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb29 = u_xlati20<4;
        if(u_xlatb29){
            u_xlat6.x = dot(u_xlat3, ImmCB_1[u_xlati20]);
        } else {
            u_xlat6.x = 0.0;
        }
        if(!u_xlatb29){
            u_xlatb20.x = u_xlati20<8;
            if(u_xlatb20.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.x = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.x = u_xlatb20.x ? u_xlat6.x : float(0.0);
        }
    } else {
        u_xlat6.x = 0.0;
    }
    if(u_xlatb5.y){
        u_xlati27 = int(_DistortionTexUVTileController.y);
        u_xlati20 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb29 = u_xlati20<4;
        if(u_xlatb29){
            u_xlat6.y = dot(u_xlat3, ImmCB_1[u_xlati20]);
        } else {
            u_xlat6.y = 0.0;
        }
        if(!u_xlatb29){
            u_xlatb20.x = u_xlati20<8;
            if(u_xlatb20.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.y = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.y = u_xlatb20.x ? u_xlat6.y : float(0.0);
        }
    } else {
        u_xlat6.y = 0.0;
    }
    u_xlat20.xy = u_xlat6.xy + _DistortionTex0_ST.xy;
    if(u_xlatb5.z){
        u_xlati27 = int(_DistortionTexUVTileController.z);
        u_xlati5 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb14 = u_xlati5<4;
        if(u_xlatb14){
            u_xlat6.x = dot(u_xlat3, ImmCB_1[u_xlati5]);
        } else {
            u_xlat6.x = 0.0;
        }
        if(!u_xlatb14){
            u_xlatb5.x = u_xlati5<8;
            if(u_xlatb5.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.x = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.x = u_xlatb5.x ? u_xlat6.x : float(0.0);
        }
    } else {
        u_xlat6.x = 0.0;
    }
    if(u_xlatb5.w){
        u_xlati27 = int(_DistortionTexUVTileController.w);
        u_xlati5 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb14 = u_xlati5<4;
        if(u_xlatb14){
            u_xlat6.y = dot(u_xlat3, ImmCB_1[u_xlati5]);
        } else {
            u_xlat6.y = 0.0;
        }
        if(!u_xlatb14){
            u_xlatb5.x = u_xlati5<8;
            if(u_xlatb5.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.y = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.y = u_xlatb5.x ? u_xlat6.y : float(0.0);
        }
    } else {
        u_xlat6.y = 0.0;
    }
    u_xlat5.xy = u_xlat6.xy + _DistortionTex0_ST.zw;
    u_xlatb27 = 0.5<_DistortionTexUVAutoOffset;
    u_xlat23.xy = u_xlat5.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat5.xy = (bool(u_xlatb27)) ? u_xlat23.xy : u_xlat5.xy;
    u_xlat5.xy = (-u_xlat5.xy) + in_TEXCOORD0.xy;
    u_xlat27 = _DistortionTex0_R * 0.0174532924;
    u_xlat6.x = sin(u_xlat27);
    u_xlat7.x = cos(u_xlat27);
    u_xlat8.x = (-u_xlat6.x);
    u_xlat8.y = u_xlat7.x;
    u_xlat8.z = u_xlat6.x;
    u_xlat6.x = dot(u_xlat5.xy, u_xlat8.yz);
    u_xlat6.y = dot(u_xlat5.xy, u_xlat8.xy);
    u_xlat5.xy = max(abs(u_xlat20.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlatb20.xy = greaterThanEqual(u_xlat20.xyxy, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat20.x = (u_xlatb20.x) ? float(1.0) : float(-1.0);
    u_xlat20.y = (u_xlatb20.y) ? float(1.0) : float(-1.0);
    u_xlat20.xy = u_xlat20.xy * u_xlat5.xy;
    u_xlat20.xy = u_xlat6.xy / u_xlat20.xy;
    vs_TEXCOORD0.xy = _DistortionScroll.xy * _Time.yy + u_xlat20.xy;
    u_xlatb5 = greaterThanEqual(_MaskTexUVTileController, vec4(1.0, 1.0, 1.0, 1.0));
    if(u_xlatb5.x){
        u_xlati27 = int(_MaskTexUVTileController.x);
        u_xlati20 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb29 = u_xlati20<4;
        if(u_xlatb29){
            u_xlat6.x = dot(u_xlat3, ImmCB_1[u_xlati20]);
        } else {
            u_xlat6.x = 0.0;
        }
        if(!u_xlatb29){
            u_xlatb20.x = u_xlati20<8;
            if(u_xlatb20.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.x = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.x = u_xlatb20.x ? u_xlat6.x : float(0.0);
        }
    } else {
        u_xlat6.x = 0.0;
    }
    if(u_xlatb5.y){
        u_xlati27 = int(_MaskTexUVTileController.y);
        u_xlati20 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb29 = u_xlati20<4;
        if(u_xlatb29){
            u_xlat6.y = dot(u_xlat3, ImmCB_1[u_xlati20]);
        } else {
            u_xlat6.y = 0.0;
        }
        if(!u_xlatb29){
            u_xlatb20.x = u_xlati20<8;
            if(u_xlatb20.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.y = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.y = u_xlatb20.x ? u_xlat6.y : float(0.0);
        }
    } else {
        u_xlat6.y = 0.0;
    }
    u_xlat20.xy = u_xlat6.xy + _MaskTex_ST.xy;
    if(u_xlatb5.z){
        u_xlati27 = int(_MaskTexUVTileController.z);
        u_xlati5 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb14 = u_xlati5<4;
        if(u_xlatb14){
            u_xlat6.x = dot(u_xlat3, ImmCB_1[u_xlati5]);
        } else {
            u_xlat6.x = 0.0;
        }
        if(!u_xlatb14){
            u_xlatb5.x = u_xlati5<8;
            if(u_xlatb5.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.x = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.x = u_xlatb5.x ? u_xlat6.x : float(0.0);
        }
    } else {
        u_xlat6.x = 0.0;
    }
    if(u_xlatb5.w){
        u_xlati27 = int(_MaskTexUVTileController.w);
        u_xlati5 = u_xlati27 + int(0xFFFFFFFFu);
        u_xlatb14 = u_xlati5<4;
        if(u_xlatb14){
            u_xlat6.y = dot(u_xlat3, ImmCB_1[u_xlati5]);
        } else {
            u_xlat6.y = 0.0;
        }
        if(!u_xlatb14){
            u_xlatb5.x = u_xlati5<8;
            if(u_xlatb5.x){
                u_xlati27 = u_xlati27 + int(0xFFFFFFFBu);
                u_xlat6.y = dot(u_xlat4, ImmCB_1[u_xlati27]);
            }
            u_xlat6.y = u_xlatb5.x ? u_xlat6.y : float(0.0);
        }
    } else {
        u_xlat6.y = 0.0;
    }
    u_xlat5.xy = u_xlat6.xy + _MaskTex_ST.zw;
    u_xlatb27 = 0.5<_MaskTexUVAutoOffset;
    u_xlat23.xy = u_xlat5.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat5.xy = (bool(u_xlatb27)) ? u_xlat23.xy : u_xlat5.xy;
    u_xlat2.xy = u_xlat2.xy + (-u_xlat5.xy);
    u_xlat27 = _MaskTex_R * 0.0174532924;
    u_xlat5.x = sin(u_xlat27);
    u_xlat6.x = cos(u_xlat27);
    u_xlat7.x = (-u_xlat5.x);
    u_xlat7.y = u_xlat6.x;
    u_xlat7.z = u_xlat5.x;
    u_xlat23.x = dot(u_xlat2.xy, u_xlat7.yz);
    u_xlat23.y = dot(u_xlat2.xy, u_xlat7.xy);
    u_xlat2.xy = max(abs(u_xlat20.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlatb20.xy = greaterThanEqual(u_xlat20.xyxy, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat20.x = (u_xlatb20.x) ? float(1.0) : float(-1.0);
    u_xlat20.y = (u_xlatb20.y) ? float(1.0) : float(-1.0);
    u_xlat2.xy = u_xlat20.xy * u_xlat2.xy;
    u_xlat2.xy = u_xlat23.xy / u_xlat2.xy;
    vs_TEXCOORD1.xy = _MaskScroll.xy * _Time.yy + u_xlat2.xy;
    u_xlat2.xz = u_xlat1.xw * vec2(0.5, 0.5);
    u_xlat27 = u_xlat1.y * _ProjectionParams.x;
    u_xlat2.w = u_xlat27 * 0.5;
    u_xlat2.xy = u_xlat2.zz + u_xlat2.xw;
    u_xlat20.xy = u_xlat2.xy / u_xlat1.ww;
    u_xlat5.xy = u_xlat20.xy + vec2(-0.5, -0.5);
    vs_TEXCOORD2.xy = (-u_xlat5.xy) * vec2(vec2(_Expansion, _Expansion)) + u_xlat20.xy;
    u_xlat5.x = hlslcc_mtx4x4unity_ObjectToWorld[0].x;
    u_xlat5.y = hlslcc_mtx4x4unity_ObjectToWorld[1].x;
    u_xlat5.z = hlslcc_mtx4x4unity_ObjectToWorld[2].x;
    u_xlat27 = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat27 = sqrt(u_xlat27);
    u_xlat27 = max(u_xlat27, 9.99999997e-07);
    u_xlat20.xy = u_xlat5.xy / vec2(u_xlat27);
    u_xlat5.x = hlslcc_mtx4x4unity_ObjectToWorld[0].y;
    u_xlat5.y = hlslcc_mtx4x4unity_ObjectToWorld[1].y;
    u_xlat5.z = hlslcc_mtx4x4unity_ObjectToWorld[2].y;
    u_xlat27 = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat27 = sqrt(u_xlat27);
    u_xlat27 = max(u_xlat27, 9.99999997e-07);
    u_xlat5.xy = u_xlat5.xy / vec2(u_xlat27);
    u_xlat6.x = hlslcc_mtx4x4unity_ObjectToWorld[0].z;
    u_xlat6.y = hlslcc_mtx4x4unity_ObjectToWorld[1].z;
    u_xlat6.z = hlslcc_mtx4x4unity_ObjectToWorld[2].z;
    u_xlat27 = dot(u_xlat6.xyz, u_xlat6.xyz);
    u_xlat27 = sqrt(u_xlat27);
    u_xlat27 = max(u_xlat27, 9.99999997e-07);
    u_xlat23.xy = u_xlat6.xy / vec2(u_xlat27);
    u_xlat6 = u_xlat5.xyxy * hlslcc_mtx4x4unity_MatrixV[1].xxyy;
    u_xlat6 = u_xlat20.xyxy * hlslcc_mtx4x4unity_MatrixV[0].xxyy + u_xlat6;
    u_xlat6 = u_xlat23.xyxy * hlslcc_mtx4x4unity_MatrixV[2].xxyy + u_xlat6;
    u_xlat5.xy = u_xlat5.xy * hlslcc_mtx4x4unity_MatrixV[1].zz;
    u_xlat20.xy = u_xlat20.xy * hlslcc_mtx4x4unity_MatrixV[0].zz + u_xlat5.xy;
    u_xlat5.xy = u_xlat23.xy * hlslcc_mtx4x4unity_MatrixV[2].zz + u_xlat20.xy;
    u_xlat7.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat7.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat7.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat27 = dot(u_xlat7.xyz, u_xlat7.xyz);
    u_xlat27 = max(u_xlat27, 1.17549435e-38);
    u_xlat27 = inversesqrt(u_xlat27);
    vs_TEXCOORD6.xyz = vec3(u_xlat27) * u_xlat7.xyz;
    gl_Position = u_xlat1;
    vs_TEXCOORD5.zw = u_xlat1.zw;
    vs_TEXCOORD5.xy = u_xlat2.xy;
    vs_TEXCOORD8 = u_xlat3;
    vs_TEXCOORD9 = u_xlat4;
    u_xlat5.zw = u_xlat6.xz;
    vs_TEXCOORD3.xyz = u_xlat5.zwx;
    vs_TEXCOORD4.xy = u_xlat6.yw;
    vs_TEXCOORD4.z = u_xlat5.y;
    vs_TEXCOORD7.xyz = u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _DistortionScroll;
	UNITY_UNIFORM vec4                _DistortionTexUVTileController;
	UNITY_UNIFORM float                _DistortionTexUVAutoOffset;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM vec4                _MaskScroll;
	UNITY_UNIFORM vec4                _MaskTexUVTileController;
	UNITY_UNIFORM float                _MaskTexUVAutoOffset;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _DistortionScaleController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPower;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRangeController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPowerController;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_FresnelColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelBlendMode;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FlipFresnelColorRange;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensity;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensityController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveEdgeWidth;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveEdgeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTexUVTileController;
	UNITY_UNIFORM float                _BlurStep;
	UNITY_UNIFORM float                _BlurWeightType;
	UNITY_UNIFORM float                _ColorOffset;
	UNITY_UNIFORM float                _ColorPow;
	UNITY_UNIFORM float                _ColorReverse;
	UNITY_UNIFORM float                _ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float                _UsePackedStreams;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(2) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
in highp  vec4 vs_TEXCOORD8;
in highp  vec4 vs_TEXCOORD9;
layout(location = 0) out highp vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
vec4 u_xlat1;
mediump vec3 u_xlat16_1;
int u_xlati1;
bool u_xlatb1;
vec2 u_xlat2;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec3 u_xlat16_3;
vec4 u_xlat4;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
vec3 u_xlat6;
vec3 u_xlat7;
vec2 u_xlat8;
bool u_xlatb9;
float u_xlat16;
mediump vec2 u_xlat16_16;
int u_xlati16;
bool u_xlatb16;
vec2 u_xlat17;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat16_0.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat0.xy = u_xlat16_0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat8.xy = u_xlat0.yy * vs_TEXCOORD4.xy;
    u_xlat0.xy = u_xlat0.xx * vs_TEXCOORD3.xy + u_xlat8.xy;
    u_xlat16_16.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat0.xy = u_xlat16_16.xx * u_xlat0.xy;
    u_xlat16 = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat16 = u_xlat16 * 0.5 + 0.5;
    u_xlat16 = u_xlat16 * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat16 = u_xlat16 * 0.300000012;
    u_xlat0.xy = vec2(u_xlat16) * u_xlat0.xy;
    u_xlatb16 = 0.0<_DistortionScaleController;
    if(u_xlatb16){
        u_xlatb16 = _DistortionScaleController>=1.0;
        if(u_xlatb16){
            u_xlati16 = int(_DistortionScaleController);
            u_xlati1 = u_xlati16 + int(0xFFFFFFFFu);
            u_xlatb9 = u_xlati1<4;
            if(u_xlatb9){
                u_xlat17.x = dot(vs_TEXCOORD8, ImmCB_0[u_xlati1]);
            } else {
                u_xlat17.x = 0.0;
            }
            if(!u_xlatb9){
                u_xlatb1 = u_xlati1<8;
                if(u_xlatb1){
                    u_xlati16 = u_xlati16 + int(0xFFFFFFFBu);
                    u_xlat17.x = dot(vs_TEXCOORD9, ImmCB_0[u_xlati16]);
                }
                u_xlat17.x = u_xlatb1 ? u_xlat17.x : float(0.0);
            }
        } else {
            u_xlat17.x = 0.0;
        }
        u_xlat16 = u_xlat17.x + _DistortionScale0;
    } else {
        u_xlat16 = _DistortionScale0;
    }
    u_xlat1.xy = u_xlat0.xy * vec2(u_xlat16) + vs_TEXCOORD2.xy;
    u_xlat17.x = u_xlat16 + _BlurStep;
    u_xlat17.xy = u_xlat0.xy * u_xlat17.xx + vs_TEXCOORD2.xy;
    u_xlat2.x = _BlurStep * 2.0 + u_xlat16;
    u_xlat2.xy = u_xlat0.xy * u_xlat2.xx + vs_TEXCOORD2.xy;
    u_xlat3.xyz = vec3(_BlurStep) * vec3(3.0, 4.0, 5.0) + vec3(u_xlat16);
    u_xlat4 = u_xlat0.xyxy * u_xlat3.xxyy + vs_TEXCOORD2.xyxy;
    u_xlat0.xy = u_xlat0.xy * u_xlat3.zz + vs_TEXCOORD2.xy;
    u_xlat1.xy = u_xlat1.xy * vec2(0.5, 0.5);
    u_xlat1.xy = fract(u_xlat1.xy);
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat1.xy = -abs(u_xlat1.xy) + vec2(1.0, 1.0);
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat1.xy, _GlobalMipBias.x).xyz;
    u_xlat1.xy = u_xlat17.xy * vec2(0.5, 0.5);
    u_xlat1.xy = fract(u_xlat1.xy);
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat1.xy = -abs(u_xlat1.xy) + vec2(1.0, 1.0);
    u_xlat16_1.xyz = texture(_CameraTransparentTexture, u_xlat1.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xy = u_xlat2.xy * vec2(0.5, 0.5);
    u_xlat2.xy = fract(u_xlat2.xy);
    u_xlat2.xy = u_xlat2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat2.xy = -abs(u_xlat2.xy) + vec2(1.0, 1.0);
    u_xlat16_2.xyz = texture(_CameraTransparentTexture, u_xlat2.xy, _GlobalMipBias.x).xyz;
    u_xlat4 = u_xlat4 * vec4(0.5, 0.5, 0.5, 0.5);
    u_xlat4 = fract(u_xlat4);
    u_xlat4 = u_xlat4 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat4 = -abs(u_xlat4) + vec4(1.0, 1.0, 1.0, 1.0);
    u_xlat16_5.xyz = texture(_CameraTransparentTexture, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = texture(_CameraTransparentTexture, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlat0.xy = fract(u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
    u_xlat16_0.xyz = texture(_CameraTransparentTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat6.xyz = u_xlat16_1.xyz + u_xlat16_3.xyz;
    u_xlat6.xyz = u_xlat16_2.xyz + u_xlat6.xyz;
    u_xlat6.xyz = u_xlat16_5.xyz + u_xlat6.xyz;
    u_xlat6.xyz = u_xlat16_4.xyz + u_xlat6.xyz;
    u_xlat6.xyz = u_xlat16_0.xyz + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat6.xyz * vec3(0.166666657, 0.166666657, 0.166666657);
    u_xlat1.xyz = u_xlat16_1.xyz * vec3(0.238095239, 0.238095239, 0.238095239);
    u_xlat1.xyz = u_xlat16_3.xyz * vec3(0.285714298, 0.285714298, 0.285714298) + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat16_2.xyz * vec3(0.190476194, 0.190476194, 0.190476194) + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat16_5.xyz * vec3(0.142857149, 0.142857149, 0.142857149) + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat16_4.xyz * vec3(0.095238097, 0.095238097, 0.095238097) + u_xlat1.xyz;
    u_xlat0.xyz = u_xlat16_0.xyz * vec3(0.0476190485, 0.0476190485, 0.0476190485) + u_xlat1.xyz;
    u_xlat0.xyz = (-u_xlat6.xyz) * vec3(0.166666657, 0.166666657, 0.166666657) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_BlurWeightType, _BlurWeightType, _BlurWeightType)) * u_xlat0.xyz + u_xlat7.xyz;
    u_xlat0.xyz = u_xlat0.xyz + vec3(vec3(_ColorOffset, _ColorOffset, _ColorOffset));
    u_xlat0.xyz = max(u_xlat0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat0.xyz = log2(u_xlat0.xyz);
    u_xlat0.xyz = u_xlat0.xyz * vec3(vec3(_ColorPow, _ColorPow, _ColorPow));
    u_xlat0.xyz = exp2(u_xlat0.xyz);
    u_xlat1.xyz = u_xlat0.xyz * vec3(-2.0, -2.0, -2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = vec3(_ColorReverse) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat1.x = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat0.xyz = u_xlat0.xyz + (-u_xlat1.xxx);
    u_xlat1.xyz = vec3(vec3(_ColorSaturation, _ColorSaturation, _ColorSaturation)) * u_xlat0.xyz + u_xlat1.xxx;
    u_xlat1.w = 1.0;
    u_xlat1 = u_xlat1 * vs_COLOR0;
    u_xlat0.x = u_xlat16_16.y * u_xlat1.w;
    SV_Target0.xyz = u_xlat0.xxx * u_xlat1.xyz;
    SV_Target0.w = u_xlat0.x;
    return;
}

#endif


// ===== program 3: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 hlslcc_mtx4x4glstate_matrix_projection[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4                _DistortionTex0_ST;
	UNITY_UNIFORM float                _DistortionTex0_R;
	UNITY_UNIFORM vec4                _DistortionScroll;
	UNITY_UNIFORM vec4                _DistortionTexUVTileController;
	UNITY_UNIFORM float                _DistortionTexUVAutoOffset;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM vec4                _MaskScroll;
	UNITY_UNIFORM vec4                _MaskTexUVTileController;
	UNITY_UNIFORM float                _MaskTexUVAutoOffset;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM float                _DistortionScale0;
	UNITY_UNIFORM float                _DistortionScaleController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRange;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPower;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelRangeController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelPowerController;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_FresnelColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FresnelBlendMode;
	UNITY_UNIFORM float Xhlslcc_UnusedX_FlipFresnelColorRange;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensity;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveIntensityController;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DissolveEdgeWidth;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveEdgeColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_DissolveTexUVTileController;
	UNITY_UNIFORM float                _BlurStep;
	UNITY_UNIFORM float                _BlurWeightType;
	UNITY_UNIFORM float                _ColorOffset;
	UNITY_UNIFORM float                _ColorPow;
	UNITY_UNIFORM float                _ColorReverse;
	UNITY_UNIFORM float                _ColorSaturation;
	UNITY_UNIFORM float                _Expansion;
	UNITY_UNIFORM float                _UsePackedStreams;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _CameraTransparentTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _DistortionTex0;
UNITY_LOCATION(2) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
in highp  vec4 vs_TEXCOORD8;
in highp  vec4 vs_TEXCOORD9;
layout(location = 0) out highp vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
vec4 u_xlat1;
mediump vec3 u_xlat16_1;
int u_xlati1;
bool u_xlatb1;
vec2 u_xlat2;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec3 u_xlat16_3;
vec4 u_xlat4;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
vec3 u_xlat6;
vec3 u_xlat7;
vec2 u_xlat8;
bool u_xlatb9;
float u_xlat16;
mediump vec2 u_xlat16_16;
int u_xlati16;
bool u_xlatb16;
vec2 u_xlat17;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat16_0.xy = texture(_DistortionTex0, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat0.xy = u_xlat16_0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat8.xy = u_xlat0.yy * vs_TEXCOORD4.xy;
    u_xlat0.xy = u_xlat0.xx * vs_TEXCOORD3.xy + u_xlat8.xy;
    u_xlat16_16.xy = texture(_MaskTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).xw;
    u_xlat0.xy = u_xlat16_16.xx * u_xlat0.xy;
    u_xlat16 = hlslcc_FragCoord.z / hlslcc_FragCoord.w;
    u_xlat16 = u_xlat16 * 0.5 + 0.5;
    u_xlat16 = u_xlat16 * hlslcc_mtx4x4glstate_matrix_projection[1].y;
    u_xlat16 = u_xlat16 * 0.300000012;
    u_xlat0.xy = vec2(u_xlat16) * u_xlat0.xy;
    u_xlatb16 = 0.0<_DistortionScaleController;
    if(u_xlatb16){
        u_xlatb16 = _DistortionScaleController>=1.0;
        if(u_xlatb16){
            u_xlati16 = int(_DistortionScaleController);
            u_xlati1 = u_xlati16 + int(0xFFFFFFFFu);
            u_xlatb9 = u_xlati1<4;
            if(u_xlatb9){
                u_xlat17.x = dot(vs_TEXCOORD8, ImmCB_0[u_xlati1]);
            } else {
                u_xlat17.x = 0.0;
            }
            if(!u_xlatb9){
                u_xlatb1 = u_xlati1<8;
                if(u_xlatb1){
                    u_xlati16 = u_xlati16 + int(0xFFFFFFFBu);
                    u_xlat17.x = dot(vs_TEXCOORD9, ImmCB_0[u_xlati16]);
                }
                u_xlat17.x = u_xlatb1 ? u_xlat17.x : float(0.0);
            }
        } else {
            u_xlat17.x = 0.0;
        }
        u_xlat16 = u_xlat17.x + _DistortionScale0;
    } else {
        u_xlat16 = _DistortionScale0;
    }
    u_xlat1.xy = u_xlat0.xy * vec2(u_xlat16) + vs_TEXCOORD2.xy;
    u_xlat17.x = u_xlat16 + _BlurStep;
    u_xlat17.xy = u_xlat0.xy * u_xlat17.xx + vs_TEXCOORD2.xy;
    u_xlat2.x = _BlurStep * 2.0 + u_xlat16;
    u_xlat2.xy = u_xlat0.xy * u_xlat2.xx + vs_TEXCOORD2.xy;
    u_xlat3.xyz = vec3(_BlurStep) * vec3(3.0, 4.0, 5.0) + vec3(u_xlat16);
    u_xlat4 = u_xlat0.xyxy * u_xlat3.xxyy + vs_TEXCOORD2.xyxy;
    u_xlat0.xy = u_xlat0.xy * u_xlat3.zz + vs_TEXCOORD2.xy;
    u_xlat1.xy = u_xlat1.xy * vec2(0.5, 0.5);
    u_xlat1.xy = fract(u_xlat1.xy);
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat1.xy = -abs(u_xlat1.xy) + vec2(1.0, 1.0);
    u_xlat16_3.xyz = texture(_CameraTransparentTexture, u_xlat1.xy, _GlobalMipBias.x).xyz;
    u_xlat1.xy = u_xlat17.xy * vec2(0.5, 0.5);
    u_xlat1.xy = fract(u_xlat1.xy);
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat1.xy = -abs(u_xlat1.xy) + vec2(1.0, 1.0);
    u_xlat16_1.xyz = texture(_CameraTransparentTexture, u_xlat1.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xy = u_xlat2.xy * vec2(0.5, 0.5);
    u_xlat2.xy = fract(u_xlat2.xy);
    u_xlat2.xy = u_xlat2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat2.xy = -abs(u_xlat2.xy) + vec2(1.0, 1.0);
    u_xlat16_2.xyz = texture(_CameraTransparentTexture, u_xlat2.xy, _GlobalMipBias.x).xyz;
    u_xlat4 = u_xlat4 * vec4(0.5, 0.5, 0.5, 0.5);
    u_xlat4 = fract(u_xlat4);
    u_xlat4 = u_xlat4 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat4 = -abs(u_xlat4) + vec4(1.0, 1.0, 1.0, 1.0);
    u_xlat16_5.xyz = texture(_CameraTransparentTexture, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = texture(_CameraTransparentTexture, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlat0.xy = fract(u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
    u_xlat16_0.xyz = texture(_CameraTransparentTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat6.xyz = u_xlat16_1.xyz + u_xlat16_3.xyz;
    u_xlat6.xyz = u_xlat16_2.xyz + u_xlat6.xyz;
    u_xlat6.xyz = u_xlat16_5.xyz + u_xlat6.xyz;
    u_xlat6.xyz = u_xlat16_4.xyz + u_xlat6.xyz;
    u_xlat6.xyz = u_xlat16_0.xyz + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat6.xyz * vec3(0.166666657, 0.166666657, 0.166666657);
    u_xlat1.xyz = u_xlat16_1.xyz * vec3(0.238095239, 0.238095239, 0.238095239);
    u_xlat1.xyz = u_xlat16_3.xyz * vec3(0.285714298, 0.285714298, 0.285714298) + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat16_2.xyz * vec3(0.190476194, 0.190476194, 0.190476194) + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat16_5.xyz * vec3(0.142857149, 0.142857149, 0.142857149) + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat16_4.xyz * vec3(0.095238097, 0.095238097, 0.095238097) + u_xlat1.xyz;
    u_xlat0.xyz = u_xlat16_0.xyz * vec3(0.0476190485, 0.0476190485, 0.0476190485) + u_xlat1.xyz;
    u_xlat0.xyz = (-u_xlat6.xyz) * vec3(0.166666657, 0.166666657, 0.166666657) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_BlurWeightType, _BlurWeightType, _BlurWeightType)) * u_xlat0.xyz + u_xlat7.xyz;
    u_xlat0.xyz = u_xlat0.xyz + vec3(vec3(_ColorOffset, _ColorOffset, _ColorOffset));
    u_xlat0.xyz = max(u_xlat0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat0.xyz = log2(u_xlat0.xyz);
    u_xlat0.xyz = u_xlat0.xyz * vec3(vec3(_ColorPow, _ColorPow, _ColorPow));
    u_xlat0.xyz = exp2(u_xlat0.xyz);
    u_xlat1.xyz = u_xlat0.xyz * vec3(-2.0, -2.0, -2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = vec3(_ColorReverse) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat1.x = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat0.xyz = u_xlat0.xyz + (-u_xlat1.xxx);
    u_xlat1.xyz = vec3(vec3(_ColorSaturation, _ColorSaturation, _ColorSaturation)) * u_xlat0.xyz + u_xlat1.xxx;
    u_xlat1.w = 1.0;
    u_xlat1 = u_xlat1 * vs_COLOR0;
    u_xlat0.x = u_xlat16_16.y * u_xlat1.w;
    SV_Target0.xyz = u_xlat0.xxx * u_xlat1.xyz;
    SV_Target0.w = u_xlat0.x;
    return;
}

#endif

