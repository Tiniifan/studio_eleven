layout(triangles_adjacency) in;
layout(triangle_strip, max_vertices = 16) out;

struct DMP_SILHOUETTE {
    vec2 width;
    bool scaleByW;
    vec4 color;
    bool frontFaceCCW;
    bool acceptEmptyTriangles;
    vec4 openEdgeColor;
    vec4 openEdgeWidth;
    float openEdgeDepthBias;
    bool openEdgeWidthScaleByW;
    bool openEdgeDepthBiasScaleByW;
};

uniform DMP_SILHOUETTE dmp_Silhouette;

in Inputs {
    vec4 var_pos;
    vec4 var_clr;
    vec4 var_nrm;
    vec4 var_tx0;
    vec4 var_gen;
}

gin[6];
out vec4 var_clr;
out vec4 var_nrm;
out vec4 var_tx0;

void main() {
    float scaleByW_0 = dmp_Silhouette.scaleByW ? 1.000000 : (1.000000 / gin[0].var_pos.w);
    float scaleByW_1 = dmp_Silhouette.scaleByW ? 1.000000 : (1.000000 / gin[1].var_pos.w);
    float scaleByW_3 = dmp_Silhouette.scaleByW ? 1.000000 : (1.000000 / gin[3].var_pos.w);
    vec3 scn_pos[6];
    scn_pos[0] = gin[0].var_pos.xyz / gin[0].var_pos.w;
    scn_pos[1] = gin[1].var_pos.xyz / gin[1].var_pos.w;
    scn_pos[2] = gin[2].var_pos.xyz / gin[2].var_pos.w;
    scn_pos[3] = gin[3].var_pos.xyz / gin[3].var_pos.w;
    scn_pos[4] = gin[4].var_pos.xyz / gin[4].var_pos.w;
    scn_pos[5] = gin[5].var_pos.xyz / gin[5].var_pos.w;
    vec3 tri0 = cross(scn_pos[1] - scn_pos[0], scn_pos[3] - scn_pos[0]);
    vec3 tri1 = cross(scn_pos[2] - scn_pos[0], scn_pos[1] - scn_pos[0]);
    vec3 tri2 = cross(scn_pos[5] - scn_pos[1], scn_pos[3] - scn_pos[1]);
    vec3 tri3 = cross(scn_pos[4] - scn_pos[3], scn_pos[0] - scn_pos[3]);
    if ((gin[2].var_pos.xyz - gin[0].var_pos.xyz) == vec3(0, 0, 0)) {
    } else if (tri0.z * tri1.z < 0) {
        gl_Position = gin[0].var_pos;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[0].var_nrm;
        var_tx0 = gin[0].var_tx0;
        EmitVertex();
        gl_Position = gin[1].var_pos;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[1].var_nrm;
        var_tx0 = gin[1].var_tx0;
        EmitVertex();
        gl_Position = gin[0].var_pos + gin[0].var_gen * vec4(10.000000 * dmp_Silhouette.width.x,
                10.000000 * 1.666600 * dmp_Silhouette.width.y, 0.000000, 0.000000) * scaleByW_0;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[0].var_nrm;
        var_tx0 = gin[0].var_tx0;
        EmitVertex();
        gl_Position = gin[1].var_pos + gin[1].var_gen * vec4(10.000000 * dmp_Silhouette.width.x,
                10.000000 * 1.666600 * dmp_Silhouette.width.y, 0.000000, 0.000000) * scaleByW_1;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[1].var_nrm;
        var_tx0 = gin[1].var_tx0;
        EmitVertex();
        gl_Position = gin[1].var_pos + gin[1].var_gen * vec4(10.000000 * dmp_Silhouette.width.x,
                10.000000 * 1.666600 * dmp_Silhouette.width.y, 0.000000, 0.000000) * scaleByW_1;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[1].var_nrm;
        var_tx0 = gin[1].var_tx0;
        EmitVertex();
    }
    if ((gin[5].var_pos.xyz - gin[1].var_pos.xyz) == vec3(0, 0, 0)) {
    } else if (tri0.z * tri2.z < 0) {
        gl_Position = gin[1].var_pos;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[1].var_nrm;
        var_tx0 = gin[1].var_tx0;
        EmitVertex();
        gl_Position = gin[1].var_pos;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[1].var_nrm;
        var_tx0 = gin[1].var_tx0;
        EmitVertex();
        gl_Position = gin[3].var_pos;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[3].var_nrm;
        var_tx0 = gin[3].var_tx0;
        EmitVertex();
        gl_Position = gin[1].var_pos + gin[1].var_gen * vec4(10.000000 * dmp_Silhouette.width.x,
                10.000000 * 1.666600 * dmp_Silhouette.width.y, 0.000000, 0.000000) * scaleByW_1;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[1].var_nrm;
        var_tx0 = gin[1].var_tx0;
        EmitVertex();
        gl_Position = gin[3].var_pos + gin[3].var_gen * vec4(10.000000 * dmp_Silhouette.width.x,
                10.000000 * 1.666600 * dmp_Silhouette.width.y, 0.000000, 0.000000) * scaleByW_3;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[3].var_nrm;
        var_tx0 = gin[3].var_tx0;
        EmitVertex();
        gl_Position = gin[3].var_pos + gin[3].var_gen * vec4(10.000000 * dmp_Silhouette.width.x,
                10.000000 * 1.666600 * dmp_Silhouette.width.y, 0.000000, 0.000000) * scaleByW_3;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[3].var_nrm;
        var_tx0 = gin[3].var_tx0;
        EmitVertex();
    }
    if ((gin[4].var_pos.xyz - gin[1].var_pos.xyz) == vec3(0, 0, 0)) {
    } else if (tri0.z * tri3.z < 0) {
        gl_Position = gin[3].var_pos;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[3].var_nrm;
        var_tx0 = gin[3].var_tx0;
        EmitVertex();
        gl_Position = gin[3].var_pos;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[3].var_nrm;
        var_tx0 = gin[3].var_tx0;
        EmitVertex();
        gl_Position = gin[0].var_pos;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[0].var_nrm;
        var_tx0 = gin[0].var_tx0;
        EmitVertex();
        gl_Position = gin[3].var_pos + gin[3].var_gen * vec4(10.000000 * dmp_Silhouette.width.x,
                10.000000 * 1.666600 * dmp_Silhouette.width.y, 0.000000, 0.000000) * scaleByW_3;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[3].var_nrm;
        var_tx0 = gin[3].var_tx0;
        EmitVertex();
        gl_Position = gin[0].var_pos + gin[0].var_gen * vec4(10.000000 * dmp_Silhouette.width.x,
                10.000000 * 1.666600 * dmp_Silhouette.width.y, 0.000000, 0.000000) * scaleByW_0;
        var_clr = dmp_Silhouette.color;
        var_nrm = gin[0].var_nrm;
        var_tx0 = gin[0].var_tx0;
        EmitVertex();
    }
    EndPrimitive();
}
