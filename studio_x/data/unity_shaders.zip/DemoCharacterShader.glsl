// DemoCharacterShader (Shader path ID -4283910403961748962, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_COLOR0;
layout(location = 0) out highp vec4 vs_TEXCOORD0;
layout(location = 1) out highp float vs_TEXCOORD3;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
void main()
{
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[1].z * hlslcc_mtx4x4unity_ObjectToWorld[1].y;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[0].z * hlslcc_mtx4x4unity_ObjectToWorld[1].x + u_xlat0.x;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[2].z * hlslcc_mtx4x4unity_ObjectToWorld[1].z + u_xlat0.x;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[3].z * hlslcc_mtx4x4unity_ObjectToWorld[1].w + u_xlat0.x;
    u_xlat0.x = u_xlat0.x * in_POSITION0.y;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[1].z * hlslcc_mtx4x4unity_ObjectToWorld[0].y;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[0].z * hlslcc_mtx4x4unity_ObjectToWorld[0].x + u_xlat2.x;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[2].z * hlslcc_mtx4x4unity_ObjectToWorld[0].z + u_xlat2.x;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[3].z * hlslcc_mtx4x4unity_ObjectToWorld[0].w + u_xlat2.x;
    u_xlat0.x = u_xlat2.x * in_POSITION0.x + u_xlat0.x;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[1].z * hlslcc_mtx4x4unity_ObjectToWorld[2].y;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[0].z * hlslcc_mtx4x4unity_ObjectToWorld[2].x + u_xlat2.x;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[2].z * hlslcc_mtx4x4unity_ObjectToWorld[2].z + u_xlat2.x;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[3].z * hlslcc_mtx4x4unity_ObjectToWorld[2].w + u_xlat2.x;
    u_xlat0.x = u_xlat2.x * in_POSITION0.z + u_xlat0.x;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[1].z * hlslcc_mtx4x4unity_ObjectToWorld[3].y;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[0].z * hlslcc_mtx4x4unity_ObjectToWorld[3].x + u_xlat2.x;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[2].z * hlslcc_mtx4x4unity_ObjectToWorld[3].z + u_xlat2.x;
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[3].z * hlslcc_mtx4x4unity_ObjectToWorld[3].w + u_xlat2.x;
    u_xlat0.x = u_xlat2.x + u_xlat0.x;
    u_xlat0.x = max((-u_xlat0.x), 0.0);
    u_xlat0.x = min(u_xlat0.x, 1.79999995);
    u_xlat2.xyz = in_NORMAL0.xyz * in_COLOR0.zzz;
    u_xlat0.xyz = u_xlat0.xxx * u_xlat2.xyz;
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.00219999999, 0.00219999999, 0.00219999999) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    vs_TEXCOORD0 = u_xlat0;
    vs_TEXCOORD3 = 0.0;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_Target0;
void main()
{
    SV_Target0 = vec4(0.0421494618, 0.034027569, 0.034027569, 1.0);
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_Target0;
void main()
{
    SV_Target0 = vec4(0.0421494618, 0.034027569, 0.034027569, 1.0);
    return;
}

#endif


// ===== program 2: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
layout(location = 4) out highp vec4 vs_TEXCOORD0;
layout(location = 0) out highp vec3 vs_TEXCOORD1;
layout(location = 5) out highp float vs_TEXCOORD3;
layout(location = 1) out highp vec4 vs_TEXCOORD4;
layout(location = 2) out highp vec4 vs_TEXCOORD5;
layout(location = 3) out highp vec4 vs_COLOR0;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_TEXCOORD1.xyz = u_xlat0.xyz;
    u_xlat0 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    vs_TEXCOORD0 = u_xlat0;
    vs_TEXCOORD3 = 0.0;
    vs_TEXCOORD4.xy = in_TEXCOORD0.xy;
    vs_TEXCOORD4.zw = vec2(0.0, 0.0);
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_TEXCOORD5.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    vs_TEXCOORD5.w = 0.0;
    vs_COLOR0 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform UnityPerMaterial {
	vec4                _MainTex_ST;
	vec4 Xhlslcc_UnusedX_SkinColor;
	vec4 Xhlslcc_UnusedX_MSKMap_ST;
	vec4                _OCMap_ST;
	vec4                _SPMMap_ST;
};
UNITY_LOCATION(0) uniform mediump sampler2D _MainTex;
UNITY_LOCATION(1) uniform mediump sampler2D _OCMap;
UNITY_LOCATION(2) uniform mediump sampler2D _SPMMap;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 1) in highp  vec4 vs_TEXCOORD4;
layout(location = 2) in highp  vec4 vs_TEXCOORD5;
layout(location = 3) in highp  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
mediump float u_xlat16_1;
vec3 u_xlat2;
vec2 u_xlat3;
int u_xlati3;
uint u_xlatu3;
bool u_xlatb3;
vec3 u_xlat4;
mediump float u_xlat16_6;
vec3 u_xlat8;
mediump float u_xlat16_8;
int u_xlati8;
uint u_xlatu8;
float u_xlat9;
float u_xlat13;
int u_xlati13;
uint u_xlatu13;
bool u_xlatb13;
float u_xlat15;
uint u_xlatu15;
float u_xlat17;
mediump float u_xlat16_17;
uint u_xlatu17;
float u_xlat18;
int u_xlati18;
float u_xlat19;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat0.xy = vs_TEXCOORD4.xy * _MainTex_ST.xy + _MainTex_ST.zw;
    u_xlat16_0.xyz = texture(_MainTex, u_xlat0.xy, -1.5).xyz;
    u_xlat16_1 = max(_MainLightColor.y, _MainLightColor.x);
    u_xlat16_1 = max(u_xlat16_1, _MainLightColor.z);
    u_xlat16_6 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlatu15 =  uint(int(u_xlat16_6));
    u_xlat2.x = float(0.0);
    u_xlat2.y = float(0.0);
    u_xlat2.z = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<u_xlatu15 ; u_xlatu_loop_1++)
    {
        u_xlatu3 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati8 = int(u_xlatu_loop_1 & 3u);
        u_xlat3.x = dot(unity_LightIndices[int(u_xlatu3)], ImmCB_0[u_xlati8]);
        u_xlati3 = int(u_xlat3.x);
        u_xlat8.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati3].www + _AdditionalLightsPosition[u_xlati3].xyz;
        u_xlat4.x = dot(u_xlat8.xyz, u_xlat8.xyz);
        u_xlat4.x = max(u_xlat4.x, 6.10351562e-05);
        u_xlat9 = inversesqrt(u_xlat4.x);
        u_xlat8.xyz = u_xlat8.xyz * vec3(u_xlat9);
        u_xlat9 = float(1.0) / float(u_xlat4.x);
        u_xlat4.x = u_xlat4.x * _AdditionalLightsAttenuation[u_xlati3].x;
        u_xlat16_6 = (-u_xlat4.x) * u_xlat4.x + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat4.x = u_xlat16_6 * u_xlat9;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati3].xyz, u_xlat8.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati3].z + _AdditionalLightsAttenuation[u_xlati3].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat8.x = u_xlat16_6 * u_xlat4.x;
        u_xlat2.xyz = _AdditionalLightsColor[u_xlati3].xyz * u_xlat8.xxx + u_xlat2.xyz;
    }
    u_xlat17 = dot(vs_TEXCOORD5.xyz, _MainLightPosition.xyz);
    u_xlat3.x = float(0.0);
    for(uint u_xlatu_loop_2 = uint(0u) ; u_xlatu_loop_2<u_xlatu15 ; u_xlatu_loop_2++)
    {
        u_xlatu13 = u_xlatu_loop_2 >> (2u & uint(0x1F));
        u_xlati18 = int(u_xlatu_loop_2 & 3u);
        u_xlat13 = dot(unity_LightIndices[int(u_xlatu13)], ImmCB_0[u_xlati18]);
        u_xlati13 = int(u_xlat13);
        u_xlat4.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati13].www + _AdditionalLightsPosition[u_xlati13].xyz;
        u_xlat18 = dot(u_xlat4.xyz, u_xlat4.xyz);
        u_xlat18 = max(u_xlat18, 6.10351562e-05);
        u_xlat19 = inversesqrt(u_xlat18);
        u_xlat4.xyz = vec3(u_xlat19) * u_xlat4.xyz;
        u_xlat19 = float(1.0) / float(u_xlat18);
        u_xlat18 = u_xlat18 * _AdditionalLightsAttenuation[u_xlati13].x;
        u_xlat16_6 = (-u_xlat18) * u_xlat18 + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat18 = u_xlat16_6 * u_xlat19;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati13].xyz, u_xlat4.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati13].z + _AdditionalLightsAttenuation[u_xlati13].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat13 = u_xlat16_6 * u_xlat18;
        u_xlat18 = dot(u_xlat4.xyz, vs_TEXCOORD5.xyz);
        u_xlat3.x = u_xlat18 * u_xlat13 + u_xlat3.x;
    }
    u_xlat15 = u_xlat17 * u_xlat16_1 + u_xlat3.x;
    u_xlat3.xy = vs_TEXCOORD4.xy * _OCMap_ST.xy + _OCMap_ST.zw;
    u_xlat16_17 = texture(_OCMap, u_xlat3.xy, -1.5).x;
    u_xlat17 = u_xlat16_17 * vs_COLOR0.w;
    u_xlat17 = dot(vec2(u_xlat17), vec2(u_xlat15));
    u_xlat17 = u_xlat17 + -0.0500000007;
    u_xlat17 = u_xlat17 * 5.0;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat3.x = u_xlat17 * -2.0 + 3.0;
    u_xlat17 = u_xlat17 * u_xlat17;
    u_xlat8.xy = vs_TEXCOORD4.xy * _SPMMap_ST.xy + _SPMMap_ST.zw;
    u_xlat16_8 = texture(_SPMMap, u_xlat8.xy, -1.5).x;
    u_xlat15 = u_xlat15 + u_xlat16_8;
    u_xlat15 = u_xlat15 + -0.800000012;
    u_xlat15 = u_xlat15 * 5.00000048;
    u_xlat15 = clamp(u_xlat15, 0.0, 1.0);
    u_xlat8.x = u_xlat15 * -2.0 + 3.0;
    u_xlat15 = u_xlat15 * u_xlat15;
    u_xlat15 = u_xlat15 * u_xlat8.x;
    u_xlat0.xyz = u_xlat16_0.xyz * _MainLightColor.xyz;
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.5, 0.5, 0.5);
    u_xlat2.xyz = max(u_xlat2.xyz, vec3(1.0, 1.0, 1.0));
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xyz;
    u_xlat2.x = (-u_xlat3.x) * u_xlat17 + 1.0;
    u_xlat2.x = (-u_xlat2.x) * 0.600000024 + 1.0;
    u_xlat15 = u_xlat15 * 0.0250000004;
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xxx + vec3(u_xlat15);
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 3: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform UnityPerMaterial {
	vec4                _MainTex_ST;
	vec4 Xhlslcc_UnusedX_SkinColor;
	vec4 Xhlslcc_UnusedX_MSKMap_ST;
	vec4                _OCMap_ST;
	vec4                _SPMMap_ST;
};
UNITY_LOCATION(0) uniform mediump sampler2D _MainTex;
UNITY_LOCATION(1) uniform mediump sampler2D _OCMap;
UNITY_LOCATION(2) uniform mediump sampler2D _SPMMap;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 1) in highp  vec4 vs_TEXCOORD4;
layout(location = 2) in highp  vec4 vs_TEXCOORD5;
layout(location = 3) in highp  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
mediump float u_xlat16_1;
vec3 u_xlat2;
vec2 u_xlat3;
int u_xlati3;
uint u_xlatu3;
bool u_xlatb3;
vec3 u_xlat4;
mediump float u_xlat16_6;
vec3 u_xlat8;
mediump float u_xlat16_8;
int u_xlati8;
uint u_xlatu8;
float u_xlat9;
float u_xlat13;
int u_xlati13;
uint u_xlatu13;
bool u_xlatb13;
float u_xlat15;
uint u_xlatu15;
float u_xlat17;
mediump float u_xlat16_17;
uint u_xlatu17;
float u_xlat18;
int u_xlati18;
float u_xlat19;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat0.xy = vs_TEXCOORD4.xy * _MainTex_ST.xy + _MainTex_ST.zw;
    u_xlat16_0.xyz = texture(_MainTex, u_xlat0.xy, -1.5).xyz;
    u_xlat16_1 = max(_MainLightColor.y, _MainLightColor.x);
    u_xlat16_1 = max(u_xlat16_1, _MainLightColor.z);
    u_xlat16_6 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlatu15 =  uint(int(u_xlat16_6));
    u_xlat2.x = float(0.0);
    u_xlat2.y = float(0.0);
    u_xlat2.z = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<u_xlatu15 ; u_xlatu_loop_1++)
    {
        u_xlatu3 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati8 = int(u_xlatu_loop_1 & 3u);
        u_xlat3.x = dot(unity_LightIndices[int(u_xlatu3)], ImmCB_0[u_xlati8]);
        u_xlati3 = int(u_xlat3.x);
        u_xlat8.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati3].www + _AdditionalLightsPosition[u_xlati3].xyz;
        u_xlat4.x = dot(u_xlat8.xyz, u_xlat8.xyz);
        u_xlat4.x = max(u_xlat4.x, 6.10351562e-05);
        u_xlat9 = inversesqrt(u_xlat4.x);
        u_xlat8.xyz = u_xlat8.xyz * vec3(u_xlat9);
        u_xlat9 = float(1.0) / float(u_xlat4.x);
        u_xlat4.x = u_xlat4.x * _AdditionalLightsAttenuation[u_xlati3].x;
        u_xlat16_6 = (-u_xlat4.x) * u_xlat4.x + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat4.x = u_xlat16_6 * u_xlat9;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati3].xyz, u_xlat8.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati3].z + _AdditionalLightsAttenuation[u_xlati3].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat8.x = u_xlat16_6 * u_xlat4.x;
        u_xlat2.xyz = _AdditionalLightsColor[u_xlati3].xyz * u_xlat8.xxx + u_xlat2.xyz;
    }
    u_xlat17 = dot(vs_TEXCOORD5.xyz, _MainLightPosition.xyz);
    u_xlat3.x = float(0.0);
    for(uint u_xlatu_loop_2 = uint(0u) ; u_xlatu_loop_2<u_xlatu15 ; u_xlatu_loop_2++)
    {
        u_xlatu13 = u_xlatu_loop_2 >> (2u & uint(0x1F));
        u_xlati18 = int(u_xlatu_loop_2 & 3u);
        u_xlat13 = dot(unity_LightIndices[int(u_xlatu13)], ImmCB_0[u_xlati18]);
        u_xlati13 = int(u_xlat13);
        u_xlat4.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati13].www + _AdditionalLightsPosition[u_xlati13].xyz;
        u_xlat18 = dot(u_xlat4.xyz, u_xlat4.xyz);
        u_xlat18 = max(u_xlat18, 6.10351562e-05);
        u_xlat19 = inversesqrt(u_xlat18);
        u_xlat4.xyz = vec3(u_xlat19) * u_xlat4.xyz;
        u_xlat19 = float(1.0) / float(u_xlat18);
        u_xlat18 = u_xlat18 * _AdditionalLightsAttenuation[u_xlati13].x;
        u_xlat16_6 = (-u_xlat18) * u_xlat18 + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat18 = u_xlat16_6 * u_xlat19;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati13].xyz, u_xlat4.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati13].z + _AdditionalLightsAttenuation[u_xlati13].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat13 = u_xlat16_6 * u_xlat18;
        u_xlat18 = dot(u_xlat4.xyz, vs_TEXCOORD5.xyz);
        u_xlat3.x = u_xlat18 * u_xlat13 + u_xlat3.x;
    }
    u_xlat15 = u_xlat17 * u_xlat16_1 + u_xlat3.x;
    u_xlat3.xy = vs_TEXCOORD4.xy * _OCMap_ST.xy + _OCMap_ST.zw;
    u_xlat16_17 = texture(_OCMap, u_xlat3.xy, -1.5).x;
    u_xlat17 = u_xlat16_17 * vs_COLOR0.w;
    u_xlat17 = dot(vec2(u_xlat17), vec2(u_xlat15));
    u_xlat17 = u_xlat17 + -0.0500000007;
    u_xlat17 = u_xlat17 * 5.0;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat3.x = u_xlat17 * -2.0 + 3.0;
    u_xlat17 = u_xlat17 * u_xlat17;
    u_xlat8.xy = vs_TEXCOORD4.xy * _SPMMap_ST.xy + _SPMMap_ST.zw;
    u_xlat16_8 = texture(_SPMMap, u_xlat8.xy, -1.5).x;
    u_xlat15 = u_xlat15 + u_xlat16_8;
    u_xlat15 = u_xlat15 + -0.800000012;
    u_xlat15 = u_xlat15 * 5.00000048;
    u_xlat15 = clamp(u_xlat15, 0.0, 1.0);
    u_xlat8.x = u_xlat15 * -2.0 + 3.0;
    u_xlat15 = u_xlat15 * u_xlat15;
    u_xlat15 = u_xlat15 * u_xlat8.x;
    u_xlat0.xyz = u_xlat16_0.xyz * _MainLightColor.xyz;
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.5, 0.5, 0.5);
    u_xlat2.xyz = max(u_xlat2.xyz, vec3(1.0, 1.0, 1.0));
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xyz;
    u_xlat2.x = (-u_xlat3.x) * u_xlat17 + 1.0;
    u_xlat2.x = (-u_xlat2.x) * 0.600000024 + 1.0;
    u_xlat15 = u_xlat15 * 0.0250000004;
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xxx + vec3(u_xlat15);
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 4: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
layout(location = 5) out highp vec4 vs_TEXCOORD0;
layout(location = 0) out highp vec3 vs_TEXCOORD1;
layout(location = 1) out highp float vs_TEXCOORD3;
layout(location = 2) out highp vec4 vs_TEXCOORD4;
layout(location = 3) out highp vec4 vs_TEXCOORD5;
layout(location = 4) out highp vec4 vs_COLOR0;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat2;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_TEXCOORD1.xyz = u_xlat0.xyz;
    u_xlat0 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    vs_TEXCOORD0 = u_xlat0;
    u_xlat0.x = u_xlat0.z + _ProjectionParams.y;
    u_xlat2 = _ProjectionParams.y + _ProjectionParams.z;
    u_xlat0.x = u_xlat0.x / u_xlat2;
    u_xlat0.x = u_xlat0.x * _ProjectionParams.z;
    u_xlat0.x = max(u_xlat0.x, 0.0);
    vs_TEXCOORD3 = u_xlat0.x * unity_FogParams.z + unity_FogParams.w;
    vs_TEXCOORD3 = clamp(vs_TEXCOORD3, 0.0, 1.0);
    vs_TEXCOORD4.xy = in_TEXCOORD0.xy;
    vs_TEXCOORD4.zw = vec2(0.0, 0.0);
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_TEXCOORD5.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    vs_TEXCOORD5.w = 0.0;
    vs_COLOR0 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	mediump vec4 unity_FogColor;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform UnityPerMaterial {
	vec4                _MainTex_ST;
	vec4 Xhlslcc_UnusedX_SkinColor;
	vec4 Xhlslcc_UnusedX_MSKMap_ST;
	vec4                _OCMap_ST;
	vec4                _SPMMap_ST;
};
UNITY_LOCATION(0) uniform mediump sampler2D _MainTex;
UNITY_LOCATION(1) uniform mediump sampler2D _OCMap;
UNITY_LOCATION(2) uniform mediump sampler2D _SPMMap;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 1) in highp  float vs_TEXCOORD3;
layout(location = 2) in highp  vec4 vs_TEXCOORD4;
layout(location = 3) in highp  vec4 vs_TEXCOORD5;
layout(location = 4) in highp  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
mediump float u_xlat16_1;
vec3 u_xlat2;
vec2 u_xlat3;
int u_xlati3;
uint u_xlatu3;
bool u_xlatb3;
vec3 u_xlat4;
mediump float u_xlat16_6;
vec3 u_xlat8;
mediump float u_xlat16_8;
int u_xlati8;
uint u_xlatu8;
float u_xlat9;
float u_xlat13;
int u_xlati13;
uint u_xlatu13;
bool u_xlatb13;
float u_xlat15;
uint u_xlatu15;
float u_xlat17;
mediump float u_xlat16_17;
uint u_xlatu17;
float u_xlat18;
int u_xlati18;
float u_xlat19;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat0.xy = vs_TEXCOORD4.xy * _MainTex_ST.xy + _MainTex_ST.zw;
    u_xlat16_0.xyz = texture(_MainTex, u_xlat0.xy, -1.5).xyz;
    u_xlat16_1 = max(_MainLightColor.y, _MainLightColor.x);
    u_xlat16_1 = max(u_xlat16_1, _MainLightColor.z);
    u_xlat16_6 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlatu15 =  uint(int(u_xlat16_6));
    u_xlat2.x = float(0.0);
    u_xlat2.y = float(0.0);
    u_xlat2.z = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<u_xlatu15 ; u_xlatu_loop_1++)
    {
        u_xlatu3 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati8 = int(u_xlatu_loop_1 & 3u);
        u_xlat3.x = dot(unity_LightIndices[int(u_xlatu3)], ImmCB_0[u_xlati8]);
        u_xlati3 = int(u_xlat3.x);
        u_xlat8.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati3].www + _AdditionalLightsPosition[u_xlati3].xyz;
        u_xlat4.x = dot(u_xlat8.xyz, u_xlat8.xyz);
        u_xlat4.x = max(u_xlat4.x, 6.10351562e-05);
        u_xlat9 = inversesqrt(u_xlat4.x);
        u_xlat8.xyz = u_xlat8.xyz * vec3(u_xlat9);
        u_xlat9 = float(1.0) / float(u_xlat4.x);
        u_xlat4.x = u_xlat4.x * _AdditionalLightsAttenuation[u_xlati3].x;
        u_xlat16_6 = (-u_xlat4.x) * u_xlat4.x + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat4.x = u_xlat16_6 * u_xlat9;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati3].xyz, u_xlat8.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati3].z + _AdditionalLightsAttenuation[u_xlati3].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat8.x = u_xlat16_6 * u_xlat4.x;
        u_xlat2.xyz = _AdditionalLightsColor[u_xlati3].xyz * u_xlat8.xxx + u_xlat2.xyz;
    }
    u_xlat17 = dot(vs_TEXCOORD5.xyz, _MainLightPosition.xyz);
    u_xlat3.x = float(0.0);
    for(uint u_xlatu_loop_2 = uint(0u) ; u_xlatu_loop_2<u_xlatu15 ; u_xlatu_loop_2++)
    {
        u_xlatu13 = u_xlatu_loop_2 >> (2u & uint(0x1F));
        u_xlati18 = int(u_xlatu_loop_2 & 3u);
        u_xlat13 = dot(unity_LightIndices[int(u_xlatu13)], ImmCB_0[u_xlati18]);
        u_xlati13 = int(u_xlat13);
        u_xlat4.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati13].www + _AdditionalLightsPosition[u_xlati13].xyz;
        u_xlat18 = dot(u_xlat4.xyz, u_xlat4.xyz);
        u_xlat18 = max(u_xlat18, 6.10351562e-05);
        u_xlat19 = inversesqrt(u_xlat18);
        u_xlat4.xyz = vec3(u_xlat19) * u_xlat4.xyz;
        u_xlat19 = float(1.0) / float(u_xlat18);
        u_xlat18 = u_xlat18 * _AdditionalLightsAttenuation[u_xlati13].x;
        u_xlat16_6 = (-u_xlat18) * u_xlat18 + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat18 = u_xlat16_6 * u_xlat19;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati13].xyz, u_xlat4.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati13].z + _AdditionalLightsAttenuation[u_xlati13].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat13 = u_xlat16_6 * u_xlat18;
        u_xlat18 = dot(u_xlat4.xyz, vs_TEXCOORD5.xyz);
        u_xlat3.x = u_xlat18 * u_xlat13 + u_xlat3.x;
    }
    u_xlat15 = u_xlat17 * u_xlat16_1 + u_xlat3.x;
    u_xlat3.xy = vs_TEXCOORD4.xy * _OCMap_ST.xy + _OCMap_ST.zw;
    u_xlat16_17 = texture(_OCMap, u_xlat3.xy, -1.5).x;
    u_xlat17 = u_xlat16_17 * vs_COLOR0.w;
    u_xlat17 = dot(vec2(u_xlat17), vec2(u_xlat15));
    u_xlat17 = u_xlat17 + -0.0500000007;
    u_xlat17 = u_xlat17 * 5.0;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat3.x = u_xlat17 * -2.0 + 3.0;
    u_xlat17 = u_xlat17 * u_xlat17;
    u_xlat8.xy = vs_TEXCOORD4.xy * _SPMMap_ST.xy + _SPMMap_ST.zw;
    u_xlat16_8 = texture(_SPMMap, u_xlat8.xy, -1.5).x;
    u_xlat15 = u_xlat15 + u_xlat16_8;
    u_xlat15 = u_xlat15 + -0.800000012;
    u_xlat15 = u_xlat15 * 5.00000048;
    u_xlat15 = clamp(u_xlat15, 0.0, 1.0);
    u_xlat8.x = u_xlat15 * -2.0 + 3.0;
    u_xlat15 = u_xlat15 * u_xlat15;
    u_xlat15 = u_xlat15 * u_xlat8.x;
    u_xlat0.xyz = u_xlat16_0.xyz * _MainLightColor.xyz;
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.5, 0.5, 0.5);
    u_xlat2.xyz = max(u_xlat2.xyz, vec3(1.0, 1.0, 1.0));
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xyz;
    u_xlat2.x = (-u_xlat3.x) * u_xlat17 + 1.0;
    u_xlat2.x = (-u_xlat2.x) * 0.600000024 + 1.0;
    u_xlat15 = u_xlat15 * 0.0250000004;
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xxx + vec3(u_xlat15);
    u_xlat0.xyz = u_xlat0.xyz + (-unity_FogColor.xyz);
    u_xlat0.xyz = vec3(vs_TEXCOORD3) * u_xlat0.xyz + unity_FogColor.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 5: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	mediump vec4 unity_FogColor;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform UnityPerMaterial {
	vec4                _MainTex_ST;
	vec4 Xhlslcc_UnusedX_SkinColor;
	vec4 Xhlslcc_UnusedX_MSKMap_ST;
	vec4                _OCMap_ST;
	vec4                _SPMMap_ST;
};
UNITY_LOCATION(0) uniform mediump sampler2D _MainTex;
UNITY_LOCATION(1) uniform mediump sampler2D _OCMap;
UNITY_LOCATION(2) uniform mediump sampler2D _SPMMap;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 1) in highp  float vs_TEXCOORD3;
layout(location = 2) in highp  vec4 vs_TEXCOORD4;
layout(location = 3) in highp  vec4 vs_TEXCOORD5;
layout(location = 4) in highp  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
mediump float u_xlat16_1;
vec3 u_xlat2;
vec2 u_xlat3;
int u_xlati3;
uint u_xlatu3;
bool u_xlatb3;
vec3 u_xlat4;
mediump float u_xlat16_6;
vec3 u_xlat8;
mediump float u_xlat16_8;
int u_xlati8;
uint u_xlatu8;
float u_xlat9;
float u_xlat13;
int u_xlati13;
uint u_xlatu13;
bool u_xlatb13;
float u_xlat15;
uint u_xlatu15;
float u_xlat17;
mediump float u_xlat16_17;
uint u_xlatu17;
float u_xlat18;
int u_xlati18;
float u_xlat19;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat0.xy = vs_TEXCOORD4.xy * _MainTex_ST.xy + _MainTex_ST.zw;
    u_xlat16_0.xyz = texture(_MainTex, u_xlat0.xy, -1.5).xyz;
    u_xlat16_1 = max(_MainLightColor.y, _MainLightColor.x);
    u_xlat16_1 = max(u_xlat16_1, _MainLightColor.z);
    u_xlat16_6 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlatu15 =  uint(int(u_xlat16_6));
    u_xlat2.x = float(0.0);
    u_xlat2.y = float(0.0);
    u_xlat2.z = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<u_xlatu15 ; u_xlatu_loop_1++)
    {
        u_xlatu3 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati8 = int(u_xlatu_loop_1 & 3u);
        u_xlat3.x = dot(unity_LightIndices[int(u_xlatu3)], ImmCB_0[u_xlati8]);
        u_xlati3 = int(u_xlat3.x);
        u_xlat8.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati3].www + _AdditionalLightsPosition[u_xlati3].xyz;
        u_xlat4.x = dot(u_xlat8.xyz, u_xlat8.xyz);
        u_xlat4.x = max(u_xlat4.x, 6.10351562e-05);
        u_xlat9 = inversesqrt(u_xlat4.x);
        u_xlat8.xyz = u_xlat8.xyz * vec3(u_xlat9);
        u_xlat9 = float(1.0) / float(u_xlat4.x);
        u_xlat4.x = u_xlat4.x * _AdditionalLightsAttenuation[u_xlati3].x;
        u_xlat16_6 = (-u_xlat4.x) * u_xlat4.x + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat4.x = u_xlat16_6 * u_xlat9;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati3].xyz, u_xlat8.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati3].z + _AdditionalLightsAttenuation[u_xlati3].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat8.x = u_xlat16_6 * u_xlat4.x;
        u_xlat2.xyz = _AdditionalLightsColor[u_xlati3].xyz * u_xlat8.xxx + u_xlat2.xyz;
    }
    u_xlat17 = dot(vs_TEXCOORD5.xyz, _MainLightPosition.xyz);
    u_xlat3.x = float(0.0);
    for(uint u_xlatu_loop_2 = uint(0u) ; u_xlatu_loop_2<u_xlatu15 ; u_xlatu_loop_2++)
    {
        u_xlatu13 = u_xlatu_loop_2 >> (2u & uint(0x1F));
        u_xlati18 = int(u_xlatu_loop_2 & 3u);
        u_xlat13 = dot(unity_LightIndices[int(u_xlatu13)], ImmCB_0[u_xlati18]);
        u_xlati13 = int(u_xlat13);
        u_xlat4.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati13].www + _AdditionalLightsPosition[u_xlati13].xyz;
        u_xlat18 = dot(u_xlat4.xyz, u_xlat4.xyz);
        u_xlat18 = max(u_xlat18, 6.10351562e-05);
        u_xlat19 = inversesqrt(u_xlat18);
        u_xlat4.xyz = vec3(u_xlat19) * u_xlat4.xyz;
        u_xlat19 = float(1.0) / float(u_xlat18);
        u_xlat18 = u_xlat18 * _AdditionalLightsAttenuation[u_xlati13].x;
        u_xlat16_6 = (-u_xlat18) * u_xlat18 + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat18 = u_xlat16_6 * u_xlat19;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati13].xyz, u_xlat4.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati13].z + _AdditionalLightsAttenuation[u_xlati13].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat13 = u_xlat16_6 * u_xlat18;
        u_xlat18 = dot(u_xlat4.xyz, vs_TEXCOORD5.xyz);
        u_xlat3.x = u_xlat18 * u_xlat13 + u_xlat3.x;
    }
    u_xlat15 = u_xlat17 * u_xlat16_1 + u_xlat3.x;
    u_xlat3.xy = vs_TEXCOORD4.xy * _OCMap_ST.xy + _OCMap_ST.zw;
    u_xlat16_17 = texture(_OCMap, u_xlat3.xy, -1.5).x;
    u_xlat17 = u_xlat16_17 * vs_COLOR0.w;
    u_xlat17 = dot(vec2(u_xlat17), vec2(u_xlat15));
    u_xlat17 = u_xlat17 + -0.0500000007;
    u_xlat17 = u_xlat17 * 5.0;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat3.x = u_xlat17 * -2.0 + 3.0;
    u_xlat17 = u_xlat17 * u_xlat17;
    u_xlat8.xy = vs_TEXCOORD4.xy * _SPMMap_ST.xy + _SPMMap_ST.zw;
    u_xlat16_8 = texture(_SPMMap, u_xlat8.xy, -1.5).x;
    u_xlat15 = u_xlat15 + u_xlat16_8;
    u_xlat15 = u_xlat15 + -0.800000012;
    u_xlat15 = u_xlat15 * 5.00000048;
    u_xlat15 = clamp(u_xlat15, 0.0, 1.0);
    u_xlat8.x = u_xlat15 * -2.0 + 3.0;
    u_xlat15 = u_xlat15 * u_xlat15;
    u_xlat15 = u_xlat15 * u_xlat8.x;
    u_xlat0.xyz = u_xlat16_0.xyz * _MainLightColor.xyz;
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.5, 0.5, 0.5);
    u_xlat2.xyz = max(u_xlat2.xyz, vec3(1.0, 1.0, 1.0));
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xyz;
    u_xlat2.x = (-u_xlat3.x) * u_xlat17 + 1.0;
    u_xlat2.x = (-u_xlat2.x) * 0.600000024 + 1.0;
    u_xlat15 = u_xlat15 * 0.0250000004;
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xxx + vec3(u_xlat15);
    u_xlat0.xyz = u_xlat0.xyz + (-unity_FogColor.xyz);
    u_xlat0.xyz = vec3(vs_TEXCOORD3) * u_xlat0.xyz + unity_FogColor.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 6: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
layout(location = 4) out highp vec4 vs_TEXCOORD0;
layout(location = 0) out highp vec3 vs_TEXCOORD1;
layout(location = 5) out highp float vs_TEXCOORD3;
layout(location = 1) out highp vec4 vs_TEXCOORD4;
layout(location = 2) out highp vec4 vs_TEXCOORD5;
layout(location = 3) out highp vec4 vs_COLOR0;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_TEXCOORD1.xyz = u_xlat0.xyz;
    u_xlat0 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    vs_TEXCOORD0 = u_xlat0;
    vs_TEXCOORD3 = 0.0;
    vs_TEXCOORD4.xy = in_TEXCOORD0.xy;
    vs_TEXCOORD4.zw = vec2(0.0, 0.0);
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_TEXCOORD5.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    vs_TEXCOORD5.w = 0.0;
    vs_COLOR0 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	float _DitheringTextureInvSize;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform UnityPerMaterial {
	vec4                _MainTex_ST;
	vec4 Xhlslcc_UnusedX_SkinColor;
	vec4 Xhlslcc_UnusedX_MSKMap_ST;
	vec4                _OCMap_ST;
	vec4                _SPMMap_ST;
};
UNITY_LOCATION(0) uniform mediump sampler2D _MainTex;
UNITY_LOCATION(1) uniform mediump sampler2D _OCMap;
UNITY_LOCATION(2) uniform mediump sampler2D _SPMMap;
UNITY_LOCATION(3) uniform mediump sampler2D _DitheringTexture;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 1) in highp  vec4 vs_TEXCOORD4;
layout(location = 2) in highp  vec4 vs_TEXCOORD5;
layout(location = 3) in highp  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
mediump float u_xlat16_1;
vec3 u_xlat2;
bool u_xlatb2;
vec2 u_xlat3;
int u_xlati3;
uint u_xlatu3;
bool u_xlatb3;
vec3 u_xlat4;
mediump float u_xlat16_6;
vec3 u_xlat8;
mediump float u_xlat16_8;
int u_xlati8;
uint u_xlatu8;
float u_xlat9;
float u_xlat13;
int u_xlati13;
uint u_xlatu13;
bool u_xlatb13;
float u_xlat15;
mediump float u_xlat16_15;
uint u_xlatu15;
bool u_xlatb15;
float u_xlat17;
mediump float u_xlat16_17;
uint u_xlatu17;
float u_xlat18;
int u_xlati18;
float u_xlat19;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = vs_TEXCOORD4.xy * _MainTex_ST.xy + _MainTex_ST.zw;
    u_xlat16_0.xyz = texture(_MainTex, u_xlat0.xy, -1.5).xyz;
    u_xlat16_1 = max(_MainLightColor.y, _MainLightColor.x);
    u_xlat16_1 = max(u_xlat16_1, _MainLightColor.z);
    u_xlat16_6 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlatu15 =  uint(int(u_xlat16_6));
    u_xlat2.x = float(0.0);
    u_xlat2.y = float(0.0);
    u_xlat2.z = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<u_xlatu15 ; u_xlatu_loop_1++)
    {
        u_xlatu3 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati8 = int(u_xlatu_loop_1 & 3u);
        u_xlat3.x = dot(unity_LightIndices[int(u_xlatu3)], ImmCB_0[u_xlati8]);
        u_xlati3 = int(u_xlat3.x);
        u_xlat8.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati3].www + _AdditionalLightsPosition[u_xlati3].xyz;
        u_xlat4.x = dot(u_xlat8.xyz, u_xlat8.xyz);
        u_xlat4.x = max(u_xlat4.x, 6.10351562e-05);
        u_xlat9 = inversesqrt(u_xlat4.x);
        u_xlat8.xyz = u_xlat8.xyz * vec3(u_xlat9);
        u_xlat9 = float(1.0) / float(u_xlat4.x);
        u_xlat4.x = u_xlat4.x * _AdditionalLightsAttenuation[u_xlati3].x;
        u_xlat16_6 = (-u_xlat4.x) * u_xlat4.x + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat4.x = u_xlat16_6 * u_xlat9;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati3].xyz, u_xlat8.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati3].z + _AdditionalLightsAttenuation[u_xlati3].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat8.x = u_xlat16_6 * u_xlat4.x;
        u_xlat2.xyz = _AdditionalLightsColor[u_xlati3].xyz * u_xlat8.xxx + u_xlat2.xyz;
    }
    u_xlat17 = dot(vs_TEXCOORD5.xyz, _MainLightPosition.xyz);
    u_xlat3.x = float(0.0);
    for(uint u_xlatu_loop_2 = uint(0u) ; u_xlatu_loop_2<u_xlatu15 ; u_xlatu_loop_2++)
    {
        u_xlatu13 = u_xlatu_loop_2 >> (2u & uint(0x1F));
        u_xlati18 = int(u_xlatu_loop_2 & 3u);
        u_xlat13 = dot(unity_LightIndices[int(u_xlatu13)], ImmCB_0[u_xlati18]);
        u_xlati13 = int(u_xlat13);
        u_xlat4.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati13].www + _AdditionalLightsPosition[u_xlati13].xyz;
        u_xlat18 = dot(u_xlat4.xyz, u_xlat4.xyz);
        u_xlat18 = max(u_xlat18, 6.10351562e-05);
        u_xlat19 = inversesqrt(u_xlat18);
        u_xlat4.xyz = vec3(u_xlat19) * u_xlat4.xyz;
        u_xlat19 = float(1.0) / float(u_xlat18);
        u_xlat18 = u_xlat18 * _AdditionalLightsAttenuation[u_xlati13].x;
        u_xlat16_6 = (-u_xlat18) * u_xlat18 + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat18 = u_xlat16_6 * u_xlat19;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati13].xyz, u_xlat4.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati13].z + _AdditionalLightsAttenuation[u_xlati13].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat13 = u_xlat16_6 * u_xlat18;
        u_xlat18 = dot(u_xlat4.xyz, vs_TEXCOORD5.xyz);
        u_xlat3.x = u_xlat18 * u_xlat13 + u_xlat3.x;
    }
    u_xlat15 = u_xlat17 * u_xlat16_1 + u_xlat3.x;
    u_xlat3.xy = vs_TEXCOORD4.xy * _OCMap_ST.xy + _OCMap_ST.zw;
    u_xlat16_17 = texture(_OCMap, u_xlat3.xy, -1.5).x;
    u_xlat17 = u_xlat16_17 * vs_COLOR0.w;
    u_xlat17 = dot(vec2(u_xlat17), vec2(u_xlat15));
    u_xlat17 = u_xlat17 + -0.0500000007;
    u_xlat17 = u_xlat17 * 5.0;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat3.x = u_xlat17 * -2.0 + 3.0;
    u_xlat17 = u_xlat17 * u_xlat17;
    u_xlat8.xy = vs_TEXCOORD4.xy * _SPMMap_ST.xy + _SPMMap_ST.zw;
    u_xlat16_8 = texture(_SPMMap, u_xlat8.xy, -1.5).x;
    u_xlat15 = u_xlat15 + u_xlat16_8;
    u_xlat15 = u_xlat15 + -0.800000012;
    u_xlat15 = u_xlat15 * 5.00000048;
    u_xlat15 = clamp(u_xlat15, 0.0, 1.0);
    u_xlat8.x = u_xlat15 * -2.0 + 3.0;
    u_xlat15 = u_xlat15 * u_xlat15;
    u_xlat15 = u_xlat15 * u_xlat8.x;
    u_xlat0.xyz = u_xlat16_0.xyz * _MainLightColor.xyz;
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.5, 0.5, 0.5);
    u_xlat2.xyz = max(u_xlat2.xyz, vec3(1.0, 1.0, 1.0));
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xyz;
    u_xlat2.x = (-u_xlat3.x) * u_xlat17 + 1.0;
    u_xlat2.x = (-u_xlat2.x) * 0.600000024 + 1.0;
    u_xlat15 = u_xlat15 * 0.0250000004;
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xxx + vec3(u_xlat15);
    u_xlat2.xy = hlslcc_FragCoord.xy * vec2(vec2(_DitheringTextureInvSize, _DitheringTextureInvSize));
    u_xlat16_15 = texture(_DitheringTexture, u_xlat2.xy, _GlobalMipBias.x).w;
    u_xlatb2 = unity_LODFade.x>=0.0;
    u_xlat15 = (u_xlatb2) ? abs(u_xlat16_15) : -abs(u_xlat16_15);
    u_xlat15 = (-u_xlat15) + unity_LODFade.x;
    u_xlatb15 = u_xlat15<0.0;
    if(u_xlatb15){discard;}
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 7: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	float _DitheringTextureInvSize;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform UnityPerMaterial {
	vec4                _MainTex_ST;
	vec4 Xhlslcc_UnusedX_SkinColor;
	vec4 Xhlslcc_UnusedX_MSKMap_ST;
	vec4                _OCMap_ST;
	vec4                _SPMMap_ST;
};
UNITY_LOCATION(0) uniform mediump sampler2D _MainTex;
UNITY_LOCATION(1) uniform mediump sampler2D _OCMap;
UNITY_LOCATION(2) uniform mediump sampler2D _SPMMap;
UNITY_LOCATION(3) uniform mediump sampler2D _DitheringTexture;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 1) in highp  vec4 vs_TEXCOORD4;
layout(location = 2) in highp  vec4 vs_TEXCOORD5;
layout(location = 3) in highp  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
mediump float u_xlat16_1;
vec3 u_xlat2;
bool u_xlatb2;
vec2 u_xlat3;
int u_xlati3;
uint u_xlatu3;
bool u_xlatb3;
vec3 u_xlat4;
mediump float u_xlat16_6;
vec3 u_xlat8;
mediump float u_xlat16_8;
int u_xlati8;
uint u_xlatu8;
float u_xlat9;
float u_xlat13;
int u_xlati13;
uint u_xlatu13;
bool u_xlatb13;
float u_xlat15;
mediump float u_xlat16_15;
uint u_xlatu15;
bool u_xlatb15;
float u_xlat17;
mediump float u_xlat16_17;
uint u_xlatu17;
float u_xlat18;
int u_xlati18;
float u_xlat19;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = vs_TEXCOORD4.xy * _MainTex_ST.xy + _MainTex_ST.zw;
    u_xlat16_0.xyz = texture(_MainTex, u_xlat0.xy, -1.5).xyz;
    u_xlat16_1 = max(_MainLightColor.y, _MainLightColor.x);
    u_xlat16_1 = max(u_xlat16_1, _MainLightColor.z);
    u_xlat16_6 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlatu15 =  uint(int(u_xlat16_6));
    u_xlat2.x = float(0.0);
    u_xlat2.y = float(0.0);
    u_xlat2.z = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<u_xlatu15 ; u_xlatu_loop_1++)
    {
        u_xlatu3 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati8 = int(u_xlatu_loop_1 & 3u);
        u_xlat3.x = dot(unity_LightIndices[int(u_xlatu3)], ImmCB_0[u_xlati8]);
        u_xlati3 = int(u_xlat3.x);
        u_xlat8.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati3].www + _AdditionalLightsPosition[u_xlati3].xyz;
        u_xlat4.x = dot(u_xlat8.xyz, u_xlat8.xyz);
        u_xlat4.x = max(u_xlat4.x, 6.10351562e-05);
        u_xlat9 = inversesqrt(u_xlat4.x);
        u_xlat8.xyz = u_xlat8.xyz * vec3(u_xlat9);
        u_xlat9 = float(1.0) / float(u_xlat4.x);
        u_xlat4.x = u_xlat4.x * _AdditionalLightsAttenuation[u_xlati3].x;
        u_xlat16_6 = (-u_xlat4.x) * u_xlat4.x + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat4.x = u_xlat16_6 * u_xlat9;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati3].xyz, u_xlat8.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati3].z + _AdditionalLightsAttenuation[u_xlati3].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat8.x = u_xlat16_6 * u_xlat4.x;
        u_xlat2.xyz = _AdditionalLightsColor[u_xlati3].xyz * u_xlat8.xxx + u_xlat2.xyz;
    }
    u_xlat17 = dot(vs_TEXCOORD5.xyz, _MainLightPosition.xyz);
    u_xlat3.x = float(0.0);
    for(uint u_xlatu_loop_2 = uint(0u) ; u_xlatu_loop_2<u_xlatu15 ; u_xlatu_loop_2++)
    {
        u_xlatu13 = u_xlatu_loop_2 >> (2u & uint(0x1F));
        u_xlati18 = int(u_xlatu_loop_2 & 3u);
        u_xlat13 = dot(unity_LightIndices[int(u_xlatu13)], ImmCB_0[u_xlati18]);
        u_xlati13 = int(u_xlat13);
        u_xlat4.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati13].www + _AdditionalLightsPosition[u_xlati13].xyz;
        u_xlat18 = dot(u_xlat4.xyz, u_xlat4.xyz);
        u_xlat18 = max(u_xlat18, 6.10351562e-05);
        u_xlat19 = inversesqrt(u_xlat18);
        u_xlat4.xyz = vec3(u_xlat19) * u_xlat4.xyz;
        u_xlat19 = float(1.0) / float(u_xlat18);
        u_xlat18 = u_xlat18 * _AdditionalLightsAttenuation[u_xlati13].x;
        u_xlat16_6 = (-u_xlat18) * u_xlat18 + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat18 = u_xlat16_6 * u_xlat19;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati13].xyz, u_xlat4.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati13].z + _AdditionalLightsAttenuation[u_xlati13].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat13 = u_xlat16_6 * u_xlat18;
        u_xlat18 = dot(u_xlat4.xyz, vs_TEXCOORD5.xyz);
        u_xlat3.x = u_xlat18 * u_xlat13 + u_xlat3.x;
    }
    u_xlat15 = u_xlat17 * u_xlat16_1 + u_xlat3.x;
    u_xlat3.xy = vs_TEXCOORD4.xy * _OCMap_ST.xy + _OCMap_ST.zw;
    u_xlat16_17 = texture(_OCMap, u_xlat3.xy, -1.5).x;
    u_xlat17 = u_xlat16_17 * vs_COLOR0.w;
    u_xlat17 = dot(vec2(u_xlat17), vec2(u_xlat15));
    u_xlat17 = u_xlat17 + -0.0500000007;
    u_xlat17 = u_xlat17 * 5.0;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat3.x = u_xlat17 * -2.0 + 3.0;
    u_xlat17 = u_xlat17 * u_xlat17;
    u_xlat8.xy = vs_TEXCOORD4.xy * _SPMMap_ST.xy + _SPMMap_ST.zw;
    u_xlat16_8 = texture(_SPMMap, u_xlat8.xy, -1.5).x;
    u_xlat15 = u_xlat15 + u_xlat16_8;
    u_xlat15 = u_xlat15 + -0.800000012;
    u_xlat15 = u_xlat15 * 5.00000048;
    u_xlat15 = clamp(u_xlat15, 0.0, 1.0);
    u_xlat8.x = u_xlat15 * -2.0 + 3.0;
    u_xlat15 = u_xlat15 * u_xlat15;
    u_xlat15 = u_xlat15 * u_xlat8.x;
    u_xlat0.xyz = u_xlat16_0.xyz * _MainLightColor.xyz;
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.5, 0.5, 0.5);
    u_xlat2.xyz = max(u_xlat2.xyz, vec3(1.0, 1.0, 1.0));
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xyz;
    u_xlat2.x = (-u_xlat3.x) * u_xlat17 + 1.0;
    u_xlat2.x = (-u_xlat2.x) * 0.600000024 + 1.0;
    u_xlat15 = u_xlat15 * 0.0250000004;
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xxx + vec3(u_xlat15);
    u_xlat2.xy = hlslcc_FragCoord.xy * vec2(vec2(_DitheringTextureInvSize, _DitheringTextureInvSize));
    u_xlat16_15 = texture(_DitheringTexture, u_xlat2.xy, _GlobalMipBias.x).w;
    u_xlatb2 = unity_LODFade.x>=0.0;
    u_xlat15 = (u_xlatb2) ? abs(u_xlat16_15) : -abs(u_xlat16_15);
    u_xlat15 = (-u_xlat15) + unity_LODFade.x;
    u_xlatb15 = u_xlat15<0.0;
    if(u_xlatb15){discard;}
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 8: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
layout(location = 5) out highp vec4 vs_TEXCOORD0;
layout(location = 0) out highp vec3 vs_TEXCOORD1;
layout(location = 1) out highp float vs_TEXCOORD3;
layout(location = 2) out highp vec4 vs_TEXCOORD4;
layout(location = 3) out highp vec4 vs_TEXCOORD5;
layout(location = 4) out highp vec4 vs_COLOR0;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat2;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_TEXCOORD1.xyz = u_xlat0.xyz;
    u_xlat0 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    vs_TEXCOORD0 = u_xlat0;
    u_xlat0.x = u_xlat0.z + _ProjectionParams.y;
    u_xlat2 = _ProjectionParams.y + _ProjectionParams.z;
    u_xlat0.x = u_xlat0.x / u_xlat2;
    u_xlat0.x = u_xlat0.x * _ProjectionParams.z;
    u_xlat0.x = max(u_xlat0.x, 0.0);
    vs_TEXCOORD3 = u_xlat0.x * unity_FogParams.z + unity_FogParams.w;
    vs_TEXCOORD3 = clamp(vs_TEXCOORD3, 0.0, 1.0);
    vs_TEXCOORD4.xy = in_TEXCOORD0.xy;
    vs_TEXCOORD4.zw = vec2(0.0, 0.0);
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_TEXCOORD5.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    vs_TEXCOORD5.w = 0.0;
    vs_COLOR0 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	mediump vec4 unity_FogColor;
uniform 	float _DitheringTextureInvSize;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform UnityPerMaterial {
	vec4                _MainTex_ST;
	vec4 Xhlslcc_UnusedX_SkinColor;
	vec4 Xhlslcc_UnusedX_MSKMap_ST;
	vec4                _OCMap_ST;
	vec4                _SPMMap_ST;
};
UNITY_LOCATION(0) uniform mediump sampler2D _MainTex;
UNITY_LOCATION(1) uniform mediump sampler2D _OCMap;
UNITY_LOCATION(2) uniform mediump sampler2D _SPMMap;
UNITY_LOCATION(3) uniform mediump sampler2D _DitheringTexture;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 1) in highp  float vs_TEXCOORD3;
layout(location = 2) in highp  vec4 vs_TEXCOORD4;
layout(location = 3) in highp  vec4 vs_TEXCOORD5;
layout(location = 4) in highp  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
mediump float u_xlat16_1;
vec3 u_xlat2;
bool u_xlatb2;
vec2 u_xlat3;
int u_xlati3;
uint u_xlatu3;
bool u_xlatb3;
vec3 u_xlat4;
mediump float u_xlat16_6;
vec3 u_xlat8;
mediump float u_xlat16_8;
int u_xlati8;
uint u_xlatu8;
float u_xlat9;
float u_xlat13;
int u_xlati13;
uint u_xlatu13;
bool u_xlatb13;
float u_xlat15;
mediump float u_xlat16_15;
uint u_xlatu15;
bool u_xlatb15;
float u_xlat17;
mediump float u_xlat16_17;
uint u_xlatu17;
float u_xlat18;
int u_xlati18;
float u_xlat19;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = vs_TEXCOORD4.xy * _MainTex_ST.xy + _MainTex_ST.zw;
    u_xlat16_0.xyz = texture(_MainTex, u_xlat0.xy, -1.5).xyz;
    u_xlat16_1 = max(_MainLightColor.y, _MainLightColor.x);
    u_xlat16_1 = max(u_xlat16_1, _MainLightColor.z);
    u_xlat16_6 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlatu15 =  uint(int(u_xlat16_6));
    u_xlat2.x = float(0.0);
    u_xlat2.y = float(0.0);
    u_xlat2.z = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<u_xlatu15 ; u_xlatu_loop_1++)
    {
        u_xlatu3 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati8 = int(u_xlatu_loop_1 & 3u);
        u_xlat3.x = dot(unity_LightIndices[int(u_xlatu3)], ImmCB_0[u_xlati8]);
        u_xlati3 = int(u_xlat3.x);
        u_xlat8.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati3].www + _AdditionalLightsPosition[u_xlati3].xyz;
        u_xlat4.x = dot(u_xlat8.xyz, u_xlat8.xyz);
        u_xlat4.x = max(u_xlat4.x, 6.10351562e-05);
        u_xlat9 = inversesqrt(u_xlat4.x);
        u_xlat8.xyz = u_xlat8.xyz * vec3(u_xlat9);
        u_xlat9 = float(1.0) / float(u_xlat4.x);
        u_xlat4.x = u_xlat4.x * _AdditionalLightsAttenuation[u_xlati3].x;
        u_xlat16_6 = (-u_xlat4.x) * u_xlat4.x + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat4.x = u_xlat16_6 * u_xlat9;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati3].xyz, u_xlat8.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati3].z + _AdditionalLightsAttenuation[u_xlati3].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat8.x = u_xlat16_6 * u_xlat4.x;
        u_xlat2.xyz = _AdditionalLightsColor[u_xlati3].xyz * u_xlat8.xxx + u_xlat2.xyz;
    }
    u_xlat17 = dot(vs_TEXCOORD5.xyz, _MainLightPosition.xyz);
    u_xlat3.x = float(0.0);
    for(uint u_xlatu_loop_2 = uint(0u) ; u_xlatu_loop_2<u_xlatu15 ; u_xlatu_loop_2++)
    {
        u_xlatu13 = u_xlatu_loop_2 >> (2u & uint(0x1F));
        u_xlati18 = int(u_xlatu_loop_2 & 3u);
        u_xlat13 = dot(unity_LightIndices[int(u_xlatu13)], ImmCB_0[u_xlati18]);
        u_xlati13 = int(u_xlat13);
        u_xlat4.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati13].www + _AdditionalLightsPosition[u_xlati13].xyz;
        u_xlat18 = dot(u_xlat4.xyz, u_xlat4.xyz);
        u_xlat18 = max(u_xlat18, 6.10351562e-05);
        u_xlat19 = inversesqrt(u_xlat18);
        u_xlat4.xyz = vec3(u_xlat19) * u_xlat4.xyz;
        u_xlat19 = float(1.0) / float(u_xlat18);
        u_xlat18 = u_xlat18 * _AdditionalLightsAttenuation[u_xlati13].x;
        u_xlat16_6 = (-u_xlat18) * u_xlat18 + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat18 = u_xlat16_6 * u_xlat19;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati13].xyz, u_xlat4.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati13].z + _AdditionalLightsAttenuation[u_xlati13].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat13 = u_xlat16_6 * u_xlat18;
        u_xlat18 = dot(u_xlat4.xyz, vs_TEXCOORD5.xyz);
        u_xlat3.x = u_xlat18 * u_xlat13 + u_xlat3.x;
    }
    u_xlat15 = u_xlat17 * u_xlat16_1 + u_xlat3.x;
    u_xlat3.xy = vs_TEXCOORD4.xy * _OCMap_ST.xy + _OCMap_ST.zw;
    u_xlat16_17 = texture(_OCMap, u_xlat3.xy, -1.5).x;
    u_xlat17 = u_xlat16_17 * vs_COLOR0.w;
    u_xlat17 = dot(vec2(u_xlat17), vec2(u_xlat15));
    u_xlat17 = u_xlat17 + -0.0500000007;
    u_xlat17 = u_xlat17 * 5.0;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat3.x = u_xlat17 * -2.0 + 3.0;
    u_xlat17 = u_xlat17 * u_xlat17;
    u_xlat8.xy = vs_TEXCOORD4.xy * _SPMMap_ST.xy + _SPMMap_ST.zw;
    u_xlat16_8 = texture(_SPMMap, u_xlat8.xy, -1.5).x;
    u_xlat15 = u_xlat15 + u_xlat16_8;
    u_xlat15 = u_xlat15 + -0.800000012;
    u_xlat15 = u_xlat15 * 5.00000048;
    u_xlat15 = clamp(u_xlat15, 0.0, 1.0);
    u_xlat8.x = u_xlat15 * -2.0 + 3.0;
    u_xlat15 = u_xlat15 * u_xlat15;
    u_xlat15 = u_xlat15 * u_xlat8.x;
    u_xlat0.xyz = u_xlat16_0.xyz * _MainLightColor.xyz;
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.5, 0.5, 0.5);
    u_xlat2.xyz = max(u_xlat2.xyz, vec3(1.0, 1.0, 1.0));
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xyz;
    u_xlat2.x = (-u_xlat3.x) * u_xlat17 + 1.0;
    u_xlat2.x = (-u_xlat2.x) * 0.600000024 + 1.0;
    u_xlat15 = u_xlat15 * 0.0250000004;
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xxx + vec3(u_xlat15);
    u_xlat2.xy = hlslcc_FragCoord.xy * vec2(vec2(_DitheringTextureInvSize, _DitheringTextureInvSize));
    u_xlat16_15 = texture(_DitheringTexture, u_xlat2.xy, _GlobalMipBias.x).w;
    u_xlatb2 = unity_LODFade.x>=0.0;
    u_xlat15 = (u_xlatb2) ? abs(u_xlat16_15) : -abs(u_xlat16_15);
    u_xlat15 = (-u_xlat15) + unity_LODFade.x;
    u_xlatb15 = u_xlat15<0.0;
    if(u_xlatb15){discard;}
    u_xlat0.xyz = u_xlat0.xyz + (-unity_FogColor.xyz);
    u_xlat0.xyz = vec3(vs_TEXCOORD3) * u_xlat0.xyz + unity_FogColor.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 9: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	mediump vec4 unity_FogColor;
uniform 	float _DitheringTextureInvSize;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform UnityPerMaterial {
	vec4                _MainTex_ST;
	vec4 Xhlslcc_UnusedX_SkinColor;
	vec4 Xhlslcc_UnusedX_MSKMap_ST;
	vec4                _OCMap_ST;
	vec4                _SPMMap_ST;
};
UNITY_LOCATION(0) uniform mediump sampler2D _MainTex;
UNITY_LOCATION(1) uniform mediump sampler2D _OCMap;
UNITY_LOCATION(2) uniform mediump sampler2D _SPMMap;
UNITY_LOCATION(3) uniform mediump sampler2D _DitheringTexture;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 1) in highp  float vs_TEXCOORD3;
layout(location = 2) in highp  vec4 vs_TEXCOORD4;
layout(location = 3) in highp  vec4 vs_TEXCOORD5;
layout(location = 4) in highp  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
mediump float u_xlat16_1;
vec3 u_xlat2;
bool u_xlatb2;
vec2 u_xlat3;
int u_xlati3;
uint u_xlatu3;
bool u_xlatb3;
vec3 u_xlat4;
mediump float u_xlat16_6;
vec3 u_xlat8;
mediump float u_xlat16_8;
int u_xlati8;
uint u_xlatu8;
float u_xlat9;
float u_xlat13;
int u_xlati13;
uint u_xlatu13;
bool u_xlatb13;
float u_xlat15;
mediump float u_xlat16_15;
uint u_xlatu15;
bool u_xlatb15;
float u_xlat17;
mediump float u_xlat16_17;
uint u_xlatu17;
float u_xlat18;
int u_xlati18;
float u_xlat19;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = vs_TEXCOORD4.xy * _MainTex_ST.xy + _MainTex_ST.zw;
    u_xlat16_0.xyz = texture(_MainTex, u_xlat0.xy, -1.5).xyz;
    u_xlat16_1 = max(_MainLightColor.y, _MainLightColor.x);
    u_xlat16_1 = max(u_xlat16_1, _MainLightColor.z);
    u_xlat16_6 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlatu15 =  uint(int(u_xlat16_6));
    u_xlat2.x = float(0.0);
    u_xlat2.y = float(0.0);
    u_xlat2.z = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<u_xlatu15 ; u_xlatu_loop_1++)
    {
        u_xlatu3 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati8 = int(u_xlatu_loop_1 & 3u);
        u_xlat3.x = dot(unity_LightIndices[int(u_xlatu3)], ImmCB_0[u_xlati8]);
        u_xlati3 = int(u_xlat3.x);
        u_xlat8.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati3].www + _AdditionalLightsPosition[u_xlati3].xyz;
        u_xlat4.x = dot(u_xlat8.xyz, u_xlat8.xyz);
        u_xlat4.x = max(u_xlat4.x, 6.10351562e-05);
        u_xlat9 = inversesqrt(u_xlat4.x);
        u_xlat8.xyz = u_xlat8.xyz * vec3(u_xlat9);
        u_xlat9 = float(1.0) / float(u_xlat4.x);
        u_xlat4.x = u_xlat4.x * _AdditionalLightsAttenuation[u_xlati3].x;
        u_xlat16_6 = (-u_xlat4.x) * u_xlat4.x + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat4.x = u_xlat16_6 * u_xlat9;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati3].xyz, u_xlat8.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati3].z + _AdditionalLightsAttenuation[u_xlati3].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat8.x = u_xlat16_6 * u_xlat4.x;
        u_xlat2.xyz = _AdditionalLightsColor[u_xlati3].xyz * u_xlat8.xxx + u_xlat2.xyz;
    }
    u_xlat17 = dot(vs_TEXCOORD5.xyz, _MainLightPosition.xyz);
    u_xlat3.x = float(0.0);
    for(uint u_xlatu_loop_2 = uint(0u) ; u_xlatu_loop_2<u_xlatu15 ; u_xlatu_loop_2++)
    {
        u_xlatu13 = u_xlatu_loop_2 >> (2u & uint(0x1F));
        u_xlati18 = int(u_xlatu_loop_2 & 3u);
        u_xlat13 = dot(unity_LightIndices[int(u_xlatu13)], ImmCB_0[u_xlati18]);
        u_xlati13 = int(u_xlat13);
        u_xlat4.xyz = (-vs_TEXCOORD1.xyz) * _AdditionalLightsPosition[u_xlati13].www + _AdditionalLightsPosition[u_xlati13].xyz;
        u_xlat18 = dot(u_xlat4.xyz, u_xlat4.xyz);
        u_xlat18 = max(u_xlat18, 6.10351562e-05);
        u_xlat19 = inversesqrt(u_xlat18);
        u_xlat4.xyz = vec3(u_xlat19) * u_xlat4.xyz;
        u_xlat19 = float(1.0) / float(u_xlat18);
        u_xlat18 = u_xlat18 * _AdditionalLightsAttenuation[u_xlati13].x;
        u_xlat16_6 = (-u_xlat18) * u_xlat18 + 1.0;
        u_xlat16_6 = max(u_xlat16_6, 0.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat18 = u_xlat16_6 * u_xlat19;
        u_xlat16_6 = dot(_AdditionalLightsSpotDir[u_xlati13].xyz, u_xlat4.xyz);
        u_xlat16_6 = u_xlat16_6 * _AdditionalLightsAttenuation[u_xlati13].z + _AdditionalLightsAttenuation[u_xlati13].w;
        u_xlat16_6 = clamp(u_xlat16_6, 0.0, 1.0);
        u_xlat16_6 = u_xlat16_6 * u_xlat16_6;
        u_xlat13 = u_xlat16_6 * u_xlat18;
        u_xlat18 = dot(u_xlat4.xyz, vs_TEXCOORD5.xyz);
        u_xlat3.x = u_xlat18 * u_xlat13 + u_xlat3.x;
    }
    u_xlat15 = u_xlat17 * u_xlat16_1 + u_xlat3.x;
    u_xlat3.xy = vs_TEXCOORD4.xy * _OCMap_ST.xy + _OCMap_ST.zw;
    u_xlat16_17 = texture(_OCMap, u_xlat3.xy, -1.5).x;
    u_xlat17 = u_xlat16_17 * vs_COLOR0.w;
    u_xlat17 = dot(vec2(u_xlat17), vec2(u_xlat15));
    u_xlat17 = u_xlat17 + -0.0500000007;
    u_xlat17 = u_xlat17 * 5.0;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat3.x = u_xlat17 * -2.0 + 3.0;
    u_xlat17 = u_xlat17 * u_xlat17;
    u_xlat8.xy = vs_TEXCOORD4.xy * _SPMMap_ST.xy + _SPMMap_ST.zw;
    u_xlat16_8 = texture(_SPMMap, u_xlat8.xy, -1.5).x;
    u_xlat15 = u_xlat15 + u_xlat16_8;
    u_xlat15 = u_xlat15 + -0.800000012;
    u_xlat15 = u_xlat15 * 5.00000048;
    u_xlat15 = clamp(u_xlat15, 0.0, 1.0);
    u_xlat8.x = u_xlat15 * -2.0 + 3.0;
    u_xlat15 = u_xlat15 * u_xlat15;
    u_xlat15 = u_xlat15 * u_xlat8.x;
    u_xlat0.xyz = u_xlat16_0.xyz * _MainLightColor.xyz;
    u_xlat2.xyz = u_xlat2.xyz * vec3(0.5, 0.5, 0.5);
    u_xlat2.xyz = max(u_xlat2.xyz, vec3(1.0, 1.0, 1.0));
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xyz;
    u_xlat2.x = (-u_xlat3.x) * u_xlat17 + 1.0;
    u_xlat2.x = (-u_xlat2.x) * 0.600000024 + 1.0;
    u_xlat15 = u_xlat15 * 0.0250000004;
    u_xlat0.xyz = u_xlat0.xyz * u_xlat2.xxx + vec3(u_xlat15);
    u_xlat2.xy = hlslcc_FragCoord.xy * vec2(vec2(_DitheringTextureInvSize, _DitheringTextureInvSize));
    u_xlat16_15 = texture(_DitheringTexture, u_xlat2.xy, _GlobalMipBias.x).w;
    u_xlatb2 = unity_LODFade.x>=0.0;
    u_xlat15 = (u_xlatb2) ? abs(u_xlat16_15) : -abs(u_xlat16_15);
    u_xlat15 = (-u_xlat15) + unity_LODFade.x;
    u_xlatb15 = u_xlat15<0.0;
    if(u_xlatb15){discard;}
    u_xlat0.xyz = u_xlat0.xyz + (-unity_FogColor.xyz);
    u_xlat0.xyz = vec3(vs_TEXCOORD3) * u_xlat0.xyz + unity_FogColor.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 10: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightDirection;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat0.xyz = vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z) * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat1.xyz = in_NORMAL0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_NORMAL0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_NORMAL0.zzz + u_xlat1.xyz;
    u_xlat6 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    u_xlat1.xyz = vec3(u_xlat6) * u_xlat1.xyz;
    u_xlat6 = dot(vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z), u_xlat1.xyz);
    u_xlat6 = clamp(u_xlat6, 0.0, 1.0);
    u_xlat6 = (-u_xlat6) + 1.0;
    u_xlat6 = u_xlat6 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat1.xyz * vec3(u_xlat6) + u_xlat0.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position.z = max(u_xlat0.z, -1.0);
    gl_Position.xyw = u_xlat0.xyw;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 11: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 12: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightDirection;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat0.xyz = _LightDirection.xyz * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat1.xyz = in_NORMAL0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_NORMAL0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_NORMAL0.zzz + u_xlat1.xyz;
    u_xlat6 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    u_xlat1.xyz = vec3(u_xlat6) * u_xlat1.xyz;
    u_xlat6 = dot(_LightDirection.xyz, u_xlat1.xyz);
    u_xlat6 = clamp(u_xlat6, 0.0, 1.0);
    u_xlat6 = (-u_xlat6) + 1.0;
    u_xlat6 = u_xlat6 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat1.xyz * vec3(u_xlat6) + u_xlat0.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position.z = max(u_xlat0.z, -1.0);
    gl_Position.xyw = u_xlat0.xyw;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _DitheringTextureInvSize;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_LOCATION(0) uniform mediump sampler2D _DitheringTexture;
layout(location = 0) out mediump vec4 SV_TARGET0;
vec2 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
bool u_xlatb1;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = hlslcc_FragCoord.xy * vec2(vec2(_DitheringTextureInvSize, _DitheringTextureInvSize));
    u_xlat16_0 = texture(_DitheringTexture, u_xlat0.xy, _GlobalMipBias.x).w;
    u_xlatb1 = unity_LODFade.x>=0.0;
    u_xlat0.x = (u_xlatb1) ? abs(u_xlat16_0) : -abs(u_xlat16_0);
    u_xlat0.x = (-u_xlat0.x) + unity_LODFade.x;
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 13: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _DitheringTextureInvSize;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_LOCATION(0) uniform mediump sampler2D _DitheringTexture;
layout(location = 0) out mediump vec4 SV_TARGET0;
vec2 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
bool u_xlatb1;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = hlslcc_FragCoord.xy * vec2(vec2(_DitheringTextureInvSize, _DitheringTextureInvSize));
    u_xlat16_0 = texture(_DitheringTexture, u_xlat0.xy, _GlobalMipBias.x).w;
    u_xlatb1 = unity_LODFade.x>=0.0;
    u_xlat0.x = (u_xlatb1) ? abs(u_xlat16_0) : -abs(u_xlat16_0);
    u_xlat0.x = (-u_xlat0.x) + unity_LODFade.x;
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 14: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightPosition;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
float u_xlat9;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + _LightPosition.xyz;
    u_xlat9 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat9 = inversesqrt(u_xlat9);
    u_xlat1.xyz = vec3(u_xlat9) * u_xlat1.xyz;
    u_xlat0.xyz = u_xlat1.xyz * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat2.xyz = in_NORMAL0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_NORMAL0.xxx + u_xlat2.xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_NORMAL0.zzz + u_xlat2.xyz;
    u_xlat9 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat9 = max(u_xlat9, 1.17549435e-38);
    u_xlat9 = inversesqrt(u_xlat9);
    u_xlat2.xyz = vec3(u_xlat9) * u_xlat2.xyz;
    u_xlat9 = dot(u_xlat1.xyz, u_xlat2.xyz);
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat9 = (-u_xlat9) + 1.0;
    u_xlat9 = u_xlat9 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat2.xyz * vec3(u_xlat9) + u_xlat0.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position.z = max(u_xlat0.z, -1.0);
    gl_Position.xyw = u_xlat0.xyw;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 15: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightPosition;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
float u_xlat9;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + _LightPosition.xyz;
    u_xlat9 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat9 = inversesqrt(u_xlat9);
    u_xlat1.xyz = vec3(u_xlat9) * u_xlat1.xyz;
    u_xlat0.xyz = u_xlat1.xyz * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat2.xyz = in_NORMAL0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_NORMAL0.xxx + u_xlat2.xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_NORMAL0.zzz + u_xlat2.xyz;
    u_xlat9 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat9 = max(u_xlat9, 1.17549435e-38);
    u_xlat9 = inversesqrt(u_xlat9);
    u_xlat2.xyz = vec3(u_xlat9) * u_xlat2.xyz;
    u_xlat9 = dot(u_xlat1.xyz, u_xlat2.xyz);
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat9 = (-u_xlat9) + 1.0;
    u_xlat9 = u_xlat9 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat2.xyz * vec3(u_xlat9) + u_xlat0.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position.z = max(u_xlat0.z, -1.0);
    gl_Position.xyw = u_xlat0.xyw;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _DitheringTextureInvSize;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_LOCATION(0) uniform mediump sampler2D _DitheringTexture;
layout(location = 0) out mediump vec4 SV_TARGET0;
vec2 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
bool u_xlatb1;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = hlslcc_FragCoord.xy * vec2(vec2(_DitheringTextureInvSize, _DitheringTextureInvSize));
    u_xlat16_0 = texture(_DitheringTexture, u_xlat0.xy, _GlobalMipBias.x).w;
    u_xlatb1 = unity_LODFade.x>=0.0;
    u_xlat0.x = (u_xlatb1) ? abs(u_xlat16_0) : -abs(u_xlat16_0);
    u_xlat0.x = (-u_xlat0.x) + unity_LODFade.x;
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 16: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
layout(location = 0) out highp vec4 vs_TEXCOORD0;
vec4 u_xlat0;
vec4 u_xlat1;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    vs_TEXCOORD0 = u_xlat0;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 17: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 18: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
layout(location = 0) out highp vec4 vs_TEXCOORD0;
vec4 u_xlat0;
vec4 u_xlat1;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    vs_TEXCOORD0 = u_xlat0;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _DitheringTextureInvSize;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_LOCATION(0) uniform mediump sampler2D _DitheringTexture;
layout(location = 0) out mediump vec4 SV_TARGET0;
vec2 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
bool u_xlatb1;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = hlslcc_FragCoord.xy * vec2(vec2(_DitheringTextureInvSize, _DitheringTextureInvSize));
    u_xlat16_0 = texture(_DitheringTexture, u_xlat0.xy, _GlobalMipBias.x).w;
    u_xlatb1 = unity_LODFade.x>=0.0;
    u_xlat0.x = (u_xlatb1) ? abs(u_xlat16_0) : -abs(u_xlat16_0);
    u_xlat0.x = (-u_xlat0.x) + unity_LODFade.x;
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 19: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
layout(location = 1) out highp vec4 vs_TEXCOORD0;
layout(location = 0) out highp vec3 vs_TEXCOORD1;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    vs_TEXCOORD0 = u_xlat0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_TEXCOORD1.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_TEXCOORD1.xyz, vs_TEXCOORD1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_TEXCOORD1.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 20: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_TEXCOORD1.xyz, vs_TEXCOORD1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_TEXCOORD1.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 21: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
layout(location = 1) out highp vec4 vs_TEXCOORD0;
layout(location = 0) out highp vec3 vs_TEXCOORD1;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    vs_TEXCOORD0 = u_xlat0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_TEXCOORD1.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _DitheringTextureInvSize;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_LOCATION(0) uniform mediump sampler2D _DitheringTexture;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
bool u_xlatb1;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = hlslcc_FragCoord.xy * vec2(vec2(_DitheringTextureInvSize, _DitheringTextureInvSize));
    u_xlat16_0 = texture(_DitheringTexture, u_xlat0.xy, _GlobalMipBias.x).w;
    u_xlatb1 = unity_LODFade.x>=0.0;
    u_xlat0.x = (u_xlatb1) ? abs(u_xlat16_0) : -abs(u_xlat16_0);
    u_xlat0.x = (-u_xlat0.x) + unity_LODFade.x;
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.x = dot(vs_TEXCOORD1.xyz, vs_TEXCOORD1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_TEXCOORD1.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 22: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _DitheringTextureInvSize;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4                unity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_LOCATION(0) uniform mediump sampler2D _DitheringTexture;
layout(location = 0) in highp  vec3 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
bool u_xlatb1;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat0.xy = hlslcc_FragCoord.xy * vec2(vec2(_DitheringTextureInvSize, _DitheringTextureInvSize));
    u_xlat16_0 = texture(_DitheringTexture, u_xlat0.xy, _GlobalMipBias.x).w;
    u_xlatb1 = unity_LODFade.x>=0.0;
    u_xlat0.x = (u_xlatb1) ? abs(u_xlat16_0) : -abs(u_xlat16_0);
    u_xlat0.x = (-u_xlat0.x) + unity_LODFade.x;
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.x = dot(vs_TEXCOORD1.xyz, vs_TEXCOORD1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_TEXCOORD1.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif

