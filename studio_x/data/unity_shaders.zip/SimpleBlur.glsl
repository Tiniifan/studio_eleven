// SimpleBlur (Shader path ID -474607138159866220, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _BlitScaleBias;
out highp vec2 vs_TEXCOORD0;
vec2 u_xlat0;
uvec3 u_xlatu0;
int int_bitfieldInsert(int base, int insert, int offset, int bits) {
    uint mask = uint(~(int(~0) << uint(bits)) << uint(offset));
    return int((uint(base) & ~mask) | ((uint(insert) << uint(offset)) & mask));
}

void main()
{
    u_xlatu0.x =  uint(int(int_bitfieldInsert(0, gl_VertexID, 1 & int(0x1F), 1)));
    u_xlatu0.z = uint(uint(gl_VertexID) & 2u);
    u_xlat0.xy = vec2(u_xlatu0.xz);
    gl_Position.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    vs_TEXCOORD0.xy = u_xlat0.xy * _BlitScaleBias.xy + _BlitScaleBias.zw;
    gl_Position.zw = vec2(-1.0, 1.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _BlitTexture_TexelSize;
uniform 	float _BlurSize;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump float u_xlat16_0;
vec4 u_xlat1;
mediump vec3 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
void main()
{
    u_xlat16_0 = _BlitTexture_TexelSize.y / _BlitTexture_TexelSize.x;
    u_xlat1.xw = vec2(_BlurSize) * vec2(0.00200000009, 0.00200000009);
    u_xlat1.y = u_xlat16_0 * u_xlat1.x;
    u_xlat1.xw = u_xlat1.wy + vs_TEXCOORD0.xy;
    u_xlat16_2.xyz = texture(_BlitTexture, u_xlat1.xw, _GlobalMipBias.x).xyz;
    u_xlat1.z = _BlurSize;
    u_xlat0 = u_xlat1.zyzy * vec4(-0.00200000009, -1.0, -0.00200000009, 1.0) + vs_TEXCOORD0.xyxy;
    u_xlat16_3.xyz = texture(_BlitTexture, u_xlat0.zw, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = texture(_BlitTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat16_3.xyz * vec3(0.100000001, 0.100000001, 0.100000001);
    u_xlat3.xyz = u_xlat16_4.xyz * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat3.xyz;
    u_xlat0 = u_xlat1.zyzy * vec4(0.00200000009, -1.0, -0.00141422008, 0.0) + vs_TEXCOORD0.xyxy;
    u_xlat16_4.xyz = texture(_BlitTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_5.xyz = texture(_BlitTexture, u_xlat0.zw, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat16_4.xyz * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat3.xyz;
    u_xlat2.xyz = u_xlat16_2.xyz * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat3.xyz;
    u_xlat2.xyz = u_xlat16_5.xyz * vec3(0.150000006, 0.150000006, 0.150000006) + u_xlat2.xyz;
    u_xlat0 = u_xlat1.zyzy * vec4(0.0, 0.707109988, 0.00141422008, 0.0) + vs_TEXCOORD0.xyxy;
    u_xlat1.xy = u_xlat1.zy * vec2(0.0, -0.707109988) + vs_TEXCOORD0.xy;
    u_xlat16_1.xyz = texture(_BlitTexture, u_xlat1.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = texture(_BlitTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = texture(_BlitTexture, u_xlat0.zw, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.150000006, 0.150000006, 0.150000006) + u_xlat2.xyz;
    u_xlat2.xyz = u_xlat16_4.xyz * vec3(0.150000006, 0.150000006, 0.150000006) + u_xlat2.xyz;
    u_xlat1.xyz = u_xlat16_1.xyz * vec3(0.150000006, 0.150000006, 0.150000006) + u_xlat2.xyz;
    SV_Target0.xyz = u_xlat1.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _BlitTexture_TexelSize;
uniform 	float _BlurSize;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump float u_xlat16_0;
vec4 u_xlat1;
mediump vec3 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
void main()
{
    u_xlat16_0 = _BlitTexture_TexelSize.y / _BlitTexture_TexelSize.x;
    u_xlat1.xw = vec2(_BlurSize) * vec2(0.00200000009, 0.00200000009);
    u_xlat1.y = u_xlat16_0 * u_xlat1.x;
    u_xlat1.xw = u_xlat1.wy + vs_TEXCOORD0.xy;
    u_xlat16_2.xyz = texture(_BlitTexture, u_xlat1.xw, _GlobalMipBias.x).xyz;
    u_xlat1.z = _BlurSize;
    u_xlat0 = u_xlat1.zyzy * vec4(-0.00200000009, -1.0, -0.00200000009, 1.0) + vs_TEXCOORD0.xyxy;
    u_xlat16_3.xyz = texture(_BlitTexture, u_xlat0.zw, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = texture(_BlitTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat16_3.xyz * vec3(0.100000001, 0.100000001, 0.100000001);
    u_xlat3.xyz = u_xlat16_4.xyz * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat3.xyz;
    u_xlat0 = u_xlat1.zyzy * vec4(0.00200000009, -1.0, -0.00141422008, 0.0) + vs_TEXCOORD0.xyxy;
    u_xlat16_4.xyz = texture(_BlitTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_5.xyz = texture(_BlitTexture, u_xlat0.zw, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat16_4.xyz * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat3.xyz;
    u_xlat2.xyz = u_xlat16_2.xyz * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat3.xyz;
    u_xlat2.xyz = u_xlat16_5.xyz * vec3(0.150000006, 0.150000006, 0.150000006) + u_xlat2.xyz;
    u_xlat0 = u_xlat1.zyzy * vec4(0.0, 0.707109988, 0.00141422008, 0.0) + vs_TEXCOORD0.xyxy;
    u_xlat1.xy = u_xlat1.zy * vec2(0.0, -0.707109988) + vs_TEXCOORD0.xy;
    u_xlat16_1.xyz = texture(_BlitTexture, u_xlat1.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = texture(_BlitTexture, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = texture(_BlitTexture, u_xlat0.zw, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * vec3(0.150000006, 0.150000006, 0.150000006) + u_xlat2.xyz;
    u_xlat2.xyz = u_xlat16_4.xyz * vec3(0.150000006, 0.150000006, 0.150000006) + u_xlat2.xyz;
    u_xlat1.xyz = u_xlat16_1.xyz * vec3(0.150000006, 0.150000006, 0.150000006) + u_xlat2.xyz;
    SV_Target0.xyz = u_xlat1.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif

