// BackGround/BG_Unlit_Water (Shader path ID -4715318945205346652, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
highp vec3 vs_INTERP2;
highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _TimeParameters;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Light_Intennsity;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalTex_TexelSize;
	UNITY_UNIFORM mediump vec2                _Tilling_1X_2Y;
	UNITY_UNIFORM mediump vec2                _UVScroll_2XY;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump vec2                _UVScroll_1;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump vec4                _Highlight_Color;
	UNITY_UNIFORM mediump float                _BaseTex_Intensity;
	UNITY_UNIFORM mediump float                _Highlight_Intensity;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseTex_0Off_1On;
	UNITY_UNIFORM mediump float                _FlowPower2;
	UNITY_UNIFORM mediump float                _FlowPower_1;
	UNITY_UNIFORM mediump float                _VC_1Color_or_0Flow;
	UNITY_UNIFORM mediump vec3                _DirectionalLight_Directionadd;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
mediump vec4 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec2 u_xlat16_3;
vec3 u_xlat4;
mediump float u_xlat16_5;
vec2 u_xlat11;
mediump float u_xlat16_14;
float u_xlat15;
void main()
{
    u_xlat0.xy = vec2(_UVScroll_2XY.x, _UVScroll_2XY.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat16_1.xy = vs_INTERP1.xy + vec2(-0.5, -0.5);
    u_xlat16_1.xy = u_xlat16_1.xy * vec2(_FlowPower_1, _FlowPower2);
    u_xlat0.xy = _Tilling_1X_2Y.yy * u_xlat0.xy + u_xlat16_1.yy;
    u_xlat16_0.xy = texture(_NormalTex, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_5 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_5 = min(u_xlat16_5, 1.0);
    u_xlat16_5 = (-u_xlat16_5) + 1.0;
    u_xlat16_5 = sqrt(u_xlat16_5);
    u_xlat16_2.z = max(u_xlat16_5, 1.00000002e-16);
    u_xlat0.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat3.xy = vec2(_UVScroll_1.x, _UVScroll_1.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat11.xy = u_xlat3.xy * _Tilling_1X_2Y.xx + u_xlat16_1.xx;
    u_xlat3.xy = u_xlat3.xy * _Tilling_1X_2Y.xx;
    u_xlat16_1 = texture(_BaseTex, u_xlat3.xy, _GlobalMipBias.x);
    u_xlat16_3.xy = texture(_NormalTex, u_xlat11.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_3.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_14 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_14 = min(u_xlat16_14, 1.0);
    u_xlat16_14 = (-u_xlat16_14) + 1.0;
    u_xlat16_14 = sqrt(u_xlat16_14);
    u_xlat16_2.z = max(u_xlat16_14, 1.00000002e-16);
    u_xlat3.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat3.xyz + (-u_xlat16_2.xyz);
    u_xlat0.xyz = u_xlat0.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.699999988, 0.699999988, 0.699999988) + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-_MainLightPosition.xyz) + _DirectionalLight_Directionadd.xyz;
    u_xlat0.x = dot((-u_xlat16_2.xyz), u_xlat0.xyz);
    u_xlat4.x = u_xlat0.x * _Light_Intennsity;
    u_xlat0.x = u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = log2(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * _Highlight_Intensity;
    u_xlat0.x = exp2(u_xlat0.x);
    u_xlat3.xyz = _Color.xyz + (-_ShadowColor.xyz);
    u_xlat4.xyz = u_xlat4.xxx * u_xlat3.xyz + _ShadowColor.xyz;
    u_xlat3.xyz = u_xlat16_1.xyz * vec3(_BaseTex_Intensity) + (-u_xlat4.xyz);
    u_xlat15 = u_xlat16_1.w * vs_INTERP1.z;
    u_xlat15 = u_xlat15 * _BaseTex_0Off_1On;
    u_xlat4.xyz = vec3(u_xlat15) * u_xlat3.xyz + u_xlat4.xyz;
    u_xlat16_2.xyz = vs_INTERP1.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat16_2.xyz = vec3(vec3(_VC_1Color_or_0Flow, _VC_1Color_or_0Flow, _VC_1Color_or_0Flow)) * u_xlat16_2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat4.xyz = u_xlat4.xyz * u_xlat16_2.xyz;
    u_xlat0.xyz = u_xlat0.xxx * _Highlight_Color.xyz + u_xlat4.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _TimeParameters;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Light_Intennsity;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalTex_TexelSize;
	UNITY_UNIFORM mediump vec2                _Tilling_1X_2Y;
	UNITY_UNIFORM mediump vec2                _UVScroll_2XY;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump vec2                _UVScroll_1;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump vec4                _Highlight_Color;
	UNITY_UNIFORM mediump float                _BaseTex_Intensity;
	UNITY_UNIFORM mediump float                _Highlight_Intensity;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseTex_0Off_1On;
	UNITY_UNIFORM mediump float                _FlowPower2;
	UNITY_UNIFORM mediump float                _FlowPower_1;
	UNITY_UNIFORM mediump float                _VC_1Color_or_0Flow;
	UNITY_UNIFORM mediump vec3                _DirectionalLight_Directionadd;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
mediump vec4 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec2 u_xlat16_3;
vec3 u_xlat4;
mediump float u_xlat16_5;
vec2 u_xlat11;
mediump float u_xlat16_14;
float u_xlat15;
void main()
{
    u_xlat0.xy = vec2(_UVScroll_2XY.x, _UVScroll_2XY.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat16_1.xy = vs_INTERP1.xy + vec2(-0.5, -0.5);
    u_xlat16_1.xy = u_xlat16_1.xy * vec2(_FlowPower_1, _FlowPower2);
    u_xlat0.xy = _Tilling_1X_2Y.yy * u_xlat0.xy + u_xlat16_1.yy;
    u_xlat16_0.xy = texture(_NormalTex, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_5 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_5 = min(u_xlat16_5, 1.0);
    u_xlat16_5 = (-u_xlat16_5) + 1.0;
    u_xlat16_5 = sqrt(u_xlat16_5);
    u_xlat16_2.z = max(u_xlat16_5, 1.00000002e-16);
    u_xlat0.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat3.xy = vec2(_UVScroll_1.x, _UVScroll_1.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat11.xy = u_xlat3.xy * _Tilling_1X_2Y.xx + u_xlat16_1.xx;
    u_xlat3.xy = u_xlat3.xy * _Tilling_1X_2Y.xx;
    u_xlat16_1 = texture(_BaseTex, u_xlat3.xy, _GlobalMipBias.x);
    u_xlat16_3.xy = texture(_NormalTex, u_xlat11.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_3.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_14 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_14 = min(u_xlat16_14, 1.0);
    u_xlat16_14 = (-u_xlat16_14) + 1.0;
    u_xlat16_14 = sqrt(u_xlat16_14);
    u_xlat16_2.z = max(u_xlat16_14, 1.00000002e-16);
    u_xlat3.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat3.xyz + (-u_xlat16_2.xyz);
    u_xlat0.xyz = u_xlat0.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.699999988, 0.699999988, 0.699999988) + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-_MainLightPosition.xyz) + _DirectionalLight_Directionadd.xyz;
    u_xlat0.x = dot((-u_xlat16_2.xyz), u_xlat0.xyz);
    u_xlat4.x = u_xlat0.x * _Light_Intennsity;
    u_xlat0.x = u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = log2(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * _Highlight_Intensity;
    u_xlat0.x = exp2(u_xlat0.x);
    u_xlat3.xyz = _Color.xyz + (-_ShadowColor.xyz);
    u_xlat4.xyz = u_xlat4.xxx * u_xlat3.xyz + _ShadowColor.xyz;
    u_xlat3.xyz = u_xlat16_1.xyz * vec3(_BaseTex_Intensity) + (-u_xlat4.xyz);
    u_xlat15 = u_xlat16_1.w * vs_INTERP1.z;
    u_xlat15 = u_xlat15 * _BaseTex_0Off_1On;
    u_xlat4.xyz = vec3(u_xlat15) * u_xlat3.xyz + u_xlat4.xyz;
    u_xlat16_2.xyz = vs_INTERP1.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat16_2.xyz = vec3(vec3(_VC_1Color_or_0Flow, _VC_1Color_or_0Flow, _VC_1Color_or_0Flow)) * u_xlat16_2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat4.xyz = u_xlat4.xyz * u_xlat16_2.xyz;
    u_xlat0.xyz = u_xlat0.xxx * _Highlight_Color.xyz + u_xlat4.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 2: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
highp vec3 vs_INTERP2;
highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _TimeParameters;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Light_Intennsity;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalTex_TexelSize;
	UNITY_UNIFORM mediump vec2                _Tilling_1X_2Y;
	UNITY_UNIFORM mediump vec2                _UVScroll_2XY;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump vec2                _UVScroll_1;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump vec4                _Highlight_Color;
	UNITY_UNIFORM mediump float                _BaseTex_Intensity;
	UNITY_UNIFORM mediump float                _Highlight_Intensity;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseTex_0Off_1On;
	UNITY_UNIFORM mediump float                _FlowPower2;
	UNITY_UNIFORM mediump float                _FlowPower_1;
	UNITY_UNIFORM mediump float                _VC_1Color_or_0Flow;
	UNITY_UNIFORM mediump vec3                _DirectionalLight_Directionadd;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
mediump vec4 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec2 u_xlat16_3;
vec3 u_xlat4;
mediump float u_xlat16_5;
vec2 u_xlat11;
mediump float u_xlat16_14;
float u_xlat15;
void main()
{
    u_xlat0.xy = vec2(_UVScroll_2XY.x, _UVScroll_2XY.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat16_1.xy = vs_INTERP1.xy + vec2(-0.5, -0.5);
    u_xlat16_1.xy = u_xlat16_1.xy * vec2(_FlowPower_1, _FlowPower2);
    u_xlat0.xy = _Tilling_1X_2Y.yy * u_xlat0.xy + u_xlat16_1.yy;
    u_xlat16_0.xy = texture(_NormalTex, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_5 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_5 = min(u_xlat16_5, 1.0);
    u_xlat16_5 = (-u_xlat16_5) + 1.0;
    u_xlat16_5 = sqrt(u_xlat16_5);
    u_xlat16_2.z = max(u_xlat16_5, 1.00000002e-16);
    u_xlat0.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat3.xy = vec2(_UVScroll_1.x, _UVScroll_1.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat11.xy = u_xlat3.xy * _Tilling_1X_2Y.xx + u_xlat16_1.xx;
    u_xlat3.xy = u_xlat3.xy * _Tilling_1X_2Y.xx;
    u_xlat16_1 = texture(_BaseTex, u_xlat3.xy, _GlobalMipBias.x);
    u_xlat16_3.xy = texture(_NormalTex, u_xlat11.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_3.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_14 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_14 = min(u_xlat16_14, 1.0);
    u_xlat16_14 = (-u_xlat16_14) + 1.0;
    u_xlat16_14 = sqrt(u_xlat16_14);
    u_xlat16_2.z = max(u_xlat16_14, 1.00000002e-16);
    u_xlat3.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat3.xyz + (-u_xlat16_2.xyz);
    u_xlat0.xyz = u_xlat0.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.699999988, 0.699999988, 0.699999988) + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-_MainLightPosition.xyz) + _DirectionalLight_Directionadd.xyz;
    u_xlat0.x = dot((-u_xlat16_2.xyz), u_xlat0.xyz);
    u_xlat4.x = u_xlat0.x * _Light_Intennsity;
    u_xlat0.x = u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = log2(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * _Highlight_Intensity;
    u_xlat0.x = exp2(u_xlat0.x);
    u_xlat3.xyz = _Color.xyz + (-_ShadowColor.xyz);
    u_xlat4.xyz = u_xlat4.xxx * u_xlat3.xyz + _ShadowColor.xyz;
    u_xlat3.xyz = u_xlat16_1.xyz * vec3(_BaseTex_Intensity) + (-u_xlat4.xyz);
    u_xlat15 = u_xlat16_1.w * vs_INTERP1.z;
    u_xlat15 = u_xlat15 * _BaseTex_0Off_1On;
    u_xlat4.xyz = vec3(u_xlat15) * u_xlat3.xyz + u_xlat4.xyz;
    u_xlat16_2.xyz = vs_INTERP1.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat16_2.xyz = vec3(vec3(_VC_1Color_or_0Flow, _VC_1Color_or_0Flow, _VC_1Color_or_0Flow)) * u_xlat16_2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat4.xyz = u_xlat4.xyz * u_xlat16_2.xyz;
    u_xlat0.xyz = u_xlat0.xxx * _Highlight_Color.xyz + u_xlat4.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    u_xlat16_2.x = vs_INTERP1.w * _Color.w;
    SV_Target0.w = u_xlat16_2.x * _BakeAlpha;
    return;
}

#endif


// ===== program 3: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _TimeParameters;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Fog_Intensity;
	UNITY_UNIFORM mediump float                _Light_Intennsity;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalTex_TexelSize;
	UNITY_UNIFORM mediump vec2                _Tilling_1X_2Y;
	UNITY_UNIFORM mediump vec2                _UVScroll_2XY;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump vec2                _UVScroll_1;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump vec4                _Highlight_Color;
	UNITY_UNIFORM mediump float                _BaseTex_Intensity;
	UNITY_UNIFORM mediump float                _Highlight_Intensity;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseTex_0Off_1On;
	UNITY_UNIFORM mediump float                _FlowPower2;
	UNITY_UNIFORM mediump float                _FlowPower_1;
	UNITY_UNIFORM mediump float                _VC_1Color_or_0Flow;
	UNITY_UNIFORM mediump vec3                _DirectionalLight_Directionadd;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
mediump vec4 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec2 u_xlat16_3;
vec3 u_xlat4;
mediump float u_xlat16_5;
vec2 u_xlat11;
mediump float u_xlat16_14;
float u_xlat15;
void main()
{
    u_xlat0.xy = vec2(_UVScroll_2XY.x, _UVScroll_2XY.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat16_1.xy = vs_INTERP1.xy + vec2(-0.5, -0.5);
    u_xlat16_1.xy = u_xlat16_1.xy * vec2(_FlowPower_1, _FlowPower2);
    u_xlat0.xy = _Tilling_1X_2Y.yy * u_xlat0.xy + u_xlat16_1.yy;
    u_xlat16_0.xy = texture(_NormalTex, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_5 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_5 = min(u_xlat16_5, 1.0);
    u_xlat16_5 = (-u_xlat16_5) + 1.0;
    u_xlat16_5 = sqrt(u_xlat16_5);
    u_xlat16_2.z = max(u_xlat16_5, 1.00000002e-16);
    u_xlat0.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat3.xy = vec2(_UVScroll_1.x, _UVScroll_1.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat11.xy = u_xlat3.xy * _Tilling_1X_2Y.xx + u_xlat16_1.xx;
    u_xlat3.xy = u_xlat3.xy * _Tilling_1X_2Y.xx;
    u_xlat16_1 = texture(_BaseTex, u_xlat3.xy, _GlobalMipBias.x);
    u_xlat16_3.xy = texture(_NormalTex, u_xlat11.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_3.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_14 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_14 = min(u_xlat16_14, 1.0);
    u_xlat16_14 = (-u_xlat16_14) + 1.0;
    u_xlat16_14 = sqrt(u_xlat16_14);
    u_xlat16_2.z = max(u_xlat16_14, 1.00000002e-16);
    u_xlat3.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat3.xyz + (-u_xlat16_2.xyz);
    u_xlat0.xyz = u_xlat0.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.699999988, 0.699999988, 0.699999988) + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-_MainLightPosition.xyz) + _DirectionalLight_Directionadd.xyz;
    u_xlat0.x = dot((-u_xlat16_2.xyz), u_xlat0.xyz);
    u_xlat4.x = u_xlat0.x * _Light_Intennsity;
    u_xlat0.x = u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = log2(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * _Highlight_Intensity;
    u_xlat0.x = exp2(u_xlat0.x);
    u_xlat3.xyz = _Color.xyz + (-_ShadowColor.xyz);
    u_xlat4.xyz = u_xlat4.xxx * u_xlat3.xyz + _ShadowColor.xyz;
    u_xlat3.xyz = u_xlat16_1.xyz * vec3(_BaseTex_Intensity) + (-u_xlat4.xyz);
    u_xlat15 = u_xlat16_1.w * vs_INTERP1.z;
    u_xlat15 = u_xlat15 * _BaseTex_0Off_1On;
    u_xlat4.xyz = vec3(u_xlat15) * u_xlat3.xyz + u_xlat4.xyz;
    u_xlat16_2.xyz = vs_INTERP1.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat16_2.xyz = vec3(vec3(_VC_1Color_or_0Flow, _VC_1Color_or_0Flow, _VC_1Color_or_0Flow)) * u_xlat16_2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat4.xyz = u_xlat4.xyz * u_xlat16_2.xyz;
    u_xlat0.xyz = u_xlat0.xxx * _Highlight_Color.xyz + u_xlat4.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    u_xlat16_2.x = vs_INTERP1.w * _Color.w;
    SV_Target0.w = u_xlat16_2.x * _BakeAlpha;
    return;
}

#endif


// ===== program 4: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _TimeParameters;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Light_Intennsity;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalTex_TexelSize;
	UNITY_UNIFORM mediump vec2                _Tilling_1X_2Y;
	UNITY_UNIFORM mediump vec2                _UVScroll_2XY;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump vec2                _UVScroll_1;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump vec4                _Highlight_Color;
	UNITY_UNIFORM mediump float                _BaseTex_Intensity;
	UNITY_UNIFORM mediump float                _Highlight_Intensity;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseTex_0Off_1On;
	UNITY_UNIFORM mediump float                _FlowPower2;
	UNITY_UNIFORM mediump float                _FlowPower_1;
	UNITY_UNIFORM mediump float                _VC_1Color_or_0Flow;
	UNITY_UNIFORM mediump vec3                _DirectionalLight_Directionadd;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
mediump vec4 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec2 u_xlat16_3;
vec4 u_xlat4;
vec3 u_xlat5;
vec3 u_xlat6;
mediump float u_xlat16_7;
vec2 u_xlat15;
float u_xlat18;
mediump float u_xlat16_20;
float u_xlat21;
void main()
{
    u_xlat0.xy = vec2(_UVScroll_2XY.x, _UVScroll_2XY.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat16_1.xy = vs_INTERP1.xy + vec2(-0.5, -0.5);
    u_xlat16_1.xy = u_xlat16_1.xy * vec2(_FlowPower_1, _FlowPower2);
    u_xlat0.xy = _Tilling_1X_2Y.yy * u_xlat0.xy + u_xlat16_1.yy;
    u_xlat16_0.xy = texture(_NormalTex, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_7 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_7 = min(u_xlat16_7, 1.0);
    u_xlat16_7 = (-u_xlat16_7) + 1.0;
    u_xlat16_7 = sqrt(u_xlat16_7);
    u_xlat16_2.z = max(u_xlat16_7, 1.00000002e-16);
    u_xlat0.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat3.xy = vec2(_UVScroll_1.x, _UVScroll_1.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat15.xy = u_xlat3.xy * _Tilling_1X_2Y.xx + u_xlat16_1.xx;
    u_xlat3.xy = u_xlat3.xy * _Tilling_1X_2Y.xx;
    u_xlat16_1 = texture(_BaseTex, u_xlat3.xy, _GlobalMipBias.x);
    u_xlat16_3.xy = texture(_NormalTex, u_xlat15.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_3.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_20 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_20 = min(u_xlat16_20, 1.0);
    u_xlat16_20 = (-u_xlat16_20) + 1.0;
    u_xlat16_20 = sqrt(u_xlat16_20);
    u_xlat16_2.z = max(u_xlat16_20, 1.00000002e-16);
    u_xlat3.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat3.xyz + (-u_xlat16_2.xyz);
    u_xlat0.xyz = u_xlat0.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.699999988, 0.699999988, 0.699999988) + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-_MainLightPosition.xyz) + _DirectionalLight_Directionadd.xyz;
    u_xlat0.x = dot((-u_xlat16_2.xyz), u_xlat0.xyz);
    u_xlat6.x = u_xlat0.x * _Light_Intennsity;
    u_xlat0.x = u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = log2(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * _Highlight_Intensity;
    u_xlat0.x = exp2(u_xlat0.x);
    u_xlat3.xyz = _Color.xyz + (-_ShadowColor.xyz);
    u_xlat6.xyz = u_xlat6.xxx * u_xlat3.xyz + _ShadowColor.xyz;
    u_xlat3.xyz = u_xlat16_1.xyz * vec3(_BaseTex_Intensity) + (-u_xlat6.xyz);
    u_xlat21 = u_xlat16_1.w * vs_INTERP1.z;
    u_xlat21 = u_xlat21 * _BaseTex_0Off_1On;
    u_xlat6.xyz = vec3(u_xlat21) * u_xlat3.xyz + u_xlat6.xyz;
    u_xlat16_2.xyz = vs_INTERP1.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat16_2.xyz = vec3(vec3(_VC_1Color_or_0Flow, _VC_1Color_or_0Flow, _VC_1Color_or_0Flow)) * u_xlat16_2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = u_xlat6.xyz * u_xlat16_2.xyz;
    u_xlat0.xyz = u_xlat0.xxx * _Highlight_Color.xyz + u_xlat6.xyz;
    u_xlat3.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat4.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat4.xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat4.xyz;
    u_xlat4.xyz = u_xlat4.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat5.xyz = u_xlat4.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat4.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat4.xxx + u_xlat5.xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat4.zzz + u_xlat4.xyw;
    u_xlat4.xyz = u_xlat4.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat18 = u_xlat4.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat18 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat4.x + u_xlat18;
    u_xlat18 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat4.z + u_xlat18;
    u_xlat18 = u_xlat18 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat18 = (-u_xlat18) + (-_ProjectionParams.y);
    u_xlat18 = max(u_xlat18, 0.0);
    u_xlat18 = u_xlat18 * unity_FogParams.z + unity_FogParams.w;
    u_xlat18 = clamp(u_xlat18, 0.0, 1.0);
    u_xlat18 = (-u_xlat18) + 1.0;
    u_xlat3.xyz = u_xlat3.xyz * vec3(u_xlat18);
    u_xlat0.xyz = vec3(_Fog_Intensity) * u_xlat3.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 5: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _TimeParameters;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Light_Intennsity;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalTex_TexelSize;
	UNITY_UNIFORM mediump vec2                _Tilling_1X_2Y;
	UNITY_UNIFORM mediump vec2                _UVScroll_2XY;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump vec2                _UVScroll_1;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump vec4                _Highlight_Color;
	UNITY_UNIFORM mediump float                _BaseTex_Intensity;
	UNITY_UNIFORM mediump float                _Highlight_Intensity;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseTex_0Off_1On;
	UNITY_UNIFORM mediump float                _FlowPower2;
	UNITY_UNIFORM mediump float                _FlowPower_1;
	UNITY_UNIFORM mediump float                _VC_1Color_or_0Flow;
	UNITY_UNIFORM mediump vec3                _DirectionalLight_Directionadd;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
mediump vec4 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec2 u_xlat16_3;
vec4 u_xlat4;
vec3 u_xlat5;
vec3 u_xlat6;
mediump float u_xlat16_7;
vec2 u_xlat15;
float u_xlat18;
mediump float u_xlat16_20;
float u_xlat21;
void main()
{
    u_xlat0.xy = vec2(_UVScroll_2XY.x, _UVScroll_2XY.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat16_1.xy = vs_INTERP1.xy + vec2(-0.5, -0.5);
    u_xlat16_1.xy = u_xlat16_1.xy * vec2(_FlowPower_1, _FlowPower2);
    u_xlat0.xy = _Tilling_1X_2Y.yy * u_xlat0.xy + u_xlat16_1.yy;
    u_xlat16_0.xy = texture(_NormalTex, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_7 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_7 = min(u_xlat16_7, 1.0);
    u_xlat16_7 = (-u_xlat16_7) + 1.0;
    u_xlat16_7 = sqrt(u_xlat16_7);
    u_xlat16_2.z = max(u_xlat16_7, 1.00000002e-16);
    u_xlat0.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat3.xy = vec2(_UVScroll_1.x, _UVScroll_1.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat15.xy = u_xlat3.xy * _Tilling_1X_2Y.xx + u_xlat16_1.xx;
    u_xlat3.xy = u_xlat3.xy * _Tilling_1X_2Y.xx;
    u_xlat16_1 = texture(_BaseTex, u_xlat3.xy, _GlobalMipBias.x);
    u_xlat16_3.xy = texture(_NormalTex, u_xlat15.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_3.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_20 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_20 = min(u_xlat16_20, 1.0);
    u_xlat16_20 = (-u_xlat16_20) + 1.0;
    u_xlat16_20 = sqrt(u_xlat16_20);
    u_xlat16_2.z = max(u_xlat16_20, 1.00000002e-16);
    u_xlat3.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat3.xyz + (-u_xlat16_2.xyz);
    u_xlat0.xyz = u_xlat0.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.699999988, 0.699999988, 0.699999988) + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-_MainLightPosition.xyz) + _DirectionalLight_Directionadd.xyz;
    u_xlat0.x = dot((-u_xlat16_2.xyz), u_xlat0.xyz);
    u_xlat6.x = u_xlat0.x * _Light_Intennsity;
    u_xlat0.x = u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = log2(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * _Highlight_Intensity;
    u_xlat0.x = exp2(u_xlat0.x);
    u_xlat3.xyz = _Color.xyz + (-_ShadowColor.xyz);
    u_xlat6.xyz = u_xlat6.xxx * u_xlat3.xyz + _ShadowColor.xyz;
    u_xlat3.xyz = u_xlat16_1.xyz * vec3(_BaseTex_Intensity) + (-u_xlat6.xyz);
    u_xlat21 = u_xlat16_1.w * vs_INTERP1.z;
    u_xlat21 = u_xlat21 * _BaseTex_0Off_1On;
    u_xlat6.xyz = vec3(u_xlat21) * u_xlat3.xyz + u_xlat6.xyz;
    u_xlat16_2.xyz = vs_INTERP1.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat16_2.xyz = vec3(vec3(_VC_1Color_or_0Flow, _VC_1Color_or_0Flow, _VC_1Color_or_0Flow)) * u_xlat16_2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = u_xlat6.xyz * u_xlat16_2.xyz;
    u_xlat0.xyz = u_xlat0.xxx * _Highlight_Color.xyz + u_xlat6.xyz;
    u_xlat3.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat4.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat4.xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat4.xyz;
    u_xlat4.xyz = u_xlat4.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat5.xyz = u_xlat4.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat4.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat4.xxx + u_xlat5.xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat4.zzz + u_xlat4.xyw;
    u_xlat4.xyz = u_xlat4.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat18 = u_xlat4.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat18 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat4.x + u_xlat18;
    u_xlat18 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat4.z + u_xlat18;
    u_xlat18 = u_xlat18 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat18 = (-u_xlat18) + (-_ProjectionParams.y);
    u_xlat18 = max(u_xlat18, 0.0);
    u_xlat18 = u_xlat18 * unity_FogParams.z + unity_FogParams.w;
    u_xlat18 = clamp(u_xlat18, 0.0, 1.0);
    u_xlat18 = (-u_xlat18) + 1.0;
    u_xlat3.xyz = u_xlat3.xyz * vec3(u_xlat18);
    u_xlat0.xyz = vec3(_Fog_Intensity) * u_xlat3.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 6: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec3 vs_INTERP2;
highp vec3 vs_INTERP3;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP2.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP3.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _TimeParameters;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Light_Intennsity;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalTex_TexelSize;
	UNITY_UNIFORM mediump vec2                _Tilling_1X_2Y;
	UNITY_UNIFORM mediump vec2                _UVScroll_2XY;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump vec2                _UVScroll_1;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump vec4                _Highlight_Color;
	UNITY_UNIFORM mediump float                _BaseTex_Intensity;
	UNITY_UNIFORM mediump float                _Highlight_Intensity;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseTex_0Off_1On;
	UNITY_UNIFORM mediump float                _FlowPower2;
	UNITY_UNIFORM mediump float                _FlowPower_1;
	UNITY_UNIFORM mediump float                _VC_1Color_or_0Flow;
	UNITY_UNIFORM mediump vec3                _DirectionalLight_Directionadd;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
mediump vec4 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec2 u_xlat16_3;
vec4 u_xlat4;
vec3 u_xlat5;
vec3 u_xlat6;
mediump float u_xlat16_7;
vec2 u_xlat15;
float u_xlat18;
mediump float u_xlat16_20;
float u_xlat21;
void main()
{
    u_xlat0.xy = vec2(_UVScroll_2XY.x, _UVScroll_2XY.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat16_1.xy = vs_INTERP1.xy + vec2(-0.5, -0.5);
    u_xlat16_1.xy = u_xlat16_1.xy * vec2(_FlowPower_1, _FlowPower2);
    u_xlat0.xy = _Tilling_1X_2Y.yy * u_xlat0.xy + u_xlat16_1.yy;
    u_xlat16_0.xy = texture(_NormalTex, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_7 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_7 = min(u_xlat16_7, 1.0);
    u_xlat16_7 = (-u_xlat16_7) + 1.0;
    u_xlat16_7 = sqrt(u_xlat16_7);
    u_xlat16_2.z = max(u_xlat16_7, 1.00000002e-16);
    u_xlat0.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat3.xy = vec2(_UVScroll_1.x, _UVScroll_1.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat15.xy = u_xlat3.xy * _Tilling_1X_2Y.xx + u_xlat16_1.xx;
    u_xlat3.xy = u_xlat3.xy * _Tilling_1X_2Y.xx;
    u_xlat16_1 = texture(_BaseTex, u_xlat3.xy, _GlobalMipBias.x);
    u_xlat16_3.xy = texture(_NormalTex, u_xlat15.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_3.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_20 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_20 = min(u_xlat16_20, 1.0);
    u_xlat16_20 = (-u_xlat16_20) + 1.0;
    u_xlat16_20 = sqrt(u_xlat16_20);
    u_xlat16_2.z = max(u_xlat16_20, 1.00000002e-16);
    u_xlat3.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat3.xyz + (-u_xlat16_2.xyz);
    u_xlat0.xyz = u_xlat0.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.699999988, 0.699999988, 0.699999988) + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-_MainLightPosition.xyz) + _DirectionalLight_Directionadd.xyz;
    u_xlat0.x = dot((-u_xlat16_2.xyz), u_xlat0.xyz);
    u_xlat6.x = u_xlat0.x * _Light_Intennsity;
    u_xlat0.x = u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = log2(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * _Highlight_Intensity;
    u_xlat0.x = exp2(u_xlat0.x);
    u_xlat3.xyz = _Color.xyz + (-_ShadowColor.xyz);
    u_xlat6.xyz = u_xlat6.xxx * u_xlat3.xyz + _ShadowColor.xyz;
    u_xlat3.xyz = u_xlat16_1.xyz * vec3(_BaseTex_Intensity) + (-u_xlat6.xyz);
    u_xlat21 = u_xlat16_1.w * vs_INTERP1.z;
    u_xlat21 = u_xlat21 * _BaseTex_0Off_1On;
    u_xlat6.xyz = vec3(u_xlat21) * u_xlat3.xyz + u_xlat6.xyz;
    u_xlat16_2.xyz = vs_INTERP1.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat16_2.xyz = vec3(vec3(_VC_1Color_or_0Flow, _VC_1Color_or_0Flow, _VC_1Color_or_0Flow)) * u_xlat16_2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = u_xlat6.xyz * u_xlat16_2.xyz;
    u_xlat0.xyz = u_xlat0.xxx * _Highlight_Color.xyz + u_xlat6.xyz;
    u_xlat3.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat4.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat4.xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat4.xyz;
    u_xlat4.xyz = u_xlat4.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat5.xyz = u_xlat4.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat4.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat4.xxx + u_xlat5.xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat4.zzz + u_xlat4.xyw;
    u_xlat4.xyz = u_xlat4.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat18 = u_xlat4.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat18 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat4.x + u_xlat18;
    u_xlat18 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat4.z + u_xlat18;
    u_xlat18 = u_xlat18 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat18 = (-u_xlat18) + (-_ProjectionParams.y);
    u_xlat18 = max(u_xlat18, 0.0);
    u_xlat18 = u_xlat18 * unity_FogParams.z + unity_FogParams.w;
    u_xlat18 = clamp(u_xlat18, 0.0, 1.0);
    u_xlat18 = (-u_xlat18) + 1.0;
    u_xlat3.xyz = u_xlat3.xyz * vec3(u_xlat18);
    u_xlat0.xyz = vec3(_Fog_Intensity) * u_xlat3.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    u_xlat16_2.x = vs_INTERP1.w * _Color.w;
    SV_Target0.w = u_xlat16_2.x * _BakeAlpha;
    return;
}

#endif


// ===== program 7: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _TimeParameters;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM mediump float                _Fog_Intensity;
	UNITY_UNIFORM mediump float                _Light_Intennsity;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalTex_TexelSize;
	UNITY_UNIFORM mediump vec2                _Tilling_1X_2Y;
	UNITY_UNIFORM mediump vec2                _UVScroll_2XY;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump vec2                _UVScroll_1;
	UNITY_UNIFORM mediump vec4                _ShadowColor;
	UNITY_UNIFORM mediump vec4                _Highlight_Color;
	UNITY_UNIFORM mediump float                _BaseTex_Intensity;
	UNITY_UNIFORM mediump float                _Highlight_Intensity;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseTex_0Off_1On;
	UNITY_UNIFORM mediump float                _FlowPower2;
	UNITY_UNIFORM mediump float                _FlowPower_1;
	UNITY_UNIFORM mediump float                _VC_1Color_or_0Flow;
	UNITY_UNIFORM mediump vec3                _DirectionalLight_Directionadd;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec3 vs_INTERP2;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
mediump vec4 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
mediump vec2 u_xlat16_3;
vec4 u_xlat4;
vec3 u_xlat5;
vec3 u_xlat6;
mediump float u_xlat16_7;
vec2 u_xlat15;
float u_xlat18;
mediump float u_xlat16_20;
float u_xlat21;
void main()
{
    u_xlat0.xy = vec2(_UVScroll_2XY.x, _UVScroll_2XY.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat16_1.xy = vs_INTERP1.xy + vec2(-0.5, -0.5);
    u_xlat16_1.xy = u_xlat16_1.xy * vec2(_FlowPower_1, _FlowPower2);
    u_xlat0.xy = _Tilling_1X_2Y.yy * u_xlat0.xy + u_xlat16_1.yy;
    u_xlat16_0.xy = texture(_NormalTex, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_7 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_7 = min(u_xlat16_7, 1.0);
    u_xlat16_7 = (-u_xlat16_7) + 1.0;
    u_xlat16_7 = sqrt(u_xlat16_7);
    u_xlat16_2.z = max(u_xlat16_7, 1.00000002e-16);
    u_xlat0.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat3.xy = vec2(_UVScroll_1.x, _UVScroll_1.y) * _TimeParameters.xx + vs_INTERP0.xy;
    u_xlat15.xy = u_xlat3.xy * _Tilling_1X_2Y.xx + u_xlat16_1.xx;
    u_xlat3.xy = u_xlat3.xy * _Tilling_1X_2Y.xx;
    u_xlat16_1 = texture(_BaseTex, u_xlat3.xy, _GlobalMipBias.x);
    u_xlat16_3.xy = texture(_NormalTex, u_xlat15.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_3.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_20 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_20 = min(u_xlat16_20, 1.0);
    u_xlat16_20 = (-u_xlat16_20) + 1.0;
    u_xlat16_20 = sqrt(u_xlat16_20);
    u_xlat16_2.z = max(u_xlat16_20, 1.00000002e-16);
    u_xlat3.xyz = (-u_xlat16_2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat3.xyz + (-u_xlat16_2.xyz);
    u_xlat0.xyz = u_xlat0.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.699999988, 0.699999988, 0.699999988) + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-_MainLightPosition.xyz) + _DirectionalLight_Directionadd.xyz;
    u_xlat0.x = dot((-u_xlat16_2.xyz), u_xlat0.xyz);
    u_xlat6.x = u_xlat0.x * _Light_Intennsity;
    u_xlat0.x = u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat0.x = log2(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * _Highlight_Intensity;
    u_xlat0.x = exp2(u_xlat0.x);
    u_xlat3.xyz = _Color.xyz + (-_ShadowColor.xyz);
    u_xlat6.xyz = u_xlat6.xxx * u_xlat3.xyz + _ShadowColor.xyz;
    u_xlat3.xyz = u_xlat16_1.xyz * vec3(_BaseTex_Intensity) + (-u_xlat6.xyz);
    u_xlat21 = u_xlat16_1.w * vs_INTERP1.z;
    u_xlat21 = u_xlat21 * _BaseTex_0Off_1On;
    u_xlat6.xyz = vec3(u_xlat21) * u_xlat3.xyz + u_xlat6.xyz;
    u_xlat16_2.xyz = vs_INTERP1.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat16_2.xyz = vec3(vec3(_VC_1Color_or_0Flow, _VC_1Color_or_0Flow, _VC_1Color_or_0Flow)) * u_xlat16_2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = u_xlat6.xyz * u_xlat16_2.xyz;
    u_xlat0.xyz = u_xlat0.xxx * _Highlight_Color.xyz + u_xlat6.xyz;
    u_xlat3.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat4.xyz = vs_INTERP2.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP2.xxx + u_xlat4.xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP2.zzz + u_xlat4.xyz;
    u_xlat4.xyz = u_xlat4.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat5.xyz = u_xlat4.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat4.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat4.xxx + u_xlat5.xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat4.zzz + u_xlat4.xyw;
    u_xlat4.xyz = u_xlat4.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat18 = u_xlat4.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat18 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat4.x + u_xlat18;
    u_xlat18 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat4.z + u_xlat18;
    u_xlat18 = u_xlat18 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat18 = (-u_xlat18) + (-_ProjectionParams.y);
    u_xlat18 = max(u_xlat18, 0.0);
    u_xlat18 = u_xlat18 * unity_FogParams.z + unity_FogParams.w;
    u_xlat18 = clamp(u_xlat18, 0.0, 1.0);
    u_xlat18 = (-u_xlat18) + 1.0;
    u_xlat3.xyz = u_xlat3.xyz * vec3(u_xlat18);
    u_xlat0.xyz = vec3(_Fog_Intensity) * u_xlat3.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    u_xlat16_2.x = vs_INTERP1.w * _Color.w;
    SV_Target0.w = u_xlat16_2.x * _BakeAlpha;
    return;
}

#endif


// ===== program 8: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
vec4 u_xlat0;
vec4 u_xlat1;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 9: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 10: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 hlslcc_mtx4x4_PrevViewProjMatrix[4];
uniform 	vec4 hlslcc_mtx4x4_NonJitteredViewProjMatrix[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec4 in_COLOR0;
in highp vec3 in_TEXCOORD4;
out highp vec3 vs_CLIP_POSITION_NO_JITTER0;
out highp vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
highp vec4 vs_INTERP0;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
bool u_xlatb9;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlatb9 = unity_MotionVectorsParams.y!=0.0;
    if(u_xlatb9){
        u_xlatb9 = unity_MotionVectorsParams.x==1.0;
        u_xlat1.xyz = (bool(u_xlatb9)) ? in_TEXCOORD4.xyz : in_POSITION0.xyz;
        u_xlat2.xyz = u_xlat0.yyy * hlslcc_mtx4x4_NonJitteredViewProjMatrix[1].xyw;
        u_xlat0.xyw = hlslcc_mtx4x4_NonJitteredViewProjMatrix[0].xyw * u_xlat0.xxx + u_xlat2.xyz;
        u_xlat0.xyz = hlslcc_mtx4x4_NonJitteredViewProjMatrix[2].xyw * u_xlat0.zzz + u_xlat0.xyw;
        vs_CLIP_POSITION_NO_JITTER0.xyz = u_xlat0.xyz + hlslcc_mtx4x4_NonJitteredViewProjMatrix[3].xyw;
        u_xlat0 = u_xlat1.yyyy * hlslcc_mtx4x4unity_MatrixPreviousM[1];
        u_xlat0 = hlslcc_mtx4x4unity_MatrixPreviousM[0] * u_xlat1.xxxx + u_xlat0;
        u_xlat0 = hlslcc_mtx4x4unity_MatrixPreviousM[2] * u_xlat1.zzzz + u_xlat0;
        u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixPreviousM[3];
        u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4_PrevViewProjMatrix[1].xyw;
        u_xlat1.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[0].xyw * u_xlat0.xxx + u_xlat1.xyz;
        u_xlat0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[2].xyw * u_xlat0.zzz + u_xlat1.xyz;
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[3].xyw * u_xlat0.www + u_xlat0.xyz;
    } else {
        vs_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
    }
    vs_INTERP0 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
float u_xlat2;
bool u_xlatb2;
void main()
{
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat2 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat2) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb2 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb2) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 11: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
float u_xlat2;
bool u_xlatb2;
void main()
{
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat2 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat2) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb2 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb2) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 12: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
out highp vec3 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP1.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
in highp  vec3 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_INTERP1.xyz, vs_INTERP1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP1.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 13: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
in highp  vec3 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_INTERP1.xyz, vs_INTERP1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP1.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 14: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightDirection;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
highp vec3 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
mediump float u_xlat16_2;
float u_xlat4;
bool u_xlatb4;
float u_xlat9;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat0.xyz = vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z) * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat9 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat9 = max(u_xlat9, 1.17549435e-38);
    u_xlat9 = inversesqrt(u_xlat9);
    u_xlat1.xyz = vec3(u_xlat9) * u_xlat1.xyz;
    u_xlat9 = dot(vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z), u_xlat1.xyz);
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat9 = (-u_xlat9) + 1.0;
    u_xlat9 = u_xlat9 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat1.xyz * vec3(u_xlat9) + u_xlat0.xyz;
    vs_INTERP1.xyz = u_xlat1.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat4 = roundEven(_ShadowBias.z);
    u_xlatb4 = u_xlat4==1.0;
    u_xlat16_2 = (u_xlatb4) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_2 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    vs_INTERP0 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 15: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 16: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightPosition;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
highp vec3 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat5;
bool u_xlatb5;
float u_xlat12;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + _LightPosition.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat1.xyz = vec3(u_xlat12) * u_xlat1.xyz;
    u_xlat0.xyz = u_xlat1.xyz * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat2.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat2.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat2.xyz = vec3(u_xlat12) * u_xlat2.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat2.xyz);
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat12 = (-u_xlat12) + 1.0;
    u_xlat12 = u_xlat12 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat2.xyz * vec3(u_xlat12) + u_xlat0.xyz;
    vs_INTERP1.xyz = u_xlat2.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat5 = roundEven(_ShadowBias.z);
    u_xlatb5 = u_xlat5==1.0;
    u_xlat16_3 = (u_xlatb5) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_3 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    vs_INTERP0 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 17: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif

