varying vec4 var_clr;
out vec4 outFragColor;

void main() {
    outFragColor = var_clr * 2.000000;
}
