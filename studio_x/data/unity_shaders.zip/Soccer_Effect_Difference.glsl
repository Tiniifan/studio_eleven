// Soccer/Effect/Difference (Shader path ID 4360280246179038593, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ResourceTex0_ST;
	UNITY_UNIFORM float                _ResourceTex0_R;
	UNITY_UNIFORM vec4                _ResourceTex1_ST;
	UNITY_UNIFORM float                _ResourceTex1_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorPlateTex_ST;
	UNITY_UNIFORM vec4                _FlowTex_ST;
	UNITY_UNIFORM float                _FlowTex_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM float                _CPlateOffsetVertexAlpha;
	UNITY_UNIFORM float                _NoneVertexAlpha;
	UNITY_UNIFORM float                _CPlateX;
	UNITY_UNIFORM float                _AbsWeight;
	UNITY_UNIFORM float                _FlowScale0;
	UNITY_UNIFORM float                _FlowScale1;
	UNITY_UNIFORM float                _EdgeMaskWidth;
	UNITY_UNIFORM float                _EdgeMaskOffset;
	UNITY_UNIFORM float                _Luminance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
in highp vec2 in_TEXCOORD2;
in highp vec2 in_TEXCOORD3;
out highp vec4 vs_COLOR0;
out highp vec2 vs_TEXCOORD0;
out highp vec2 vs_TEXCOORD1;
out highp vec2 vs_TEXCOORD2;
out highp vec2 vs_TEXCOORD3;
out highp vec2 vs_TEXCOORD4;
vec3 u_xlat0;
bvec2 u_xlatb0;
vec4 u_xlat1;
vec3 u_xlat2;
vec3 u_xlat3;
float u_xlat4;
vec2 u_xlat8;
vec2 u_xlat9;
float u_xlat12;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat12 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    u_xlat12 = dot(hlslcc_mtx4x4unity_ObjectToWorld[0].xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat1.x = sqrt(u_xlat12);
    u_xlat12 = dot(hlslcc_mtx4x4unity_ObjectToWorld[1].xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat1.y = sqrt(u_xlat12);
    u_xlat12 = dot(hlslcc_mtx4x4unity_ObjectToWorld[2].xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat1.z = sqrt(u_xlat12);
    u_xlat1.xyz = in_NORMAL0.xyz / u_xlat1.xyz;
    u_xlat2.xyz = u_xlat1.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat1.xxx + u_xlat2.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat1.zzz + u_xlat1.xyw;
    u_xlat0.x = dot(u_xlat1.xyz, u_xlat0.xyz);
    u_xlat4 = _EdgeMaskOffset + _EdgeMaskWidth;
    u_xlat4 = clamp(u_xlat4, 0.0, 1.0);
    u_xlat4 = float(1.0) / u_xlat4;
    u_xlat0.x = u_xlat4 * abs(u_xlat0.x);
    u_xlat0.x = min(u_xlat0.x, 1.0);
    u_xlat0.x = u_xlat0.x + (-_EdgeMaskOffset);
    u_xlat4 = (-_EdgeMaskOffset) + 1.0;
    u_xlat4 = float(1.0) / u_xlat4;
    u_xlat0.x = u_xlat4 * u_xlat0.x;
    u_xlat0.x = max(u_xlat0.x, 0.0);
    u_xlat4 = (-in_COLOR0.w) * u_xlat0.x + 1.0;
    u_xlat0.x = u_xlat0.x * in_COLOR0.w;
    u_xlat4 = _NoneVertexAlpha * u_xlat4 + u_xlat0.x;
    u_xlat0.x = _CPlateX * u_xlat0.x + (-_CPlateX);
    vs_TEXCOORD2.x = _CPlateOffsetVertexAlpha * u_xlat0.x + _CPlateX;
    u_xlat0.x = _Transparency * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    vs_COLOR0.w = u_xlat4 * u_xlat0.x;
    u_xlat0.xyz = in_COLOR0.xyz * _Color.xyz;
    u_xlat12 = _Luminance + 1.0;
    vs_COLOR0.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    vs_TEXCOORD0.xy = in_TEXCOORD0.xy;
    vs_TEXCOORD1.xy = in_TEXCOORD1.xy;
    u_xlatb0.xy = greaterThanEqual(_FlowTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat8.xy = max(abs(_FlowTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat8.xy;
    u_xlat8.x = _FlowTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat8.x);
    u_xlat2.x = cos(u_xlat8.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat8.xy = in_TEXCOORD2.xy + (-_FlowTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat9.y = dot(u_xlat8.xy, u_xlat3.xy);
    u_xlat9.x = dot(u_xlat8.xy, u_xlat3.yz);
    vs_TEXCOORD3.xy = u_xlat9.xy / u_xlat0.xy;
    vs_TEXCOORD2.y = 1.0;
    u_xlatb0.xy = greaterThanEqual(_MaskTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat8.xy = max(abs(_MaskTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat8.xy;
    u_xlat8.x = _MaskTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat8.x);
    u_xlat2.x = cos(u_xlat8.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat8.xy = in_TEXCOORD3.xy + (-_MaskTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat8.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat8.xy, u_xlat3.yz);
    vs_TEXCOORD4.xy = u_xlat1.xy / u_xlat0.xy;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ResourceTex0_ST;
	UNITY_UNIFORM float                _ResourceTex0_R;
	UNITY_UNIFORM vec4                _ResourceTex1_ST;
	UNITY_UNIFORM float                _ResourceTex1_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorPlateTex_ST;
	UNITY_UNIFORM vec4                _FlowTex_ST;
	UNITY_UNIFORM float                _FlowTex_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM float                _CPlateOffsetVertexAlpha;
	UNITY_UNIFORM float                _NoneVertexAlpha;
	UNITY_UNIFORM float                _CPlateX;
	UNITY_UNIFORM float                _AbsWeight;
	UNITY_UNIFORM float                _FlowScale0;
	UNITY_UNIFORM float                _FlowScale1;
	UNITY_UNIFORM float                _EdgeMaskWidth;
	UNITY_UNIFORM float                _EdgeMaskOffset;
	UNITY_UNIFORM float                _Luminance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ResourceTex0;
UNITY_LOCATION(1) uniform mediump sampler2D _ResourceTex1;
UNITY_LOCATION(2) uniform mediump sampler2D _ColorPlateTex;
UNITY_LOCATION(3) uniform mediump sampler2D _FlowTex;
UNITY_LOCATION(4) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec2 vs_TEXCOORD3;
in highp  vec2 vs_TEXCOORD4;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
bvec2 u_xlatb0;
vec4 u_xlat1;
mediump float u_xlat16_1;
bvec2 u_xlatb1;
vec2 u_xlat2;
float u_xlat3;
vec3 u_xlat4;
vec2 u_xlat5;
mediump vec2 u_xlat16_5;
vec2 u_xlat10;
mediump vec2 u_xlat16_10;
vec2 u_xlat11;
float u_xlat15;
void main()
{
    u_xlatb0.xy = greaterThanEqual(_ResourceTex1_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = max(abs(_ResourceTex1_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat10.xy;
    u_xlat16_10.xy = texture(_FlowTex, vs_TEXCOORD3.xy, _GlobalMipBias.x).xy;
    u_xlat10.xy = u_xlat16_10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat1.xy = u_xlat10.xy * vec2(_FlowScale1) + vs_TEXCOORD1.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(vec2(_FlowScale0, _FlowScale0)) + vs_TEXCOORD0.xy;
    u_xlat10.xy = u_xlat10.xy + (-_ResourceTex0_ST.zw);
    u_xlat1.xy = u_xlat1.xy + (-_ResourceTex1_ST.zw);
    u_xlat11.x = _ResourceTex1_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat11.x);
    u_xlat3 = cos(u_xlat11.x);
    u_xlat4.z = u_xlat2.x;
    u_xlat4.y = u_xlat3;
    u_xlat4.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat1.xy, u_xlat4.xy);
    u_xlat2.x = dot(u_xlat1.xy, u_xlat4.yz);
    u_xlat0.xy = u_xlat2.xy / u_xlat0.xy;
    u_xlat16_0.x = texture(_ResourceTex1, u_xlat0.xy, _GlobalMipBias.x).x;
    u_xlatb1.xy = greaterThanEqual(_ResourceTex0_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = u_xlatb1.x ? float(1.0) : 0.0;
    u_xlat1.y = u_xlatb1.y ? float(1.0) : 0.0;
;
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat11.xy = max(abs(_ResourceTex0_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat11.xy;
    u_xlat5.x = _ResourceTex0_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat5.x);
    u_xlat3 = cos(u_xlat5.x);
    u_xlat4.z = u_xlat2.x;
    u_xlat4.y = u_xlat3;
    u_xlat4.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat10.xy, u_xlat4.xy);
    u_xlat2.x = dot(u_xlat10.xy, u_xlat4.yz);
    u_xlat5.xy = u_xlat2.xy / u_xlat1.xy;
    u_xlat16_5.xy = texture(_ResourceTex0, u_xlat5.xy, _GlobalMipBias.x).xw;
    u_xlat0.x = (-u_xlat16_0.x) + u_xlat16_5.x;
    u_xlat1.w = u_xlat16_5.y * vs_COLOR0.w;
    u_xlat5.x = (-u_xlat0.x) + abs(u_xlat0.x);
    u_xlat0.y = _AbsWeight * u_xlat5.x + u_xlat0.x;
    u_xlat0.x = 1.0;
    u_xlat0.xy = u_xlat0.xy * vs_TEXCOORD2.xy;
    u_xlat16_0 = texture(_ColorPlateTex, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat1.xyz = vs_COLOR0.xyz;
    u_xlat0 = u_xlat16_0 * u_xlat1;
    u_xlat16_1 = texture(_MaskTex, vs_TEXCOORD4.xy, _GlobalMipBias.x).x;
    u_xlat15 = u_xlat0.w * u_xlat16_1;
    SV_Target0.xyz = vec3(u_xlat15) * u_xlat0.xyz;
    SV_Target0.w = u_xlat15;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ResourceTex0_ST;
	UNITY_UNIFORM float                _ResourceTex0_R;
	UNITY_UNIFORM vec4                _ResourceTex1_ST;
	UNITY_UNIFORM float                _ResourceTex1_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorPlateTex_ST;
	UNITY_UNIFORM vec4                _FlowTex_ST;
	UNITY_UNIFORM float                _FlowTex_R;
	UNITY_UNIFORM vec4                _MaskTex_ST;
	UNITY_UNIFORM float                _MaskTex_R;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM float                _CPlateOffsetVertexAlpha;
	UNITY_UNIFORM float                _NoneVertexAlpha;
	UNITY_UNIFORM float                _CPlateX;
	UNITY_UNIFORM float                _AbsWeight;
	UNITY_UNIFORM float                _FlowScale0;
	UNITY_UNIFORM float                _FlowScale1;
	UNITY_UNIFORM float                _EdgeMaskWidth;
	UNITY_UNIFORM float                _EdgeMaskOffset;
	UNITY_UNIFORM float                _Luminance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ResourceTex0;
UNITY_LOCATION(1) uniform mediump sampler2D _ResourceTex1;
UNITY_LOCATION(2) uniform mediump sampler2D _ColorPlateTex;
UNITY_LOCATION(3) uniform mediump sampler2D _FlowTex;
UNITY_LOCATION(4) uniform mediump sampler2D _MaskTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD2;
in highp  vec2 vs_TEXCOORD3;
in highp  vec2 vs_TEXCOORD4;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
bvec2 u_xlatb0;
vec4 u_xlat1;
mediump float u_xlat16_1;
bvec2 u_xlatb1;
vec2 u_xlat2;
float u_xlat3;
vec3 u_xlat4;
vec2 u_xlat5;
mediump vec2 u_xlat16_5;
vec2 u_xlat10;
mediump vec2 u_xlat16_10;
vec2 u_xlat11;
float u_xlat15;
void main()
{
    u_xlatb0.xy = greaterThanEqual(_ResourceTex1_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat10.xy = max(abs(_ResourceTex1_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat10.xy;
    u_xlat16_10.xy = texture(_FlowTex, vs_TEXCOORD3.xy, _GlobalMipBias.x).xy;
    u_xlat10.xy = u_xlat16_10.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat1.xy = u_xlat10.xy * vec2(_FlowScale1) + vs_TEXCOORD1.xy;
    u_xlat10.xy = u_xlat10.xy * vec2(vec2(_FlowScale0, _FlowScale0)) + vs_TEXCOORD0.xy;
    u_xlat10.xy = u_xlat10.xy + (-_ResourceTex0_ST.zw);
    u_xlat1.xy = u_xlat1.xy + (-_ResourceTex1_ST.zw);
    u_xlat11.x = _ResourceTex1_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat11.x);
    u_xlat3 = cos(u_xlat11.x);
    u_xlat4.z = u_xlat2.x;
    u_xlat4.y = u_xlat3;
    u_xlat4.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat1.xy, u_xlat4.xy);
    u_xlat2.x = dot(u_xlat1.xy, u_xlat4.yz);
    u_xlat0.xy = u_xlat2.xy / u_xlat0.xy;
    u_xlat16_0.x = texture(_ResourceTex1, u_xlat0.xy, _GlobalMipBias.x).x;
    u_xlatb1.xy = greaterThanEqual(_ResourceTex0_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = u_xlatb1.x ? float(1.0) : 0.0;
    u_xlat1.y = u_xlatb1.y ? float(1.0) : 0.0;
;
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat11.xy = max(abs(_ResourceTex0_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat11.xy;
    u_xlat5.x = _ResourceTex0_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat5.x);
    u_xlat3 = cos(u_xlat5.x);
    u_xlat4.z = u_xlat2.x;
    u_xlat4.y = u_xlat3;
    u_xlat4.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat10.xy, u_xlat4.xy);
    u_xlat2.x = dot(u_xlat10.xy, u_xlat4.yz);
    u_xlat5.xy = u_xlat2.xy / u_xlat1.xy;
    u_xlat16_5.xy = texture(_ResourceTex0, u_xlat5.xy, _GlobalMipBias.x).xw;
    u_xlat0.x = (-u_xlat16_0.x) + u_xlat16_5.x;
    u_xlat1.w = u_xlat16_5.y * vs_COLOR0.w;
    u_xlat5.x = (-u_xlat0.x) + abs(u_xlat0.x);
    u_xlat0.y = _AbsWeight * u_xlat5.x + u_xlat0.x;
    u_xlat0.x = 1.0;
    u_xlat0.xy = u_xlat0.xy * vs_TEXCOORD2.xy;
    u_xlat16_0 = texture(_ColorPlateTex, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat1.xyz = vs_COLOR0.xyz;
    u_xlat0 = u_xlat16_0 * u_xlat1;
    u_xlat16_1 = texture(_MaskTex, vs_TEXCOORD4.xy, _GlobalMipBias.x).x;
    u_xlat15 = u_xlat0.w * u_xlat16_1;
    SV_Target0.xyz = vec3(u_xlat15) * u_xlat0.xyz;
    SV_Target0.w = u_xlat15;
    return;
}

#endif

