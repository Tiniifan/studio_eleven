// Soccer/PostProcess_Level5Bloom (Shader path ID -7278324996608432985, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _BlitScaleBias;
out highp vec2 vs_TEXCOORD0;
vec2 u_xlat0;
uvec3 u_xlatu0;
int int_bitfieldInsert(int base, int insert, int offset, int bits) {
    uint mask = uint(~(int(~0) << uint(bits)) << uint(offset));
    return int((uint(base) & ~mask) | ((uint(insert) << uint(offset)) & mask));
}

void main()
{
    u_xlatu0.x =  uint(int(int_bitfieldInsert(0, gl_VertexID, 1 & int(0x1F), 1)));
    u_xlatu0.z = uint(uint(gl_VertexID) & 2u);
    u_xlat0.xy = vec2(u_xlatu0.xz);
    gl_Position.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    vs_TEXCOORD0.xy = u_xlat0.xy * _BlitScaleBias.xy + _BlitScaleBias.zw;
    gl_Position.zw = vec2(-1.0, 1.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _SubLum;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump vec3 u_xlat16_0;
mediump vec3 u_xlat16_1;
void main()
{
    u_xlat16_0.xyz = texture(_BlitTexture, vs_TEXCOORD0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_1.xyz = u_xlat16_0.xyz + (-vec3(_SubLum));
    SV_TARGET0.xyz = max(u_xlat16_1.xyz, vec3(0.0, 0.0, 0.0));
    SV_TARGET0.w = 0.0;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _SubLum;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump vec3 u_xlat16_0;
mediump vec3 u_xlat16_1;
void main()
{
    u_xlat16_0.xyz = texture(_BlitTexture, vs_TEXCOORD0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_1.xyz = u_xlat16_0.xyz + (-vec3(_SubLum));
    SV_TARGET0.xyz = max(u_xlat16_1.xyz, vec3(0.0, 0.0, 0.0));
    SV_TARGET0.w = 0.0;
    return;
}

#endif


// ===== program 2: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _BlitScaleBias;
out highp vec2 vs_TEXCOORD0;
vec2 u_xlat0;
uvec3 u_xlatu0;
int int_bitfieldInsert(int base, int insert, int offset, int bits) {
    uint mask = uint(~(int(~0) << uint(bits)) << uint(offset));
    return int((uint(base) & ~mask) | ((uint(insert) << uint(offset)) & mask));
}

void main()
{
    u_xlatu0.x =  uint(int(int_bitfieldInsert(0, gl_VertexID, 1 & int(0x1F), 1)));
    u_xlatu0.z = uint(uint(gl_VertexID) & 2u);
    u_xlat0.xy = vec2(u_xlatu0.xz);
    gl_Position.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    vs_TEXCOORD0.xy = u_xlat0.xy * _BlitScaleBias.xy + _BlitScaleBias.zw;
    gl_Position.zw = vec2(-1.0, 1.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _BlitTexture_TexelSize;
uniform 	float _TexelStepSize;
uniform 	vec4 _Weight0_3;
uniform 	vec4 _Weight4_7;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
bvec2 u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
vec4 u_xlat3;
mediump vec4 u_xlat16_3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec4 u_xlat5;
mediump vec4 u_xlat16_5;
vec2 u_xlat12;
void main()
{
    u_xlatb0.xy = lessThan(vec4(1.0, 1.0, 0.0, 0.0), vs_TEXCOORD0.xyxx).xy;
    u_xlatb0.x = u_xlatb0.y || u_xlatb0.x;
    if(!u_xlatb0.x){
        u_xlat0 = vec4(vec4(_TexelStepSize, _TexelStepSize, _TexelStepSize, _TexelStepSize)) * vec4(4.0, 0.5, 1.5, 2.5);
        u_xlat1 = u_xlat0.xxyy / _BlitTexture_TexelSize.zwzw;
        u_xlat0.xy = (-u_xlat1.xy) * vec2(1.0, 0.0) + vs_TEXCOORD0.xy;
        u_xlat1.xy = u_xlat1.zw * vec2(1.0, 0.0) + u_xlat0.xy;
        u_xlat2 = u_xlat0.zzww / _BlitTexture_TexelSize.zwzw;
        u_xlat2 = u_xlat2 * vec4(1.0, 0.0, 1.0, 0.0) + u_xlat0.xyxy;
        u_xlat3 = vec4(vec4(_TexelStepSize, _TexelStepSize, _TexelStepSize, _TexelStepSize)) * vec4(3.5, 4.5, 5.5, 6.5);
        u_xlat4 = u_xlat3.xxyy / _BlitTexture_TexelSize.zwzw;
        u_xlat4 = u_xlat4 * vec4(1.0, 0.0, 1.0, 0.0) + u_xlat0.xyxy;
        u_xlat3 = u_xlat3.wwzz / _BlitTexture_TexelSize.zwzw;
        u_xlat3 = u_xlat3 * vec4(1.0, 0.0, 1.0, 0.0) + u_xlat0.xyxy;
        u_xlat12.x = _TexelStepSize * 7.5;
        u_xlat12.xy = u_xlat12.xx / _BlitTexture_TexelSize.zw;
        u_xlat0.xy = u_xlat12.xy * vec2(1.0, 0.0) + u_xlat0.xy;
        u_xlat12.xy = u_xlat1.xy * vec2(0.5, 0.5);
        u_xlat12.xy = fract(u_xlat12.xy);
        u_xlat12.xy = u_xlat12.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
        u_xlat12.xy = -abs(u_xlat12.xy) + vec2(1.0, 1.0);
        u_xlat16_1 = texture(_BlitTexture, u_xlat12.xy, _GlobalMipBias.x);
        u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
        u_xlat0.xy = fract(u_xlat0.xy);
        u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
        u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
        u_xlat16_0 = texture(_BlitTexture, u_xlat0.xy, _GlobalMipBias.x);
        u_xlat16_0 = u_xlat16_0 + u_xlat16_1;
        u_xlat1 = u_xlat2 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat1 = fract(u_xlat1);
        u_xlat1 = u_xlat1 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat1 = -abs(u_xlat1) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_2 = texture(_BlitTexture, u_xlat1.xy, _GlobalMipBias.x);
        u_xlat3 = u_xlat3 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat3 = fract(u_xlat3);
        u_xlat3 = u_xlat3 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat3 = -abs(u_xlat3) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_5 = texture(_BlitTexture, u_xlat3.xy, _GlobalMipBias.x);
        u_xlat16_2 = u_xlat16_2 + u_xlat16_5;
        u_xlat5 = u_xlat16_2 * _Weight0_3.yyyy;
        u_xlat5 = _Weight0_3.xxxx * u_xlat16_0 + u_xlat5;
        u_xlat16_1 = texture(_BlitTexture, u_xlat1.zw, _GlobalMipBias.x);
        u_xlat16_3 = texture(_BlitTexture, u_xlat3.zw, _GlobalMipBias.x);
        u_xlat16_1 = u_xlat16_1 + u_xlat16_3;
        u_xlat3 = _Weight0_3.zzzz * u_xlat16_1 + u_xlat5;
        u_xlat4 = u_xlat4 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat4 = fract(u_xlat4);
        u_xlat4 = u_xlat4 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat4 = -abs(u_xlat4) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_5 = texture(_BlitTexture, u_xlat4.xy, _GlobalMipBias.x);
        u_xlat16_4 = texture(_BlitTexture, u_xlat4.zw, _GlobalMipBias.x);
        u_xlat16_4 = u_xlat16_4 + u_xlat16_5;
        u_xlat3 = _Weight0_3.wwww * u_xlat16_4 + u_xlat3;
        u_xlat3 = _Weight4_7.xxxx * u_xlat16_4 + u_xlat3;
        u_xlat1 = _Weight4_7.yyyy * u_xlat16_1 + u_xlat3;
        u_xlat1 = _Weight4_7.zzzz * u_xlat16_2 + u_xlat1;
        u_xlat0 = _Weight4_7.wwww * u_xlat16_0 + u_xlat1;
        SV_Target0 = u_xlat0;
    } else {
        SV_Target0 = vec4(0.0, 0.0, 0.0, 0.0);
    }
    return;
}

#endif


// ===== program 3: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _BlitTexture_TexelSize;
uniform 	float _TexelStepSize;
uniform 	vec4 _Weight0_3;
uniform 	vec4 _Weight4_7;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
bvec2 u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
vec4 u_xlat3;
mediump vec4 u_xlat16_3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec4 u_xlat5;
mediump vec4 u_xlat16_5;
vec2 u_xlat12;
void main()
{
    u_xlatb0.xy = lessThan(vec4(1.0, 1.0, 0.0, 0.0), vs_TEXCOORD0.xyxx).xy;
    u_xlatb0.x = u_xlatb0.y || u_xlatb0.x;
    if(!u_xlatb0.x){
        u_xlat0 = vec4(vec4(_TexelStepSize, _TexelStepSize, _TexelStepSize, _TexelStepSize)) * vec4(4.0, 0.5, 1.5, 2.5);
        u_xlat1 = u_xlat0.xxyy / _BlitTexture_TexelSize.zwzw;
        u_xlat0.xy = (-u_xlat1.xy) * vec2(1.0, 0.0) + vs_TEXCOORD0.xy;
        u_xlat1.xy = u_xlat1.zw * vec2(1.0, 0.0) + u_xlat0.xy;
        u_xlat2 = u_xlat0.zzww / _BlitTexture_TexelSize.zwzw;
        u_xlat2 = u_xlat2 * vec4(1.0, 0.0, 1.0, 0.0) + u_xlat0.xyxy;
        u_xlat3 = vec4(vec4(_TexelStepSize, _TexelStepSize, _TexelStepSize, _TexelStepSize)) * vec4(3.5, 4.5, 5.5, 6.5);
        u_xlat4 = u_xlat3.xxyy / _BlitTexture_TexelSize.zwzw;
        u_xlat4 = u_xlat4 * vec4(1.0, 0.0, 1.0, 0.0) + u_xlat0.xyxy;
        u_xlat3 = u_xlat3.wwzz / _BlitTexture_TexelSize.zwzw;
        u_xlat3 = u_xlat3 * vec4(1.0, 0.0, 1.0, 0.0) + u_xlat0.xyxy;
        u_xlat12.x = _TexelStepSize * 7.5;
        u_xlat12.xy = u_xlat12.xx / _BlitTexture_TexelSize.zw;
        u_xlat0.xy = u_xlat12.xy * vec2(1.0, 0.0) + u_xlat0.xy;
        u_xlat12.xy = u_xlat1.xy * vec2(0.5, 0.5);
        u_xlat12.xy = fract(u_xlat12.xy);
        u_xlat12.xy = u_xlat12.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
        u_xlat12.xy = -abs(u_xlat12.xy) + vec2(1.0, 1.0);
        u_xlat16_1 = texture(_BlitTexture, u_xlat12.xy, _GlobalMipBias.x);
        u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
        u_xlat0.xy = fract(u_xlat0.xy);
        u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
        u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
        u_xlat16_0 = texture(_BlitTexture, u_xlat0.xy, _GlobalMipBias.x);
        u_xlat16_0 = u_xlat16_0 + u_xlat16_1;
        u_xlat1 = u_xlat2 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat1 = fract(u_xlat1);
        u_xlat1 = u_xlat1 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat1 = -abs(u_xlat1) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_2 = texture(_BlitTexture, u_xlat1.xy, _GlobalMipBias.x);
        u_xlat3 = u_xlat3 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat3 = fract(u_xlat3);
        u_xlat3 = u_xlat3 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat3 = -abs(u_xlat3) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_5 = texture(_BlitTexture, u_xlat3.xy, _GlobalMipBias.x);
        u_xlat16_2 = u_xlat16_2 + u_xlat16_5;
        u_xlat5 = u_xlat16_2 * _Weight0_3.yyyy;
        u_xlat5 = _Weight0_3.xxxx * u_xlat16_0 + u_xlat5;
        u_xlat16_1 = texture(_BlitTexture, u_xlat1.zw, _GlobalMipBias.x);
        u_xlat16_3 = texture(_BlitTexture, u_xlat3.zw, _GlobalMipBias.x);
        u_xlat16_1 = u_xlat16_1 + u_xlat16_3;
        u_xlat3 = _Weight0_3.zzzz * u_xlat16_1 + u_xlat5;
        u_xlat4 = u_xlat4 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat4 = fract(u_xlat4);
        u_xlat4 = u_xlat4 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat4 = -abs(u_xlat4) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_5 = texture(_BlitTexture, u_xlat4.xy, _GlobalMipBias.x);
        u_xlat16_4 = texture(_BlitTexture, u_xlat4.zw, _GlobalMipBias.x);
        u_xlat16_4 = u_xlat16_4 + u_xlat16_5;
        u_xlat3 = _Weight0_3.wwww * u_xlat16_4 + u_xlat3;
        u_xlat3 = _Weight4_7.xxxx * u_xlat16_4 + u_xlat3;
        u_xlat1 = _Weight4_7.yyyy * u_xlat16_1 + u_xlat3;
        u_xlat1 = _Weight4_7.zzzz * u_xlat16_2 + u_xlat1;
        u_xlat0 = _Weight4_7.wwww * u_xlat16_0 + u_xlat1;
        SV_Target0 = u_xlat0;
    } else {
        SV_Target0 = vec4(0.0, 0.0, 0.0, 0.0);
    }
    return;
}

#endif


// ===== program 4: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _BlitScaleBias;
out highp vec2 vs_TEXCOORD0;
vec2 u_xlat0;
uvec3 u_xlatu0;
int int_bitfieldInsert(int base, int insert, int offset, int bits) {
    uint mask = uint(~(int(~0) << uint(bits)) << uint(offset));
    return int((uint(base) & ~mask) | ((uint(insert) << uint(offset)) & mask));
}

void main()
{
    u_xlatu0.x =  uint(int(int_bitfieldInsert(0, gl_VertexID, 1 & int(0x1F), 1)));
    u_xlatu0.z = uint(uint(gl_VertexID) & 2u);
    u_xlat0.xy = vec2(u_xlatu0.xz);
    gl_Position.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    vs_TEXCOORD0.xy = u_xlat0.xy * _BlitScaleBias.xy + _BlitScaleBias.zw;
    gl_Position.zw = vec2(-1.0, 1.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _BlitTexture_TexelSize;
uniform 	float _TexelStepSize;
uniform 	vec4 _Weight0_3;
uniform 	vec4 _Weight4_7;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
bvec2 u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
vec4 u_xlat3;
mediump vec4 u_xlat16_3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec4 u_xlat5;
mediump vec4 u_xlat16_5;
vec2 u_xlat12;
void main()
{
    u_xlatb0.xy = lessThan(vec4(1.0, 1.0, 0.0, 0.0), vs_TEXCOORD0.xyxx).xy;
    u_xlatb0.x = u_xlatb0.y || u_xlatb0.x;
    if(!u_xlatb0.x){
        u_xlat0 = vec4(vec4(_TexelStepSize, _TexelStepSize, _TexelStepSize, _TexelStepSize)) * vec4(4.0, 0.5, 1.5, 2.5);
        u_xlat1 = u_xlat0.xxyy / _BlitTexture_TexelSize.zwzw;
        u_xlat0.xy = (-u_xlat1.xy) * vec2(0.0, 1.0) + vs_TEXCOORD0.xy;
        u_xlat1.xy = u_xlat1.zw * vec2(0.0, 1.0) + u_xlat0.xy;
        u_xlat2 = u_xlat0.zzww / _BlitTexture_TexelSize.zwzw;
        u_xlat2 = u_xlat2 * vec4(0.0, 1.0, 0.0, 1.0) + u_xlat0.xyxy;
        u_xlat3 = vec4(vec4(_TexelStepSize, _TexelStepSize, _TexelStepSize, _TexelStepSize)) * vec4(3.5, 4.5, 5.5, 6.5);
        u_xlat4 = u_xlat3.xxyy / _BlitTexture_TexelSize.zwzw;
        u_xlat4 = u_xlat4 * vec4(0.0, 1.0, 0.0, 1.0) + u_xlat0.xyxy;
        u_xlat3 = u_xlat3.wwzz / _BlitTexture_TexelSize.zwzw;
        u_xlat3 = u_xlat3 * vec4(0.0, 1.0, 0.0, 1.0) + u_xlat0.xyxy;
        u_xlat12.x = _TexelStepSize * 7.5;
        u_xlat12.xy = u_xlat12.xx / _BlitTexture_TexelSize.zw;
        u_xlat0.xy = u_xlat12.xy * vec2(0.0, 1.0) + u_xlat0.xy;
        u_xlat12.xy = u_xlat1.xy * vec2(0.5, 0.5);
        u_xlat12.xy = fract(u_xlat12.xy);
        u_xlat12.xy = u_xlat12.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
        u_xlat12.xy = -abs(u_xlat12.xy) + vec2(1.0, 1.0);
        u_xlat16_1 = texture(_BlitTexture, u_xlat12.xy, _GlobalMipBias.x);
        u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
        u_xlat0.xy = fract(u_xlat0.xy);
        u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
        u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
        u_xlat16_0 = texture(_BlitTexture, u_xlat0.xy, _GlobalMipBias.x);
        u_xlat16_0 = u_xlat16_0 + u_xlat16_1;
        u_xlat1 = u_xlat2 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat1 = fract(u_xlat1);
        u_xlat1 = u_xlat1 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat1 = -abs(u_xlat1) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_2 = texture(_BlitTexture, u_xlat1.xy, _GlobalMipBias.x);
        u_xlat3 = u_xlat3 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat3 = fract(u_xlat3);
        u_xlat3 = u_xlat3 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat3 = -abs(u_xlat3) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_5 = texture(_BlitTexture, u_xlat3.xy, _GlobalMipBias.x);
        u_xlat16_2 = u_xlat16_2 + u_xlat16_5;
        u_xlat5 = u_xlat16_2 * _Weight0_3.yyyy;
        u_xlat5 = _Weight0_3.xxxx * u_xlat16_0 + u_xlat5;
        u_xlat16_1 = texture(_BlitTexture, u_xlat1.zw, _GlobalMipBias.x);
        u_xlat16_3 = texture(_BlitTexture, u_xlat3.zw, _GlobalMipBias.x);
        u_xlat16_1 = u_xlat16_1 + u_xlat16_3;
        u_xlat3 = _Weight0_3.zzzz * u_xlat16_1 + u_xlat5;
        u_xlat4 = u_xlat4 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat4 = fract(u_xlat4);
        u_xlat4 = u_xlat4 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat4 = -abs(u_xlat4) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_5 = texture(_BlitTexture, u_xlat4.xy, _GlobalMipBias.x);
        u_xlat16_4 = texture(_BlitTexture, u_xlat4.zw, _GlobalMipBias.x);
        u_xlat16_4 = u_xlat16_4 + u_xlat16_5;
        u_xlat3 = _Weight0_3.wwww * u_xlat16_4 + u_xlat3;
        u_xlat3 = _Weight4_7.xxxx * u_xlat16_4 + u_xlat3;
        u_xlat1 = _Weight4_7.yyyy * u_xlat16_1 + u_xlat3;
        u_xlat1 = _Weight4_7.zzzz * u_xlat16_2 + u_xlat1;
        u_xlat0 = _Weight4_7.wwww * u_xlat16_0 + u_xlat1;
        SV_Target0 = u_xlat0;
    } else {
        SV_Target0 = vec4(0.0, 0.0, 0.0, 0.0);
    }
    return;
}

#endif


// ===== program 5: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _BlitTexture_TexelSize;
uniform 	float _TexelStepSize;
uniform 	vec4 _Weight0_3;
uniform 	vec4 _Weight4_7;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
bvec2 u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
vec4 u_xlat3;
mediump vec4 u_xlat16_3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec4 u_xlat5;
mediump vec4 u_xlat16_5;
vec2 u_xlat12;
void main()
{
    u_xlatb0.xy = lessThan(vec4(1.0, 1.0, 0.0, 0.0), vs_TEXCOORD0.xyxx).xy;
    u_xlatb0.x = u_xlatb0.y || u_xlatb0.x;
    if(!u_xlatb0.x){
        u_xlat0 = vec4(vec4(_TexelStepSize, _TexelStepSize, _TexelStepSize, _TexelStepSize)) * vec4(4.0, 0.5, 1.5, 2.5);
        u_xlat1 = u_xlat0.xxyy / _BlitTexture_TexelSize.zwzw;
        u_xlat0.xy = (-u_xlat1.xy) * vec2(0.0, 1.0) + vs_TEXCOORD0.xy;
        u_xlat1.xy = u_xlat1.zw * vec2(0.0, 1.0) + u_xlat0.xy;
        u_xlat2 = u_xlat0.zzww / _BlitTexture_TexelSize.zwzw;
        u_xlat2 = u_xlat2 * vec4(0.0, 1.0, 0.0, 1.0) + u_xlat0.xyxy;
        u_xlat3 = vec4(vec4(_TexelStepSize, _TexelStepSize, _TexelStepSize, _TexelStepSize)) * vec4(3.5, 4.5, 5.5, 6.5);
        u_xlat4 = u_xlat3.xxyy / _BlitTexture_TexelSize.zwzw;
        u_xlat4 = u_xlat4 * vec4(0.0, 1.0, 0.0, 1.0) + u_xlat0.xyxy;
        u_xlat3 = u_xlat3.wwzz / _BlitTexture_TexelSize.zwzw;
        u_xlat3 = u_xlat3 * vec4(0.0, 1.0, 0.0, 1.0) + u_xlat0.xyxy;
        u_xlat12.x = _TexelStepSize * 7.5;
        u_xlat12.xy = u_xlat12.xx / _BlitTexture_TexelSize.zw;
        u_xlat0.xy = u_xlat12.xy * vec2(0.0, 1.0) + u_xlat0.xy;
        u_xlat12.xy = u_xlat1.xy * vec2(0.5, 0.5);
        u_xlat12.xy = fract(u_xlat12.xy);
        u_xlat12.xy = u_xlat12.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
        u_xlat12.xy = -abs(u_xlat12.xy) + vec2(1.0, 1.0);
        u_xlat16_1 = texture(_BlitTexture, u_xlat12.xy, _GlobalMipBias.x);
        u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
        u_xlat0.xy = fract(u_xlat0.xy);
        u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
        u_xlat0.xy = -abs(u_xlat0.xy) + vec2(1.0, 1.0);
        u_xlat16_0 = texture(_BlitTexture, u_xlat0.xy, _GlobalMipBias.x);
        u_xlat16_0 = u_xlat16_0 + u_xlat16_1;
        u_xlat1 = u_xlat2 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat1 = fract(u_xlat1);
        u_xlat1 = u_xlat1 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat1 = -abs(u_xlat1) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_2 = texture(_BlitTexture, u_xlat1.xy, _GlobalMipBias.x);
        u_xlat3 = u_xlat3 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat3 = fract(u_xlat3);
        u_xlat3 = u_xlat3 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat3 = -abs(u_xlat3) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_5 = texture(_BlitTexture, u_xlat3.xy, _GlobalMipBias.x);
        u_xlat16_2 = u_xlat16_2 + u_xlat16_5;
        u_xlat5 = u_xlat16_2 * _Weight0_3.yyyy;
        u_xlat5 = _Weight0_3.xxxx * u_xlat16_0 + u_xlat5;
        u_xlat16_1 = texture(_BlitTexture, u_xlat1.zw, _GlobalMipBias.x);
        u_xlat16_3 = texture(_BlitTexture, u_xlat3.zw, _GlobalMipBias.x);
        u_xlat16_1 = u_xlat16_1 + u_xlat16_3;
        u_xlat3 = _Weight0_3.zzzz * u_xlat16_1 + u_xlat5;
        u_xlat4 = u_xlat4 * vec4(0.5, 0.5, 0.5, 0.5);
        u_xlat4 = fract(u_xlat4);
        u_xlat4 = u_xlat4 * vec4(2.0, 2.0, 2.0, 2.0) + vec4(-1.0, -1.0, -1.0, -1.0);
        u_xlat4 = -abs(u_xlat4) + vec4(1.0, 1.0, 1.0, 1.0);
        u_xlat16_5 = texture(_BlitTexture, u_xlat4.xy, _GlobalMipBias.x);
        u_xlat16_4 = texture(_BlitTexture, u_xlat4.zw, _GlobalMipBias.x);
        u_xlat16_4 = u_xlat16_4 + u_xlat16_5;
        u_xlat3 = _Weight0_3.wwww * u_xlat16_4 + u_xlat3;
        u_xlat3 = _Weight4_7.xxxx * u_xlat16_4 + u_xlat3;
        u_xlat1 = _Weight4_7.yyyy * u_xlat16_1 + u_xlat3;
        u_xlat1 = _Weight4_7.zzzz * u_xlat16_2 + u_xlat1;
        u_xlat0 = _Weight4_7.wwww * u_xlat16_0 + u_xlat1;
        SV_Target0 = u_xlat0;
    } else {
        SV_Target0 = vec4(0.0, 0.0, 0.0, 0.0);
    }
    return;
}

#endif


// ===== program 6: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _BlitScaleBias;
out highp vec2 vs_TEXCOORD0;
vec2 u_xlat0;
uvec3 u_xlatu0;
int int_bitfieldInsert(int base, int insert, int offset, int bits) {
    uint mask = uint(~(int(~0) << uint(bits)) << uint(offset));
    return int((uint(base) & ~mask) | ((uint(insert) << uint(offset)) & mask));
}

void main()
{
    u_xlatu0.x =  uint(int(int_bitfieldInsert(0, gl_VertexID, 1 & int(0x1F), 1)));
    u_xlatu0.z = uint(uint(gl_VertexID) & 2u);
    u_xlat0.xy = vec2(u_xlatu0.xz);
    gl_Position.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    vs_TEXCOORD0.xy = u_xlat0.xy * _BlitScaleBias.xy + _BlitScaleBias.zw;
    gl_Position.zw = vec2(-1.0, 1.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
void main()
{
    u_xlat16_0 = texture(_BlitTexture, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 7: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
void main()
{
    u_xlat16_0 = texture(_BlitTexture, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 8: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _BlitScaleBias;
out highp vec2 vs_TEXCOORD0;
vec2 u_xlat0;
uvec3 u_xlatu0;
int int_bitfieldInsert(int base, int insert, int offset, int bits) {
    uint mask = uint(~(int(~0) << uint(bits)) << uint(offset));
    return int((uint(base) & ~mask) | ((uint(insert) << uint(offset)) & mask));
}

void main()
{
    u_xlatu0.x =  uint(int(int_bitfieldInsert(0, gl_VertexID, 1 & int(0x1F), 1)));
    u_xlatu0.z = uint(uint(gl_VertexID) & 2u);
    u_xlat0.xy = vec2(u_xlatu0.xz);
    gl_Position.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    vs_TEXCOORD0.xy = u_xlat0.xy * _BlitScaleBias.xy + _BlitScaleBias.zw;
    gl_Position.zw = vec2(-1.0, 1.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _UseBloomTex0;
uniform 	float _Bloom0Intensity;
uniform 	float _Bloom0AlphaBlendRate;
uniform 	float _Bloom0UVScale;
uniform 	float _UseBloomTex1;
uniform 	float _Bloom1Intensity;
uniform 	float _Bloom1AlphaBlendRate;
uniform 	float _Bloom1UVScale;
uniform 	float _UseBloomTex2;
uniform 	float _Bloom2Intensity;
uniform 	float _Bloom2AlphaBlendRate;
uniform 	float _Bloom2UVScale;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _BloomTex0;
UNITY_LOCATION(2) uniform mediump sampler2D _BloomTex1;
UNITY_LOCATION(3) uniform mediump sampler2D _BloomTex2;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec2 u_xlat2;
mediump float u_xlat16_3;
void main()
{
    u_xlat0.x = max(_Bloom2UVScale, 9.99999975e-06);
    u_xlat0.xy = vs_TEXCOORD0.xy / u_xlat0.xx;
    u_xlat16_0 = texture(_BloomTex2, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat0 = u_xlat16_0 * vec4(vec4(_Bloom2Intensity, _Bloom2Intensity, _Bloom2Intensity, _Bloom2Intensity));
    u_xlat0 = clamp(u_xlat0, 0.0, 1.0);
    u_xlat0 = u_xlat0 + vec4(-0.0, -0.0, -0.0, -1.0);
    u_xlat0 = vec4(_UseBloomTex2) * u_xlat0 + vec4(0.0, 0.0, 0.0, 1.0);
    u_xlat16_1.x = max(u_xlat0.y, u_xlat0.x);
    u_xlat16_1.x = max(u_xlat0.z, u_xlat16_1.x);
    u_xlat2.x = (-u_xlat16_1.x) * _Bloom2AlphaBlendRate + 1.0;
    u_xlat16_1 = texture(_BlitTexture, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_0 = u_xlat16_1 * u_xlat2.xxxx + u_xlat0;
    u_xlat2.x = max(_Bloom1UVScale, 9.99999975e-06);
    u_xlat2.xy = vs_TEXCOORD0.xy / u_xlat2.xx;
    u_xlat16_1 = texture(_BloomTex1, u_xlat2.xy, _GlobalMipBias.x);
    u_xlat1 = u_xlat16_1 * vec4(vec4(_Bloom1Intensity, _Bloom1Intensity, _Bloom1Intensity, _Bloom1Intensity));
    u_xlat1 = clamp(u_xlat1, 0.0, 1.0);
    u_xlat1 = u_xlat1 + vec4(-0.0, -0.0, -0.0, -1.0);
    u_xlat1 = vec4(_UseBloomTex1) * u_xlat1 + vec4(0.0, 0.0, 0.0, 1.0);
    u_xlat16_3 = max(u_xlat1.y, u_xlat1.x);
    u_xlat16_3 = max(u_xlat1.z, u_xlat16_3);
    u_xlat2.x = (-u_xlat16_3) * _Bloom1AlphaBlendRate + 1.0;
    u_xlat16_0 = u_xlat16_0 * u_xlat2.xxxx + u_xlat1;
    u_xlat2.x = max(_Bloom0UVScale, 9.99999975e-06);
    u_xlat2.xy = vs_TEXCOORD0.xy / u_xlat2.xx;
    u_xlat16_1 = texture(_BloomTex0, u_xlat2.xy, _GlobalMipBias.x);
    u_xlat1 = u_xlat16_1 * vec4(vec4(_Bloom0Intensity, _Bloom0Intensity, _Bloom0Intensity, _Bloom0Intensity));
    u_xlat1 = clamp(u_xlat1, 0.0, 1.0);
    u_xlat1 = u_xlat1 + vec4(-0.0, -0.0, -0.0, -1.0);
    u_xlat1 = vec4(_UseBloomTex0) * u_xlat1 + vec4(0.0, 0.0, 0.0, 1.0);
    u_xlat16_3 = max(u_xlat1.y, u_xlat1.x);
    u_xlat16_3 = max(u_xlat1.z, u_xlat16_3);
    u_xlat2.x = (-u_xlat16_3) * _Bloom0AlphaBlendRate + 1.0;
    SV_Target0 = u_xlat16_0 * u_xlat2.xxxx + u_xlat1;
    return;
}

#endif


// ===== program 9: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _UseBloomTex0;
uniform 	float _Bloom0Intensity;
uniform 	float _Bloom0AlphaBlendRate;
uniform 	float _Bloom0UVScale;
uniform 	float _UseBloomTex1;
uniform 	float _Bloom1Intensity;
uniform 	float _Bloom1AlphaBlendRate;
uniform 	float _Bloom1UVScale;
uniform 	float _UseBloomTex2;
uniform 	float _Bloom2Intensity;
uniform 	float _Bloom2AlphaBlendRate;
uniform 	float _Bloom2UVScale;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _BloomTex0;
UNITY_LOCATION(2) uniform mediump sampler2D _BloomTex1;
UNITY_LOCATION(3) uniform mediump sampler2D _BloomTex2;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec2 u_xlat2;
mediump float u_xlat16_3;
void main()
{
    u_xlat0.x = max(_Bloom2UVScale, 9.99999975e-06);
    u_xlat0.xy = vs_TEXCOORD0.xy / u_xlat0.xx;
    u_xlat16_0 = texture(_BloomTex2, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat0 = u_xlat16_0 * vec4(vec4(_Bloom2Intensity, _Bloom2Intensity, _Bloom2Intensity, _Bloom2Intensity));
    u_xlat0 = clamp(u_xlat0, 0.0, 1.0);
    u_xlat0 = u_xlat0 + vec4(-0.0, -0.0, -0.0, -1.0);
    u_xlat0 = vec4(_UseBloomTex2) * u_xlat0 + vec4(0.0, 0.0, 0.0, 1.0);
    u_xlat16_1.x = max(u_xlat0.y, u_xlat0.x);
    u_xlat16_1.x = max(u_xlat0.z, u_xlat16_1.x);
    u_xlat2.x = (-u_xlat16_1.x) * _Bloom2AlphaBlendRate + 1.0;
    u_xlat16_1 = texture(_BlitTexture, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_0 = u_xlat16_1 * u_xlat2.xxxx + u_xlat0;
    u_xlat2.x = max(_Bloom1UVScale, 9.99999975e-06);
    u_xlat2.xy = vs_TEXCOORD0.xy / u_xlat2.xx;
    u_xlat16_1 = texture(_BloomTex1, u_xlat2.xy, _GlobalMipBias.x);
    u_xlat1 = u_xlat16_1 * vec4(vec4(_Bloom1Intensity, _Bloom1Intensity, _Bloom1Intensity, _Bloom1Intensity));
    u_xlat1 = clamp(u_xlat1, 0.0, 1.0);
    u_xlat1 = u_xlat1 + vec4(-0.0, -0.0, -0.0, -1.0);
    u_xlat1 = vec4(_UseBloomTex1) * u_xlat1 + vec4(0.0, 0.0, 0.0, 1.0);
    u_xlat16_3 = max(u_xlat1.y, u_xlat1.x);
    u_xlat16_3 = max(u_xlat1.z, u_xlat16_3);
    u_xlat2.x = (-u_xlat16_3) * _Bloom1AlphaBlendRate + 1.0;
    u_xlat16_0 = u_xlat16_0 * u_xlat2.xxxx + u_xlat1;
    u_xlat2.x = max(_Bloom0UVScale, 9.99999975e-06);
    u_xlat2.xy = vs_TEXCOORD0.xy / u_xlat2.xx;
    u_xlat16_1 = texture(_BloomTex0, u_xlat2.xy, _GlobalMipBias.x);
    u_xlat1 = u_xlat16_1 * vec4(vec4(_Bloom0Intensity, _Bloom0Intensity, _Bloom0Intensity, _Bloom0Intensity));
    u_xlat1 = clamp(u_xlat1, 0.0, 1.0);
    u_xlat1 = u_xlat1 + vec4(-0.0, -0.0, -0.0, -1.0);
    u_xlat1 = vec4(_UseBloomTex0) * u_xlat1 + vec4(0.0, 0.0, 0.0, 1.0);
    u_xlat16_3 = max(u_xlat1.y, u_xlat1.x);
    u_xlat16_3 = max(u_xlat1.z, u_xlat16_3);
    u_xlat2.x = (-u_xlat16_3) * _Bloom0AlphaBlendRate + 1.0;
    SV_Target0 = u_xlat16_0 * u_xlat2.xxxx + u_xlat1;
    return;
}

#endif


// ===== program 10: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _BlitScaleBias;
out highp vec2 vs_TEXCOORD0;
vec2 u_xlat0;
uvec3 u_xlatu0;
int int_bitfieldInsert(int base, int insert, int offset, int bits) {
    uint mask = uint(~(int(~0) << uint(bits)) << uint(offset));
    return int((uint(base) & ~mask) | ((uint(insert) << uint(offset)) & mask));
}

void main()
{
    u_xlatu0.x =  uint(int(int_bitfieldInsert(0, gl_VertexID, 1 & int(0x1F), 1)));
    u_xlatu0.z = uint(uint(gl_VertexID) & 2u);
    u_xlat0.xy = vec2(u_xlatu0.xz);
    gl_Position.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    vs_TEXCOORD0.xy = u_xlat0.xy * _BlitScaleBias.xy + _BlitScaleBias.zw;
    gl_Position.zw = vec2(-1.0, 1.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _UseBloomTex0;
uniform 	float _Bloom0Intensity;
uniform 	float _Bloom0AlphaBlendRate;
uniform 	float _Bloom0UVScale;
uniform 	float _UseBloomTex1;
uniform 	float _Bloom1Intensity;
uniform 	float _Bloom1AlphaBlendRate;
uniform 	float _Bloom1UVScale;
uniform 	float _UseBloomTex2;
uniform 	float _Bloom2Intensity;
uniform 	float _Bloom2AlphaBlendRate;
uniform 	float _Bloom2UVScale;
UNITY_LOCATION(0) uniform mediump sampler2D _BloomTex0;
UNITY_LOCATION(1) uniform mediump sampler2D _BloomTex1;
UNITY_LOCATION(2) uniform mediump sampler2D _BloomTex2;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
mediump float u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
float u_xlat3;
mediump float u_xlat16_4;
mediump vec3 u_xlat16_6;
float u_xlat15;
float u_xlat17;
void main()
{
    u_xlat0.x = max(_Bloom2UVScale, 9.99999975e-06);
    u_xlat0.xy = vs_TEXCOORD0.xy / u_xlat0.xx;
    u_xlat16_0.xyz = texture(_BloomTex2, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat0.xyz = u_xlat16_0.xyz * vec3(vec3(_Bloom2Intensity, _Bloom2Intensity, _Bloom2Intensity));
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(_UseBloomTex2);
    u_xlat16_1 = max(u_xlat0.y, u_xlat0.x);
    u_xlat16_1 = max(u_xlat0.z, u_xlat16_1);
    u_xlat15 = u_xlat16_1 * _Bloom2AlphaBlendRate;
    u_xlat2.x = max(_Bloom1UVScale, 9.99999975e-06);
    u_xlat2.xy = vs_TEXCOORD0.xy / u_xlat2.xx;
    u_xlat16_2.xyz = texture(_BloomTex1, u_xlat2.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_2.xyz * vec3(vec3(_Bloom1Intensity, _Bloom1Intensity, _Bloom1Intensity));
    u_xlat2.xyz = clamp(u_xlat2.xyz, 0.0, 1.0);
    u_xlat2.xyz = u_xlat2.xyz * vec3(_UseBloomTex1);
    u_xlat16_1 = max(u_xlat2.y, u_xlat2.x);
    u_xlat16_1 = max(u_xlat2.z, u_xlat16_1);
    u_xlat17 = u_xlat16_1 * _Bloom1AlphaBlendRate;
    u_xlat3 = (-u_xlat16_1) * _Bloom1AlphaBlendRate + 1.0;
    u_xlat16_1 = u_xlat15 * u_xlat3 + u_xlat17;
    u_xlat16_6.xyz = u_xlat0.xyz * vec3(u_xlat3) + u_xlat2.xyz;
    u_xlat0.x = max(_Bloom0UVScale, 9.99999975e-06);
    u_xlat0.xy = vs_TEXCOORD0.xy / u_xlat0.xx;
    u_xlat16_0.xyz = texture(_BloomTex0, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat0.xyz = u_xlat16_0.xyz * vec3(vec3(_Bloom0Intensity, _Bloom0Intensity, _Bloom0Intensity));
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(_UseBloomTex0);
    u_xlat16_4 = max(u_xlat0.y, u_xlat0.x);
    u_xlat16_4 = max(u_xlat0.z, u_xlat16_4);
    u_xlat15 = u_xlat16_4 * _Bloom0AlphaBlendRate;
    u_xlat2.x = (-u_xlat16_4) * _Bloom0AlphaBlendRate + 1.0;
    SV_Target0.w = u_xlat16_1 * u_xlat2.x + u_xlat15;
    SV_Target0.xyz = u_xlat16_6.xyz * u_xlat2.xxx + u_xlat0.xyz;
    return;
}

#endif


// ===== program 11: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _UseBloomTex0;
uniform 	float _Bloom0Intensity;
uniform 	float _Bloom0AlphaBlendRate;
uniform 	float _Bloom0UVScale;
uniform 	float _UseBloomTex1;
uniform 	float _Bloom1Intensity;
uniform 	float _Bloom1AlphaBlendRate;
uniform 	float _Bloom1UVScale;
uniform 	float _UseBloomTex2;
uniform 	float _Bloom2Intensity;
uniform 	float _Bloom2AlphaBlendRate;
uniform 	float _Bloom2UVScale;
UNITY_LOCATION(0) uniform mediump sampler2D _BloomTex0;
UNITY_LOCATION(1) uniform mediump sampler2D _BloomTex1;
UNITY_LOCATION(2) uniform mediump sampler2D _BloomTex2;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec3 u_xlat16_0;
mediump float u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
float u_xlat3;
mediump float u_xlat16_4;
mediump vec3 u_xlat16_6;
float u_xlat15;
float u_xlat17;
void main()
{
    u_xlat0.x = max(_Bloom2UVScale, 9.99999975e-06);
    u_xlat0.xy = vs_TEXCOORD0.xy / u_xlat0.xx;
    u_xlat16_0.xyz = texture(_BloomTex2, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat0.xyz = u_xlat16_0.xyz * vec3(vec3(_Bloom2Intensity, _Bloom2Intensity, _Bloom2Intensity));
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(_UseBloomTex2);
    u_xlat16_1 = max(u_xlat0.y, u_xlat0.x);
    u_xlat16_1 = max(u_xlat0.z, u_xlat16_1);
    u_xlat15 = u_xlat16_1 * _Bloom2AlphaBlendRate;
    u_xlat2.x = max(_Bloom1UVScale, 9.99999975e-06);
    u_xlat2.xy = vs_TEXCOORD0.xy / u_xlat2.xx;
    u_xlat16_2.xyz = texture(_BloomTex1, u_xlat2.xy, _GlobalMipBias.x).xyz;
    u_xlat2.xyz = u_xlat16_2.xyz * vec3(vec3(_Bloom1Intensity, _Bloom1Intensity, _Bloom1Intensity));
    u_xlat2.xyz = clamp(u_xlat2.xyz, 0.0, 1.0);
    u_xlat2.xyz = u_xlat2.xyz * vec3(_UseBloomTex1);
    u_xlat16_1 = max(u_xlat2.y, u_xlat2.x);
    u_xlat16_1 = max(u_xlat2.z, u_xlat16_1);
    u_xlat17 = u_xlat16_1 * _Bloom1AlphaBlendRate;
    u_xlat3 = (-u_xlat16_1) * _Bloom1AlphaBlendRate + 1.0;
    u_xlat16_1 = u_xlat15 * u_xlat3 + u_xlat17;
    u_xlat16_6.xyz = u_xlat0.xyz * vec3(u_xlat3) + u_xlat2.xyz;
    u_xlat0.x = max(_Bloom0UVScale, 9.99999975e-06);
    u_xlat0.xy = vs_TEXCOORD0.xy / u_xlat0.xx;
    u_xlat16_0.xyz = texture(_BloomTex0, u_xlat0.xy, _GlobalMipBias.x).xyz;
    u_xlat0.xyz = u_xlat16_0.xyz * vec3(vec3(_Bloom0Intensity, _Bloom0Intensity, _Bloom0Intensity));
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vec3(_UseBloomTex0);
    u_xlat16_4 = max(u_xlat0.y, u_xlat0.x);
    u_xlat16_4 = max(u_xlat0.z, u_xlat16_4);
    u_xlat15 = u_xlat16_4 * _Bloom0AlphaBlendRate;
    u_xlat2.x = (-u_xlat16_4) * _Bloom0AlphaBlendRate + 1.0;
    SV_Target0.w = u_xlat16_1 * u_xlat2.x + u_xlat15;
    SV_Target0.xyz = u_xlat16_6.xyz * u_xlat2.xxx + u_xlat0.xyz;
    return;
}

#endif

