#version 150
#define varying in
#define texture2D texture
#define textureCube texture
#define texture2DProj textureProj
precision mediump float;
precision mediump int;
varying vec4 var_clr;

void main() {
    gl_FragColor = var_clr * 2.000000;
}
