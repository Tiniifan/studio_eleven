// Soccer/Effect/Solid (Shader path ID 1946454178054170581, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
in highp vec2 in_TEXCOORD3;
out highp vec3 vs_TEXCOORD0;
out highp vec3 vs_TEXCOORD1;
out highp vec3 vs_TEXCOORD2;
out highp vec4 vs_TEXCOORD4;
highp vec2 vs_TEXCOORD5;
out mediump float vs_TEXCOORD8;
out highp vec3 vs_TEXCOORD6;
out highp vec3 vs_TEXCOORD7;
vec3 u_xlat0;
bool u_xlatb0;
vec4 u_xlat1;
bvec2 u_xlatb1;
vec3 u_xlat2;
mediump vec3 u_xlat16_3;
vec3 u_xlat4;
vec3 u_xlat5;
vec2 u_xlat13;
vec2 u_xlat14;
float u_xlat18;
bool u_xlatb18;
mediump float u_xlat16_21;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat18 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat18 = max(u_xlat18, 1.17549435e-38);
    u_xlat18 = inversesqrt(u_xlat18);
    u_xlat1.xyz = vec3(u_xlat18) * u_xlat1.xyz;
    u_xlat18 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat18 = inversesqrt(u_xlat18);
    vs_TEXCOORD0.xyz = vec3(u_xlat18) * u_xlat1.xyz;
    u_xlat2.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat2.xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat2.xyz;
    u_xlat18 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat18 = max(u_xlat18, 1.17549435e-38);
    u_xlat18 = inversesqrt(u_xlat18);
    u_xlat2.xyz = vec3(u_xlat18) * u_xlat2.xyz;
    u_xlat16_3.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat16_3.x = inversesqrt(u_xlat16_3.x);
    u_xlat16_3.xyz = u_xlat2.xyz * u_xlat16_3.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_3.xyz;
    u_xlat4.xyz = u_xlat1.zxy * u_xlat2.yzx;
    u_xlat1.xyz = u_xlat1.yzx * u_xlat2.zxy + (-u_xlat4.xyz);
    u_xlatb18 = unity_WorldTransformParams.w>=0.0;
    u_xlat18 = (u_xlatb18) ? 1.0 : -1.0;
    u_xlat16_3.x = u_xlat18 * in_TANGENT0.w;
    u_xlat16_3.xyz = u_xlat1.xyz * u_xlat16_3.xxx;
    u_xlat16_21 = dot(u_xlat16_3.xyz, u_xlat16_3.xyz);
    u_xlat16_21 = inversesqrt(u_xlat16_21);
    u_xlat16_3.xyz = vec3(u_xlat16_21) * u_xlat16_3.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_3.xyz;
    u_xlatb1.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = u_xlatb1.x ? float(1.0) : 0.0;
    u_xlat1.y = u_xlatb1.y ? float(1.0) : 0.0;
;
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat13.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat13.xy;
    u_xlat18 = _ColorTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat18);
    u_xlat4.x = cos(u_xlat18);
    u_xlat5.z = u_xlat2.x;
    u_xlat13.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat5.y = u_xlat4.x;
    u_xlat5.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat13.xy, u_xlat5.xy);
    u_xlat2.x = dot(u_xlat13.xy, u_xlat5.yz);
    vs_TEXCOORD4.xy = u_xlat2.xy / u_xlat1.xy;
    u_xlatb1.xy = greaterThanEqual(_NormalTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = u_xlatb1.x ? float(1.0) : 0.0;
    u_xlat1.y = u_xlatb1.y ? float(1.0) : 0.0;
;
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat13.xy = max(abs(_NormalTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat13.xy;
    u_xlat18 = _NormalTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat18);
    u_xlat4.x = cos(u_xlat18);
    u_xlat5.z = u_xlat2.x;
    u_xlat13.xy = in_TEXCOORD1.xy + (-_NormalTex_ST.zw);
    u_xlat5.y = u_xlat4.x;
    u_xlat5.x = (-u_xlat2.x);
    u_xlat14.y = dot(u_xlat13.xy, u_xlat5.xy);
    u_xlat14.x = dot(u_xlat13.xy, u_xlat5.yz);
    vs_TEXCOORD4.zw = u_xlat14.xy / u_xlat1.xy;
    u_xlatb1.xy = greaterThanEqual(_SpecuThickTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = u_xlatb1.x ? float(1.0) : 0.0;
    u_xlat1.y = u_xlatb1.y ? float(1.0) : 0.0;
;
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat13.xy = max(abs(_SpecuThickTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat13.xy;
    u_xlat18 = _SpecuThickTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat18);
    u_xlat4.x = cos(u_xlat18);
    u_xlat5.z = u_xlat2.x;
    u_xlat13.xy = in_TEXCOORD3.xy + (-_SpecuThickTex_ST.zw);
    u_xlat5.y = u_xlat4.x;
    u_xlat5.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat13.xy, u_xlat5.xy);
    u_xlat2.x = dot(u_xlat13.xy, u_xlat5.yz);
    vs_TEXCOORD5.xy = u_xlat2.xy / u_xlat1.xy;
    u_xlat1.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD7.xyz = u_xlat0.xyz;
    u_xlatb0 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD6.x = (u_xlatb0) ? u_xlat1.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD6.y = (u_xlatb0) ? u_xlat1.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD6.z = (u_xlatb0) ? u_xlat1.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8 = 0.0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale));
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale));
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 2: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
in highp vec2 in_TEXCOORD3;
out highp vec3 vs_TEXCOORD0;
out highp vec3 vs_TEXCOORD1;
out highp vec3 vs_TEXCOORD2;
out highp vec4 vs_TEXCOORD4;
highp vec2 vs_TEXCOORD5;
out mediump float vs_TEXCOORD8;
out highp vec3 vs_TEXCOORD6;
out highp vec3 vs_TEXCOORD7;
vec3 u_xlat0;
bool u_xlatb0;
vec4 u_xlat1;
bvec2 u_xlatb1;
vec3 u_xlat2;
mediump vec3 u_xlat16_3;
vec3 u_xlat4;
vec3 u_xlat5;
vec2 u_xlat13;
vec2 u_xlat14;
float u_xlat18;
bool u_xlatb18;
mediump float u_xlat16_21;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat18 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat18 = max(u_xlat18, 1.17549435e-38);
    u_xlat18 = inversesqrt(u_xlat18);
    u_xlat1.xyz = vec3(u_xlat18) * u_xlat1.xyz;
    u_xlat18 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat18 = inversesqrt(u_xlat18);
    vs_TEXCOORD0.xyz = vec3(u_xlat18) * u_xlat1.xyz;
    u_xlat2.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat2.xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat2.xyz;
    u_xlat18 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat18 = max(u_xlat18, 1.17549435e-38);
    u_xlat18 = inversesqrt(u_xlat18);
    u_xlat2.xyz = vec3(u_xlat18) * u_xlat2.xyz;
    u_xlat16_3.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat16_3.x = inversesqrt(u_xlat16_3.x);
    u_xlat16_3.xyz = u_xlat2.xyz * u_xlat16_3.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_3.xyz;
    u_xlat4.xyz = u_xlat1.zxy * u_xlat2.yzx;
    u_xlat1.xyz = u_xlat1.yzx * u_xlat2.zxy + (-u_xlat4.xyz);
    u_xlatb18 = unity_WorldTransformParams.w>=0.0;
    u_xlat18 = (u_xlatb18) ? 1.0 : -1.0;
    u_xlat16_3.x = u_xlat18 * in_TANGENT0.w;
    u_xlat16_3.xyz = u_xlat1.xyz * u_xlat16_3.xxx;
    u_xlat16_21 = dot(u_xlat16_3.xyz, u_xlat16_3.xyz);
    u_xlat16_21 = inversesqrt(u_xlat16_21);
    u_xlat16_3.xyz = vec3(u_xlat16_21) * u_xlat16_3.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_3.xyz;
    u_xlatb1.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = u_xlatb1.x ? float(1.0) : 0.0;
    u_xlat1.y = u_xlatb1.y ? float(1.0) : 0.0;
;
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat13.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat13.xy;
    u_xlat18 = _ColorTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat18);
    u_xlat4.x = cos(u_xlat18);
    u_xlat5.z = u_xlat2.x;
    u_xlat13.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat5.y = u_xlat4.x;
    u_xlat5.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat13.xy, u_xlat5.xy);
    u_xlat2.x = dot(u_xlat13.xy, u_xlat5.yz);
    vs_TEXCOORD4.xy = u_xlat2.xy / u_xlat1.xy;
    u_xlatb1.xy = greaterThanEqual(_NormalTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = u_xlatb1.x ? float(1.0) : 0.0;
    u_xlat1.y = u_xlatb1.y ? float(1.0) : 0.0;
;
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat13.xy = max(abs(_NormalTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat13.xy;
    u_xlat18 = _NormalTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat18);
    u_xlat4.x = cos(u_xlat18);
    u_xlat5.z = u_xlat2.x;
    u_xlat13.xy = in_TEXCOORD1.xy + (-_NormalTex_ST.zw);
    u_xlat5.y = u_xlat4.x;
    u_xlat5.x = (-u_xlat2.x);
    u_xlat14.y = dot(u_xlat13.xy, u_xlat5.xy);
    u_xlat14.x = dot(u_xlat13.xy, u_xlat5.yz);
    vs_TEXCOORD4.zw = u_xlat14.xy / u_xlat1.xy;
    u_xlatb1.xy = greaterThanEqual(_SpecuThickTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = u_xlatb1.x ? float(1.0) : 0.0;
    u_xlat1.y = u_xlatb1.y ? float(1.0) : 0.0;
;
    u_xlat1.xy = u_xlat1.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat13.xy = max(abs(_SpecuThickTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat13.xy;
    u_xlat18 = _SpecuThickTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat18);
    u_xlat4.x = cos(u_xlat18);
    u_xlat5.z = u_xlat2.x;
    u_xlat13.xy = in_TEXCOORD3.xy + (-_SpecuThickTex_ST.zw);
    u_xlat5.y = u_xlat4.x;
    u_xlat5.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat13.xy, u_xlat5.xy);
    u_xlat2.x = dot(u_xlat13.xy, u_xlat5.yz);
    vs_TEXCOORD5.xy = u_xlat2.xy / u_xlat1.xy;
    u_xlat1.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD7.xyz = u_xlat0.xyz;
    u_xlatb0 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD6.x = (u_xlatb0) ? u_xlat1.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD6.y = (u_xlatb0) ? u_xlat1.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD6.z = (u_xlatb0) ? u_xlat1.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8 = 0.0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SphereTex;
UNITY_LOCATION(4) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat5.xy = u_xlat16_2.yy * hlslcc_mtx4x4unity_MatrixV[1].xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[0].xy * u_xlat16_2.xx + u_xlat5.xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[2].xy * u_xlat16_2.zz + u_xlat5.xy;
    u_xlat5.xy = u_xlat5.xy * vec2(0.5, 0.5) + vec2(0.5, 0.5);
    u_xlat16_5.xyz = texture(_SphereTex, u_xlat5.xy, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale)) + u_xlat16_5.xyz;
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 3: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SphereTex;
UNITY_LOCATION(4) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat5.xy = u_xlat16_2.yy * hlslcc_mtx4x4unity_MatrixV[1].xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[0].xy * u_xlat16_2.xx + u_xlat5.xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[2].xy * u_xlat16_2.zz + u_xlat5.xy;
    u_xlat5.xy = u_xlat5.xy * vec2(0.5, 0.5) + vec2(0.5, 0.5);
    u_xlat16_5.xyz = texture(_SphereTex, u_xlat5.xy, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale)) + u_xlat16_5.xyz;
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 4: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
in highp vec2 in_TEXCOORD3;
out highp vec3 vs_TEXCOORD0;
out highp vec3 vs_TEXCOORD1;
out highp vec3 vs_TEXCOORD2;
out highp vec4 vs_TEXCOORD4;
highp vec2 vs_TEXCOORD5;
out mediump float vs_TEXCOORD8;
out highp vec3 vs_TEXCOORD6;
out highp vec3 vs_TEXCOORD7;
vec4 u_xlat0;
bvec2 u_xlatb0;
vec4 u_xlat1;
vec4 u_xlat2;
vec4 u_xlat3;
vec3 u_xlat4;
vec3 u_xlat5;
vec3 u_xlat6;
vec3 u_xlat7;
mediump vec3 u_xlat16_8;
vec2 u_xlat18;
vec2 u_xlat19;
float u_xlat27;
bool u_xlatb27;
float u_xlat28;
mediump float u_xlat16_35;
void main()
{
    u_xlat0.w = hlslcc_mtx4x4unity_ObjectToWorld[3].x;
    u_xlat1.xyz = _WorldSpaceCameraPos.zxy + (-hlslcc_mtx4x4unity_ObjectToWorld[3].zxy);
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat2.xyz = u_xlat1.xyz * vec3(0.0, 1.0, 0.0);
    u_xlat2.xyz = u_xlat1.yzx * vec3(0.0, 0.0, 1.0) + (-u_xlat2.xyz);
    u_xlat28 = dot(u_xlat2.yz, u_xlat2.yz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat0.xyz = vec3(u_xlat28) * u_xlat2.zxy;
    u_xlat2.xyz = u_xlat0.yzx * u_xlat1.xyz;
    u_xlat2.xyz = u_xlat1.zxy * u_xlat0.zxy + (-u_xlat2.xyz);
    u_xlat28 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat2.xyz = vec3(u_xlat28) * u_xlat2.xzy;
    u_xlat0.y = u_xlat2.x;
    u_xlat28 = dot(hlslcc_mtx4x4unity_ObjectToWorld[0].xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat3.x = inversesqrt(u_xlat28);
    u_xlat4.x = sqrt(u_xlat28);
    u_xlat3.xyz = u_xlat3.xxx * hlslcc_mtx4x4unity_ObjectToWorld[0].xyz;
    u_xlat28 = dot(hlslcc_mtx4x4unity_ObjectToWorld[1].xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.y = sqrt(u_xlat28);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat5.xyz = vec3(u_xlat28) * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat28 = dot(hlslcc_mtx4x4unity_ObjectToWorld[2].xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat4.z = sqrt(u_xlat28);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat6.xyz = vec3(u_xlat28) * hlslcc_mtx4x4unity_ObjectToWorld[2].xyz;
    u_xlat7.xyz = u_xlat4.xyz * in_POSITION0.xyz;
    u_xlat3.x = dot(u_xlat7.xyz, u_xlat3.xyz);
    u_xlat3.y = dot(u_xlat7.xyz, u_xlat5.xyz);
    u_xlat3.z = dot(u_xlat7.xyz, u_xlat6.xyz);
    u_xlat2.x = u_xlat0.z;
    u_xlat0.z = u_xlat1.y;
    u_xlat3.w = 1.0;
    u_xlat5.x = dot(u_xlat3, u_xlat0);
    u_xlat0.xyz = u_xlat0.xyz * u_xlat4.xxx;
    u_xlat0.x = dot(in_NORMAL0.xyz, u_xlat0.xyz);
    u_xlat6.x = u_xlat2.z;
    u_xlat6.y = u_xlat1.z;
    u_xlat2.z = u_xlat1.x;
    u_xlat6.z = hlslcc_mtx4x4unity_ObjectToWorld[3].y;
    u_xlat5.y = dot(u_xlat3.yzw, u_xlat6.xyz);
    u_xlat1.xy = u_xlat4.yy * u_xlat6.xy;
    u_xlat0.y = dot(in_NORMAL0.yz, u_xlat1.xy);
    u_xlat1 = u_xlat5.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat5.xxxx + u_xlat1;
    u_xlat2.w = hlslcc_mtx4x4unity_ObjectToWorld[3].z;
    u_xlat5.z = dot(u_xlat3, u_xlat2);
    u_xlat2.xyz = u_xlat4.zzz * u_xlat2.xyz;
    u_xlat0.z = dot(in_NORMAL0.xyz, u_xlat2.xyz);
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat5.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = max(u_xlat27, 1.17549435e-38);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    vs_TEXCOORD0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat1.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat1.xyz;
    u_xlat27 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat27 = max(u_xlat27, 1.17549435e-38);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat1.xyz = vec3(u_xlat27) * u_xlat1.xyz;
    u_xlat16_8.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_8.x = inversesqrt(u_xlat16_8.x);
    u_xlat16_8.xyz = u_xlat1.xyz * u_xlat16_8.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_8.xyz;
    u_xlat2.xyz = u_xlat0.zxy * u_xlat1.yzx;
    u_xlat0.xyz = u_xlat0.yzx * u_xlat1.zxy + (-u_xlat2.xyz);
    u_xlatb27 = unity_WorldTransformParams.w>=0.0;
    u_xlat27 = (u_xlatb27) ? 1.0 : -1.0;
    u_xlat16_8.x = u_xlat27 * in_TANGENT0.w;
    u_xlat16_8.xyz = u_xlat0.xyz * u_xlat16_8.xxx;
    u_xlat16_35 = dot(u_xlat16_8.xyz, u_xlat16_8.xyz);
    u_xlat16_35 = inversesqrt(u_xlat16_35);
    u_xlat16_8.xyz = vec3(u_xlat16_35) * u_xlat16_8.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_8.xyz;
    u_xlatb0.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _ColorTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD4.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_NormalTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_NormalTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _NormalTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD1.xy + (-_NormalTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat19.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat19.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD4.zw = u_xlat19.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_SpecuThickTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_SpecuThickTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _SpecuThickTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD3.xy + (-_SpecuThickTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD5.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlat0.xyz = (-u_xlat5.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD7.xyz = u_xlat5.xyz;
    u_xlatb27 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD6.x = (u_xlatb27) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD6.y = (u_xlatb27) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD6.z = (u_xlatb27) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8 = 0.0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale));
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 5: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale));
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 6: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
in highp vec2 in_TEXCOORD3;
out highp vec3 vs_TEXCOORD0;
out highp vec3 vs_TEXCOORD1;
out highp vec3 vs_TEXCOORD2;
out highp vec4 vs_TEXCOORD4;
highp vec2 vs_TEXCOORD5;
out mediump float vs_TEXCOORD8;
out highp vec3 vs_TEXCOORD6;
out highp vec3 vs_TEXCOORD7;
vec4 u_xlat0;
bvec2 u_xlatb0;
vec4 u_xlat1;
vec4 u_xlat2;
vec4 u_xlat3;
vec3 u_xlat4;
vec3 u_xlat5;
vec3 u_xlat6;
vec3 u_xlat7;
mediump vec3 u_xlat16_8;
vec2 u_xlat18;
vec2 u_xlat19;
float u_xlat27;
bool u_xlatb27;
float u_xlat28;
mediump float u_xlat16_35;
void main()
{
    u_xlat0.w = hlslcc_mtx4x4unity_ObjectToWorld[3].x;
    u_xlat1.xyz = _WorldSpaceCameraPos.zxy + (-hlslcc_mtx4x4unity_ObjectToWorld[3].zxy);
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat2.xyz = u_xlat1.xyz * vec3(0.0, 1.0, 0.0);
    u_xlat2.xyz = u_xlat1.yzx * vec3(0.0, 0.0, 1.0) + (-u_xlat2.xyz);
    u_xlat28 = dot(u_xlat2.yz, u_xlat2.yz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat0.xyz = vec3(u_xlat28) * u_xlat2.zxy;
    u_xlat2.xyz = u_xlat0.yzx * u_xlat1.xyz;
    u_xlat2.xyz = u_xlat1.zxy * u_xlat0.zxy + (-u_xlat2.xyz);
    u_xlat28 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat2.xyz = vec3(u_xlat28) * u_xlat2.xzy;
    u_xlat0.y = u_xlat2.x;
    u_xlat28 = dot(hlslcc_mtx4x4unity_ObjectToWorld[0].xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat3.x = inversesqrt(u_xlat28);
    u_xlat4.x = sqrt(u_xlat28);
    u_xlat3.xyz = u_xlat3.xxx * hlslcc_mtx4x4unity_ObjectToWorld[0].xyz;
    u_xlat28 = dot(hlslcc_mtx4x4unity_ObjectToWorld[1].xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.y = sqrt(u_xlat28);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat5.xyz = vec3(u_xlat28) * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat28 = dot(hlslcc_mtx4x4unity_ObjectToWorld[2].xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat4.z = sqrt(u_xlat28);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat6.xyz = vec3(u_xlat28) * hlslcc_mtx4x4unity_ObjectToWorld[2].xyz;
    u_xlat7.xyz = u_xlat4.xyz * in_POSITION0.xyz;
    u_xlat3.x = dot(u_xlat7.xyz, u_xlat3.xyz);
    u_xlat3.y = dot(u_xlat7.xyz, u_xlat5.xyz);
    u_xlat3.z = dot(u_xlat7.xyz, u_xlat6.xyz);
    u_xlat2.x = u_xlat0.z;
    u_xlat0.z = u_xlat1.y;
    u_xlat3.w = 1.0;
    u_xlat5.x = dot(u_xlat3, u_xlat0);
    u_xlat0.xyz = u_xlat0.xyz * u_xlat4.xxx;
    u_xlat0.x = dot(in_NORMAL0.xyz, u_xlat0.xyz);
    u_xlat6.x = u_xlat2.z;
    u_xlat6.y = u_xlat1.z;
    u_xlat2.z = u_xlat1.x;
    u_xlat6.z = hlslcc_mtx4x4unity_ObjectToWorld[3].y;
    u_xlat5.y = dot(u_xlat3.yzw, u_xlat6.xyz);
    u_xlat1.xy = u_xlat4.yy * u_xlat6.xy;
    u_xlat0.y = dot(in_NORMAL0.yz, u_xlat1.xy);
    u_xlat1 = u_xlat5.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat5.xxxx + u_xlat1;
    u_xlat2.w = hlslcc_mtx4x4unity_ObjectToWorld[3].z;
    u_xlat5.z = dot(u_xlat3, u_xlat2);
    u_xlat2.xyz = u_xlat4.zzz * u_xlat2.xyz;
    u_xlat0.z = dot(in_NORMAL0.xyz, u_xlat2.xyz);
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat5.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = max(u_xlat27, 1.17549435e-38);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    vs_TEXCOORD0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat1.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat1.xyz;
    u_xlat27 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat27 = max(u_xlat27, 1.17549435e-38);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat1.xyz = vec3(u_xlat27) * u_xlat1.xyz;
    u_xlat16_8.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_8.x = inversesqrt(u_xlat16_8.x);
    u_xlat16_8.xyz = u_xlat1.xyz * u_xlat16_8.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_8.xyz;
    u_xlat2.xyz = u_xlat0.zxy * u_xlat1.yzx;
    u_xlat0.xyz = u_xlat0.yzx * u_xlat1.zxy + (-u_xlat2.xyz);
    u_xlatb27 = unity_WorldTransformParams.w>=0.0;
    u_xlat27 = (u_xlatb27) ? 1.0 : -1.0;
    u_xlat16_8.x = u_xlat27 * in_TANGENT0.w;
    u_xlat16_8.xyz = u_xlat0.xyz * u_xlat16_8.xxx;
    u_xlat16_35 = dot(u_xlat16_8.xyz, u_xlat16_8.xyz);
    u_xlat16_35 = inversesqrt(u_xlat16_35);
    u_xlat16_8.xyz = vec3(u_xlat16_35) * u_xlat16_8.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_8.xyz;
    u_xlatb0.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _ColorTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD4.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_NormalTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_NormalTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _NormalTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD1.xy + (-_NormalTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat19.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat19.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD4.zw = u_xlat19.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_SpecuThickTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_SpecuThickTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _SpecuThickTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD3.xy + (-_SpecuThickTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD5.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlat0.xyz = (-u_xlat5.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD7.xyz = u_xlat5.xyz;
    u_xlatb27 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD6.x = (u_xlatb27) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD6.y = (u_xlatb27) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD6.z = (u_xlatb27) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8 = 0.0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SphereTex;
UNITY_LOCATION(4) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat5.xy = u_xlat16_2.yy * hlslcc_mtx4x4unity_MatrixV[1].xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[0].xy * u_xlat16_2.xx + u_xlat5.xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[2].xy * u_xlat16_2.zz + u_xlat5.xy;
    u_xlat5.xy = u_xlat5.xy * vec2(0.5, 0.5) + vec2(0.5, 0.5);
    u_xlat16_5.xyz = texture(_SphereTex, u_xlat5.xy, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale)) + u_xlat16_5.xyz;
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif
�

// ===== program 7: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SphereTex;
UNITY_LOCATION(4) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat5.xy = u_xlat16_2.yy * hlslcc_mtx4x4unity_MatrixV[1].xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[0].xy * u_xlat16_2.xx + u_xlat5.xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[2].xy * u_xlat16_2.zz + u_xlat5.xy;
    u_xlat5.xy = u_xlat5.xy * vec2(0.5, 0.5) + vec2(0.5, 0.5);
    u_xlat16_5.xyz = texture(_SphereTex, u_xlat5.xy, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale)) + u_xlat16_5.xyz;
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif
�

// ===== program 8: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
in highp vec2 in_TEXCOORD3;
out highp vec3 vs_TEXCOORD0;
out highp vec3 vs_TEXCOORD1;
out highp vec3 vs_TEXCOORD2;
out highp vec4 vs_TEXCOORD4;
highp vec2 vs_TEXCOORD5;
out mediump float vs_TEXCOORD8;
out highp vec3 vs_TEXCOORD6;
out highp vec3 vs_TEXCOORD7;
vec4 u_xlat0;
bvec2 u_xlatb0;
vec4 u_xlat1;
vec4 u_xlat2;
vec3 u_xlat3;
vec4 u_xlat4;
vec4 u_xlat5;
vec3 u_xlat6;
vec4 u_xlat7;
mediump vec3 u_xlat16_8;
float u_xlat11;
vec2 u_xlat18;
vec2 u_xlat19;
float u_xlat27;
bool u_xlatb27;
float u_xlat30;
mediump float u_xlat16_35;
void main()
{
    u_xlat0.w = hlslcc_mtx4x4unity_ObjectToWorld[3].y;
    u_xlat1 = _WorldSpaceCameraPos.zyyx + (-hlslcc_mtx4x4unity_ObjectToWorld[3].zyyx);
    u_xlat2.x = dot(u_xlat1.xzw, u_xlat1.xzw);
    u_xlat2.x = inversesqrt(u_xlat2.x);
    u_xlat1 = u_xlat1 * u_xlat2.xxxx;
    u_xlat2.x = dot(hlslcc_mtx4x4unity_ObjectToWorld[1].xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat11 = inversesqrt(u_xlat2.x);
    u_xlat3.y = sqrt(u_xlat2.x);
    u_xlat2.xyz = vec3(u_xlat11) * hlslcc_mtx4x4unity_ObjectToWorld[1].xzy;
    u_xlat4.xyz = u_xlat1.zxw * u_xlat2.yxz;
    u_xlat4.xyz = u_xlat2.zyx * u_xlat1.xwz + (-u_xlat4.xyz);
    u_xlat30 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat4.xyz = vec3(u_xlat30) * u_xlat4.xyz;
    u_xlat0.x = u_xlat4.y;
    u_xlat30 = dot(hlslcc_mtx4x4unity_ObjectToWorld[0].xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat3.x = sqrt(u_xlat30);
    u_xlat30 = dot(hlslcc_mtx4x4unity_ObjectToWorld[2].xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat3.z = sqrt(u_xlat30);
    u_xlat5.xyz = u_xlat3.xyz * in_POSITION0.xyz;
    u_xlat0.z = u_xlat2.z;
    u_xlat0.y = u_xlat1.z;
    u_xlat5.w = 1.0;
    u_xlat6.y = dot(u_xlat5.xzyw, u_xlat0);
    u_xlat7 = u_xlat6.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat4.y = u_xlat2.x;
    u_xlat2.x = u_xlat4.z;
    u_xlat4.w = hlslcc_mtx4x4unity_ObjectToWorld[3].x;
    u_xlat4.z = u_xlat1.w;
    u_xlat6.x = dot(u_xlat5, u_xlat4);
    u_xlat7 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat6.xxxx + u_xlat7;
    u_xlat2.z = u_xlat1.x;
    u_xlat2.w = hlslcc_mtx4x4unity_ObjectToWorld[3].z;
    u_xlat6.z = dot(u_xlat5, u_xlat2);
    u_xlat4.w = u_xlat2.z;
    u_xlat2 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat6.zzzz + u_xlat7;
    gl_Position = u_xlat2 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat18.xy = u_xlat1.zw * vec2(0.0, 1.0);
    u_xlat18.xy = u_xlat1.xy * vec2(1.0, 0.0) + (-u_xlat18.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat18.xy);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat4.xy = u_xlat18.xy * u_xlat1.xx;
    u_xlat1 = u_xlat3.xxzz * u_xlat4.xzyw;
    u_xlat2.x = dot(in_NORMAL0.xz, u_xlat1.xy);
    u_xlat2.z = dot(in_NORMAL0.xz, u_xlat1.zw);
    u_xlat0.x = 1.0;
    u_xlat0.xy = u_xlat3.yy * u_xlat0.xy;
    u_xlat2.y = dot(in_NORMAL0.yz, u_xlat0.xy);
    u_xlat0.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat0.x = max(u_xlat0.x, 1.17549435e-38);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * u_xlat2.xyz;
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    vs_TEXCOORD0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat1.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat1.xyz;
    u_xlat27 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat27 = max(u_xlat27, 1.17549435e-38);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat1.xyz = vec3(u_xlat27) * u_xlat1.xyz;
    u_xlat16_8.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_8.x = inversesqrt(u_xlat16_8.x);
    u_xlat16_8.xyz = u_xlat1.xyz * u_xlat16_8.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_8.xyz;
    u_xlat2.xyz = u_xlat0.zxy * u_xlat1.yzx;
    u_xlat0.xyz = u_xlat0.yzx * u_xlat1.zxy + (-u_xlat2.xyz);
    u_xlatb27 = unity_WorldTransformParams.w>=0.0;
    u_xlat27 = (u_xlatb27) ? 1.0 : -1.0;
    u_xlat16_8.x = u_xlat27 * in_TANGENT0.w;
    u_xlat16_8.xyz = u_xlat0.xyz * u_xlat16_8.xxx;
    u_xlat16_35 = dot(u_xlat16_8.xyz, u_xlat16_8.xyz);
    u_xlat16_35 = inversesqrt(u_xlat16_35);
    u_xlat16_8.xyz = vec3(u_xlat16_35) * u_xlat16_8.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_8.xyz;
    u_xlatb0.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _ColorTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD4.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_NormalTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_NormalTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _NormalTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD1.xy + (-_NormalTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat19.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat19.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD4.zw = u_xlat19.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_SpecuThickTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_SpecuThickTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _SpecuThickTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD3.xy + (-_SpecuThickTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD5.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlat0.xyz = (-u_xlat6.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD7.xyz = u_xlat6.xyz;
    u_xlatb27 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD6.x = (u_xlatb27) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD6.y = (u_xlatb27) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD6.z = (u_xlatb27) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8 = 0.0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale));
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 9: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
in highp vec2 in_TEXCOORD3;
out highp vec3 vs_TEXCOORD0;
out highp vec3 vs_TEXCOORD1;
out highp vec3 vs_TEXCOORD2;
out highp vec4 vs_TEXCOORD4;
highp vec2 vs_TEXCOORD5;
out mediump float vs_TEXCOORD8;
out highp vec3 vs_TEXCOORD6;
out highp vec3 vs_TEXCOORD7;
vec4 u_xlat0;
bvec2 u_xlatb0;
vec4 u_xlat1;
vec4 u_xlat2;
vec3 u_xlat3;
vec4 u_xlat4;
vec4 u_xlat5;
vec3 u_xlat6;
vec4 u_xlat7;
mediump vec3 u_xlat16_8;
float u_xlat11;
vec2 u_xlat18;
vec2 u_xlat19;
float u_xlat27;
bool u_xlatb27;
float u_xlat30;
mediump float u_xlat16_35;
void main()
{
    u_xlat0.w = hlslcc_mtx4x4unity_ObjectToWorld[3].y;
    u_xlat1 = _WorldSpaceCameraPos.zyyx + (-hlslcc_mtx4x4unity_ObjectToWorld[3].zyyx);
    u_xlat2.x = dot(u_xlat1.xzw, u_xlat1.xzw);
    u_xlat2.x = inversesqrt(u_xlat2.x);
    u_xlat1 = u_xlat1 * u_xlat2.xxxx;
    u_xlat2.x = dot(hlslcc_mtx4x4unity_ObjectToWorld[1].xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat11 = inversesqrt(u_xlat2.x);
    u_xlat3.y = sqrt(u_xlat2.x);
    u_xlat2.xyz = vec3(u_xlat11) * hlslcc_mtx4x4unity_ObjectToWorld[1].xzy;
    u_xlat4.xyz = u_xlat1.zxw * u_xlat2.yxz;
    u_xlat4.xyz = u_xlat2.zyx * u_xlat1.xwz + (-u_xlat4.xyz);
    u_xlat30 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat4.xyz = vec3(u_xlat30) * u_xlat4.xyz;
    u_xlat0.x = u_xlat4.y;
    u_xlat30 = dot(hlslcc_mtx4x4unity_ObjectToWorld[0].xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat3.x = sqrt(u_xlat30);
    u_xlat30 = dot(hlslcc_mtx4x4unity_ObjectToWorld[2].xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat3.z = sqrt(u_xlat30);
    u_xlat5.xyz = u_xlat3.xyz * in_POSITION0.xyz;
    u_xlat0.z = u_xlat2.z;
    u_xlat0.y = u_xlat1.z;
    u_xlat5.w = 1.0;
    u_xlat6.y = dot(u_xlat5.xzyw, u_xlat0);
    u_xlat7 = u_xlat6.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat4.y = u_xlat2.x;
    u_xlat2.x = u_xlat4.z;
    u_xlat4.w = hlslcc_mtx4x4unity_ObjectToWorld[3].x;
    u_xlat4.z = u_xlat1.w;
    u_xlat6.x = dot(u_xlat5, u_xlat4);
    u_xlat7 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat6.xxxx + u_xlat7;
    u_xlat2.z = u_xlat1.x;
    u_xlat2.w = hlslcc_mtx4x4unity_ObjectToWorld[3].z;
    u_xlat6.z = dot(u_xlat5, u_xlat2);
    u_xlat4.w = u_xlat2.z;
    u_xlat2 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat6.zzzz + u_xlat7;
    gl_Position = u_xlat2 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat18.xy = u_xlat1.zw * vec2(0.0, 1.0);
    u_xlat18.xy = u_xlat1.xy * vec2(1.0, 0.0) + (-u_xlat18.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat18.xy);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat4.xy = u_xlat18.xy * u_xlat1.xx;
    u_xlat1 = u_xlat3.xxzz * u_xlat4.xzyw;
    u_xlat2.x = dot(in_NORMAL0.xz, u_xlat1.xy);
    u_xlat2.z = dot(in_NORMAL0.xz, u_xlat1.zw);
    u_xlat0.x = 1.0;
    u_xlat0.xy = u_xlat3.yy * u_xlat0.xy;
    u_xlat2.y = dot(in_NORMAL0.yz, u_xlat0.xy);
    u_xlat0.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat0.x = max(u_xlat0.x, 1.17549435e-38);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * u_xlat2.xyz;
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    vs_TEXCOORD0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat1.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat1.xyz;
    u_xlat27 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat27 = max(u_xlat27, 1.17549435e-38);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat1.xyz = vec3(u_xlat27) * u_xlat1.xyz;
    u_xlat16_8.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_8.x = inversesqrt(u_xlat16_8.x);
    u_xlat16_8.xyz = u_xlat1.xyz * u_xlat16_8.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_8.xyz;
    u_xlat2.xyz = u_xlat0.zxy * u_xlat1.yzx;
    u_xlat0.xyz = u_xlat0.yzx * u_xlat1.zxy + (-u_xlat2.xyz);
    u_xlatb27 = unity_WorldTransformParams.w>=0.0;
    u_xlat27 = (u_xlatb27) ? 1.0 : -1.0;
    u_xlat16_8.x = u_xlat27 * in_TANGENT0.w;
    u_xlat16_8.xyz = u_xlat0.xyz * u_xlat16_8.xxx;
    u_xlat16_35 = dot(u_xlat16_8.xyz, u_xlat16_8.xyz);
    u_xlat16_35 = inversesqrt(u_xlat16_35);
    u_xlat16_8.xyz = vec3(u_xlat16_35) * u_xlat16_8.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_8.xyz;
    u_xlatb0.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _ColorTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD4.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_NormalTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_NormalTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _NormalTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD1.xy + (-_NormalTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat19.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat19.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD4.zw = u_xlat19.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_SpecuThickTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_SpecuThickTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _SpecuThickTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat2.x = cos(u_xlat18.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD3.xy + (-_SpecuThickTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat3.yz);
    vs_TEXCOORD5.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlat0.xyz = (-u_xlat6.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD7.xyz = u_xlat6.xyz;
    u_xlatb27 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD6.x = (u_xlatb27) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD6.y = (u_xlatb27) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD6.z = (u_xlatb27) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8 = 0.0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SphereTex;
UNITY_LOCATION(4) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat5.xy = u_xlat16_2.yy * hlslcc_mtx4x4unity_MatrixV[1].xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[0].xy * u_xlat16_2.xx + u_xlat5.xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[2].xy * u_xlat16_2.zz + u_xlat5.xy;
    u_xlat5.xy = u_xlat5.xy * vec2(0.5, 0.5) + vec2(0.5, 0.5);
    u_xlat16_5.xyz = texture(_SphereTex, u_xlat5.xy, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale)) + u_xlat16_5.xyz;
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 10: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SphereTex;
UNITY_LOCATION(4) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat5.xy = u_xlat16_2.yy * hlslcc_mtx4x4unity_MatrixV[1].xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[0].xy * u_xlat16_2.xx + u_xlat5.xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[2].xy * u_xlat16_2.zz + u_xlat5.xy;
    u_xlat5.xy = u_xlat5.xy * vec2(0.5, 0.5) + vec2(0.5, 0.5);
    u_xlat16_5.xyz = texture(_SphereTex, u_xlat5.xy, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale)) + u_xlat16_5.xyz;
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 11: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
in highp vec2 in_TEXCOORD3;
out highp vec3 vs_TEXCOORD0;
out highp vec3 vs_TEXCOORD1;
out highp vec3 vs_TEXCOORD2;
out highp vec4 vs_TEXCOORD4;
highp vec2 vs_TEXCOORD5;
out mediump float vs_TEXCOORD8;
out highp vec3 vs_TEXCOORD6;
out highp vec3 vs_TEXCOORD7;
vec4 u_xlat0;
bvec2 u_xlatb0;
vec4 u_xlat1;
vec3 u_xlat2;
vec4 u_xlat3;
vec3 u_xlat4;
vec4 u_xlat5;
vec4 u_xlat6;
vec3 u_xlat7;
mediump vec3 u_xlat16_8;
vec3 u_xlat10;
vec2 u_xlat18;
vec2 u_xlat19;
float u_xlat27;
bool u_xlatb27;
float u_xlat28;
float u_xlat29;
mediump float u_xlat16_35;
void main()
{
    u_xlat0.z = hlslcc_mtx4x4unity_ObjectToWorld[3].x;
    u_xlat1.xyz = _WorldSpaceCameraPos.xyz + (-hlslcc_mtx4x4unity_ObjectToWorld[3].xyz);
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat2.xyz = u_xlat1.zxy * vec3(0.0, 1.0, 0.0);
    u_xlat2.xyz = u_xlat1.xyz * vec3(0.0, 0.0, 1.0) + (-u_xlat2.xyz);
    u_xlat29 = dot(u_xlat2.yz, u_xlat2.yz);
    u_xlat29 = inversesqrt(u_xlat29);
    u_xlat2.xyz = vec3(u_xlat29) * u_xlat2.xyz;
    u_xlat3.xyz = u_xlat1.zxy * u_xlat2.xyz;
    u_xlat3.xyz = u_xlat1.yzx * u_xlat2.yzx + (-u_xlat3.xyz);
    u_xlat2.x = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat2.x = inversesqrt(u_xlat2.x);
    u_xlat3.xyz = u_xlat2.xxx * u_xlat3.xzy;
    u_xlat0.y = u_xlat3.x;
    u_xlat2.x = dot(hlslcc_mtx4x4unity_ObjectToWorld[0].xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat29 = inversesqrt(u_xlat2.x);
    u_xlat4.x = sqrt(u_xlat2.x);
    u_xlat5.xyz = vec3(u_xlat29) * hlslcc_mtx4x4unity_ObjectToWorld[0].xyz;
    u_xlat2.x = dot(hlslcc_mtx4x4unity_ObjectToWorld[2].xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat4.z = sqrt(u_xlat2.x);
    u_xlat2.x = dot(hlslcc_mtx4x4unity_ObjectToWorld[1].xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.y = sqrt(u_xlat2.x);
    u_xlat2.x = inversesqrt(u_xlat2.x);
    u_xlat6.xyz = u_xlat2.xxx * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat7.xyz = u_xlat4.xyz * in_POSITION0.xyz;
    u_xlat5.x = dot(u_xlat7.xyz, u_xlat5.xyz);
    u_xlat5.y = dot(u_xlat7.xyz, u_xlat6.xyz);
    u_xlat0.x = u_xlat2.z;
    u_xlat3.x = u_xlat2.y;
    u_xlat5.z = 1.0;
    u_xlat2.x = dot(u_xlat5.xyz, u_xlat0.xyz);
    u_xlat3.w = hlslcc_mtx4x4unity_ObjectToWorld[3].y;
    u_xlat2.y = dot(u_xlat5.yz, u_xlat3.zw);
    u_xlat6 = u_xlat2.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat6 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat2.xxxx + u_xlat6;
    u_xlat1.w = u_xlat3.z;
    u_xlat10.xz = u_xlat1.wy * u_xlat4.yy;
    u_xlat7.y = dot(in_NORMAL0.yz, u_xlat10.xz);
    u_xlat3.z = hlslcc_mtx4x4unity_ObjectToWorld[3].z;
    u_xlat2.z = dot(u_xlat5.xyz, u_xlat3.xyz);
    u_xlat5 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat2.zzzz + u_xlat6;
    gl_Position = u_xlat5 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat0.w = u_xlat1.x;
    u_xlat3.w = u_xlat1.z;
    u_xlat1.xyz = u_xlat4.zzz * u_xlat3.xyw;
    u_xlat7.z = dot(in_NORMAL0.xyz, u_xlat1.xyz);
    u_xlat0.xyz = u_xlat0.xyw * u_xlat4.xxx;
    u_xlat7.x = dot(in_NORMAL0.xyz, u_xlat0.xyz);
    u_xlat0.x = dot(u_xlat7.xyz, u_xlat7.xyz);
    u_xlat0.x = max(u_xlat0.x, 1.17549435e-38);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * u_xlat7.xyz;
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    vs_TEXCOORD0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat1.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat1.xyz;
    u_xlat27 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat27 = max(u_xlat27, 1.17549435e-38);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat1.xyz = vec3(u_xlat27) * u_xlat1.xyz;
    u_xlat16_8.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_8.x = inversesqrt(u_xlat16_8.x);
    u_xlat16_8.xyz = u_xlat1.xyz * u_xlat16_8.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_8.xyz;
    u_xlat3.xyz = u_xlat0.zxy * u_xlat1.yzx;
    u_xlat0.xyz = u_xlat0.yzx * u_xlat1.zxy + (-u_xlat3.xyz);
    u_xlatb27 = unity_WorldTransformParams.w>=0.0;
    u_xlat27 = (u_xlatb27) ? 1.0 : -1.0;
    u_xlat16_8.x = u_xlat27 * in_TANGENT0.w;
    u_xlat16_8.xyz = u_xlat0.xyz * u_xlat16_8.xxx;
    u_xlat16_35 = dot(u_xlat16_8.xyz, u_xlat16_8.xyz);
    u_xlat16_35 = inversesqrt(u_xlat16_35);
    u_xlat16_8.xyz = vec3(u_xlat16_35) * u_xlat16_8.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_8.xyz;
    u_xlatb0.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _ColorTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat3.x = cos(u_xlat18.x);
    u_xlat4.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat4.y = u_xlat3.x;
    u_xlat4.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat4.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat4.yz);
    vs_TEXCOORD4.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_NormalTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_NormalTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _NormalTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat3.x = cos(u_xlat18.x);
    u_xlat4.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD1.xy + (-_NormalTex_ST.zw);
    u_xlat4.y = u_xlat3.x;
    u_xlat4.x = (-u_xlat1.x);
    u_xlat19.y = dot(u_xlat18.xy, u_xlat4.xy);
    u_xlat19.x = dot(u_xlat18.xy, u_xlat4.yz);
    vs_TEXCOORD4.zw = u_xlat19.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_SpecuThickTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_SpecuThickTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _SpecuThickTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat3.x = cos(u_xlat18.x);
    u_xlat4.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD3.xy + (-_SpecuThickTex_ST.zw);
    u_xlat4.y = u_xlat3.x;
    u_xlat4.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat4.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat4.yz);
    vs_TEXCOORD5.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlat0.xyz = (-u_xlat2.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD7.xyz = u_xlat2.xyz;
    u_xlatb27 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD6.x = (u_xlatb27) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD6.y = (u_xlatb27) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD6.z = (u_xlatb27) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8 = 0.0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale));
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif


// ===== program 12: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
in highp vec2 in_TEXCOORD3;
out highp vec3 vs_TEXCOORD0;
out highp vec3 vs_TEXCOORD1;
out highp vec3 vs_TEXCOORD2;
out highp vec4 vs_TEXCOORD4;
highp vec2 vs_TEXCOORD5;
out mediump float vs_TEXCOORD8;
out highp vec3 vs_TEXCOORD6;
out highp vec3 vs_TEXCOORD7;
vec4 u_xlat0;
bvec2 u_xlatb0;
vec4 u_xlat1;
vec3 u_xlat2;
vec4 u_xlat3;
vec3 u_xlat4;
vec4 u_xlat5;
vec4 u_xlat6;
vec3 u_xlat7;
mediump vec3 u_xlat16_8;
vec3 u_xlat10;
vec2 u_xlat18;
vec2 u_xlat19;
float u_xlat27;
bool u_xlatb27;
float u_xlat28;
float u_xlat29;
mediump float u_xlat16_35;
void main()
{
    u_xlat0.z = hlslcc_mtx4x4unity_ObjectToWorld[3].x;
    u_xlat1.xyz = _WorldSpaceCameraPos.xyz + (-hlslcc_mtx4x4unity_ObjectToWorld[3].xyz);
    u_xlat28 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat28 = inversesqrt(u_xlat28);
    u_xlat1.xyz = vec3(u_xlat28) * u_xlat1.xyz;
    u_xlat2.xyz = u_xlat1.zxy * vec3(0.0, 1.0, 0.0);
    u_xlat2.xyz = u_xlat1.xyz * vec3(0.0, 0.0, 1.0) + (-u_xlat2.xyz);
    u_xlat29 = dot(u_xlat2.yz, u_xlat2.yz);
    u_xlat29 = inversesqrt(u_xlat29);
    u_xlat2.xyz = vec3(u_xlat29) * u_xlat2.xyz;
    u_xlat3.xyz = u_xlat1.zxy * u_xlat2.xyz;
    u_xlat3.xyz = u_xlat1.yzx * u_xlat2.yzx + (-u_xlat3.xyz);
    u_xlat2.x = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat2.x = inversesqrt(u_xlat2.x);
    u_xlat3.xyz = u_xlat2.xxx * u_xlat3.xzy;
    u_xlat0.y = u_xlat3.x;
    u_xlat2.x = dot(hlslcc_mtx4x4unity_ObjectToWorld[0].xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat29 = inversesqrt(u_xlat2.x);
    u_xlat4.x = sqrt(u_xlat2.x);
    u_xlat5.xyz = vec3(u_xlat29) * hlslcc_mtx4x4unity_ObjectToWorld[0].xyz;
    u_xlat2.x = dot(hlslcc_mtx4x4unity_ObjectToWorld[2].xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat4.z = sqrt(u_xlat2.x);
    u_xlat2.x = dot(hlslcc_mtx4x4unity_ObjectToWorld[1].xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat4.y = sqrt(u_xlat2.x);
    u_xlat2.x = inversesqrt(u_xlat2.x);
    u_xlat6.xyz = u_xlat2.xxx * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat7.xyz = u_xlat4.xyz * in_POSITION0.xyz;
    u_xlat5.x = dot(u_xlat7.xyz, u_xlat5.xyz);
    u_xlat5.y = dot(u_xlat7.xyz, u_xlat6.xyz);
    u_xlat0.x = u_xlat2.z;
    u_xlat3.x = u_xlat2.y;
    u_xlat5.z = 1.0;
    u_xlat2.x = dot(u_xlat5.xyz, u_xlat0.xyz);
    u_xlat3.w = hlslcc_mtx4x4unity_ObjectToWorld[3].y;
    u_xlat2.y = dot(u_xlat5.yz, u_xlat3.zw);
    u_xlat6 = u_xlat2.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat6 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat2.xxxx + u_xlat6;
    u_xlat1.w = u_xlat3.z;
    u_xlat10.xz = u_xlat1.wy * u_xlat4.yy;
    u_xlat7.y = dot(in_NORMAL0.yz, u_xlat10.xz);
    u_xlat3.z = hlslcc_mtx4x4unity_ObjectToWorld[3].z;
    u_xlat2.z = dot(u_xlat5.xyz, u_xlat3.xyz);
    u_xlat5 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat2.zzzz + u_xlat6;
    gl_Position = u_xlat5 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat0.w = u_xlat1.x;
    u_xlat3.w = u_xlat1.z;
    u_xlat1.xyz = u_xlat4.zzz * u_xlat3.xyw;
    u_xlat7.z = dot(in_NORMAL0.xyz, u_xlat1.xyz);
    u_xlat0.xyz = u_xlat0.xyw * u_xlat4.xxx;
    u_xlat7.x = dot(in_NORMAL0.xyz, u_xlat0.xyz);
    u_xlat0.x = dot(u_xlat7.xyz, u_xlat7.xyz);
    u_xlat0.x = max(u_xlat0.x, 1.17549435e-38);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * u_xlat7.xyz;
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    vs_TEXCOORD0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat1.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat1.xyz;
    u_xlat27 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat27 = max(u_xlat27, 1.17549435e-38);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat1.xyz = vec3(u_xlat27) * u_xlat1.xyz;
    u_xlat16_8.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_8.x = inversesqrt(u_xlat16_8.x);
    u_xlat16_8.xyz = u_xlat1.xyz * u_xlat16_8.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_8.xyz;
    u_xlat3.xyz = u_xlat0.zxy * u_xlat1.yzx;
    u_xlat0.xyz = u_xlat0.yzx * u_xlat1.zxy + (-u_xlat3.xyz);
    u_xlatb27 = unity_WorldTransformParams.w>=0.0;
    u_xlat27 = (u_xlatb27) ? 1.0 : -1.0;
    u_xlat16_8.x = u_xlat27 * in_TANGENT0.w;
    u_xlat16_8.xyz = u_xlat0.xyz * u_xlat16_8.xxx;
    u_xlat16_35 = dot(u_xlat16_8.xyz, u_xlat16_8.xyz);
    u_xlat16_35 = inversesqrt(u_xlat16_35);
    u_xlat16_8.xyz = vec3(u_xlat16_35) * u_xlat16_8.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_8.xyz;
    u_xlatb0.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _ColorTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat3.x = cos(u_xlat18.x);
    u_xlat4.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat4.y = u_xlat3.x;
    u_xlat4.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat4.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat4.yz);
    vs_TEXCOORD4.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_NormalTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_NormalTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _NormalTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat3.x = cos(u_xlat18.x);
    u_xlat4.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD1.xy + (-_NormalTex_ST.zw);
    u_xlat4.y = u_xlat3.x;
    u_xlat4.x = (-u_xlat1.x);
    u_xlat19.y = dot(u_xlat18.xy, u_xlat4.xy);
    u_xlat19.x = dot(u_xlat18.xy, u_xlat4.yz);
    vs_TEXCOORD4.zw = u_xlat19.xy / u_xlat0.xy;
    u_xlatb0.xy = greaterThanEqual(_SpecuThickTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat18.xy = max(abs(_SpecuThickTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat18.xy;
    u_xlat18.x = _SpecuThickTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18.x);
    u_xlat3.x = cos(u_xlat18.x);
    u_xlat4.z = u_xlat1.x;
    u_xlat18.xy = in_TEXCOORD3.xy + (-_SpecuThickTex_ST.zw);
    u_xlat4.y = u_xlat3.x;
    u_xlat4.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat18.xy, u_xlat4.xy);
    u_xlat1.x = dot(u_xlat18.xy, u_xlat4.yz);
    vs_TEXCOORD5.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlat0.xyz = (-u_xlat2.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD7.xyz = u_xlat2.xyz;
    u_xlatb27 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD6.x = (u_xlatb27) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD6.y = (u_xlatb27) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD6.z = (u_xlatb27) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8 = 0.0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	mediump float _MainLightToonX;
uniform 	mediump float _AdditionalLightToonX;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4                unity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4                unity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _NormalTex_ST;
	UNITY_UNIFORM float                _NormalTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ToonTex_ST;
	UNITY_UNIFORM vec4                _SpecuThickTex_ST;
	UNITY_UNIFORM float                _SpecuThickTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SpecuOccTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SpecuOccTex_R;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SphereTex_ST;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SphereTex_R;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Transparency;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyMultiplier;
	UNITY_UNIFORM float Xhlslcc_UnusedX_TransparencyOffset;
	UNITY_UNIFORM float                _FresnelIn;
	UNITY_UNIFORM float                _FresnelOut;
	UNITY_UNIFORM float                _SpecularPower;
	UNITY_UNIFORM float                _SpecularScale;
	UNITY_UNIFORM float Xhlslcc_UnusedX_OcclusionRate;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_HighLightColor;
	UNITY_UNIFORM float Xhlslcc_UnusedX_HighLightRate;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(3) uniform mediump sampler2D _SphereTex;
UNITY_LOCATION(4) uniform mediump sampler2D _SpecuThickTex;
in highp  vec3 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
in highp  vec4 vs_TEXCOORD4;
in mediump  float vs_TEXCOORD8;
in highp  vec3 vs_TEXCOORD6;
in highp  vec3 vs_TEXCOORD7;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
vec3 u_xlat1;
mediump vec2 u_xlat16_1;
mediump vec3 u_xlat16_2;
vec3 u_xlat3;
bool u_xlatb3;
vec4 u_xlat4;
mediump vec4 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
int u_xlati5;
float u_xlat6;
vec3 u_xlat7;
float u_xlat9;
mediump vec3 u_xlat16_9;
vec3 u_xlat11;
vec3 u_xlat13;
uint u_xlatu14;
float u_xlat22;
int u_xlati22;
uint u_xlatu22;
bool u_xlatb22;
float u_xlat25;
mediump float u_xlat16_26;
float u_xlat27;
float u_xlat30;
int u_xlati30;
float u_xlat31;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD4.xy, _GlobalMipBias.x);
    u_xlat16_1.xy = texture(_NormalTex, vs_TEXCOORD4.zw, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_1.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_26 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat16_26 = min(u_xlat16_26, 1.0);
    u_xlat16_26 = (-u_xlat16_26) + 1.0;
    u_xlat16_26 = sqrt(u_xlat16_26);
    u_xlat16_2.z = max(u_xlat16_26, 1.00000002e-16);
    u_xlat1.x = vs_TEXCOORD1.x;
    u_xlat1.y = vs_TEXCOORD2.x;
    u_xlat1.z = vs_TEXCOORD0.x;
    u_xlat1.x = dot(u_xlat16_2.xyz, u_xlat1.xyz);
    u_xlat3.x = vs_TEXCOORD1.y;
    u_xlat3.y = vs_TEXCOORD2.y;
    u_xlat3.z = vs_TEXCOORD0.y;
    u_xlat1.y = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat3.x = vs_TEXCOORD1.z;
    u_xlat3.y = vs_TEXCOORD2.z;
    u_xlat3.z = vs_TEXCOORD0.z;
    u_xlat1.z = dot(u_xlat16_2.xyz, u_xlat3.xyz);
    u_xlat16_2.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat16_2.x = max(u_xlat16_2.x, 6.10351562e-05);
    u_xlat16_2.x = inversesqrt(u_xlat16_2.x);
    u_xlat16_2.xyz = u_xlat1.xyz * u_xlat16_2.xxx;
    u_xlat1.x = dot(vs_TEXCOORD6.xyz, vs_TEXCOORD6.xyz);
    u_xlat1.x = inversesqrt(u_xlat1.x);
    u_xlat1.xyz = u_xlat1.xxx * vs_TEXCOORD6.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat16_2.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = u_xlat1.x * u_xlat1.x;
    u_xlat9 = (-_FresnelIn) + _FresnelOut;
    u_xlat1.x = u_xlat1.x * u_xlat9 + _FresnelIn;
    u_xlat16_9.xyz = texture(_SpecuThickTex, vs_TEXCOORD4.xz, _GlobalMipBias.x).xyz;
    u_xlat16_26 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_26 = inversesqrt(u_xlat16_26);
    u_xlatb3 = unity_OrthoParams.w==0.0;
    u_xlat11.xyz = (-vs_TEXCOORD7.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat4.x = (u_xlatb3) ? u_xlat11.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat4.y = (u_xlatb3) ? u_xlat11.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat4.z = (u_xlatb3) ? u_xlat11.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    u_xlat3.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat3.x = inversesqrt(u_xlat3.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat4.xyz;
    u_xlat4.xyz = _MainLightPosition.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
    u_xlat27 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat4.xyz = vec3(u_xlat27) * u_xlat4.xyz;
    u_xlat27 = dot(u_xlat16_2.xyz, u_xlat4.xyz);
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = log2(u_xlat27);
    u_xlat27 = u_xlat27 * _SpecularPower;
    u_xlat27 = exp2(u_xlat27);
    u_xlat4.x = dot(u_xlat16_2.xyz, _MainLightPosition.xyz);
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x * 0.5 + 0.5;
    u_xlat4.x = u_xlat4.x * unity_LightData.z;
    u_xlat4.y = u_xlat1.x * u_xlat4.x;
    u_xlat16_26 = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati5 = int(u_xlat16_26);
    u_xlat13.x = float(0.0);
    u_xlat13.y = float(0.0);
    u_xlat13.z = float(0.0);
    u_xlat6 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(uint(0u)) ; u_xlatu_loop_1<uint(u_xlati5) ; u_xlatu_loop_1++)
    {
        u_xlatu22 = uint(u_xlatu_loop_1 >> (2u & uint(0x1F)));
        u_xlati30 = int(uint(u_xlatu_loop_1 & 3u));
        u_xlat22 = dot(unity_LightIndices[int(u_xlatu22)], ImmCB_0[u_xlati30]);
        u_xlati22 = int(u_xlat22);
        u_xlat7.xyz = (-vs_TEXCOORD7.xyz) * _AdditionalLightsPosition[u_xlati22].www + _AdditionalLightsPosition[u_xlati22].xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = max(u_xlat30, 6.10351562e-05);
        u_xlat31 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat31) * u_xlat7.xyz;
        u_xlat31 = float(1.0) / float(u_xlat30);
        u_xlat30 = u_xlat30 * _AdditionalLightsAttenuation[u_xlati22].x;
        u_xlat16_26 = (-u_xlat30) * u_xlat30 + 1.0;
        u_xlat16_26 = max(u_xlat16_26, 0.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat31;
        u_xlat16_26 = dot(_AdditionalLightsSpotDir[u_xlati22].xyz, u_xlat7.xyz);
        u_xlat16_26 = u_xlat16_26 * _AdditionalLightsAttenuation[u_xlati22].z + _AdditionalLightsAttenuation[u_xlati22].w;
        u_xlat16_26 = clamp(u_xlat16_26, 0.0, 1.0);
        u_xlat16_26 = u_xlat16_26 * u_xlat16_26;
        u_xlat30 = u_xlat16_26 * u_xlat30;
        u_xlat31 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
        u_xlat31 = u_xlat31 * 0.5 + 0.5;
        u_xlat6 = u_xlat31 * u_xlat30 + u_xlat6;
        u_xlat16_26 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat16_26 = inversesqrt(u_xlat16_26);
        u_xlat7.xyz = u_xlat7.xyz * vec3(u_xlat16_26) + u_xlat3.xyz;
        u_xlat30 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat30 = inversesqrt(u_xlat30);
        u_xlat7.xyz = vec3(u_xlat30) * u_xlat7.xyz;
        u_xlat30 = dot(u_xlat16_2.xyz, u_xlat7.xyz);
        u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
        u_xlat30 = log2(u_xlat30);
        u_xlat30 = u_xlat30 * _SpecularPower;
        u_xlat30 = exp2(u_xlat30);
        u_xlat13.xyz = vec3(u_xlat30) * _AdditionalLightsColor[u_xlati22].xyz + u_xlat13.xyz;
    }
    u_xlat4.w = u_xlat6 * u_xlat1.x + vs_TEXCOORD8;
    u_xlat4.w = clamp(u_xlat4.w, 0.0, 1.0);
    u_xlat3.xyz = vec3(u_xlat27) * _MainLightColor.xyz + u_xlat13.xyz;
    u_xlat3.xyz = clamp(u_xlat3.xyz, 0.0, 1.0);
    u_xlat4.xz = vec2(_MainLightToonX, _AdditionalLightToonX);
    u_xlat16_5.xyz = texture(_ToonTex, u_xlat4.xy, _GlobalMipBias.x).xyz;
    u_xlat16_4.xzw = texture(_ToonTex, u_xlat4.zw, _GlobalMipBias.x).xyz;
    u_xlat5.xyz = (-u_xlat16_4.xzw) + u_xlat16_5.xyz;
    u_xlat4.xyz = u_xlat4.yyy * u_xlat5.xyz + u_xlat16_4.xzw;
    u_xlat5.xy = u_xlat16_2.yy * hlslcc_mtx4x4unity_MatrixV[1].xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[0].xy * u_xlat16_2.xx + u_xlat5.xy;
    u_xlat5.xy = hlslcc_mtx4x4unity_MatrixV[2].xy * u_xlat16_2.zz + u_xlat5.xy;
    u_xlat5.xy = u_xlat5.xy * vec2(0.5, 0.5) + vec2(0.5, 0.5);
    u_xlat16_5.xyz = texture(_SphereTex, u_xlat5.xy, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat3.xyz * vec3(vec3(_SpecularScale, _SpecularScale, _SpecularScale)) + u_xlat16_5.xyz;
    u_xlat1.xyz = u_xlat16_9.xyz * u_xlat3.xyz;
    u_xlat1.xyz = u_xlat16_0.xyz * u_xlat4.xyz + u_xlat1.xyz;
    u_xlat25 = _Luminance + 1.0;
    u_xlat16_0.xyz = vec3(u_xlat25) * u_xlat1.xyz;
    SV_Target0 = u_xlat16_0;
    return;
}

#endif
�
