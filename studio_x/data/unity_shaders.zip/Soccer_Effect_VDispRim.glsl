// Soccer/Effect/VDispRim (Shader path ID 4412837850814892121, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_RimTex_ST;
	UNITY_UNIFORM float                _RimX;
	UNITY_UNIFORM float                _RimAlpha;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_MaskRimTex_ST;
	UNITY_UNIFORM vec4                _VectorDisplacementTex_ST;
	UNITY_UNIFORM float                _VectorDisplacementTex_R;
	UNITY_UNIFORM float                _VectorDisplacementScale;
	UNITY_UNIFORM float                _VDSCover;
	UNITY_UNIFORM float                _VectorDisplacementAdjust;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalTex_ST;
	UNITY_UNIFORM float                _Use_EffectScale;
	UNITY_UNIFORM float                _EffectScale;
	UNITY_UNIFORM float                _Luminance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(3) uniform mediump sampler2D _VectorDisplacementTex;
UNITY_LOCATION(4) uniform mediump sampler2D _NormalTex;
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec3 in_TANGENT0;
in highp vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec2 in_TEXCOORD1;
in highp vec2 in_TEXCOORD2;
in highp vec2 in_TEXCOORD3;
out highp vec4 vs_COLOR0;
out highp vec2 vs_TEXCOORD0;
out highp vec3 vs_TEXCOORD1;
out highp vec3 vs_TEXCOORD2;
highp vec4 vs_TEXCOORD3;
vec3 u_xlat0;
bvec2 u_xlatb0;
vec4 u_xlat1;
vec4 u_xlat2;
bvec2 u_xlatb2;
vec3 u_xlat3;
vec4 u_xlat4;
float u_xlat5;
vec3 u_xlat6;
vec2 u_xlat14;
vec2 u_xlat16;
float u_xlat21;
float u_xlat22;
void main()
{
    u_xlatb0.xy = greaterThanEqual(_VectorDisplacementTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
;
    u_xlat0.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat14.xy = max(abs(_VectorDisplacementTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat14.xy;
    u_xlat14.x = _VectorDisplacementTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat14.x);
    u_xlat2.x = cos(u_xlat14.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat14.xy = in_TEXCOORD1.xy + (-_VectorDisplacementTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat14.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat14.xy, u_xlat3.yz);
    u_xlat0.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlat1.xyz = textureLod(_VectorDisplacementTex, u_xlat0.xy, 0.0).xyz;
    u_xlat0.xyz = textureLod(_NormalTex, u_xlat0.xy, 0.0).xyz;
    u_xlat1.xyz = u_xlat1.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat2.xy = vec2(_EffectScale, _Luminance) + vec2(-1.0, 1.0);
    u_xlat21 = _Use_EffectScale * u_xlat2.x + 1.0;
    u_xlat21 = u_xlat21 * _VectorDisplacementAdjust;
    u_xlat22 = in_COLOR0.x * _VectorDisplacementScale;
    u_xlat21 = u_xlat21 * u_xlat22;
    u_xlat1.xyz = vec3(u_xlat21) * u_xlat1.xyz;
    u_xlat21 = in_COLOR0.w * 2.0 + -1.0;
    u_xlat2.xzw = vec3(u_xlat21) * in_NORMAL0.yzx;
    u_xlat0.xy = vec2(u_xlat21) * u_xlat0.xy;
    u_xlat0.xyz = u_xlat0.xyz + vec3(-0.0, -0.0, -1.0);
    u_xlat0.xyz = vec3(u_xlat22) * u_xlat0.xyz + vec3(0.0, 0.0, 1.0);
    u_xlat3.xyz = u_xlat2.zwx * in_TANGENT0.yzx;
    u_xlat3.xyz = u_xlat2.xzw * in_TANGENT0.zxy + (-u_xlat3.xyz);
    u_xlat3.xyz = u_xlat3.xzy * vec3(vec3(_VDSCover, _VDSCover, _VDSCover));
    u_xlat4.xyz = u_xlat1.yyy * u_xlat3.xzy;
    u_xlat1.xyw = u_xlat1.xxx * in_TANGENT0.xyz + u_xlat4.xyz;
    u_xlat1.xyz = u_xlat1.zzz * u_xlat2.wxz + u_xlat1.xyw;
    u_xlat4.x = in_TANGENT0.y;
    u_xlat4.z = u_xlat2.x;
    u_xlat4.y = u_xlat3.z;
    u_xlat21 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat4.y = sqrt(u_xlat21);
    u_xlat3.z = u_xlat2.z;
    u_xlat2.z = u_xlat3.x;
    u_xlat3.x = in_TANGENT0.z;
    u_xlat21 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat4.z = sqrt(u_xlat21);
    u_xlat2.x = in_TANGENT0.x;
    u_xlat21 = dot(u_xlat2.xzw, u_xlat2.xzw);
    u_xlat3.x = dot(u_xlat0.xyz, u_xlat2.xzw);
    u_xlat4.x = sqrt(u_xlat21);
    u_xlat1.xyz = u_xlat1.xyz / u_xlat4.xyz;
    u_xlat1.xyz = u_xlat1.xyz + in_POSITION0.xyz;
    u_xlat2.xzw = u_xlat1.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat1.xxx + u_xlat2.xzw;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat1.zzz + u_xlat1.xyw;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat4 = u_xlat1.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat4 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat1.xxxx + u_xlat4;
    u_xlat4 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat1.zzzz + u_xlat4;
    u_xlat1.xyz = (-u_xlat1.xyz) + _WorldSpaceCameraPos.xyz;
    gl_Position = u_xlat4 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat4.xy = in_TEXCOORD2.xy;
    u_xlat4.zw = in_TEXCOORD3.xy;
    u_xlat2.xzw = u_xlat4.xyz * _Color.xyz;
    vs_COLOR0.xyz = u_xlat2.yyy * u_xlat2.xzw;
    u_xlat21 = _Transparency * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat21 = (-u_xlat21) + 1.0;
    vs_COLOR0.w = u_xlat4.w * u_xlat21;
    u_xlatb2.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat2.x = u_xlatb2.x ? float(1.0) : 0.0;
    u_xlat2.y = u_xlatb2.y ? float(1.0) : 0.0;
;
    u_xlat2.xy = u_xlat2.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat2.xy = u_xlat2.xy * u_xlat16.xy;
    u_xlat21 = _ColorTex_R * 0.0174532924;
    u_xlat4.x = sin(u_xlat21);
    u_xlat5 = cos(u_xlat21);
    u_xlat6.z = u_xlat4.x;
    u_xlat16.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat6.y = u_xlat5;
    u_xlat6.x = (-u_xlat4.x);
    u_xlat4.y = dot(u_xlat16.xy, u_xlat6.xy);
    u_xlat4.x = dot(u_xlat16.xy, u_xlat6.yz);
    vs_TEXCOORD0.xy = u_xlat4.xy / u_xlat2.xy;
    u_xlat2.xyz = in_NORMAL0.zxy * in_TANGENT0.yzx;
    u_xlat2.xyz = in_NORMAL0.yzx * in_TANGENT0.zxy + (-u_xlat2.xyz);
    u_xlat3.y = dot(u_xlat0.xyz, u_xlat2.xyz);
    u_xlat3.z = dot(u_xlat0.xyz, in_NORMAL0.xyz);
    u_xlat0.x = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(u_xlat3.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat21 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat21 = max(u_xlat21, 1.17549435e-38);
    u_xlat21 = inversesqrt(u_xlat21);
    vs_TEXCOORD1.xyz = vec3(u_xlat21) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    vs_TEXCOORD2.xyz = u_xlat0.xxx * u_xlat1.xyz;
    vs_TEXCOORD3 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_RimTex_ST;
	UNITY_UNIFORM float                _RimX;
	UNITY_UNIFORM float                _RimAlpha;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_MaskRimTex_ST;
	UNITY_UNIFORM vec4                _VectorDisplacementTex_ST;
	UNITY_UNIFORM float                _VectorDisplacementTex_R;
	UNITY_UNIFORM float                _VectorDisplacementScale;
	UNITY_UNIFORM float                _VDSCover;
	UNITY_UNIFORM float                _VectorDisplacementAdjust;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalTex_ST;
	UNITY_UNIFORM float                _Use_EffectScale;
	UNITY_UNIFORM float                _EffectScale;
	UNITY_UNIFORM float                _Luminance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _RimTex;
UNITY_LOCATION(2) uniform mediump sampler2D _MaskRimTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
layout(location = 0) out highp vec4 SV_Target0;
vec3 u_xlat0;
mediump float u_xlat16_0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
float u_xlat9;
void main()
{
    u_xlat0.x = dot(vs_TEXCOORD1.xyz, vs_TEXCOORD1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_TEXCOORD1.xyz;
    u_xlat9 = dot(vs_TEXCOORD2.xyz, vs_TEXCOORD2.xyz);
    u_xlat9 = inversesqrt(u_xlat9);
    u_xlat1.xyz = vec3(u_xlat9) * vs_TEXCOORD2.xyz;
    u_xlat0.y = dot(u_xlat1.xyz, u_xlat0.xyz);
    u_xlat0.x = _RimX;
    u_xlat16_1 = texture(_RimTex, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat16_0 = texture(_MaskRimTex, u_xlat0.xy, _GlobalMipBias.x).w;
    u_xlat3.x = _RimAlpha * (-u_xlat16_1.w) + 1.0;
    u_xlat16_2 = texture(_ColorTex, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat16_2.xyz;
    u_xlat3.xyz = u_xlat16_1.xyz * u_xlat16_1.www + u_xlat3.xyz;
    u_xlat1.x = vs_COLOR0.w;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = u_xlat1.x * u_xlat16_2.w;
    u_xlat0.x = u_xlat16_0 * u_xlat1.x;
    SV_Target0.xyz = u_xlat0.xxx * u_xlat3.xyz;
    SV_Target0.w = u_xlat0.x;
    return;
}

#endif
�

// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex_ST;
	UNITY_UNIFORM float                _ColorTex_R;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_RimTex_ST;
	UNITY_UNIFORM float                _RimX;
	UNITY_UNIFORM float                _RimAlpha;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_MaskRimTex_ST;
	UNITY_UNIFORM vec4                _VectorDisplacementTex_ST;
	UNITY_UNIFORM float                _VectorDisplacementTex_R;
	UNITY_UNIFORM float                _VectorDisplacementScale;
	UNITY_UNIFORM float                _VDSCover;
	UNITY_UNIFORM float                _VectorDisplacementAdjust;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalTex_ST;
	UNITY_UNIFORM float                _Use_EffectScale;
	UNITY_UNIFORM float                _EffectScale;
	UNITY_UNIFORM float                _Luminance;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _RimTex;
UNITY_LOCATION(2) uniform mediump sampler2D _MaskRimTex;
in highp  vec4 vs_COLOR0;
in highp  vec2 vs_TEXCOORD0;
in highp  vec3 vs_TEXCOORD1;
in highp  vec3 vs_TEXCOORD2;
layout(location = 0) out highp vec4 SV_Target0;
vec3 u_xlat0;
mediump float u_xlat16_0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
mediump vec4 u_xlat16_2;
vec3 u_xlat3;
float u_xlat9;
void main()
{
    u_xlat0.x = dot(vs_TEXCOORD1.xyz, vs_TEXCOORD1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_TEXCOORD1.xyz;
    u_xlat9 = dot(vs_TEXCOORD2.xyz, vs_TEXCOORD2.xyz);
    u_xlat9 = inversesqrt(u_xlat9);
    u_xlat1.xyz = vec3(u_xlat9) * vs_TEXCOORD2.xyz;
    u_xlat0.y = dot(u_xlat1.xyz, u_xlat0.xyz);
    u_xlat0.x = _RimX;
    u_xlat16_1 = texture(_RimTex, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat16_0 = texture(_MaskRimTex, u_xlat0.xy, _GlobalMipBias.x).w;
    u_xlat3.x = _RimAlpha * (-u_xlat16_1.w) + 1.0;
    u_xlat16_2 = texture(_ColorTex, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat3.xyz = u_xlat3.xxx * u_xlat16_2.xyz;
    u_xlat3.xyz = u_xlat16_1.xyz * u_xlat16_1.www + u_xlat3.xyz;
    u_xlat1.x = vs_COLOR0.w;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.x = u_xlat1.x * u_xlat16_2.w;
    u_xlat0.x = u_xlat16_0 * u_xlat1.x;
    SV_Target0.xyz = u_xlat0.xxx * u_xlat3.xyz;
    SV_Target0.w = u_xlat0.x;
    return;
}

#endif
�
