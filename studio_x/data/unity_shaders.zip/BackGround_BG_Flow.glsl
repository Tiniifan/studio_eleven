// BackGround/BG_Flow (Shader path ID -3287021646697927538, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _Time;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _MainTex_ST;
	UNITY_UNIFORM vec4                _FlowNormal_ST;
	UNITY_UNIFORM float                _FlowSpeed1;
	UNITY_UNIFORM float                _FlowSpeed2;
	UNITY_UNIFORM float                _WaterSpeed;
	UNITY_UNIFORM float                _FlowPow;
	UNITY_UNIFORM float                _TexDistortion;
	UNITY_UNIFORM mediump vec4                _TexColor;
	UNITY_UNIFORM float                _LuminanceIntensity;
	UNITY_UNIFORM float                _HeightMixPow;
	UNITY_UNIFORM float                _OverallAlpha;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Cutoff;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SrcBlend;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DstBlend;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ZWrite;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec2 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_TEXCOORD0;
out highp vec4 vs_TEXCOORD1;
out highp vec2 vs_TEXCOORD3;
out highp vec4 vs_COLOR0;
vec4 u_xlat0;
vec4 u_xlat1;
vec4 u_xlat2;
vec3 u_xlat3;
void main()
{
    u_xlat0 = in_POSITION0.yyyy * hlslcc_mtx4x4unity_ObjectToWorld[1];
    u_xlat0 = hlslcc_mtx4x4unity_ObjectToWorld[0] * in_POSITION0.xxxx + u_xlat0;
    u_xlat0 = hlslcc_mtx4x4unity_ObjectToWorld[2] * in_POSITION0.zzzz + u_xlat0;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_ObjectToWorld[3];
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = hlslcc_mtx4x4unity_MatrixVP[3] * u_xlat0.wwww + u_xlat1;
    u_xlat0 = _Time.yyyy * vec4(_FlowSpeed2, _FlowSpeed2, _FlowSpeed1, _FlowSpeed1);
    u_xlat0 = u_xlat0 * vec4(vec4(_WaterSpeed, _WaterSpeed, _WaterSpeed, _WaterSpeed));
    u_xlat0 = fract(u_xlat0);
    u_xlat1 = u_xlat0 + vec4(0.5, 0.5, 0.5, 0.5);
    u_xlat1 = fract(u_xlat1);
    u_xlat0.xz = in_TEXCOORD0.xy * _FlowNormal_ST.xy + _FlowNormal_ST.zw;
    u_xlat2 = in_COLOR0.xyxy + vec4(-0.5, -0.5, -0.5, -0.5);
    u_xlat2 = u_xlat2 * vec4(vec4(_FlowPow, _FlowPow, _FlowPow, _FlowPow));
    vs_TEXCOORD0.zw = u_xlat1.zw * u_xlat2.zw + u_xlat0.xz;
    vs_TEXCOORD0.xy = u_xlat0.ww * u_xlat2.zw + u_xlat0.xz;
    u_xlat0.xz = in_TEXCOORD0.xy * _MainTex_ST.xy + _MainTex_ST.zw;
    vs_TEXCOORD1.xy = u_xlat0.yy * u_xlat2.zw + u_xlat0.xz;
    u_xlat3.xz = (-u_xlat0.wy) + vec2(0.5, 0.5);
    u_xlat3.xz = u_xlat3.xz + u_xlat3.xz;
    vs_TEXCOORD3.xy = abs(u_xlat3.xz);
    vs_TEXCOORD1.zw = u_xlat1.xy * u_xlat2.xy + u_xlat0.xz;
    vs_COLOR0 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _MainTex_ST;
	UNITY_UNIFORM vec4                _FlowNormal_ST;
	UNITY_UNIFORM float                _FlowSpeed1;
	UNITY_UNIFORM float                _FlowSpeed2;
	UNITY_UNIFORM float                _WaterSpeed;
	UNITY_UNIFORM float                _FlowPow;
	UNITY_UNIFORM float                _TexDistortion;
	UNITY_UNIFORM mediump vec4                _TexColor;
	UNITY_UNIFORM float                _LuminanceIntensity;
	UNITY_UNIFORM float                _HeightMixPow;
	UNITY_UNIFORM float                _OverallAlpha;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Cutoff;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SrcBlend;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DstBlend;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ZWrite;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _MainTex;
UNITY_LOCATION(1) uniform mediump sampler2D _FlowNormal;
in highp  vec4 vs_TEXCOORD0;
in highp  vec4 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD3;
in highp  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec2 u_xlat16_6;
void main()
{
    u_xlat16_0.xy = texture(_FlowNormal, vs_TEXCOORD0.zw, _GlobalMipBias.x).xy;
    u_xlat16_6.xy = texture(_FlowNormal, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat1 = (-u_xlat16_6.xyxy) + u_xlat16_0.xyxy;
    u_xlat0 = vs_TEXCOORD3.xxxx * u_xlat1 + u_xlat16_6.xyxy;
    u_xlat0 = u_xlat0 + vec4(-0.5, -0.5, -0.5, -0.5);
    u_xlat0 = u_xlat0 * vec4(_TexDistortion) + vs_TEXCOORD1;
    u_xlat16_1 = texture(_MainTex, u_xlat0.zw, _GlobalMipBias.x);
    u_xlat16_0 = texture(_MainTex, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat1 = (-u_xlat16_0) + u_xlat16_1;
    u_xlat0 = vs_TEXCOORD3.yyyy * u_xlat1 + u_xlat16_0;
    u_xlat16_1 = texture(_MainTex, vs_TEXCOORD1.zw, _GlobalMipBias.x);
    u_xlat16_2 = texture(_MainTex, vs_TEXCOORD1.xy, _GlobalMipBias.x);
    u_xlat1 = u_xlat16_1 + (-u_xlat16_2);
    u_xlat1 = vs_TEXCOORD3.yyyy * u_xlat1 + u_xlat16_2;
    u_xlat2 = (-u_xlat0) + u_xlat1;
    u_xlat1.x = (-_HeightMixPow) * 2.0 + 1.0;
    u_xlat1.x = u_xlat1.w * u_xlat1.w + (-u_xlat1.x);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat0 = u_xlat1.xxxx * u_xlat2 + u_xlat0;
    u_xlat1.xyz = u_xlat0.xyz * vec3(_LuminanceIntensity);
    u_xlat1.xyz = u_xlat0.www * u_xlat1.xyz;
    u_xlat1.xyz = u_xlat0.xyz * _TexColor.xyz + u_xlat1.xyz;
    u_xlat0.x = u_xlat0.w * vs_COLOR0.w;
    u_xlat1.w = u_xlat0.x * _OverallAlpha;
    SV_Target0 = u_xlat1;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _MainTex_ST;
	UNITY_UNIFORM vec4                _FlowNormal_ST;
	UNITY_UNIFORM float                _FlowSpeed1;
	UNITY_UNIFORM float                _FlowSpeed2;
	UNITY_UNIFORM float                _WaterSpeed;
	UNITY_UNIFORM float                _FlowPow;
	UNITY_UNIFORM float                _TexDistortion;
	UNITY_UNIFORM mediump vec4                _TexColor;
	UNITY_UNIFORM float                _LuminanceIntensity;
	UNITY_UNIFORM float                _HeightMixPow;
	UNITY_UNIFORM float                _OverallAlpha;
	UNITY_UNIFORM float Xhlslcc_UnusedX_Cutoff;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SrcBlend;
	UNITY_UNIFORM float Xhlslcc_UnusedX_DstBlend;
	UNITY_UNIFORM float Xhlslcc_UnusedX_ZWrite;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _MainTex;
UNITY_LOCATION(1) uniform mediump sampler2D _FlowNormal;
in highp  vec4 vs_TEXCOORD0;
in highp  vec4 vs_TEXCOORD1;
in highp  vec2 vs_TEXCOORD3;
in highp  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec2 u_xlat16_6;
void main()
{
    u_xlat16_0.xy = texture(_FlowNormal, vs_TEXCOORD0.zw, _GlobalMipBias.x).xy;
    u_xlat16_6.xy = texture(_FlowNormal, vs_TEXCOORD0.xy, _GlobalMipBias.x).xy;
    u_xlat1 = (-u_xlat16_6.xyxy) + u_xlat16_0.xyxy;
    u_xlat0 = vs_TEXCOORD3.xxxx * u_xlat1 + u_xlat16_6.xyxy;
    u_xlat0 = u_xlat0 + vec4(-0.5, -0.5, -0.5, -0.5);
    u_xlat0 = u_xlat0 * vec4(_TexDistortion) + vs_TEXCOORD1;
    u_xlat16_1 = texture(_MainTex, u_xlat0.zw, _GlobalMipBias.x);
    u_xlat16_0 = texture(_MainTex, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat1 = (-u_xlat16_0) + u_xlat16_1;
    u_xlat0 = vs_TEXCOORD3.yyyy * u_xlat1 + u_xlat16_0;
    u_xlat16_1 = texture(_MainTex, vs_TEXCOORD1.zw, _GlobalMipBias.x);
    u_xlat16_2 = texture(_MainTex, vs_TEXCOORD1.xy, _GlobalMipBias.x);
    u_xlat1 = u_xlat16_1 + (-u_xlat16_2);
    u_xlat1 = vs_TEXCOORD3.yyyy * u_xlat1 + u_xlat16_2;
    u_xlat2 = (-u_xlat0) + u_xlat1;
    u_xlat1.x = (-_HeightMixPow) * 2.0 + 1.0;
    u_xlat1.x = u_xlat1.w * u_xlat1.w + (-u_xlat1.x);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat0 = u_xlat1.xxxx * u_xlat2 + u_xlat0;
    u_xlat1.xyz = u_xlat0.xyz * vec3(_LuminanceIntensity);
    u_xlat1.xyz = u_xlat0.www * u_xlat1.xyz;
    u_xlat1.xyz = u_xlat0.xyz * _TexColor.xyz + u_xlat1.xyz;
    u_xlat0.x = u_xlat0.w * vs_COLOR0.w;
    u_xlat1.w = u_xlat0.x * _OverallAlpha;
    SV_Target0 = u_xlat1;
    return;
}

#endif

