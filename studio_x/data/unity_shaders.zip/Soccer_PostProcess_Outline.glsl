// Soccer/PostProcess_Outline (Shader path ID -5632466107619642053, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _BlitScaleBias;
uniform 	vec4 _BlitTexture_TexelSize;
out highp vec2 vs_TEXCOORD0;
out highp vec4 vs_TEXCOORD1;
out highp vec4 vs_TEXCOORD2;
vec2 u_xlat0;
uvec3 u_xlatu0;
vec2 u_xlat1;
vec2 u_xlat4;
int int_bitfieldInsert(int base, int insert, int offset, int bits) {
    uint mask = uint(~(int(~0) << uint(bits)) << uint(offset));
    return int((uint(base) & ~mask) | ((uint(insert) << uint(offset)) & mask));
}

void main()
{
    u_xlatu0.x =  uint(int(int_bitfieldInsert(0, gl_VertexID, 1 & int(0x1F), 1)));
    u_xlatu0.z = uint(uint(gl_VertexID) & 2u);
    u_xlat0.xy = vec2(u_xlatu0.xz);
    gl_Position.xy = u_xlat0.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat0.xy = u_xlat0.xy * _BlitScaleBias.xy + _BlitScaleBias.zw;
    gl_Position.zw = vec2(-1.0, 1.0);
    vs_TEXCOORD0.xy = u_xlat0.xy;
    u_xlat4.y = _BlitTexture_TexelSize.x * 0.5;
    u_xlat1.y = (-u_xlat4.y);
    u_xlat1.x = -0.0;
    vs_TEXCOORD1.xy = u_xlat0.xy + u_xlat1.yx;
    vs_TEXCOORD2.xy = u_xlat0.xy + u_xlat1.xy;
    u_xlat4.x = -0.0;
    vs_TEXCOORD1.zw = u_xlat4.yx + u_xlat0.xy;
    vs_TEXCOORD2.zw = u_xlat4.xy + u_xlat0.xy;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _DepthNormalsTex;
in highp  vec2 vs_TEXCOORD0;
in highp  vec4 vs_TEXCOORD1;
in highp  vec4 vs_TEXCOORD2;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
mediump vec2 u_xlat16_0;
vec2 u_xlat1;
mediump vec3 u_xlat16_1;
bvec2 u_xlatb1;
mediump vec2 u_xlat16_2;
float u_xlat3;
mediump vec2 u_xlat16_3;
bool u_xlatb3;
mediump float u_xlat16_4;
float u_xlat5;
mediump vec2 u_xlat16_5;
bool u_xlatb5;
vec3 u_xlat6;
mediump vec2 u_xlat16_6;
bvec3 u_xlatb6;
mediump float u_xlat16_9;
vec2 u_xlat10;
mediump vec2 u_xlat16_10;
bool u_xlatb10;
float u_xlat12;
mediump vec2 u_xlat16_12;
bool u_xlatb12;
float u_xlat13;
float u_xlat15;
bool u_xlatb15;
float u_xlat16;
bool u_xlatb16;
void main()
{
    u_xlat16_0.xy = texture(_BlitTexture, vs_TEXCOORD1.xy, _GlobalMipBias.x).xy;
    u_xlat16_1.xyz = texture(_BlitTexture, vs_TEXCOORD0.xy, _GlobalMipBias.x).xyz;
    u_xlat0.xy = (-u_xlat16_0.xy) + u_xlat16_1.xy;
    u_xlat16_10.xy = texture(_BlitTexture, vs_TEXCOORD1.zw, _GlobalMipBias.x).xy;
    u_xlat10.xy = (-u_xlat16_10.xy) + u_xlat16_1.xy;
    u_xlat0.xy = abs(u_xlat10.xy) + abs(u_xlat0.xy);
    u_xlat16_10.xy = texture(_BlitTexture, vs_TEXCOORD2.xy, _GlobalMipBias.x).xy;
    u_xlat10.xy = (-u_xlat16_10.xy) + u_xlat16_1.xy;
    u_xlat16_2.xy = texture(_BlitTexture, vs_TEXCOORD2.zw, _GlobalMipBias.x).xy;
    u_xlat1.xy = u_xlat16_1.xy + (-u_xlat16_2.xy);
    u_xlat10.xy = abs(u_xlat10.xy) + abs(u_xlat1.xy);
    u_xlat0.xy = u_xlat10.xy + u_xlat0.xy;
    u_xlat0.x = dot(u_xlat0.xy, u_xlat0.xy);
    u_xlat0.x = sqrt(u_xlat0.x);
    u_xlat0.x = u_xlat16_1.z * u_xlat0.x;
    u_xlat16_5.xy = texture(_DepthNormalsTex, vs_TEXCOORD0.xy, _GlobalMipBias.x).yw;
    u_xlat15 = u_xlat16_5.y;
    u_xlat15 = clamp(u_xlat15, 0.0, 1.0);
    u_xlat15 = u_xlat15 * -0.300000012 + 0.5;
    u_xlat15 = log2(u_xlat15);
    u_xlat15 = u_xlat15 * 1.39999998;
    u_xlat15 = exp2(u_xlat15);
    u_xlat1.x = u_xlat15 * 0.0500000007;
    u_xlat15 = u_xlat15 * -0.100000001 + 0.200000003;
    u_xlat16_6.xy = texture(_DepthNormalsTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).yw;
    u_xlat16 = u_xlat16_5.y + (-u_xlat16_6.y);
    u_xlatb16 = u_xlat1.x>=abs(u_xlat16);
    u_xlat16 = u_xlatb16 ? 1.0 : float(0.0);
    u_xlat16_2.xy = texture(_DepthNormalsTex, vs_TEXCOORD1.zw, _GlobalMipBias.x).yw;
    u_xlat12 = u_xlat16_5.y + (-u_xlat16_2.y);
    u_xlatb12 = u_xlat1.x>=abs(u_xlat12);
    u_xlat12 = u_xlatb12 ? 1.0 : float(0.0);
    u_xlat16 = u_xlat16 * u_xlat12;
    u_xlat16_12.xy = texture(_DepthNormalsTex, vs_TEXCOORD2.xy, _GlobalMipBias.x).yw;
    u_xlat3 = u_xlat16_5.y + (-u_xlat16_12.y);
    u_xlatb3 = u_xlat1.x>=abs(u_xlat3);
    u_xlat3 = u_xlatb3 ? 1.0 : float(0.0);
    u_xlat16 = u_xlat16 * u_xlat3;
    u_xlat16_3.xy = texture(_DepthNormalsTex, vs_TEXCOORD2.zw, _GlobalMipBias.x).yw;
    u_xlat13 = u_xlat16_5.y + (-u_xlat16_3.y);
    u_xlatb1.x = u_xlat1.x>=abs(u_xlat13);
    u_xlat1.x = u_xlatb1.x ? 1.0 : float(0.0);
    u_xlat1.x = u_xlat1.x * u_xlat16;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat16_4 = u_xlat16_6.x * 2.0 + -1.0;
    u_xlat16_9 = u_xlat16_5.x * 2.0 + -1.0;
    u_xlat5 = u_xlat16_5.y + 0.00499999989;
    u_xlat10.x = (-u_xlat16_4) + u_xlat16_9;
    u_xlatb10 = u_xlat15>=abs(u_xlat10.x);
    u_xlat10.x = u_xlatb10 ? 1.0 : float(0.0);
    u_xlat16_4 = u_xlat16_2.x * 2.0 + -1.0;
    u_xlatb1.x = u_xlat16_2.y>=u_xlat5;
    u_xlat6.x = (-u_xlat16_4) + u_xlat16_9;
    u_xlatb1.y = u_xlat15>=abs(u_xlat6.x);
    u_xlat1.x = u_xlatb1.x ? float(1.0) : 0.0;
    u_xlat1.y = u_xlatb1.y ? float(1.0) : 0.0;
;
    u_xlat10.x = u_xlat10.x * u_xlat1.y;
    u_xlat16_4 = u_xlat16_12.x * 2.0 + -1.0;
    u_xlatb6.x = u_xlat16_12.y>=u_xlat5;
    u_xlat16 = (-u_xlat16_4) + u_xlat16_9;
    u_xlatb6.z = u_xlat15>=abs(u_xlat16);
    u_xlat6.x = u_xlatb6.x ? float(1.0) : 0.0;
    u_xlat6.z = u_xlatb6.z ? float(1.0) : 0.0;
;
    u_xlat10.x = u_xlat10.x * u_xlat6.z;
    u_xlat16_4 = u_xlat16_3.x * 2.0 + -1.0;
    u_xlatb16 = u_xlat16_3.y>=u_xlat5;
    u_xlatb5 = u_xlat16_6.y>=u_xlat5;
    u_xlat5 = u_xlatb5 ? 1.0 : float(0.0);
    u_xlat5 = u_xlat1.x + u_xlat5;
    u_xlat5 = u_xlat6.x + u_xlat5;
    u_xlat1.x = u_xlatb16 ? 1.0 : float(0.0);
    u_xlat5 = u_xlat5 + u_xlat1.x;
    u_xlat5 = min(u_xlat5, 1.0);
    u_xlat1.x = (-u_xlat16_4) + u_xlat16_9;
    u_xlatb15 = u_xlat15>=abs(u_xlat1.x);
    u_xlat15 = u_xlatb15 ? 1.0 : float(0.0);
    u_xlat10.x = u_xlat15 * u_xlat10.x;
    u_xlat0.x = u_xlat10.x * u_xlat0.x;
    u_xlat0.x = max(u_xlat5, u_xlat0.x);
    u_xlatb5 = u_xlat0.x>=0.25;
    u_xlat5 = u_xlatb5 ? 1.0 : float(0.0);
    u_xlat0.x = u_xlat5 * u_xlat0.x;
    SV_Target0.xyz = u_xlat0.xxx * vec3(0.25, 0.25, 0.25);
    SV_Target0.w = u_xlat0.x;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
UNITY_LOCATION(0) uniform mediump sampler2D _BlitTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _DepthNormalsTex;
in highp  vec2 vs_TEXCOORD0;
in highp  vec4 vs_TEXCOORD1;
in highp  vec4 vs_TEXCOORD2;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
mediump vec2 u_xlat16_0;
vec2 u_xlat1;
mediump vec3 u_xlat16_1;
bvec2 u_xlatb1;
mediump vec2 u_xlat16_2;
float u_xlat3;
mediump vec2 u_xlat16_3;
bool u_xlatb3;
mediump float u_xlat16_4;
float u_xlat5;
mediump vec2 u_xlat16_5;
bool u_xlatb5;
vec3 u_xlat6;
mediump vec2 u_xlat16_6;
bvec3 u_xlatb6;
mediump float u_xlat16_9;
vec2 u_xlat10;
mediump vec2 u_xlat16_10;
bool u_xlatb10;
float u_xlat12;
mediump vec2 u_xlat16_12;
bool u_xlatb12;
float u_xlat13;
float u_xlat15;
bool u_xlatb15;
float u_xlat16;
bool u_xlatb16;
void main()
{
    u_xlat16_0.xy = texture(_BlitTexture, vs_TEXCOORD1.xy, _GlobalMipBias.x).xy;
    u_xlat16_1.xyz = texture(_BlitTexture, vs_TEXCOORD0.xy, _GlobalMipBias.x).xyz;
    u_xlat0.xy = (-u_xlat16_0.xy) + u_xlat16_1.xy;
    u_xlat16_10.xy = texture(_BlitTexture, vs_TEXCOORD1.zw, _GlobalMipBias.x).xy;
    u_xlat10.xy = (-u_xlat16_10.xy) + u_xlat16_1.xy;
    u_xlat0.xy = abs(u_xlat10.xy) + abs(u_xlat0.xy);
    u_xlat16_10.xy = texture(_BlitTexture, vs_TEXCOORD2.xy, _GlobalMipBias.x).xy;
    u_xlat10.xy = (-u_xlat16_10.xy) + u_xlat16_1.xy;
    u_xlat16_2.xy = texture(_BlitTexture, vs_TEXCOORD2.zw, _GlobalMipBias.x).xy;
    u_xlat1.xy = u_xlat16_1.xy + (-u_xlat16_2.xy);
    u_xlat10.xy = abs(u_xlat10.xy) + abs(u_xlat1.xy);
    u_xlat0.xy = u_xlat10.xy + u_xlat0.xy;
    u_xlat0.x = dot(u_xlat0.xy, u_xlat0.xy);
    u_xlat0.x = sqrt(u_xlat0.x);
    u_xlat0.x = u_xlat16_1.z * u_xlat0.x;
    u_xlat16_5.xy = texture(_DepthNormalsTex, vs_TEXCOORD0.xy, _GlobalMipBias.x).yw;
    u_xlat15 = u_xlat16_5.y;
    u_xlat15 = clamp(u_xlat15, 0.0, 1.0);
    u_xlat15 = u_xlat15 * -0.300000012 + 0.5;
    u_xlat15 = log2(u_xlat15);
    u_xlat15 = u_xlat15 * 1.39999998;
    u_xlat15 = exp2(u_xlat15);
    u_xlat1.x = u_xlat15 * 0.0500000007;
    u_xlat15 = u_xlat15 * -0.100000001 + 0.200000003;
    u_xlat16_6.xy = texture(_DepthNormalsTex, vs_TEXCOORD1.xy, _GlobalMipBias.x).yw;
    u_xlat16 = u_xlat16_5.y + (-u_xlat16_6.y);
    u_xlatb16 = u_xlat1.x>=abs(u_xlat16);
    u_xlat16 = u_xlatb16 ? 1.0 : float(0.0);
    u_xlat16_2.xy = texture(_DepthNormalsTex, vs_TEXCOORD1.zw, _GlobalMipBias.x).yw;
    u_xlat12 = u_xlat16_5.y + (-u_xlat16_2.y);
    u_xlatb12 = u_xlat1.x>=abs(u_xlat12);
    u_xlat12 = u_xlatb12 ? 1.0 : float(0.0);
    u_xlat16 = u_xlat16 * u_xlat12;
    u_xlat16_12.xy = texture(_DepthNormalsTex, vs_TEXCOORD2.xy, _GlobalMipBias.x).yw;
    u_xlat3 = u_xlat16_5.y + (-u_xlat16_12.y);
    u_xlatb3 = u_xlat1.x>=abs(u_xlat3);
    u_xlat3 = u_xlatb3 ? 1.0 : float(0.0);
    u_xlat16 = u_xlat16 * u_xlat3;
    u_xlat16_3.xy = texture(_DepthNormalsTex, vs_TEXCOORD2.zw, _GlobalMipBias.x).yw;
    u_xlat13 = u_xlat16_5.y + (-u_xlat16_3.y);
    u_xlatb1.x = u_xlat1.x>=abs(u_xlat13);
    u_xlat1.x = u_xlatb1.x ? 1.0 : float(0.0);
    u_xlat1.x = u_xlat1.x * u_xlat16;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat16_4 = u_xlat16_6.x * 2.0 + -1.0;
    u_xlat16_9 = u_xlat16_5.x * 2.0 + -1.0;
    u_xlat5 = u_xlat16_5.y + 0.00499999989;
    u_xlat10.x = (-u_xlat16_4) + u_xlat16_9;
    u_xlatb10 = u_xlat15>=abs(u_xlat10.x);
    u_xlat10.x = u_xlatb10 ? 1.0 : float(0.0);
    u_xlat16_4 = u_xlat16_2.x * 2.0 + -1.0;
    u_xlatb1.x = u_xlat16_2.y>=u_xlat5;
    u_xlat6.x = (-u_xlat16_4) + u_xlat16_9;
    u_xlatb1.y = u_xlat15>=abs(u_xlat6.x);
    u_xlat1.x = u_xlatb1.x ? float(1.0) : 0.0;
    u_xlat1.y = u_xlatb1.y ? float(1.0) : 0.0;
;
    u_xlat10.x = u_xlat10.x * u_xlat1.y;
    u_xlat16_4 = u_xlat16_12.x * 2.0 + -1.0;
    u_xlatb6.x = u_xlat16_12.y>=u_xlat5;
    u_xlat16 = (-u_xlat16_4) + u_xlat16_9;
    u_xlatb6.z = u_xlat15>=abs(u_xlat16);
    u_xlat6.x = u_xlatb6.x ? float(1.0) : 0.0;
    u_xlat6.z = u_xlatb6.z ? float(1.0) : 0.0;
;
    u_xlat10.x = u_xlat10.x * u_xlat6.z;
    u_xlat16_4 = u_xlat16_3.x * 2.0 + -1.0;
    u_xlatb16 = u_xlat16_3.y>=u_xlat5;
    u_xlatb5 = u_xlat16_6.y>=u_xlat5;
    u_xlat5 = u_xlatb5 ? 1.0 : float(0.0);
    u_xlat5 = u_xlat1.x + u_xlat5;
    u_xlat5 = u_xlat6.x + u_xlat5;
    u_xlat1.x = u_xlatb16 ? 1.0 : float(0.0);
    u_xlat5 = u_xlat5 + u_xlat1.x;
    u_xlat5 = min(u_xlat5, 1.0);
    u_xlat1.x = (-u_xlat16_4) + u_xlat16_9;
    u_xlatb15 = u_xlat15>=abs(u_xlat1.x);
    u_xlat15 = u_xlatb15 ? 1.0 : float(0.0);
    u_xlat10.x = u_xlat15 * u_xlat10.x;
    u_xlat0.x = u_xlat10.x * u_xlat0.x;
    u_xlat0.x = max(u_xlat5, u_xlat0.x);
    u_xlatb5 = u_xlat0.x>=0.25;
    u_xlat5 = u_xlatb5 ? 1.0 : float(0.0);
    u_xlat0.x = u_xlat5 * u_xlat0.x;
    SV_Target0.xyz = u_xlat0.xxx * vec3(0.25, 0.25, 0.25);
    SV_Target0.w = u_xlat0.x;
    return;
}

#endif

