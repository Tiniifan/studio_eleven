struct DMP_OPERATION {
    bool enableClippingPlane;
    vec4 clippingPlane;
    bool enableAlphaTest;
    float alphaRefValue;
    int alphaTestFunc;
    int mode;
    float wScale;
    float penumbraScale;
    float penumbraBias;
};

uniform DMP_OPERATION dmp_FragOperation;

struct DMP_TEXTURE {
    int samplerType;
    bool perspectiveShadow;
    float shadowZScale;
    float shadowZBias;
    int texcoord;
};

uniform DMP_TEXTURE dmp_Texture[4];

struct DMP_COMBINER {
    int combineRgb;
    int combineAlpha;
    ivec3 srcRgb;
    ivec3 srcAlpha;
    ivec3 operandRgb;
    ivec3 operandAlpha;
    int scaleRgb;
    int scaleAlpha;
    vec4 constRgba;
    ivec2 bufferInput;
    vec4 bufferColor;
};

uniform DMP_COMBINER dmp_TexEnv[2];

struct DMP_MATERIAL {
    int samplerRR;
    int samplerRG;
    int samplerRB;
    int samplerD0;
    int samplerD1;
    int samplerSP;
    int samplerFR;
    vec4 ambient;
    vec4 emission;
    vec4 diffuse;
    vec4 specular0;
    vec4 specular1;
};

uniform DMP_MATERIAL dmp_FragmentMaterial;

struct DMP_LIGHT_ENV {
    bool absLutInputD0;
    bool absLutInputD1;
    bool absLutInputRR;
    bool absLutInputRG;
    bool absLutInputRB;
    bool absLutInputSP;
    bool absLutInputFR;
    int lutInputD0;
    int lutInputD1;
    int lutInputRR;
    int lutInputRG;
    int lutInputRB;
    int lutInputSP;
    int lutInputFR;
    float lutScaleD0;
    float lutScaleD1;
    float lutScaleRR;
    float lutScaleRG;
    float lutScaleRB;
    float lutScaleSP;
    float lutScaleFR;
    int shadowSelector;
    int bumpSelector;
    int bumpMode;
    bool bumpRenorm;
    int config;
    bool invertShadow;
    bool shadowPrimary;
    bool shadowSecondary;
    bool shadowAlpha;
    int fresnelSelector;
    bool clampHighlights;
    bool lutEnabledD0;
    bool lutEnabledD1;
    bool lutEnabledRefl;
};

uniform DMP_LIGHT_ENV dmp_LightEnv;

struct DMP_LIGHTING {
    bool enabled;
    vec3 ambient;
};

uniform DMP_LIGHTING dmp_FragmentLighting;

struct DMP_LIGHT_SOURCE {
    bool enabled;
    vec4 ambient;
    vec4 diffuse;
    vec4 specular0;
    vec4 specular1;
    vec4 position;
    bool spotEnabled;
    vec3 spotDirection;
    int samplerSP;
    bool shadowed;
    bool geomFactor0;
    bool geomFactor1;
    bool twoSideDiffuse;
    bool distanceAttenuationEnabled;
    float distanceAttenuationBias;
    float distanceAttenuationScale;
    int samplerDA;
};

uniform DMP_LIGHT_SOURCE dmp_FragmentLightSource[8];
uniform sampler2D unf_frg_txt_2d_0;
uniform sampler2D unf_frg_txt_2d_1;
uniform sampler2D unf_frg_txt_2d_2;
uniform samplerCube unf_frg_txt_cube;
uniform sampler2D unf_frg_txt_lut;
varying vec4 var_clr;
varying vec4 var_nrm;
varying vec4 var_tng;
varying vec4 var_tx0;
varying vec4 var_tx1;
varying vec4 var_tx2;
varying vec4 var_prm;

float getLut(int _tbl, float _smp_in, bool _abs, float _scale) {
    float smp_out = 1.000000;
    if (_abs) {
        _smp_in = abs(_smp_in);
        float index = min(floor(_smp_in * 256.000000), 255.000000);
        float x = index / 512.000000;
        float dx = (index + 256.000000) / 512.000000;
        float y = float(_tbl) / float(32);
        smp_out = texture2D(unf_frg_txt_lut, vec2(x, y)).r + texture2D(unf_frg_txt_lut, vec2(dx,
                y)).r * (_smp_in * 256.000000 - index);
    } else {
        if (_smp_in < 0.000000) {
            float flooredInput = floor(_smp_in * 127.000000);
            float index = 255.000000 + flooredInput;
            float x = index / 512.000000;
            float dx = (index + 256.000000) / 512.000000;
            float y = float(_tbl) / float(32);
            smp_out = texture2D(unf_frg_txt_lut, vec2(x, y)).r + texture2D(unf_frg_txt_lut, vec2(dx,
                    y)).r * (_smp_in * 128.000000 - flooredInput);
        } else {
            float index = min(floor(_smp_in * 128.000000), 127.000000);
            float x = index / 512.000000;
            float dx = (index + 256.000000) / 512.000000;
            float y = float(_tbl) / float(32);
            smp_out = texture2D(unf_frg_txt_lut, vec2(x, y)).r + texture2D(unf_frg_txt_lut, vec2(dx,
                    y)).r * (_smp_in * 128.000000 - index);
        }
    }
    smp_out = _scale * smp_out;
    return smp_out;
}

float getLutInSelect(int _tbl, int _inp_id, bool _abs, float _scale, float _NH, float _VH, float _NV,

        float _LN, float _SP, float _CP) {
    float smp_in = (0 == _inp_id) ? _NH : (1 == _inp_id) ? _VH : (2 == _inp_id) ? _NV : (3 == _inp_id)
            ? _LN : (4 == _inp_id) ? _SP : (5 == _inp_id) ? _CP : 0.000000;
    return getLut(_tbl, smp_in, _abs, _scale);
}

out vec4 outFragColor;

void main() {
    vec4 clr_1st = vec4(1.000000, 1.000000, 1.000000, 1.000000);
    vec4 clr_2nd = vec4(0.000000, 0.000000, 0.000000, 1.000000);
    if (dmp_FragmentLighting.enabled) {
        vec3 N = normalize(var_nrm.xyz);
        vec3 V = -normalize(var_prm.xyz);
        float NV = dot(N, V);
        vec3 pri_light_clr = vec3(0.000000, 0.000000, 0.000000);
        vec3 sec_light_clr = vec3(0.000000, 0.000000, 0.000000);
        float fresnel = 0.000000;
        for (int c = 0; c < 8; c++) {
            if (dmp_FragmentLightSource[c].enabled) {
                vec3 L = vec3(0.000000, 0.000000, 0.000000);
                if (dmp_FragmentLightSource[c].position.w == 0.000000) L = normalize(dmp_FragmentLightSource[c].position.xyz);
                else L = normalize(dmp_FragmentLightSource[c].position.xyz - var_prm.xyz);
                vec3 H = normalize(V + L);
                float NH = dot(N, H);
                float VH = dot(V, H);
                float LN = dot(L, N);
                float SP = dot(-L, normalize(dmp_FragmentLightSource[c].spotDirection));
                float da = 1.000000;
                if (dmp_FragmentLightSource[c].distanceAttenuationEnabled && 7 != dmp_LightEnv.config) {
                    float smp_in = dmp_FragmentLightSource[c].distanceAttenuationScale * distance(dmp_FragmentLightSource[c].position.xyz,
                            var_prm.xyz) + dmp_FragmentLightSource[c].distanceAttenuationBias;
                    da = getLut(dmp_FragmentLightSource[c].samplerDA, max(min(smp_in, 1.000000),
                            0.000000), true, 1.000000);
                }
                float rr = 1.000000;
                float rg = 1.000000;
                float rb = 1.000000;
                float d0 = 1.000000;
                float d1 = 1.000000;
                float sp = 1.000000;
                float fr = getLutInSelect(2, dmp_LightEnv.lutInputFR, dmp_LightEnv.absLutInputFR,
                        dmp_LightEnv.lutScaleFR, NH, VH, NV, LN, SP, 0.000000);
                if (dmp_LightEnv.lutEnabledRefl) {
                    rr = getLutInSelect(5, dmp_LightEnv.lutInputRR, dmp_LightEnv.absLutInputRR,
                            dmp_LightEnv.lutScaleRR, NH, VH, NV, LN, SP, 0.000000);
                    rg = getLutInSelect(4, dmp_LightEnv.lutInputRG, dmp_LightEnv.absLutInputRG,
                            dmp_LightEnv.lutScaleRG, NH, VH, NV, LN, SP, 0.000000);
                    rb = getLutInSelect(3, dmp_LightEnv.lutInputRB, dmp_LightEnv.absLutInputRB,
                            dmp_LightEnv.lutScaleRB, NH, VH, NV, LN, SP, 0.000000);
                }
                if (dmp_LightEnv.lutEnabledD0) {
                    d0 = getLutInSelect(0, dmp_LightEnv.lutInputD0, dmp_LightEnv.absLutInputD0,
                            dmp_LightEnv.lutScaleD0, NH, VH, NV, LN, SP, 0.000000);
                }
                if (dmp_LightEnv.lutEnabledD1) {
                    d1 = getLutInSelect(1, dmp_LightEnv.lutInputD1, dmp_LightEnv.absLutInputD1,
                            dmp_LightEnv.lutScaleD1, NH, VH, NV, LN, SP, 0.000000);
                }
                if (dmp_FragmentLightSource[c].spotEnabled) {
                    sp = getLutInSelect(dmp_FragmentLightSource[c].samplerSP, dmp_LightEnv.lutInputSP,
                            dmp_LightEnv.absLutInputSP, dmp_LightEnv.lutScaleSP, NH, VH, NV, LN,
                            SP, 0.000000);
                }
                if (0 == dmp_LightEnv.config) {
                    rr = rr;
                    rg = rr;
                    rb = rr;
                    d0 = d0;
                    d1 = 1.000000;
                    fr = 1.000000;
                    sp = sp;
                } else if (1 == dmp_LightEnv.config) {
                    rr = rr;
                    rg = rr;
                    rb = rr;
                    d0 = 1.000000;
                    d1 = 1.000000;
                    fr = fr;
                    sp = sp;
                } else if (2 == dmp_LightEnv.config) {
                    rr = rr;
                    rg = rr;
                    rb = rr;
                    d0 = d0;
                    d1 = d1;
                    fr = 1.000000;
                    sp = 1.000000;
                } else if (3 == dmp_LightEnv.config) {
                    rr = 1.000000;
                    rg = 1.000000;
                    rb = 1.000000;
                    d0 = d0;
                    d1 = d1;
                    fr = fr;
                    sp = 1.000000;
                } else if (4 == dmp_LightEnv.config) {
                    rr = rr;
                    rg = rg;
                    rb = rb;
                    d0 = d0;
                    d1 = d1;
                    fr = 1.000000;
                    sp = sp;
                } else if (5 == dmp_LightEnv.config) {
                    rr = rr;
                    rg = rg;
                    rb = rb;
                    d0 = d0;
                    d1 = 1.000000;
                    fr = fr;
                    sp = sp;
                } else if (6 == dmp_LightEnv.config) {
                    rr = rr;
                    rg = rr;
                    rb = rr;
                    d0 = d0;
                    d1 = d1;
                    fr = fr;
                    sp = sp;
                } else if (7 == dmp_LightEnv.config) {
                    rr = rr;
                    rg = rg;
                    rb = rb;
                    d0 = d0;
                    d1 = d1;
                    fr = fr;
                    sp = sp;
                }
                if (!dmp_LightEnv.lutEnabledRefl) {
                    rr = dmp_FragmentMaterial.specular1.x;
                    rg = dmp_FragmentMaterial.specular1.y;
                    rb = dmp_FragmentMaterial.specular1.z;
                }
                vec3 diffuse = dmp_FragmentMaterial.diffuse.xyz * dmp_FragmentLightSource[c].diffuse.xyz;
                float dpLN = dmp_FragmentLightSource[c].twoSideDiffuse ? abs(LN) : max(0.000000,
                        LN);
                float shadow = (dmp_LightEnv.shadowPrimary && dmp_FragmentLightSource[c].shadowed)
                        ? 0.000000 : 1.000000;
                shadow = dmp_LightEnv.invertShadow ? 1.000000 - shadow : shadow;
                vec3 ambient = dmp_FragmentMaterial.ambient.xyz * dmp_FragmentLightSource[c].ambient.xyz;
                pri_light_clr = da * sp * (diffuse * dpLN * shadow + ambient) + pri_light_clr;
                vec3 spc0 = dmp_FragmentLightSource[c].specular0.xyz * dmp_FragmentMaterial.specular0.xyz
                        * d0;
                vec3 spc1;
                spc1.x = dmp_FragmentLightSource[c].specular1.x * rr * d1;
                spc1.y = dmp_FragmentLightSource[c].specular1.y * rg * d1;
                spc1.z = dmp_FragmentLightSource[c].specular1.z * rb * d1;
                float fi = 1.000000;
                if (dmp_LightEnv.clampHighlights) {
                    if (LN < 0.000000) {
                        fi = 0.000000;
                    }
                }
                sec_light_clr = fi * da * sp * (spc0 + spc1) + sec_light_clr;
                fresnel = fr;
            }
        }
        clr_1st.xyz = dmp_FragmentMaterial.emission.xyz + (dmp_FragmentLighting.ambient.xyz * dmp_FragmentMaterial.ambient.xyz)
                + pri_light_clr;
        clr_2nd.xyz = sec_light_clr;
        clr_1st.w = (dmp_LightEnv.fresnelSelector == 1 || dmp_LightEnv.fresnelSelector == 3) ? fresnel
                : 1.000000;
        clr_2nd.w = (dmp_LightEnv.fresnelSelector == 2 || dmp_LightEnv.fresnelSelector == 3) ? fresnel
                : 1.000000;
        clr_1st = min(vec4(1.000000, 1.000000, 1.000000, 1.000000), clr_1st);
        clr_2nd = min(vec4(1.000000, 1.000000, 1.000000, 1.000000), clr_2nd);
    }
    vec4 tex_clr[4];
    tex_clr[0] = (dmp_Texture[0].samplerType == 0) ? vec4(1.000000, 1.000000, 1.000000, 1.000000)
            : (dmp_Texture[0].samplerType == 3553) ? texture2D(unf_frg_txt_2d_0, var_tx0.xy) : (dmp_Texture[0].samplerType == 34067)
            ? textureCube(unf_frg_txt_cube, var_tx0.xyz) : (dmp_Texture[0].samplerType == 28160)
            ? texture2DProj(unf_frg_txt_2d_0, var_tx0.xyz) : (dmp_Texture[0].samplerType == 28161)
            ? texture2D(unf_frg_txt_2d_0, var_tx0.xy) : (dmp_Texture[0].samplerType == 28162)
            ? textureCube(unf_frg_txt_cube, var_tx0.xyz) : vec4(0.000000, 0.000000, 0.000000,
            0.000000);
    tex_clr[1] = (dmp_Texture[1].samplerType == 0) ? vec4(1.000000, 1.000000, 1.000000, 1.000000)
            : (dmp_Texture[1].samplerType == 3553) ? texture2D(unf_frg_txt_2d_1, var_tx1.xy) : vec4(0.000000,
            0.000000, 0.000000, 0.000000);
    tex_clr[2] = (dmp_Texture[2].samplerType == 0) ? vec4(1.000000, 1.000000, 1.000000, 1.000000)
            : (dmp_Texture[2].samplerType == 3553) ? texture2D(unf_frg_txt_2d_2, var_tx2.xy) : vec4(0.000000,
            0.000000, 0.000000, 0.000000);
    vec4 clr_prv = vec4(0.000000, 0.000000, 0.000000, 0.000000);
    vec4 buf_prv = dmp_TexEnv[0].bufferColor;
    for (int c = 0; c < 2; c++) {
        vec4 clr_arg[3];
        {
            for (int a = 0; a < 3; a++) {
                int src_rgb = dmp_TexEnv[c].srcRgb[a];
                int src_alp = dmp_TexEnv[c].srcAlpha[a];
                vec4 arg_rgb, arg_alp;
                arg_rgb = (src_rgb == 15) ? clr_prv : (src_rgb == 14) ? dmp_TexEnv[c].constRgba
                        : (src_rgb == 0) ? var_clr : (src_rgb == 3) ? tex_clr[0] : (src_rgb == 4)
                        ? tex_clr[1] : (src_rgb == 5) ? tex_clr[2] : (src_rgb == 1) ? clr_1st
                        : (src_rgb == 2) ? clr_2nd : (src_rgb == 13) ? buf_prv : vec4(0.000000,
                        0.000000, 0.000000, 0.000000);
                if (src_rgb != src_alp) {
                    arg_alp = (src_alp == 15) ? clr_prv : (src_alp == 14) ? dmp_TexEnv[c].constRgba
                            : (src_alp == 0) ? var_clr : (src_alp == 3) ? tex_clr[0] : (src_alp == 4)
                            ? tex_clr[1] : (src_alp == 5) ? tex_clr[2] : (src_alp == 1) ? clr_1st
                            : (src_alp == 2) ? clr_2nd : (src_alp == 13) ? buf_prv : vec4(0.000000,
                            0.000000, 0.000000, 0.000000);
                } else {
                    arg_alp = arg_rgb;
                }
                int opr_rgb = dmp_TexEnv[c].operandRgb[a];
                int opr_alp = dmp_TexEnv[c].operandAlpha[a];
                clr_arg[a].xyz = (opr_rgb == 0) ? arg_rgb.xyz : (opr_rgb == 1) ? 1.000000 - arg_rgb.xyz
                        : (opr_rgb == 2) ? vec3(arg_rgb.w, arg_rgb.w, arg_rgb.w) : (opr_rgb == 3)
                        ? 1.000000 - vec3(arg_rgb.w, arg_rgb.w, arg_rgb.w) : (opr_rgb == 4) ? vec3(arg_rgb.x,
                        arg_rgb.x, arg_rgb.x) : (opr_rgb == 5) ? 1.000000 - vec3(arg_rgb.x, arg_rgb.x,
                        arg_rgb.x) : (opr_rgb == 8) ? vec3(arg_rgb.y, arg_rgb.y, arg_rgb.y) : (opr_rgb == 9)
                        ? 1.000000 - vec3(arg_rgb.y, arg_rgb.y, arg_rgb.y) : (opr_rgb == 12) ? vec3(arg_rgb.z,
                        arg_rgb.z, arg_rgb.z) : (opr_rgb == 13) ? 1.000000 - vec3(arg_rgb.z, arg_rgb.z,
                        arg_rgb.z) : vec3(0.000000, 0.000000, 0.000000);
                clr_arg[a].w = (opr_alp == 0) ? arg_alp.w : (opr_alp == 1) ? 1.000000 - arg_alp.w
                        : (opr_alp == 2) ? arg_alp.x : (opr_alp == 3) ? 1.000000 - arg_alp.x : (opr_alp == 4)
                        ? arg_alp.y : (opr_alp == 5) ? 1.000000 - arg_alp.y : (opr_alp == 6) ? arg_alp.z
                        : (opr_alp == 7) ? 1.000000 - arg_alp.z : 0.000000;
            }
            if (0 < c && c < 2 - 1) {
                buf_prv.xyz = (dmp_TexEnv[c].bufferInput.x == 1) ? clr_prv.xyz : (dmp_TexEnv[c].bufferInput.x == 0)
                        ? buf_prv.xyz : vec3(1.000000, 1.000000, 1.000000);
                {
                    buf_prv.w = (dmp_TexEnv[c].bufferInput.y == 1) ? clr_prv.w : (dmp_TexEnv[c].bufferInput.y == 0)
                            ? buf_prv.w : 1.000000;
                }
            }
        }
        {
            int cmb_rgb = dmp_TexEnv[c].combineRgb;
            int cmb_alp = dmp_TexEnv[c].combineAlpha;
            clr_prv.xyz = (cmb_rgb == 0) ? clr_arg[0].xyz : (cmb_rgb == 1) ? clr_arg[0].xyz * clr_arg[1].xyz
                    : (cmb_rgb == 2) ? clr_arg[0].xyz + clr_arg[1].xyz : (cmb_rgb == 5) ? clr_arg[0].xyz
                    - clr_arg[1].xyz : (cmb_rgb == 3) ? clr_arg[0].xyz + clr_arg[1].xyz - 0.500000
                    : (cmb_rgb == 6) ? vec3(4.000000 * dot(clr_arg[0].xyz - 0.500000, clr_arg[1].xyz
                    - 0.500000)) : (cmb_rgb == 7) ? vec3(4.000000 * dot(clr_arg[0].xyz - 0.500000,
                    clr_arg[1].xyz - 0.500000)) : (cmb_rgb == 4) ? (clr_arg[0].xyz - clr_arg[1].xyz)
                    * clr_arg[2].xyz + clr_arg[1].xyz : (cmb_rgb == 9) ? clamp(clr_arg[0].xyz
                    + clr_arg[1].xyz, 0.000000, 1.000000) * clr_arg[2].xyz : (cmb_rgb == 8) ? (clr_arg[0].xyz
                    * clr_arg[1].xyz) + clr_arg[2].xyz : vec3(0.000000, 0.000000, 0.000000);
            clr_prv.xyz *= (dmp_TexEnv[c].scaleRgb == 0) ? 1.000000 : (dmp_TexEnv[c].scaleRgb == 1)
                    ? 2.000000 : (dmp_TexEnv[c].scaleRgb == 2) ? 4.000000 : 1.000000;
            clr_prv.w = clr_arg[0].w = (cmb_alp == 0) ? clr_arg[0].w : (cmb_alp == 1) ? clr_arg[0].w
                    * clr_arg[1].w : (cmb_alp == 2) ? clr_arg[0].w + clr_arg[1].w : (cmb_alp == 5)
                    ? clr_arg[0].w - clr_arg[1].w : (cmb_alp == 3) ? clr_arg[0].w + clr_arg[1].w
                    - 0.500000 : (cmb_alp == 7) ? 4.000000 * dot(clr_arg[0].xyz - 0.500000, clr_arg[1].xyz
                    - 0.500000) : (cmb_alp == 4) ? (clr_arg[0].w - clr_arg[1].w) * clr_arg[2].w
                    + clr_arg[1].w : (cmb_alp == 9) ? clamp(clr_arg[0].w + clr_arg[1].w, 0.000000,
                    1.000000) * clr_arg[2].w : (cmb_alp == 8) ? (clr_arg[0].w * clr_arg[1].w)
                    + clr_arg[2].w : 0.000000;
            clr_prv.w *= (dmp_TexEnv[c].scaleAlpha == 0) ? 1.000000 : (dmp_TexEnv[c].scaleAlpha == 1)
                    ? 2.000000 : (dmp_TexEnv[c].scaleAlpha == 2) ? 4.000000 : 1.000000;
            clr_prv = min(max(clr_prv, vec4(0.000000, 0.000000, 0.000000, 0.000000)), vec4(1.000000,
                    1.000000, 1.000000, 1.000000));
        }
    }
    if (true == dmp_FragOperation.enableAlphaTest) {
        bool pass = (dmp_FragOperation.alphaTestFunc == 519) ? true : (dmp_FragOperation.alphaTestFunc == 512)
                ? false : (dmp_FragOperation.alphaTestFunc == 518) ? (dmp_FragOperation.alphaRefValue <= clr_prv.a)
                : (dmp_FragOperation.alphaTestFunc == 516) ? (dmp_FragOperation.alphaRefValue < clr_prv.a)
                : (dmp_FragOperation.alphaTestFunc == 513) ? (dmp_FragOperation.alphaRefValue > clr_prv.a)
                : (dmp_FragOperation.alphaTestFunc == 515) ? (dmp_FragOperation.alphaRefValue >= clr_prv.a)
                : (dmp_FragOperation.alphaTestFunc == 514) ? (dmp_FragOperation.alphaRefValue == clr_prv.a)
                : (dmp_FragOperation.alphaTestFunc == 517) ? (dmp_FragOperation.alphaRefValue != clr_prv.a)
                : false;
        if (false == pass) {
            discard;
        }
    }
    outFragColor = clr_prv;
}
