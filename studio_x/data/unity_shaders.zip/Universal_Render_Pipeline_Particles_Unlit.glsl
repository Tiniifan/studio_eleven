// Universal Render Pipeline/Particles/Unlit (Shader path ID 8918850207803687531, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in mediump vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec3 in_NORMAL0;
out highp vec2 vs_TEXCOORD0;
out mediump vec4 vs_COLOR0;
highp vec4 vs_TEXCOORD1;
mediump vec3 vs_TEXCOORD2;
mediump vec3 vs_TEXCOORD3;
mediump vec3 vs_TEXCOORD8;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
bool u_xlatb6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_TEXCOORD0.xy = in_TEXCOORD0.xy;
    vs_COLOR0 = in_COLOR0;
    vs_TEXCOORD1.xyz = u_xlat0.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD1.w = 0.0;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    u_xlat1.xyz = vec3(u_xlat6) * u_xlat1.xyz;
    vs_TEXCOORD2.xyz = u_xlat1.xyz;
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = inversesqrt(u_xlat6);
    u_xlat0.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    u_xlatb6 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD3.x = (u_xlatb6) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD3.y = (u_xlatb6) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD3.z = (u_xlatb6) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8.xyz = vec3(0.0, 0.0, 0.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CameraFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	UNITY_UNIFORM mediump vec4                _BaseColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_BaseColorAddSubDiff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Cutoff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionBlend;
	UNITY_UNIFORM mediump float                _Surface;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
in highp  vec2 vs_TEXCOORD0;
in mediump  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
bool u_xlatb1;
void main()
{
    u_xlat16_0 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_0 = u_xlat16_0 * _BaseColor;
    u_xlat16_0 = u_xlat16_0 * vs_COLOR0;
    u_xlatb1 = _Surface==1.0;
    SV_Target0.w = (u_xlatb1) ? u_xlat16_0.w : 1.0;
    SV_Target0.xyz = u_xlat16_0.xyz;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CameraFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	UNITY_UNIFORM mediump vec4                _BaseColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_BaseColorAddSubDiff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Cutoff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionBlend;
	UNITY_UNIFORM mediump float                _Surface;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
in highp  vec2 vs_TEXCOORD0;
in mediump  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
bool u_xlatb1;
void main()
{
    u_xlat16_0 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_0 = u_xlat16_0 * _BaseColor;
    u_xlat16_0 = u_xlat16_0 * vs_COLOR0;
    u_xlatb1 = _Surface==1.0;
    SV_Target0.w = (u_xlatb1) ? u_xlat16_0.w : 1.0;
    SV_Target0.xyz = u_xlat16_0.xyz;
    return;
}

#endif


// ===== program 2: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in mediump vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec3 in_NORMAL0;
out highp vec2 vs_TEXCOORD0;
out mediump vec4 vs_COLOR0;
highp vec4 vs_TEXCOORD1;
mediump vec3 vs_TEXCOORD2;
mediump vec3 vs_TEXCOORD3;
mediump vec3 vs_TEXCOORD8;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
bool u_xlatb6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_TEXCOORD0.xy = in_TEXCOORD0.xy;
    vs_COLOR0 = in_COLOR0;
    vs_TEXCOORD1.xyz = u_xlat0.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD1.w = 0.0;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    u_xlat1.xyz = vec3(u_xlat6) * u_xlat1.xyz;
    vs_TEXCOORD2.xyz = u_xlat1.xyz;
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = inversesqrt(u_xlat6);
    u_xlat0.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    u_xlatb6 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD3.x = (u_xlatb6) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD3.y = (u_xlatb6) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD3.z = (u_xlatb6) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8.xyz = vec3(0.0, 0.0, 0.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CameraFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	UNITY_UNIFORM mediump vec4                _BaseColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	UNITY_UNIFORM mediump vec4                _BaseColorAddSubDiff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Cutoff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionBlend;
	UNITY_UNIFORM mediump float                _Surface;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
in highp  vec2 vs_TEXCOORD0;
in mediump  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
mediump vec3 u_xlat16_1;
mediump vec3 u_xlat16_2;
bool u_xlatb3;
mediump float u_xlat16_13;
void main()
{
    u_xlat16_0 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_0 = u_xlat16_0 * _BaseColor;
    u_xlat16_1.xyz = vs_COLOR0.xyz * _BaseColorAddSubDiff.xxx + u_xlat16_0.xyz;
    u_xlat16_13 = u_xlat16_0.w * vs_COLOR0.w;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + abs(u_xlat16_1.xyz);
    SV_Target0.xyz = _BaseColorAddSubDiff.yyy * u_xlat16_2.xyz + u_xlat16_1.xyz;
    u_xlatb3 = _Surface==1.0;
    SV_Target0.w = (u_xlatb3) ? u_xlat16_13 : 1.0;
    return;
}

#endif


// ===== program 3: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CameraFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	UNITY_UNIFORM mediump vec4                _BaseColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	UNITY_UNIFORM mediump vec4                _BaseColorAddSubDiff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Cutoff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionBlend;
	UNITY_UNIFORM mediump float                _Surface;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
in highp  vec2 vs_TEXCOORD0;
in mediump  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
mediump vec3 u_xlat16_1;
mediump vec3 u_xlat16_2;
bool u_xlatb3;
mediump float u_xlat16_13;
void main()
{
    u_xlat16_0 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_0 = u_xlat16_0 * _BaseColor;
    u_xlat16_1.xyz = vs_COLOR0.xyz * _BaseColorAddSubDiff.xxx + u_xlat16_0.xyz;
    u_xlat16_13 = u_xlat16_0.w * vs_COLOR0.w;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + abs(u_xlat16_1.xyz);
    SV_Target0.xyz = _BaseColorAddSubDiff.yyy * u_xlat16_2.xyz + u_xlat16_1.xyz;
    u_xlatb3 = _Surface==1.0;
    SV_Target0.w = (u_xlatb3) ? u_xlat16_13 : 1.0;
    return;
}

#endif


// ===== program 4: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	int unity_BaseInstanceID;
uniform 	vec4 unity_ParticleUVShiftData;
uniform 	mediump float unity_ParticleUseMeshColors;
 struct unity_ParticleInstanceData_type {
	uint[14] value;
};

layout(std430, binding = 0) readonly buffer unity_ParticleInstanceData {
	unity_ParticleInstanceData_type unity_ParticleInstanceData_buf[];
};
in highp vec4 in_POSITION0;
in mediump vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec3 in_NORMAL0;
layout(location = 0) out highp vec2 vs_TEXCOORD0;
layout(location = 1) out mediump vec4 vs_COLOR0;
layout(location = 2) out highp vec4 vs_TEXCOORD1;
layout(location = 3) out mediump vec3 vs_TEXCOORD2;
layout(location = 4) out mediump vec3 vs_TEXCOORD3;
layout(location = 5) out mediump vec3 vs_TEXCOORD8;
layout(location = 6) flat out highp uint vs_SV_InstanceID0;
vec4 u_xlat0;
uint u_xlatu0;
vec2 u_xlat1;
mediump vec4 u_xlat16_1;
int u_xlati1;
uvec3 u_xlatu1;
vec4 u_xlat2;
vec4 u_xlat3;
vec4 u_xlat4;
vec4 u_xlat5;
vec3 u_xlat6;
vec4 u_xlat7;
float u_xlat8;
vec3 u_xlat9;
bool u_xlatb16;
float u_xlat24;
bool u_xlatb24;
uint uint_bitfieldExtract(uint value, int offset, int bits) { return (value >> uint(offset)) & uint(~(int(~0) << uint(bits))); }

void main()
{
    u_xlat0.xyz = in_POSITION0.xyz;
    u_xlat0.w = 1.0;
    u_xlati1 = gl_InstanceID + unity_BaseInstanceID;
    u_xlat2 = vec4(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 3]));
    u_xlat3.w = u_xlat2.y;
    u_xlat9.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 2]));
    u_xlat3.y = u_xlat9.y;
    u_xlat4.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 0]));
    u_xlat3.z = u_xlat4.x;
    u_xlat5.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 1]));
    u_xlat1.x = uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(52 >> 2) + 0]);
    u_xlat1.x = floor(u_xlat1.x);
    u_xlat3.x = u_xlat5.z;
    u_xlat6.y = dot(u_xlat3, u_xlat0);
    u_xlat7 = u_xlat6.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat4.w = u_xlat2.x;
    u_xlat5.z = u_xlat4.y;
    u_xlat4.x = u_xlat5.y;
    u_xlat4.y = u_xlat9.x;
    u_xlat5.y = u_xlat9.z;
    u_xlat6.x = dot(u_xlat4, u_xlat0);
    u_xlat7 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat6.xxxx + u_xlat7;
    u_xlat5.w = u_xlat2.z;
    u_xlat6.z = dot(u_xlat5, u_xlat0);
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat6.zzzz + u_xlat7;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat0.x = u_xlat1.x / unity_ParticleUVShiftData.y;
    u_xlat0.x = floor(u_xlat0.x);
    u_xlat8 = (-u_xlat0.x) * unity_ParticleUVShiftData.y + u_xlat1.x;
    u_xlat8 = floor(u_xlat8);
    u_xlat1.x = u_xlat8 * unity_ParticleUVShiftData.z;
    u_xlat8 = (-unity_ParticleUVShiftData.w) + 1.0;
    u_xlat1.y = (-u_xlat0.x) * unity_ParticleUVShiftData.w + u_xlat8;
    u_xlat0.xy = in_TEXCOORD0.xy * unity_ParticleUVShiftData.zw + u_xlat1.xy;
    u_xlatb16 = unity_ParticleUVShiftData.x!=0.0;
    vs_TEXCOORD0.xy = (bool(u_xlatb16)) ? u_xlat0.xy : in_TEXCOORD0.xy;
    u_xlatu0 = uint(floatBitsToUint(u_xlat2.w)) & 255u;
    u_xlat0.x = float(u_xlatu0);
    u_xlatu1.xy = uvec2(uint_bitfieldExtract(uint(floatBitsToUint(u_xlat2.w)), int(8) & int(0x1F), int(8) & int(0x1F)), uint_bitfieldExtract(uint(floatBitsToUint(u_xlat2.w)), int(16) & int(0x1F), int(8) & int(0x1F)));
    u_xlatu1.z = uint(floatBitsToUint(u_xlat2.w)) >> (24u & uint(0x1F));
    u_xlat0.yzw = vec3(u_xlatu1.xyz);
    u_xlat0 = u_xlat0 * vec4(0.00392156886, 0.00392156886, 0.00392156886, 0.00392156886);
    u_xlat16_1 = in_COLOR0 + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat16_1 = vec4(unity_ParticleUseMeshColors) * u_xlat16_1 + vec4(1.0, 1.0, 1.0, 1.0);
    vs_COLOR0 = u_xlat0 * u_xlat16_1;
    vs_TEXCOORD1.w = 0.0;
    vs_TEXCOORD1.xyz = u_xlat6.xyz;
    u_xlat0.xyz = (-u_xlat6.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat2.xyz = u_xlat4.yzx * u_xlat5.zxy;
    u_xlat2.xyz = u_xlat4.zxy * u_xlat5.yzx + (-u_xlat2.xyz);
    u_xlat6.xyz = u_xlat3.zxy * u_xlat5.yzx;
    u_xlat5.xyz = u_xlat3.yzx * u_xlat5.zxy + (-u_xlat6.xyz);
    u_xlat24 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat24 = float(1.0) / float(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat2.xyz;
    u_xlat2.y = dot(in_NORMAL0.xyz, u_xlat2.xyz);
    u_xlat6.xyz = u_xlat3.yzx * u_xlat4.zxy;
    u_xlat3.xyz = u_xlat4.yzx * u_xlat3.zxy + (-u_xlat6.xyz);
    u_xlat3.xyz = vec3(u_xlat24) * u_xlat3.xyz;
    u_xlat4.xyz = vec3(u_xlat24) * u_xlat5.xyz;
    u_xlat2.x = dot(in_NORMAL0.xyz, u_xlat4.xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, u_xlat3.xyz);
    u_xlat24 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat24 = max(u_xlat24, 1.17549435e-38);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat2.xyz;
    vs_TEXCOORD2.xyz = u_xlat2.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlatb24 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD3.x = (u_xlatb24) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD3.y = (u_xlatb24) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD3.z = (u_xlatb24) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8.xyz = vec3(0.0, 0.0, 0.0);
    vs_SV_InstanceID0 =  uint(gl_InstanceID);
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
UNITY_BINDING(0) uniform UnityPerMaterial {
	vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	vec4 Xhlslcc_UnusedX_CameraFadeParams;
	vec4 Xhlslcc_UnusedX_BaseMap_ST;
	vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	mediump vec4                _BaseColor;
	mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	mediump vec4 Xhlslcc_UnusedX_BaseColorAddSubDiff;
	mediump float Xhlslcc_UnusedX_Cutoff;
	mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	mediump float Xhlslcc_UnusedX_DistortionBlend;
	mediump float                _Surface;
};
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
layout(location = 0) in highp  vec2 vs_TEXCOORD0;
layout(location = 1) in mediump  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
bool u_xlatb1;
void main()
{
    u_xlat16_0 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_0 = u_xlat16_0 * _BaseColor;
    u_xlat16_0 = u_xlat16_0 * vs_COLOR0;
    u_xlatb1 = _Surface==1.0;
    SV_Target0.w = (u_xlatb1) ? u_xlat16_0.w : 1.0;
    SV_Target0.xyz = u_xlat16_0.xyz;
    return;
}

#endif


// ===== program 5: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
UNITY_BINDING(0) uniform UnityPerMaterial {
	vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	vec4 Xhlslcc_UnusedX_CameraFadeParams;
	vec4 Xhlslcc_UnusedX_BaseMap_ST;
	vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	mediump vec4                _BaseColor;
	mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	mediump vec4 Xhlslcc_UnusedX_BaseColorAddSubDiff;
	mediump float Xhlslcc_UnusedX_Cutoff;
	mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	mediump float Xhlslcc_UnusedX_DistortionBlend;
	mediump float                _Surface;
};
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
layout(location = 0) in highp  vec2 vs_TEXCOORD0;
layout(location = 1) in mediump  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
bool u_xlatb1;
void main()
{
    u_xlat16_0 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_0 = u_xlat16_0 * _BaseColor;
    u_xlat16_0 = u_xlat16_0 * vs_COLOR0;
    u_xlatb1 = _Surface==1.0;
    SV_Target0.w = (u_xlatb1) ? u_xlat16_0.w : 1.0;
    SV_Target0.xyz = u_xlat16_0.xyz;
    return;
}

#endif


// ===== program 6: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	int unity_BaseInstanceID;
uniform 	vec4 unity_ParticleUVShiftData;
uniform 	mediump float unity_ParticleUseMeshColors;
 struct unity_ParticleInstanceData_type {
	uint[14] value;
};

layout(std430, binding = 0) readonly buffer unity_ParticleInstanceData {
	unity_ParticleInstanceData_type unity_ParticleInstanceData_buf[];
};
in highp vec4 in_POSITION0;
in mediump vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec3 in_NORMAL0;
layout(location = 0) out highp vec2 vs_TEXCOORD0;
layout(location = 1) out mediump vec4 vs_COLOR0;
layout(location = 2) out highp vec4 vs_TEXCOORD1;
layout(location = 3) out mediump vec3 vs_TEXCOORD2;
layout(location = 4) out mediump vec3 vs_TEXCOORD3;
layout(location = 5) out mediump vec3 vs_TEXCOORD8;
layout(location = 6) flat out highp uint vs_SV_InstanceID0;
vec4 u_xlat0;
uint u_xlatu0;
vec2 u_xlat1;
mediump vec4 u_xlat16_1;
int u_xlati1;
uvec3 u_xlatu1;
vec4 u_xlat2;
vec4 u_xlat3;
vec4 u_xlat4;
vec4 u_xlat5;
vec3 u_xlat6;
vec4 u_xlat7;
float u_xlat8;
vec3 u_xlat9;
bool u_xlatb16;
float u_xlat24;
bool u_xlatb24;
uint uint_bitfieldExtract(uint value, int offset, int bits) { return (value >> uint(offset)) & uint(~(int(~0) << uint(bits))); }

void main()
{
    u_xlat0.xyz = in_POSITION0.xyz;
    u_xlat0.w = 1.0;
    u_xlati1 = gl_InstanceID + unity_BaseInstanceID;
    u_xlat2 = vec4(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 3]));
    u_xlat3.w = u_xlat2.y;
    u_xlat9.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 2]));
    u_xlat3.y = u_xlat9.y;
    u_xlat4.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 0]));
    u_xlat3.z = u_xlat4.x;
    u_xlat5.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 1]));
    u_xlat1.x = uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(52 >> 2) + 0]);
    u_xlat1.x = floor(u_xlat1.x);
    u_xlat3.x = u_xlat5.z;
    u_xlat6.y = dot(u_xlat3, u_xlat0);
    u_xlat7 = u_xlat6.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat4.w = u_xlat2.x;
    u_xlat5.z = u_xlat4.y;
    u_xlat4.x = u_xlat5.y;
    u_xlat4.y = u_xlat9.x;
    u_xlat5.y = u_xlat9.z;
    u_xlat6.x = dot(u_xlat4, u_xlat0);
    u_xlat7 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat6.xxxx + u_xlat7;
    u_xlat5.w = u_xlat2.z;
    u_xlat6.z = dot(u_xlat5, u_xlat0);
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat6.zzzz + u_xlat7;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat0.x = u_xlat1.x / unity_ParticleUVShiftData.y;
    u_xlat0.x = floor(u_xlat0.x);
    u_xlat8 = (-u_xlat0.x) * unity_ParticleUVShiftData.y + u_xlat1.x;
    u_xlat8 = floor(u_xlat8);
    u_xlat1.x = u_xlat8 * unity_ParticleUVShiftData.z;
    u_xlat8 = (-unity_ParticleUVShiftData.w) + 1.0;
    u_xlat1.y = (-u_xlat0.x) * unity_ParticleUVShiftData.w + u_xlat8;
    u_xlat0.xy = in_TEXCOORD0.xy * unity_ParticleUVShiftData.zw + u_xlat1.xy;
    u_xlatb16 = unity_ParticleUVShiftData.x!=0.0;
    vs_TEXCOORD0.xy = (bool(u_xlatb16)) ? u_xlat0.xy : in_TEXCOORD0.xy;
    u_xlatu0 = uint(floatBitsToUint(u_xlat2.w)) & 255u;
    u_xlat0.x = float(u_xlatu0);
    u_xlatu1.xy = uvec2(uint_bitfieldExtract(uint(floatBitsToUint(u_xlat2.w)), int(8) & int(0x1F), int(8) & int(0x1F)), uint_bitfieldExtract(uint(floatBitsToUint(u_xlat2.w)), int(16) & int(0x1F), int(8) & int(0x1F)));
    u_xlatu1.z = uint(floatBitsToUint(u_xlat2.w)) >> (24u & uint(0x1F));
    u_xlat0.yzw = vec3(u_xlatu1.xyz);
    u_xlat0 = u_xlat0 * vec4(0.00392156886, 0.00392156886, 0.00392156886, 0.00392156886);
    u_xlat16_1 = in_COLOR0 + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat16_1 = vec4(unity_ParticleUseMeshColors) * u_xlat16_1 + vec4(1.0, 1.0, 1.0, 1.0);
    vs_COLOR0 = u_xlat0 * u_xlat16_1;
    vs_TEXCOORD1.w = 0.0;
    vs_TEXCOORD1.xyz = u_xlat6.xyz;
    u_xlat0.xyz = (-u_xlat6.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat2.xyz = u_xlat4.yzx * u_xlat5.zxy;
    u_xlat2.xyz = u_xlat4.zxy * u_xlat5.yzx + (-u_xlat2.xyz);
    u_xlat6.xyz = u_xlat3.zxy * u_xlat5.yzx;
    u_xlat5.xyz = u_xlat3.yzx * u_xlat5.zxy + (-u_xlat6.xyz);
    u_xlat24 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat24 = float(1.0) / float(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat2.xyz;
    u_xlat2.y = dot(in_NORMAL0.xyz, u_xlat2.xyz);
    u_xlat6.xyz = u_xlat3.yzx * u_xlat4.zxy;
    u_xlat3.xyz = u_xlat4.yzx * u_xlat3.zxy + (-u_xlat6.xyz);
    u_xlat3.xyz = vec3(u_xlat24) * u_xlat3.xyz;
    u_xlat4.xyz = vec3(u_xlat24) * u_xlat5.xyz;
    u_xlat2.x = dot(in_NORMAL0.xyz, u_xlat4.xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, u_xlat3.xyz);
    u_xlat24 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat24 = max(u_xlat24, 1.17549435e-38);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat2.xyz;
    vs_TEXCOORD2.xyz = u_xlat2.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlatb24 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD3.x = (u_xlatb24) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD3.y = (u_xlatb24) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD3.z = (u_xlatb24) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8.xyz = vec3(0.0, 0.0, 0.0);
    vs_SV_InstanceID0 =  uint(gl_InstanceID);
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
UNITY_BINDING(0) uniform UnityPerMaterial {
	vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	vec4 Xhlslcc_UnusedX_CameraFadeParams;
	vec4 Xhlslcc_UnusedX_BaseMap_ST;
	vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	mediump vec4                _BaseColor;
	mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	mediump vec4                _BaseColorAddSubDiff;
	mediump float Xhlslcc_UnusedX_Cutoff;
	mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	mediump float Xhlslcc_UnusedX_DistortionBlend;
	mediump float                _Surface;
};
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
layout(location = 0) in highp  vec2 vs_TEXCOORD0;
layout(location = 1) in mediump  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
mediump vec3 u_xlat16_1;
mediump vec3 u_xlat16_2;
bool u_xlatb3;
mediump float u_xlat16_13;
void main()
{
    u_xlat16_0 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_0 = u_xlat16_0 * _BaseColor;
    u_xlat16_1.xyz = vs_COLOR0.xyz * _BaseColorAddSubDiff.xxx + u_xlat16_0.xyz;
    u_xlat16_13 = u_xlat16_0.w * vs_COLOR0.w;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + abs(u_xlat16_1.xyz);
    SV_Target0.xyz = _BaseColorAddSubDiff.yyy * u_xlat16_2.xyz + u_xlat16_1.xyz;
    u_xlatb3 = _Surface==1.0;
    SV_Target0.w = (u_xlatb3) ? u_xlat16_13 : 1.0;
    return;
}

#endif


// ===== program 7: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
UNITY_BINDING(0) uniform UnityPerMaterial {
	vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	vec4 Xhlslcc_UnusedX_CameraFadeParams;
	vec4 Xhlslcc_UnusedX_BaseMap_ST;
	vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	mediump vec4                _BaseColor;
	mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	mediump vec4                _BaseColorAddSubDiff;
	mediump float Xhlslcc_UnusedX_Cutoff;
	mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	mediump float Xhlslcc_UnusedX_DistortionBlend;
	mediump float                _Surface;
};
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
layout(location = 0) in highp  vec2 vs_TEXCOORD0;
layout(location = 1) in mediump  vec4 vs_COLOR0;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec4 u_xlat16_0;
mediump vec3 u_xlat16_1;
mediump vec3 u_xlat16_2;
bool u_xlatb3;
mediump float u_xlat16_13;
void main()
{
    u_xlat16_0 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_0 = u_xlat16_0 * _BaseColor;
    u_xlat16_1.xyz = vs_COLOR0.xyz * _BaseColorAddSubDiff.xxx + u_xlat16_0.xyz;
    u_xlat16_13 = u_xlat16_0.w * vs_COLOR0.w;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + abs(u_xlat16_1.xyz);
    SV_Target0.xyz = _BaseColorAddSubDiff.yyy * u_xlat16_2.xyz + u_xlat16_1.xyz;
    u_xlatb3 = _Surface==1.0;
    SV_Target0.w = (u_xlatb3) ? u_xlat16_13 : 1.0;
    return;
}

#endif


// ===== program 8: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in mediump vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec3 in_NORMAL0;
out highp vec2 vs_TEXCOORD0;
out mediump vec4 vs_COLOR0;
out highp vec4 vs_TEXCOORD1;
mediump vec3 vs_TEXCOORD2;
mediump vec3 vs_TEXCOORD3;
mediump vec3 vs_TEXCOORD8;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
bool u_xlatb6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_TEXCOORD0.xy = in_TEXCOORD0.xy;
    vs_COLOR0 = in_COLOR0;
    vs_TEXCOORD1.xyz = u_xlat0.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD1.w = 0.0;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    u_xlat1.xyz = vec3(u_xlat6) * u_xlat1.xyz;
    vs_TEXCOORD2.xyz = u_xlat1.xyz;
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = inversesqrt(u_xlat6);
    u_xlat0.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    u_xlatb6 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD3.x = (u_xlatb6) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD3.y = (u_xlatb6) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD3.z = (u_xlatb6) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8.xyz = vec3(0.0, 0.0, 0.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CameraFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	UNITY_UNIFORM mediump vec4                _BaseColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_BaseColorAddSubDiff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Cutoff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionBlend;
	UNITY_UNIFORM mediump float                _Surface;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
in highp  vec2 vs_TEXCOORD0;
in mediump  vec4 vs_COLOR0;
in highp  vec4 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
float u_xlat0;
bool u_xlatb0;
mediump vec3 u_xlat16_1;
mediump vec4 u_xlat16_2;
void main()
{
    u_xlat0 = vs_TEXCOORD1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[0].z * vs_TEXCOORD1.x + u_xlat0;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[2].z * vs_TEXCOORD1.z + u_xlat0;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0 = (-u_xlat0) + (-_ProjectionParams.y);
    u_xlat0 = max(u_xlat0, 0.0);
    u_xlat0 = u_xlat0 * unity_FogParams.z + unity_FogParams.w;
    u_xlat0 = clamp(u_xlat0, 0.0, 1.0);
    u_xlat16_1.x = (-u_xlat0) + 1.0;
    u_xlat16_1.xyz = u_xlat16_1.xxx * unity_FogColor.xyz;
    u_xlat16_2 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_2 = u_xlat16_2 * _BaseColor;
    u_xlat16_2 = u_xlat16_2 * vs_COLOR0;
    SV_Target0.xyz = u_xlat16_2.xyz * vec3(u_xlat0) + u_xlat16_1.xyz;
    u_xlatb0 = _Surface==1.0;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_2.w : 1.0;
    return;
}

#endif


// ===== program 9: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CameraFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	UNITY_UNIFORM mediump vec4                _BaseColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_BaseColorAddSubDiff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Cutoff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionBlend;
	UNITY_UNIFORM mediump float                _Surface;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
in highp  vec2 vs_TEXCOORD0;
in mediump  vec4 vs_COLOR0;
in highp  vec4 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
float u_xlat0;
bool u_xlatb0;
mediump vec3 u_xlat16_1;
mediump vec4 u_xlat16_2;
void main()
{
    u_xlat0 = vs_TEXCOORD1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[0].z * vs_TEXCOORD1.x + u_xlat0;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[2].z * vs_TEXCOORD1.z + u_xlat0;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0 = (-u_xlat0) + (-_ProjectionParams.y);
    u_xlat0 = max(u_xlat0, 0.0);
    u_xlat0 = u_xlat0 * unity_FogParams.z + unity_FogParams.w;
    u_xlat0 = clamp(u_xlat0, 0.0, 1.0);
    u_xlat16_1.x = (-u_xlat0) + 1.0;
    u_xlat16_1.xyz = u_xlat16_1.xxx * unity_FogColor.xyz;
    u_xlat16_2 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_2 = u_xlat16_2 * _BaseColor;
    u_xlat16_2 = u_xlat16_2 * vs_COLOR0;
    SV_Target0.xyz = u_xlat16_2.xyz * vec3(u_xlat0) + u_xlat16_1.xyz;
    u_xlatb0 = _Surface==1.0;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_2.w : 1.0;
    return;
}

#endif


// ===== program 10: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in mediump vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec3 in_NORMAL0;
out highp vec2 vs_TEXCOORD0;
out mediump vec4 vs_COLOR0;
out highp vec4 vs_TEXCOORD1;
mediump vec3 vs_TEXCOORD2;
mediump vec3 vs_TEXCOORD3;
mediump vec3 vs_TEXCOORD8;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
bool u_xlatb6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_TEXCOORD0.xy = in_TEXCOORD0.xy;
    vs_COLOR0 = in_COLOR0;
    vs_TEXCOORD1.xyz = u_xlat0.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    vs_TEXCOORD1.w = 0.0;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    u_xlat1.xyz = vec3(u_xlat6) * u_xlat1.xyz;
    vs_TEXCOORD2.xyz = u_xlat1.xyz;
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = inversesqrt(u_xlat6);
    u_xlat0.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    u_xlatb6 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD3.x = (u_xlatb6) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD3.y = (u_xlatb6) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD3.z = (u_xlatb6) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8.xyz = vec3(0.0, 0.0, 0.0);
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CameraFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	UNITY_UNIFORM mediump vec4                _BaseColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	UNITY_UNIFORM mediump vec4                _BaseColorAddSubDiff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Cutoff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionBlend;
	UNITY_UNIFORM mediump float                _Surface;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
in highp  vec2 vs_TEXCOORD0;
in mediump  vec4 vs_COLOR0;
in highp  vec4 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
float u_xlat0;
bool u_xlatb0;
mediump vec3 u_xlat16_1;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump float u_xlat16_16;
void main()
{
    u_xlat0 = vs_TEXCOORD1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[0].z * vs_TEXCOORD1.x + u_xlat0;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[2].z * vs_TEXCOORD1.z + u_xlat0;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0 = (-u_xlat0) + (-_ProjectionParams.y);
    u_xlat0 = max(u_xlat0, 0.0);
    u_xlat0 = u_xlat0 * unity_FogParams.z + unity_FogParams.w;
    u_xlat0 = clamp(u_xlat0, 0.0, 1.0);
    u_xlat16_1.x = (-u_xlat0) + 1.0;
    u_xlat16_1.xyz = u_xlat16_1.xxx * unity_FogColor.xyz;
    u_xlat16_2 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_2 = u_xlat16_2 * _BaseColor;
    u_xlat16_3.xyz = vs_COLOR0.xyz * _BaseColorAddSubDiff.xxx + u_xlat16_2.xyz;
    u_xlat16_16 = u_xlat16_2.w * vs_COLOR0.w;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + abs(u_xlat16_3.xyz);
    u_xlat16_3.xyz = _BaseColorAddSubDiff.yyy * u_xlat16_4.xyz + u_xlat16_3.xyz;
    SV_Target0.xyz = u_xlat16_3.xyz * vec3(u_xlat0) + u_xlat16_1.xyz;
    u_xlatb0 = _Surface==1.0;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_16 : 1.0;
    return;
}

#endif


// ===== program 11: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CameraFadeParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	UNITY_UNIFORM mediump vec4                _BaseColor;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	UNITY_UNIFORM mediump vec4                _BaseColorAddSubDiff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Cutoff;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_DistortionBlend;
	UNITY_UNIFORM mediump float                _Surface;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
in highp  vec2 vs_TEXCOORD0;
in mediump  vec4 vs_COLOR0;
in highp  vec4 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
float u_xlat0;
bool u_xlatb0;
mediump vec3 u_xlat16_1;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump float u_xlat16_16;
void main()
{
    u_xlat0 = vs_TEXCOORD1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[0].z * vs_TEXCOORD1.x + u_xlat0;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[2].z * vs_TEXCOORD1.z + u_xlat0;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0 = (-u_xlat0) + (-_ProjectionParams.y);
    u_xlat0 = max(u_xlat0, 0.0);
    u_xlat0 = u_xlat0 * unity_FogParams.z + unity_FogParams.w;
    u_xlat0 = clamp(u_xlat0, 0.0, 1.0);
    u_xlat16_1.x = (-u_xlat0) + 1.0;
    u_xlat16_1.xyz = u_xlat16_1.xxx * unity_FogColor.xyz;
    u_xlat16_2 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_2 = u_xlat16_2 * _BaseColor;
    u_xlat16_3.xyz = vs_COLOR0.xyz * _BaseColorAddSubDiff.xxx + u_xlat16_2.xyz;
    u_xlat16_16 = u_xlat16_2.w * vs_COLOR0.w;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + abs(u_xlat16_3.xyz);
    u_xlat16_3.xyz = _BaseColorAddSubDiff.yyy * u_xlat16_4.xyz + u_xlat16_3.xyz;
    SV_Target0.xyz = u_xlat16_3.xyz * vec3(u_xlat0) + u_xlat16_1.xyz;
    u_xlatb0 = _Surface==1.0;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_16 : 1.0;
    return;
}

#endif


// ===== program 12: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	int unity_BaseInstanceID;
uniform 	vec4 unity_ParticleUVShiftData;
uniform 	mediump float unity_ParticleUseMeshColors;
 struct unity_ParticleInstanceData_type {
	uint[14] value;
};

layout(std430, binding = 0) readonly buffer unity_ParticleInstanceData {
	unity_ParticleInstanceData_type unity_ParticleInstanceData_buf[];
};
in highp vec4 in_POSITION0;
in mediump vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec3 in_NORMAL0;
layout(location = 0) out highp vec2 vs_TEXCOORD0;
layout(location = 1) out mediump vec4 vs_COLOR0;
layout(location = 2) out highp vec4 vs_TEXCOORD1;
layout(location = 3) out mediump vec3 vs_TEXCOORD2;
layout(location = 4) out mediump vec3 vs_TEXCOORD3;
layout(location = 5) out mediump vec3 vs_TEXCOORD8;
layout(location = 6) flat out highp uint vs_SV_InstanceID0;
vec4 u_xlat0;
uint u_xlatu0;
vec2 u_xlat1;
mediump vec4 u_xlat16_1;
int u_xlati1;
uvec3 u_xlatu1;
vec4 u_xlat2;
vec4 u_xlat3;
vec4 u_xlat4;
vec4 u_xlat5;
vec3 u_xlat6;
vec4 u_xlat7;
float u_xlat8;
vec3 u_xlat9;
bool u_xlatb16;
float u_xlat24;
bool u_xlatb24;
uint uint_bitfieldExtract(uint value, int offset, int bits) { return (value >> uint(offset)) & uint(~(int(~0) << uint(bits))); }

void main()
{
    u_xlat0.xyz = in_POSITION0.xyz;
    u_xlat0.w = 1.0;
    u_xlati1 = gl_InstanceID + unity_BaseInstanceID;
    u_xlat2 = vec4(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 3]));
    u_xlat3.w = u_xlat2.y;
    u_xlat9.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 2]));
    u_xlat3.y = u_xlat9.y;
    u_xlat4.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 0]));
    u_xlat3.z = u_xlat4.x;
    u_xlat5.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 1]));
    u_xlat1.x = uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(52 >> 2) + 0]);
    u_xlat1.x = floor(u_xlat1.x);
    u_xlat3.x = u_xlat5.z;
    u_xlat6.y = dot(u_xlat3, u_xlat0);
    u_xlat7 = u_xlat6.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat4.w = u_xlat2.x;
    u_xlat5.z = u_xlat4.y;
    u_xlat4.x = u_xlat5.y;
    u_xlat4.y = u_xlat9.x;
    u_xlat5.y = u_xlat9.z;
    u_xlat6.x = dot(u_xlat4, u_xlat0);
    u_xlat7 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat6.xxxx + u_xlat7;
    u_xlat5.w = u_xlat2.z;
    u_xlat6.z = dot(u_xlat5, u_xlat0);
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat6.zzzz + u_xlat7;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat0.x = u_xlat1.x / unity_ParticleUVShiftData.y;
    u_xlat0.x = floor(u_xlat0.x);
    u_xlat8 = (-u_xlat0.x) * unity_ParticleUVShiftData.y + u_xlat1.x;
    u_xlat8 = floor(u_xlat8);
    u_xlat1.x = u_xlat8 * unity_ParticleUVShiftData.z;
    u_xlat8 = (-unity_ParticleUVShiftData.w) + 1.0;
    u_xlat1.y = (-u_xlat0.x) * unity_ParticleUVShiftData.w + u_xlat8;
    u_xlat0.xy = in_TEXCOORD0.xy * unity_ParticleUVShiftData.zw + u_xlat1.xy;
    u_xlatb16 = unity_ParticleUVShiftData.x!=0.0;
    vs_TEXCOORD0.xy = (bool(u_xlatb16)) ? u_xlat0.xy : in_TEXCOORD0.xy;
    u_xlatu0 = uint(floatBitsToUint(u_xlat2.w)) & 255u;
    u_xlat0.x = float(u_xlatu0);
    u_xlatu1.xy = uvec2(uint_bitfieldExtract(uint(floatBitsToUint(u_xlat2.w)), int(8) & int(0x1F), int(8) & int(0x1F)), uint_bitfieldExtract(uint(floatBitsToUint(u_xlat2.w)), int(16) & int(0x1F), int(8) & int(0x1F)));
    u_xlatu1.z = uint(floatBitsToUint(u_xlat2.w)) >> (24u & uint(0x1F));
    u_xlat0.yzw = vec3(u_xlatu1.xyz);
    u_xlat0 = u_xlat0 * vec4(0.00392156886, 0.00392156886, 0.00392156886, 0.00392156886);
    u_xlat16_1 = in_COLOR0 + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat16_1 = vec4(unity_ParticleUseMeshColors) * u_xlat16_1 + vec4(1.0, 1.0, 1.0, 1.0);
    vs_COLOR0 = u_xlat0 * u_xlat16_1;
    vs_TEXCOORD1.w = 0.0;
    vs_TEXCOORD1.xyz = u_xlat6.xyz;
    u_xlat0.xyz = (-u_xlat6.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat2.xyz = u_xlat4.yzx * u_xlat5.zxy;
    u_xlat2.xyz = u_xlat4.zxy * u_xlat5.yzx + (-u_xlat2.xyz);
    u_xlat6.xyz = u_xlat3.zxy * u_xlat5.yzx;
    u_xlat5.xyz = u_xlat3.yzx * u_xlat5.zxy + (-u_xlat6.xyz);
    u_xlat24 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat24 = float(1.0) / float(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat2.xyz;
    u_xlat2.y = dot(in_NORMAL0.xyz, u_xlat2.xyz);
    u_xlat6.xyz = u_xlat3.yzx * u_xlat4.zxy;
    u_xlat3.xyz = u_xlat4.yzx * u_xlat3.zxy + (-u_xlat6.xyz);
    u_xlat3.xyz = vec3(u_xlat24) * u_xlat3.xyz;
    u_xlat4.xyz = vec3(u_xlat24) * u_xlat5.xyz;
    u_xlat2.x = dot(in_NORMAL0.xyz, u_xlat4.xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, u_xlat3.xyz);
    u_xlat24 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat24 = max(u_xlat24, 1.17549435e-38);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat2.xyz;
    vs_TEXCOORD2.xyz = u_xlat2.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlatb24 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD3.x = (u_xlatb24) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD3.y = (u_xlatb24) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD3.z = (u_xlatb24) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8.xyz = vec3(0.0, 0.0, 0.0);
    vs_SV_InstanceID0 =  uint(gl_InstanceID);
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
UNITY_BINDING(0) uniform UnityPerMaterial {
	vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	vec4 Xhlslcc_UnusedX_CameraFadeParams;
	vec4 Xhlslcc_UnusedX_BaseMap_ST;
	vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	mediump vec4                _BaseColor;
	mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	mediump vec4 Xhlslcc_UnusedX_BaseColorAddSubDiff;
	mediump float Xhlslcc_UnusedX_Cutoff;
	mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	mediump float Xhlslcc_UnusedX_DistortionBlend;
	mediump float                _Surface;
};
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
layout(location = 0) in highp  vec2 vs_TEXCOORD0;
layout(location = 1) in mediump  vec4 vs_COLOR0;
layout(location = 2) in highp  vec4 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
float u_xlat0;
bool u_xlatb0;
mediump vec3 u_xlat16_1;
mediump vec4 u_xlat16_2;
void main()
{
    u_xlat0 = vs_TEXCOORD1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[0].z * vs_TEXCOORD1.x + u_xlat0;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[2].z * vs_TEXCOORD1.z + u_xlat0;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0 = (-u_xlat0) + (-_ProjectionParams.y);
    u_xlat0 = max(u_xlat0, 0.0);
    u_xlat0 = u_xlat0 * unity_FogParams.z + unity_FogParams.w;
    u_xlat0 = clamp(u_xlat0, 0.0, 1.0);
    u_xlat16_1.x = (-u_xlat0) + 1.0;
    u_xlat16_1.xyz = u_xlat16_1.xxx * unity_FogColor.xyz;
    u_xlat16_2 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_2 = u_xlat16_2 * _BaseColor;
    u_xlat16_2 = u_xlat16_2 * vs_COLOR0;
    SV_Target0.xyz = u_xlat16_2.xyz * vec3(u_xlat0) + u_xlat16_1.xyz;
    u_xlatb0 = _Surface==1.0;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_2.w : 1.0;
    return;
}

#endif


// ===== program 13: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
UNITY_BINDING(0) uniform UnityPerMaterial {
	vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	vec4 Xhlslcc_UnusedX_CameraFadeParams;
	vec4 Xhlslcc_UnusedX_BaseMap_ST;
	vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	mediump vec4                _BaseColor;
	mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	mediump vec4 Xhlslcc_UnusedX_BaseColorAddSubDiff;
	mediump float Xhlslcc_UnusedX_Cutoff;
	mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	mediump float Xhlslcc_UnusedX_DistortionBlend;
	mediump float                _Surface;
};
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
layout(location = 0) in highp  vec2 vs_TEXCOORD0;
layout(location = 1) in mediump  vec4 vs_COLOR0;
layout(location = 2) in highp  vec4 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
float u_xlat0;
bool u_xlatb0;
mediump vec3 u_xlat16_1;
mediump vec4 u_xlat16_2;
void main()
{
    u_xlat0 = vs_TEXCOORD1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[0].z * vs_TEXCOORD1.x + u_xlat0;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[2].z * vs_TEXCOORD1.z + u_xlat0;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0 = (-u_xlat0) + (-_ProjectionParams.y);
    u_xlat0 = max(u_xlat0, 0.0);
    u_xlat0 = u_xlat0 * unity_FogParams.z + unity_FogParams.w;
    u_xlat0 = clamp(u_xlat0, 0.0, 1.0);
    u_xlat16_1.x = (-u_xlat0) + 1.0;
    u_xlat16_1.xyz = u_xlat16_1.xxx * unity_FogColor.xyz;
    u_xlat16_2 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_2 = u_xlat16_2 * _BaseColor;
    u_xlat16_2 = u_xlat16_2 * vs_COLOR0;
    SV_Target0.xyz = u_xlat16_2.xyz * vec3(u_xlat0) + u_xlat16_1.xyz;
    u_xlatb0 = _Surface==1.0;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_2.w : 1.0;
    return;
}

#endif


// ===== program 14: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	int unity_BaseInstanceID;
uniform 	vec4 unity_ParticleUVShiftData;
uniform 	mediump float unity_ParticleUseMeshColors;
 struct unity_ParticleInstanceData_type {
	uint[14] value;
};

layout(std430, binding = 0) readonly buffer unity_ParticleInstanceData {
	unity_ParticleInstanceData_type unity_ParticleInstanceData_buf[];
};
in highp vec4 in_POSITION0;
in mediump vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
in highp vec3 in_NORMAL0;
layout(location = 0) out highp vec2 vs_TEXCOORD0;
layout(location = 1) out mediump vec4 vs_COLOR0;
layout(location = 2) out highp vec4 vs_TEXCOORD1;
layout(location = 3) out mediump vec3 vs_TEXCOORD2;
layout(location = 4) out mediump vec3 vs_TEXCOORD3;
layout(location = 5) out mediump vec3 vs_TEXCOORD8;
layout(location = 6) flat out highp uint vs_SV_InstanceID0;
vec4 u_xlat0;
uint u_xlatu0;
vec2 u_xlat1;
mediump vec4 u_xlat16_1;
int u_xlati1;
uvec3 u_xlatu1;
vec4 u_xlat2;
vec4 u_xlat3;
vec4 u_xlat4;
vec4 u_xlat5;
vec3 u_xlat6;
vec4 u_xlat7;
float u_xlat8;
vec3 u_xlat9;
bool u_xlatb16;
float u_xlat24;
bool u_xlatb24;
uint uint_bitfieldExtract(uint value, int offset, int bits) { return (value >> uint(offset)) & uint(~(int(~0) << uint(bits))); }

void main()
{
    u_xlat0.xyz = in_POSITION0.xyz;
    u_xlat0.w = 1.0;
    u_xlati1 = gl_InstanceID + unity_BaseInstanceID;
    u_xlat2 = vec4(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 3]));
    u_xlat3.w = u_xlat2.y;
    u_xlat9.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 2]));
    u_xlat3.y = u_xlat9.y;
    u_xlat4.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 0]));
    u_xlat3.z = u_xlat4.x;
    u_xlat5.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 1]));
    u_xlat1.x = uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(52 >> 2) + 0]);
    u_xlat1.x = floor(u_xlat1.x);
    u_xlat3.x = u_xlat5.z;
    u_xlat6.y = dot(u_xlat3, u_xlat0);
    u_xlat7 = u_xlat6.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat4.w = u_xlat2.x;
    u_xlat5.z = u_xlat4.y;
    u_xlat4.x = u_xlat5.y;
    u_xlat4.y = u_xlat9.x;
    u_xlat5.y = u_xlat9.z;
    u_xlat6.x = dot(u_xlat4, u_xlat0);
    u_xlat7 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat6.xxxx + u_xlat7;
    u_xlat5.w = u_xlat2.z;
    u_xlat6.z = dot(u_xlat5, u_xlat0);
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat6.zzzz + u_xlat7;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat0.x = u_xlat1.x / unity_ParticleUVShiftData.y;
    u_xlat0.x = floor(u_xlat0.x);
    u_xlat8 = (-u_xlat0.x) * unity_ParticleUVShiftData.y + u_xlat1.x;
    u_xlat8 = floor(u_xlat8);
    u_xlat1.x = u_xlat8 * unity_ParticleUVShiftData.z;
    u_xlat8 = (-unity_ParticleUVShiftData.w) + 1.0;
    u_xlat1.y = (-u_xlat0.x) * unity_ParticleUVShiftData.w + u_xlat8;
    u_xlat0.xy = in_TEXCOORD0.xy * unity_ParticleUVShiftData.zw + u_xlat1.xy;
    u_xlatb16 = unity_ParticleUVShiftData.x!=0.0;
    vs_TEXCOORD0.xy = (bool(u_xlatb16)) ? u_xlat0.xy : in_TEXCOORD0.xy;
    u_xlatu0 = uint(floatBitsToUint(u_xlat2.w)) & 255u;
    u_xlat0.x = float(u_xlatu0);
    u_xlatu1.xy = uvec2(uint_bitfieldExtract(uint(floatBitsToUint(u_xlat2.w)), int(8) & int(0x1F), int(8) & int(0x1F)), uint_bitfieldExtract(uint(floatBitsToUint(u_xlat2.w)), int(16) & int(0x1F), int(8) & int(0x1F)));
    u_xlatu1.z = uint(floatBitsToUint(u_xlat2.w)) >> (24u & uint(0x1F));
    u_xlat0.yzw = vec3(u_xlatu1.xyz);
    u_xlat0 = u_xlat0 * vec4(0.00392156886, 0.00392156886, 0.00392156886, 0.00392156886);
    u_xlat16_1 = in_COLOR0 + vec4(-1.0, -1.0, -1.0, -1.0);
    u_xlat16_1 = vec4(unity_ParticleUseMeshColors) * u_xlat16_1 + vec4(1.0, 1.0, 1.0, 1.0);
    vs_COLOR0 = u_xlat0 * u_xlat16_1;
    vs_TEXCOORD1.w = 0.0;
    vs_TEXCOORD1.xyz = u_xlat6.xyz;
    u_xlat0.xyz = (-u_xlat6.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat2.xyz = u_xlat4.yzx * u_xlat5.zxy;
    u_xlat2.xyz = u_xlat4.zxy * u_xlat5.yzx + (-u_xlat2.xyz);
    u_xlat6.xyz = u_xlat3.zxy * u_xlat5.yzx;
    u_xlat5.xyz = u_xlat3.yzx * u_xlat5.zxy + (-u_xlat6.xyz);
    u_xlat24 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat24 = float(1.0) / float(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat2.xyz;
    u_xlat2.y = dot(in_NORMAL0.xyz, u_xlat2.xyz);
    u_xlat6.xyz = u_xlat3.yzx * u_xlat4.zxy;
    u_xlat3.xyz = u_xlat4.yzx * u_xlat3.zxy + (-u_xlat6.xyz);
    u_xlat3.xyz = vec3(u_xlat24) * u_xlat3.xyz;
    u_xlat4.xyz = vec3(u_xlat24) * u_xlat5.xyz;
    u_xlat2.x = dot(in_NORMAL0.xyz, u_xlat4.xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, u_xlat3.xyz);
    u_xlat24 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat24 = max(u_xlat24, 1.17549435e-38);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat2.xyz;
    vs_TEXCOORD2.xyz = u_xlat2.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlatb24 = unity_OrthoParams.w==0.0;
    vs_TEXCOORD3.x = (u_xlatb24) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    vs_TEXCOORD3.y = (u_xlatb24) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    vs_TEXCOORD3.z = (u_xlatb24) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD8.xyz = vec3(0.0, 0.0, 0.0);
    vs_SV_InstanceID0 =  uint(gl_InstanceID);
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
UNITY_BINDING(0) uniform UnityPerMaterial {
	vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	vec4 Xhlslcc_UnusedX_CameraFadeParams;
	vec4 Xhlslcc_UnusedX_BaseMap_ST;
	vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	mediump vec4                _BaseColor;
	mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	mediump vec4                _BaseColorAddSubDiff;
	mediump float Xhlslcc_UnusedX_Cutoff;
	mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	mediump float Xhlslcc_UnusedX_DistortionBlend;
	mediump float                _Surface;
};
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
layout(location = 0) in highp  vec2 vs_TEXCOORD0;
layout(location = 1) in mediump  vec4 vs_COLOR0;
layout(location = 2) in highp  vec4 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
float u_xlat0;
bool u_xlatb0;
mediump vec3 u_xlat16_1;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump float u_xlat16_16;
void main()
{
    u_xlat0 = vs_TEXCOORD1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[0].z * vs_TEXCOORD1.x + u_xlat0;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[2].z * vs_TEXCOORD1.z + u_xlat0;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0 = (-u_xlat0) + (-_ProjectionParams.y);
    u_xlat0 = max(u_xlat0, 0.0);
    u_xlat0 = u_xlat0 * unity_FogParams.z + unity_FogParams.w;
    u_xlat0 = clamp(u_xlat0, 0.0, 1.0);
    u_xlat16_1.x = (-u_xlat0) + 1.0;
    u_xlat16_1.xyz = u_xlat16_1.xxx * unity_FogColor.xyz;
    u_xlat16_2 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_2 = u_xlat16_2 * _BaseColor;
    u_xlat16_3.xyz = vs_COLOR0.xyz * _BaseColorAddSubDiff.xxx + u_xlat16_2.xyz;
    u_xlat16_16 = u_xlat16_2.w * vs_COLOR0.w;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + abs(u_xlat16_3.xyz);
    u_xlat16_3.xyz = _BaseColorAddSubDiff.yyy * u_xlat16_4.xyz + u_xlat16_3.xyz;
    SV_Target0.xyz = u_xlat16_3.xyz * vec3(u_xlat0) + u_xlat16_1.xyz;
    u_xlatb0 = _Surface==1.0;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_16 : 1.0;
    return;
}

#endif


// ===== program 15: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
UNITY_BINDING(0) uniform UnityPerMaterial {
	vec4 Xhlslcc_UnusedX_SoftParticleFadeParams;
	vec4 Xhlslcc_UnusedX_CameraFadeParams;
	vec4 Xhlslcc_UnusedX_BaseMap_ST;
	vec4 Xhlslcc_UnusedX_BaseMap_TexelSize;
	mediump vec4                _BaseColor;
	mediump vec4 Xhlslcc_UnusedX_EmissionColor;
	mediump vec4                _BaseColorAddSubDiff;
	mediump float Xhlslcc_UnusedX_Cutoff;
	mediump float Xhlslcc_UnusedX_DistortionStrengthScaled;
	mediump float Xhlslcc_UnusedX_DistortionBlend;
	mediump float                _Surface;
};
UNITY_LOCATION(0) uniform mediump sampler2D _BaseMap;
layout(location = 0) in highp  vec2 vs_TEXCOORD0;
layout(location = 1) in mediump  vec4 vs_COLOR0;
layout(location = 2) in highp  vec4 vs_TEXCOORD1;
layout(location = 0) out mediump vec4 SV_Target0;
float u_xlat0;
bool u_xlatb0;
mediump vec3 u_xlat16_1;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump float u_xlat16_16;
void main()
{
    u_xlat0 = vs_TEXCOORD1.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[0].z * vs_TEXCOORD1.x + u_xlat0;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixV[2].z * vs_TEXCOORD1.z + u_xlat0;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0 = (-u_xlat0) + (-_ProjectionParams.y);
    u_xlat0 = max(u_xlat0, 0.0);
    u_xlat0 = u_xlat0 * unity_FogParams.z + unity_FogParams.w;
    u_xlat0 = clamp(u_xlat0, 0.0, 1.0);
    u_xlat16_1.x = (-u_xlat0) + 1.0;
    u_xlat16_1.xyz = u_xlat16_1.xxx * unity_FogColor.xyz;
    u_xlat16_2 = texture(_BaseMap, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_2 = u_xlat16_2 * _BaseColor;
    u_xlat16_3.xyz = vs_COLOR0.xyz * _BaseColorAddSubDiff.xxx + u_xlat16_2.xyz;
    u_xlat16_16 = u_xlat16_2.w * vs_COLOR0.w;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + abs(u_xlat16_3.xyz);
    u_xlat16_3.xyz = _BaseColorAddSubDiff.yyy * u_xlat16_4.xyz + u_xlat16_3.xyz;
    SV_Target0.xyz = u_xlat16_3.xyz * vec3(u_xlat0) + u_xlat16_1.xyz;
    u_xlatb0 = _Surface==1.0;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_16 : 1.0;
    return;
}

#endif


// ===== program 16: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
vec4 u_xlat0;
vec4 u_xlat1;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump float SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.z;
    return;
}

#endif


// ===== program 17: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump float SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.z;
    return;
}

#endif


// ===== program 18: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	int unity_BaseInstanceID;
 struct unity_ParticleInstanceData_type {
	uint[14] value;
};

layout(std430, binding = 0) readonly buffer unity_ParticleInstanceData {
	unity_ParticleInstanceData_type unity_ParticleInstanceData_buf[];
};
in highp vec4 in_POSITION0;
layout(location = 0) flat out highp uint vs_SV_InstanceID0;
vec4 u_xlat0;
float u_xlat1;
int u_xlati1;
vec4 u_xlat2;
vec4 u_xlat3;
vec4 u_xlat4;
vec3 u_xlat5;
vec3 u_xlat7;
void main()
{
    u_xlat0.xyz = in_POSITION0.xyz;
    u_xlat0.w = 1.0;
    u_xlati1 = gl_InstanceID + unity_BaseInstanceID;
    u_xlat2.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 1]));
    u_xlat3.x = u_xlat2.z;
    u_xlat4.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 2]));
    u_xlat3.y = u_xlat4.x;
    u_xlat7.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 2]));
    u_xlat5.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 2]));
    u_xlat3.z = u_xlat7.y;
    u_xlat3.w = u_xlat5.y;
    u_xlat1 = dot(u_xlat3, u_xlat0);
    u_xlat3 = vec4(u_xlat1) * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat4.x = u_xlat2.y;
    u_xlat2.y = u_xlat4.z;
    u_xlat4.z = u_xlat7.x;
    u_xlat2.z = u_xlat7.z;
    u_xlat4.w = u_xlat5.x;
    u_xlat2.w = u_xlat5.z;
    u_xlat1 = dot(u_xlat2, u_xlat0);
    u_xlat0.x = dot(u_xlat4, u_xlat0);
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat3;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * vec4(u_xlat1) + u_xlat0;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_SV_InstanceID0 =  uint(gl_InstanceID);
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) out mediump float SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.z;
    return;
}

#endif


// ===== program 19: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) out mediump float SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.z;
    return;
}

#endif


// ===== program 20: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
out highp vec3 vs_TEXCOORD2;
highp vec3 vs_TEXCOORD3;
vec3 u_xlat0;
vec4 u_xlat1;
mediump vec3 u_xlat16_2;
float u_xlat9;
bool u_xlatb9;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat9 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat9 = max(u_xlat9, 1.17549435e-38);
    u_xlat9 = inversesqrt(u_xlat9);
    vs_TEXCOORD2.xyz = vec3(u_xlat9) * u_xlat1.xyz;
    u_xlat9 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat9 = inversesqrt(u_xlat9);
    u_xlat0.xyz = vec3(u_xlat9) * u_xlat0.xyz;
    u_xlatb9 = unity_OrthoParams.w==0.0;
    u_xlat16_2.x = (u_xlatb9) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat16_2.y = (u_xlatb9) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat16_2.z = (u_xlatb9) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD3.xyz = u_xlat16_2.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
in highp  vec3 vs_TEXCOORD2;
layout(location = 0) out mediump vec4 SV_TARGET0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_TEXCOORD2.xyz, vs_TEXCOORD2.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_TEXCOORD2.xyz;
    SV_TARGET0.xyz = u_xlat0.xyz;
    SV_TARGET0.w = 0.0;
    return;
}

#endif


// ===== program 21: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
in highp  vec3 vs_TEXCOORD2;
layout(location = 0) out mediump vec4 SV_TARGET0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_TEXCOORD2.xyz, vs_TEXCOORD2.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_TEXCOORD2.xyz;
    SV_TARGET0.xyz = u_xlat0.xyz;
    SV_TARGET0.w = 0.0;
    return;
}

#endif


// ===== program 22: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 unity_OrthoParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	int unity_BaseInstanceID;
 struct unity_ParticleInstanceData_type {
	uint[14] value;
};

layout(std430, binding = 0) readonly buffer unity_ParticleInstanceData {
	unity_ParticleInstanceData_type unity_ParticleInstanceData_buf[];
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
layout(location = 0) out highp vec3 vs_TEXCOORD2;
layout(location = 1) out highp vec3 vs_TEXCOORD3;
layout(location = 2) flat out highp uint vs_SV_InstanceID0;
vec4 u_xlat0;
vec3 u_xlat1;
int u_xlati1;
vec4 u_xlat2;
vec3 u_xlat3;
vec4 u_xlat4;
vec4 u_xlat5;
vec3 u_xlat6;
vec4 u_xlat7;
mediump vec3 u_xlat16_8;
vec3 u_xlat10;
float u_xlat27;
bool u_xlatb27;
void main()
{
    u_xlat0.xyz = in_POSITION0.xyz;
    u_xlat0.w = 1.0;
    u_xlati1 = gl_InstanceID + unity_BaseInstanceID;
    u_xlat10.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(36 >> 2) + 2]));
    u_xlat2.w = u_xlat10.y;
    u_xlat3.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(12 >> 2) + 2]));
    u_xlat2.y = u_xlat3.y;
    u_xlat4.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 1]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(24 >> 2) + 0]));
    u_xlat5.xyz = vec3(uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 2]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 0]), uintBitsToFloat(unity_ParticleInstanceData_buf[u_xlati1].value[(0 >> 2) + 1]));
    u_xlat2.z = u_xlat4.x;
    u_xlat2.x = u_xlat5.z;
    u_xlat6.y = dot(u_xlat2, u_xlat0);
    u_xlat7 = u_xlat6.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat4.w = u_xlat10.x;
    u_xlat5.w = u_xlat10.z;
    u_xlat5.z = u_xlat4.y;
    u_xlat4.x = u_xlat5.y;
    u_xlat4.y = u_xlat3.x;
    u_xlat5.y = u_xlat3.z;
    u_xlat6.x = dot(u_xlat4, u_xlat0);
    u_xlat6.z = dot(u_xlat5, u_xlat0);
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat6.xxxx + u_xlat7;
    u_xlat1.xyz = (-u_xlat6.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat6.zzzz + u_xlat0;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat0.xyz = u_xlat4.yzx * u_xlat5.zxy;
    u_xlat0.xyz = u_xlat4.zxy * u_xlat5.yzx + (-u_xlat0.xyz);
    u_xlat3.xyz = u_xlat2.zxy * u_xlat5.yzx;
    u_xlat3.xyz = u_xlat2.yzx * u_xlat5.zxy + (-u_xlat3.xyz);
    u_xlat27 = dot(u_xlat4.xyz, u_xlat3.xyz);
    u_xlat27 = float(1.0) / float(u_xlat27);
    u_xlat0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat0.y = dot(in_NORMAL0.xyz, u_xlat0.xyz);
    u_xlat5.xyz = u_xlat2.yzx * u_xlat4.zxy;
    u_xlat2.xyz = u_xlat4.yzx * u_xlat2.zxy + (-u_xlat5.xyz);
    u_xlat2.xyz = vec3(u_xlat27) * u_xlat2.xyz;
    u_xlat3.xyz = vec3(u_xlat27) * u_xlat3.xyz;
    u_xlat0.x = dot(in_NORMAL0.xyz, u_xlat3.xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, u_xlat2.xyz);
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = max(u_xlat27, 1.17549435e-38);
    u_xlat27 = inversesqrt(u_xlat27);
    vs_TEXCOORD2.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * u_xlat1.xyz;
    u_xlatb27 = unity_OrthoParams.w==0.0;
    u_xlat16_8.x = (u_xlatb27) ? u_xlat0.x : hlslcc_mtx4x4unity_MatrixV[0].z;
    u_xlat16_8.y = (u_xlatb27) ? u_xlat0.y : hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat16_8.z = (u_xlatb27) ? u_xlat0.z : hlslcc_mtx4x4unity_MatrixV[2].z;
    vs_TEXCOORD3.xyz = u_xlat16_8.xyz;
    vs_SV_InstanceID0 =  uint(gl_InstanceID);
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) in highp  vec3 vs_TEXCOORD2;
layout(location = 0) out mediump vec4 SV_TARGET0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_TEXCOORD2.xyz, vs_TEXCOORD2.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_TEXCOORD2.xyz;
    SV_TARGET0.xyz = u_xlat0.xyz;
    SV_TARGET0.w = 0.0;
    return;
}

#endif


// ===== program 23: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) in highp  vec3 vs_TEXCOORD2;
layout(location = 0) out mediump vec4 SV_TARGET0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_TEXCOORD2.xyz, vs_TEXCOORD2.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_TEXCOORD2.xyz;
    SV_TARGET0.xyz = u_xlat0.xyz;
    SV_TARGET0.w = 0.0;
    return;
}

#endif

