// Soccer/T3ThresholdFX (Shader path ID 2976956620046100945, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_1[4];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex0_ST;
	UNITY_UNIFORM float                _ColorTex0_R;
	UNITY_UNIFORM int                _ColorTex0Index;
	UNITY_UNIFORM vec4                _ColorTex0UVTileController;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex1_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex2_ST;
	UNITY_UNIFORM vec4                _MaskTex0_ST;
	UNITY_UNIFORM float                _MaskTex0_R;
	UNITY_UNIFORM int                _MaskTex0Index;
	UNITY_UNIFORM vec4                _MaskTex0UVTileController;
	UNITY_UNIFORM vec4                _MaskTex1_ST;
	UNITY_UNIFORM float                _MaskTex1_R;
	UNITY_UNIFORM int                _MaskTex1Index;
	UNITY_UNIFORM vec4                _MaskTex1UVTileController;
	UNITY_UNIFORM vec4                _FlowTex_ST;
	UNITY_UNIFORM float                _FlowTex_R;
	UNITY_UNIFORM int                _FlowTexIndex;
	UNITY_UNIFORM vec4                _FlowTexUVTileController;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM vec4                _SecondColor;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorRGIndex;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorBAIndex;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM uint                _TransparencyController;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM float                _VertexAlphaThresholdMode;
	UNITY_UNIFORM float                _ColorBorderMin0;
	UNITY_UNIFORM float                _ColorBorderMax0;
	UNITY_UNIFORM uint                _ColorBorderMax0Controller;
	UNITY_UNIFORM float                _ColorBorderMin1;
	UNITY_UNIFORM float                _ColorBorderMax1;
	UNITY_UNIFORM uint                _ColorBorderMax1Controller;
	UNITY_UNIFORM float                _ColorBorderMin2;
	UNITY_UNIFORM uint                _ColorBorderMin2Controller;
	UNITY_UNIFORM float                _ColorBorderMax2;
	UNITY_UNIFORM uint                _ColorBorderMax2Controller;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParThresholdMode;
	UNITY_UNIFORM float                _M0PatternX;
	UNITY_UNIFORM float                _M0PatternY;
	UNITY_UNIFORM float                _M0PatternFadeAnime;
	UNITY_UNIFORM uint                _M0PatternFadeAnimeController;
	UNITY_UNIFORM float                _M0FlowScale0;
	UNITY_UNIFORM uint                _M0FlowScale0Controller;
	UNITY_UNIFORM float                _M0FlowScale2;
	UNITY_UNIFORM uint                _M0FlowScale2Controller;
	UNITY_UNIFORM float                _FlowScale0;
	UNITY_UNIFORM uint                _FlowScale0Controller;
	UNITY_UNIFORM float                _FlowScale1;
	UNITY_UNIFORM uint                _FlowScale1Controller;
	UNITY_UNIFORM float                _FlowScale2;
	UNITY_UNIFORM uint                _FlowScale2Controller;
	UNITY_UNIFORM float                _EdgeMaskWidth;
	UNITY_UNIFORM uint                _EdgeMaskWidthController;
	UNITY_UNIFORM float                _EdgeMaskOffset;
	UNITY_UNIFORM uint                _EdgeMaskOffsetController;
	UNITY_UNIFORM float                _ColorProjType;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM uint                _LuminanceController;
	UNITY_UNIFORM float                _DebugMode;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in highp vec4 in_COLOR0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
out highp vec4 vs_COLOR0;
out highp vec4 vs_TEXCOORD0;
out highp vec4 vs_TEXCOORD1;
out highp vec4 vs_TEXCOORD2;
out highp vec3 vs_TEXCOORD3;
out highp vec3 vs_TEXCOORD4;
out highp vec3 vs_TEXCOORD5;
out highp vec4 vs_TEXCOORD6;
out highp vec4 vs_TEXCOORD7;
vec4 u_xlat0;
vec4 u_xlat1;
vec4 u_xlat2;
int u_xlati2;
uvec4 u_xlatu2;
vec4 u_xlat3;
uvec4 u_xlatu3;
bvec4 u_xlatb3;
vec4 u_xlat4;
bvec4 u_xlatb4;
vec4 u_xlat5;
bvec4 u_xlatb5;
vec4 u_xlat6;
bvec4 u_xlatb6;
vec4 u_xlat7;
mediump float u_xlat16_7;
int u_xlati7;
uvec3 u_xlatu7;
bvec2 u_xlatb7;
vec3 u_xlat8;
mediump float u_xlat16_8;
int u_xlati8;
uint u_xlatu8;
vec3 u_xlat9;
mediump float u_xlat16_9;
int u_xlati9;
uint u_xlatu9;
bvec3 u_xlatb9;
vec4 u_xlat10;
mediump float u_xlat16_11;
vec3 u_xlat12;
vec2 u_xlat13;
mediump float u_xlat16_13;
int u_xlati13;
uint u_xlatu13;
bool u_xlatb13;
float u_xlat14;
vec2 u_xlat17;
int u_xlati22;
uint u_xlatu22;
vec2 u_xlat23;
uint u_xlatu23;
vec2 u_xlat28;
uint u_xlatu28;
bool u_xlatb28;
vec2 u_xlat32;
int u_xlati32;
uint u_xlatu32;
bool u_xlatb32;
vec2 u_xlat33;
vec2 u_xlat34;
vec2 u_xlat36;
mediump float u_xlat16_36;
ivec2 u_xlati36;
uvec2 u_xlatu36;
bvec2 u_xlatb36;
vec2 u_xlat37;
int u_xlati37;
uint u_xlatu37;
bvec2 u_xlatb37;
vec2 u_xlat38;
vec2 u_xlat39;
uint u_xlatu39;
bvec2 u_xlatb39;
vec2 u_xlat43;
float u_xlat45;
mediump float u_xlat16_45;
int u_xlati45;
uint u_xlatu45;
bool u_xlatb45;
float u_xlat49;
mediump float u_xlat16_49;
int u_xlati49;
uint u_xlatu49;
bool u_xlatb49;
float u_xlat50;
mediump float u_xlat16_50;
int u_xlati50;
uint u_xlatu50;
bool u_xlatb50;
uint u_xlatu51;
int u_xlati52;
uint u_xlatu52;
float u_xlat55;
mediump float u_xlat16_55;
int u_xlati55;
uint u_xlatu55;
bool u_xlatb55;
mediump float u_xlat16_57;
int u_xlati57;
uint u_xlatu57;
bool u_xlatb57;
void main()
{
ImmCB_1[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_1[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_1[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_1[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat1 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlatu2 = uvec4(_MaskTex0UVTileController);
    u_xlatb3 = lessThan(uvec4(uint(0u), uint(0u), uint(0u), uint(0u)), u_xlatu2);
    u_xlatb4 = greaterThanEqual(uvec4(8u, 8u, 8u, 8u), u_xlatu2);
    u_xlatb3.x = u_xlatb3.x && u_xlatb4.x;
    u_xlatb3.y = u_xlatb3.y && u_xlatb4.y;
    u_xlatb3.z = u_xlatb3.z && u_xlatb4.z;
    u_xlatb3.w = u_xlatb3.w && u_xlatb4.w;
    if(u_xlatb3.x){
        u_xlatu45 = u_xlatu2.x + 4294967295u;
        u_xlati2 = int(uint(u_xlatu45 & 1u));
        u_xlatu45 = uint(u_xlatu45 >> (1u & uint(0x1F)));
        u_xlat4 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu45)].xxyy;
        u_xlat4.xy = u_xlat4.xy + u_xlat4.zw;
        u_xlat4.xy = ImmCB_1[int(u_xlatu45)].zz * in_TEXCOORD2.xy + u_xlat4.xy;
        u_xlat4.xy = ImmCB_1[int(u_xlatu45)].ww * in_TEXCOORD2.zw + u_xlat4.xy;
        u_xlat45 = dot(u_xlat4.xy, ImmCB_1[u_xlati2].xy);
        u_xlat4.x = u_xlat45 * _MaskTex0_ST.x;
    } else {
        u_xlat4.x = _MaskTex0_ST.x;
    }
    if(u_xlatb3.y){
        u_xlatu45 = u_xlatu2.y + 4294967295u;
        u_xlati2 = int(uint(u_xlatu45 & 1u));
        u_xlatu45 = uint(u_xlatu45 >> (1u & uint(0x1F)));
        u_xlat5 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu45)].xxyy;
        u_xlat3.xy = u_xlat5.xy + u_xlat5.zw;
        u_xlat3.xy = ImmCB_1[int(u_xlatu45)].zz * in_TEXCOORD2.xy + u_xlat3.xy;
        u_xlat3.xy = ImmCB_1[int(u_xlatu45)].ww * in_TEXCOORD2.zw + u_xlat3.xy;
        u_xlat45 = dot(u_xlat3.xy, ImmCB_1[u_xlati2].xy);
        u_xlat4.y = u_xlat45 * _MaskTex0_ST.y;
    } else {
        u_xlat4.y = _MaskTex0_ST.y;
    }
    if(u_xlatb3.z){
        u_xlatu45 = u_xlatu2.z + 4294967295u;
        u_xlati2 = int(uint(u_xlatu45 & 1u));
        u_xlatu45 = uint(u_xlatu45 >> (1u & uint(0x1F)));
        u_xlat5 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu45)].xxyy;
        u_xlat17.xy = u_xlat5.xy + u_xlat5.zw;
        u_xlat17.xy = ImmCB_1[int(u_xlatu45)].zz * in_TEXCOORD2.xy + u_xlat17.xy;
        u_xlat17.xy = ImmCB_1[int(u_xlatu45)].ww * in_TEXCOORD2.zw + u_xlat17.xy;
        u_xlat2.x = dot(u_xlat17.xy, ImmCB_1[u_xlati2].xy);
    } else {
        u_xlat2.x = _MaskTex0_ST.z;
    }
    if(u_xlatb3.w){
        u_xlatu45 = u_xlatu2.w + 4294967295u;
        u_xlati32 = int(uint(u_xlatu45 & 1u));
        u_xlatu45 = uint(u_xlatu45 >> (1u & uint(0x1F)));
        u_xlat3 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu45)].xxyy;
        u_xlat3.xy = u_xlat3.xy + u_xlat3.zw;
        u_xlat3.xy = ImmCB_1[int(u_xlatu45)].zz * in_TEXCOORD2.xy + u_xlat3.xy;
        u_xlat3.xy = ImmCB_1[int(u_xlatu45)].ww * in_TEXCOORD2.zw + u_xlat3.xy;
        u_xlat2.y = dot(u_xlat3.xy, ImmCB_1[u_xlati32].xy);
    } else {
        u_xlat2.y = _MaskTex0_ST.w;
    }
    u_xlatu3 = uvec4(_FlowTexUVTileController);
    u_xlatb5 = lessThan(uvec4(uint(0u), uint(0u), uint(0u), uint(0u)), u_xlatu3);
    u_xlatb6 = greaterThanEqual(uvec4(8u, 8u, 8u, 8u), u_xlatu3);
    u_xlatb5.x = u_xlatb5.x && u_xlatb6.x;
    u_xlatb5.y = u_xlatb5.y && u_xlatb6.y;
    u_xlatb5.z = u_xlatb5.z && u_xlatb6.z;
    u_xlatb5.w = u_xlatb5.w && u_xlatb6.w;
    if(u_xlatb5.x){
        u_xlatu45 = u_xlatu3.x + 4294967295u;
        u_xlati32 = int(uint(u_xlatu45 & 1u));
        u_xlatu45 = uint(u_xlatu45 >> (1u & uint(0x1F)));
        u_xlat6 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu45)].xxyy;
        u_xlat34.xy = u_xlat6.xy + u_xlat6.zw;
        u_xlat34.xy = ImmCB_1[int(u_xlatu45)].zz * in_TEXCOORD2.xy + u_xlat34.xy;
        u_xlat34.xy = ImmCB_1[int(u_xlatu45)].ww * in_TEXCOORD2.zw + u_xlat34.xy;
        u_xlat45 = dot(u_xlat34.xy, ImmCB_1[u_xlati32].xy);
        u_xlat6.x = u_xlat45 * _FlowTex_ST.x;
    } else {
        u_xlat6.x = _FlowTex_ST.x;
    }
    if(u_xlatb5.y){
        u_xlatu45 = u_xlatu3.y + 4294967295u;
        u_xlati32 = int(uint(u_xlatu45 & 1u));
        u_xlatu45 = uint(u_xlatu45 >> (1u & uint(0x1F)));
        u_xlat7 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu45)].xxyy;
        u_xlat3.xy = u_xlat7.xy + u_xlat7.zw;
        u_xlat3.xy = ImmCB_1[int(u_xlatu45)].zz * in_TEXCOORD2.xy + u_xlat3.xy;
        u_xlat3.xy = ImmCB_1[int(u_xlatu45)].ww * in_TEXCOORD2.zw + u_xlat3.xy;
        u_xlat45 = dot(u_xlat3.xy, ImmCB_1[u_xlati32].xy);
        u_xlat6.y = u_xlat45 * _FlowTex_ST.y;
    } else {
        u_xlat6.y = _FlowTex_ST.y;
    }
    if(u_xlatb5.z){
        u_xlatu45 = u_xlatu3.z + 4294967295u;
        u_xlati32 = int(uint(u_xlatu45 & 1u));
        u_xlatu45 = uint(u_xlatu45 >> (1u & uint(0x1F)));
        u_xlat7 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu45)].xxyy;
        u_xlat3.xy = u_xlat7.xy + u_xlat7.zw;
        u_xlat3.xy = ImmCB_1[int(u_xlatu45)].zz * in_TEXCOORD2.xy + u_xlat3.xy;
        u_xlat3.xy = ImmCB_1[int(u_xlatu45)].ww * in_TEXCOORD2.zw + u_xlat3.xy;
        u_xlat3.x = dot(u_xlat3.xy, ImmCB_1[u_xlati32].xy);
    } else {
        u_xlat3.x = _FlowTex_ST.z;
    }
    if(u_xlatb5.w){
        u_xlatu45 = u_xlatu3.w + 4294967295u;
        u_xlati32 = int(uint(u_xlatu45 & 1u));
        u_xlatu45 = uint(u_xlatu45 >> (1u & uint(0x1F)));
        u_xlat5 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu45)].xxyy;
        u_xlat33.xy = u_xlat5.xy + u_xlat5.zw;
        u_xlat33.xy = ImmCB_1[int(u_xlatu45)].zz * in_TEXCOORD2.xy + u_xlat33.xy;
        u_xlat33.xy = ImmCB_1[int(u_xlatu45)].ww * in_TEXCOORD2.zw + u_xlat33.xy;
        u_xlat3.y = dot(u_xlat33.xy, ImmCB_1[u_xlati32].xy);
    } else {
        u_xlat3.y = _FlowTex_ST.w;
    }
    u_xlatb5.xyz = lessThan(in_COLOR0.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat7.xyz = in_COLOR0.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    u_xlat8.xyz = max(in_COLOR0.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat8.xyz = u_xlat8.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat8.xyz = log2(u_xlat8.xyz);
    u_xlat8.xyz = u_xlat8.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat8.xyz = exp2(u_xlat8.xyz);
    u_xlat5.x = (u_xlatb5.x) ? u_xlat7.x : u_xlat8.x;
    u_xlat5.y = (u_xlatb5.y) ? u_xlat7.y : u_xlat8.y;
    u_xlat5.z = (u_xlatb5.z) ? u_xlat7.z : u_xlat8.z;
    u_xlat7.xyz = u_xlat5.xyz * _Color.xyz;
    u_xlat8.xyz = in_COLOR0.xyz * _Color.xyz;
    u_xlatb9.xyz = lessThan(u_xlat8.xyzx, vec4(0.0404499993, 0.0404499993, 0.0404499993, 0.0)).xyz;
    u_xlat10.xyz = u_xlat8.xyz * vec3(0.0773993805, 0.0773993805, 0.0773993805);
    u_xlat8.xyz = max(u_xlat8.xyz, vec3(0.0, 0.0, 0.0));
    u_xlat8.xyz = u_xlat8.xyz * vec3(0.947867274, 0.947867274, 0.947867274) + vec3(0.0521326996, 0.0521326996, 0.0521326996);
    u_xlat8.xyz = log2(u_xlat8.xyz);
    u_xlat8.xyz = u_xlat8.xyz * vec3(2.4000001, 2.4000001, 2.4000001);
    u_xlat8.xyz = exp2(u_xlat8.xyz);
    {
        vec3 hlslcc_movcTemp = u_xlat8;
        hlslcc_movcTemp.x = (u_xlatb9.x) ? u_xlat10.x : u_xlat8.x;
        hlslcc_movcTemp.y = (u_xlatb9.y) ? u_xlat10.y : u_xlat8.y;
        hlslcc_movcTemp.z = (u_xlatb9.z) ? u_xlat10.z : u_xlat8.z;
        u_xlat8 = hlslcc_movcTemp;
    }
    u_xlat5.xyz = (-u_xlat5.xyz) * _Color.xyz + u_xlat8.xyz;
    u_xlat5.xyz = vec3(vec3(_IsGammaColor, _IsGammaColor, _IsGammaColor)) * u_xlat5.xyz + u_xlat7.xyz;
    u_xlatb45 = int(_ColorBorderMax2Controller)==0;
    u_xlatb32 = 8u<_ColorBorderMax2Controller;
    u_xlatb45 = u_xlatb45 || u_xlatb32;
    if(!u_xlatb45){
        u_xlatu45 = _ColorBorderMax2Controller + 4294967295u;
        u_xlatu32 = uint(u_xlatu45 >> (1u & uint(0x1F)));
        u_xlati45 = int(uint(u_xlatu45 & 1u));
        u_xlat7 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu32)].xxyy;
        u_xlat33.xy = u_xlat7.xy + u_xlat7.zw;
        u_xlat33.xy = ImmCB_1[int(u_xlatu32)].zz * in_TEXCOORD2.xy + u_xlat33.xy;
        u_xlat32.xy = ImmCB_1[int(u_xlatu32)].ww * in_TEXCOORD2.zw + u_xlat33.xy;
        u_xlat16_45 = dot(u_xlat32.xy, ImmCB_1[u_xlati45].xy);
    } else {
        u_xlat16_45 = _ColorBorderMax2;
    }
    u_xlat34.x = u_xlat16_45 * in_COLOR0.w + (-u_xlat16_45);
    u_xlat34.x = _VertexAlphaThresholdMode * u_xlat34.x + u_xlat16_45;
    u_xlat49 = (-in_COLOR0.w) + 1.0;
    vs_COLOR0.w = _VertexAlphaThresholdMode * u_xlat49 + in_COLOR0.w;
    u_xlat7.xz = u_xlat1.xw * vec2(0.5, 0.5);
    u_xlat49 = u_xlat1.y * _ProjectionParams.x;
    u_xlat7.w = u_xlat49 * 0.5;
    u_xlat36.xy = u_xlat7.zz + u_xlat7.xw;
    u_xlatb49 = 9.99999975e-05<abs(u_xlat1.w);
    u_xlatb50 = u_xlat1.w>=0.0;
    u_xlat50 = (u_xlatb50) ? 9.99999975e-05 : -9.99999975e-05;
    u_xlat49 = (u_xlatb49) ? u_xlat1.w : u_xlat50;
    u_xlat36.xy = u_xlat36.xy / vec2(u_xlat49);
    u_xlatb49 = _ColorTex0Index==1;
    u_xlat7.xy = (bool(u_xlatb49)) ? in_TEXCOORD0.zw : in_TEXCOORD0.xy;
    u_xlat36.xy = u_xlat36.xy + (-u_xlat7.xy);
    vs_TEXCOORD0.xy = vec2(vec2(_ColorProjType, _ColorProjType)) * u_xlat36.xy + u_xlat7.xy;
    u_xlatb49 = _MaskTex0Index==1;
    u_xlat36.xy = (bool(u_xlatb49)) ? in_TEXCOORD0.zw : in_TEXCOORD0.xy;
    u_xlat36.xy = (-u_xlat2.xy) + u_xlat36.xy;
    u_xlat49 = _MaskTex0_R * 0.0174532924;
    u_xlat7.x = sin(u_xlat49);
    u_xlat8.x = cos(u_xlat49);
    u_xlat9.x = (-u_xlat7.x);
    u_xlat9.y = u_xlat8.x;
    u_xlat9.z = u_xlat7.x;
    u_xlat7.x = dot(u_xlat36.xy, u_xlat9.yz);
    u_xlat7.y = dot(u_xlat36.xy, u_xlat9.xy);
    u_xlat36.xy = max(abs(u_xlat4.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlatb4.xy = greaterThanEqual(u_xlat4.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat4.x = (u_xlatb4.x) ? float(1.0) : float(-1.0);
    u_xlat4.y = (u_xlatb4.y) ? float(1.0) : float(-1.0);
    u_xlat4.xy = u_xlat4.xy * u_xlat36.xy;
    u_xlat4.xy = u_xlat7.xy / u_xlat4.xy;
    u_xlatb49 = int(_M0PatternFadeAnimeController)==0;
    u_xlatb50 = 8u<_M0PatternFadeAnimeController;
    u_xlatb49 = u_xlatb49 || u_xlatb50;
    if(!u_xlatb49){
        u_xlatu49 = _M0PatternFadeAnimeController + 4294967295u;
        u_xlatu50 = uint(u_xlatu49 >> (1u & uint(0x1F)));
        u_xlati49 = int(uint(u_xlatu49 & 1u));
        u_xlat2 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu50)].xxyy;
        u_xlat36.xy = u_xlat2.xy + u_xlat2.zw;
        u_xlat36.xy = ImmCB_1[int(u_xlatu50)].zz * in_TEXCOORD2.xy + u_xlat36.xy;
        u_xlat36.xy = ImmCB_1[int(u_xlatu50)].ww * in_TEXCOORD2.zw + u_xlat36.xy;
        u_xlat16_49 = dot(u_xlat36.xy, ImmCB_1[u_xlati49].xy);
    } else {
        u_xlat16_49 = _M0PatternFadeAnime;
    }
    u_xlat16_11 = trunc(u_xlat16_49);
    u_xlati50 = int(u_xlat16_11);
    u_xlati36.xy = ivec2(vec2(_M0PatternX, _M0PatternY));
    u_xlatu36.xy =  uvec2(max(u_xlati36.xy, ivec2(1, 1)));
    u_xlati7 = int(uint(uint(u_xlati50) & 2147483648u));
    u_xlatu22 =  uint(max(u_xlati50, (-u_xlati50)));
    {
        uint quo = u_xlatu22 / u_xlatu36.x;
        uint rem = u_xlatu22 % u_xlatu36.x;
        u_xlatu8 = quo;
        u_xlatu9 = rem;
    }
    u_xlatu22 =  uint(0 - int(u_xlatu9));
    u_xlatu7.x = (u_xlati7 != 0) ? u_xlatu22 : u_xlatu9;
    u_xlati22 = int(uint(uint(u_xlati50) ^ u_xlatu36.x));
    u_xlatu37 =  uint(0 - int(u_xlatu8));
    u_xlati22 = int(uint(uint(u_xlati22) & 2147483648u));
    u_xlatu22 = (u_xlati22 != 0) ? u_xlatu37 : u_xlatu8;
    u_xlati37 = int(uint(u_xlatu22 & 2147483648u));
    u_xlatu22 =  uint(max(int(u_xlatu22), (-int(u_xlatu22))));
    {
        uint rem = u_xlatu22 % u_xlatu36.y;
        u_xlatu22 = rem;
    }
    u_xlatu52 =  uint(0 - int(u_xlatu22));
    u_xlatu7.y = (u_xlati37 != 0) ? u_xlatu52 : u_xlatu22;
    u_xlati50 = u_xlati50 + 1;
    u_xlati37 = int(uint(uint(u_xlati50) & 2147483648u));
    u_xlatu52 =  uint(max(u_xlati50, (-u_xlati50)));
    {
        uint quo = u_xlatu52 / u_xlatu36.x;
        uint rem = u_xlatu52 % u_xlatu36.x;
        u_xlatu8 = quo;
        u_xlatu9 = rem;
    }
    u_xlatu52 =  uint(0 - int(u_xlatu9));
    u_xlatu7.z = (u_xlati37 != 0) ? u_xlatu52 : u_xlatu9;
    u_xlat7.xyz = vec3(ivec3(u_xlatu7.xyz));
    u_xlati50 = int(uint(u_xlatu36.x ^ uint(u_xlati50)));
    u_xlatu52 =  uint(0 - int(u_xlatu8));
    u_xlati50 = int(uint(uint(u_xlati50) & 2147483648u));
    u_xlatu50 = (u_xlati50 != 0) ? u_xlatu52 : u_xlatu8;
    u_xlati52 = int(uint(u_xlatu50 & 2147483648u));
    u_xlatu50 =  uint(max(int(u_xlatu50), (-int(u_xlatu50))));
    {
        uint rem = u_xlatu50 % u_xlatu36.y;
        u_xlatu50 = rem;
    }
    u_xlatu8 =  uint(0 - int(u_xlatu50));
    u_xlatu50 = (u_xlati52 != 0) ? u_xlatu8 : u_xlatu50;
    u_xlat50 = float(int(u_xlatu50));
    u_xlat36.xy = vec2(ivec2(u_xlatu36.xy));
    u_xlat36.xy = vec2(1.0, 1.0) / u_xlat36.xy;
    u_xlat38.x = u_xlat7.x * u_xlat36.x;
    u_xlat16_11 = (-u_xlat36.y) + 1.0;
    u_xlat38.y = (-u_xlat36.y) * u_xlat7.y + u_xlat16_11;
    vs_TEXCOORD0.zw = u_xlat4.xy * u_xlat36.xy + u_xlat38.xy;
    u_xlat7.x = u_xlat7.z * u_xlat36.x;
    u_xlat7.y = (-u_xlat36.y) * u_xlat50 + u_xlat16_11;
    vs_TEXCOORD1.xy = u_xlat4.xy * u_xlat36.xy + u_xlat7.xy;
    u_xlatb50 = u_xlat16_49>=(-u_xlat16_49);
    u_xlat50 = (u_xlatb50) ? 1.0 : -1.0;
    u_xlat36.x = u_xlat16_49 * u_xlat50;
    u_xlat36.x = fract(u_xlat36.x);
    vs_TEXCOORD4.x = u_xlat50 * u_xlat36.x;
    u_xlatb36.xy = equal(ivec4(uvec4(_M0FlowScale0Controller, _M0FlowScale2Controller, _M0FlowScale0Controller, _M0FlowScale2Controller)), ivec4(0, 0, 0, 0)).xy;
    u_xlatb7.xy = lessThan(uvec4(8u, 8u, uint(0u), uint(0u)), uvec4(_M0FlowScale0Controller, _M0FlowScale2Controller, _M0FlowScale0Controller, _M0FlowScale0Controller)).xy;
    {
        bvec2 hlslcc_orTemp = u_xlatb36;
        hlslcc_orTemp.x = u_xlatb36.x || u_xlatb7.x;
        hlslcc_orTemp.y = u_xlatb36.y || u_xlatb7.y;
        u_xlatb36 = hlslcc_orTemp;
    }
    if(!u_xlatb36.x){
        u_xlatu50 = _M0FlowScale0Controller + 4294967295u;
        u_xlatu36.x = uint(u_xlatu50 >> (1u & uint(0x1F)));
        u_xlati50 = int(uint(u_xlatu50 & 1u));
        u_xlat2 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu36.x)].xxyy;
        u_xlat7.xy = u_xlat2.xy + u_xlat2.zw;
        u_xlat7.xy = ImmCB_1[int(u_xlatu36.x)].zz * in_TEXCOORD2.xy + u_xlat7.xy;
        u_xlat7.xy = ImmCB_1[int(u_xlatu36.x)].ww * in_TEXCOORD2.zw + u_xlat7.xy;
        u_xlat16_50 = dot(u_xlat7.xy, ImmCB_1[u_xlati50].xy);
    } else {
        u_xlat16_50 = _M0FlowScale0;
    }
    if(!u_xlatb36.y){
        u_xlatu36.x = _M0FlowScale2Controller + 4294967295u;
        u_xlatu51 = uint(u_xlatu36.x >> (1u & uint(0x1F)));
        u_xlati36.x = int(uint(u_xlatu36.x & 1u));
        u_xlat2 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu51)].xxyy;
        u_xlat7.xy = u_xlat2.xy + u_xlat2.zw;
        u_xlat7.xy = ImmCB_1[int(u_xlatu51)].zz * in_TEXCOORD2.xy + u_xlat7.xy;
        u_xlat7.xy = ImmCB_1[int(u_xlatu51)].ww * in_TEXCOORD2.zw + u_xlat7.xy;
        u_xlat16_36 = dot(u_xlat7.xy, ImmCB_1[u_xlati36.x].xy);
    } else {
        u_xlat16_36 = _M0FlowScale2;
    }
    u_xlatb7.x = _MaskTex1Index==1;
    vs_TEXCOORD1.zw = (u_xlatb7.x) ? in_TEXCOORD0.zw : in_TEXCOORD0.xy;
    u_xlatb7.x = _FlowTexIndex==1;
    u_xlat7.xy = (u_xlatb7.x) ? in_TEXCOORD0.zw : in_TEXCOORD0.xy;
    u_xlat7.xy = (-u_xlat3.xy) + u_xlat7.xy;
    u_xlat37.x = _FlowTex_R * 0.0174532924;
    u_xlat8.x = sin(u_xlat37.x);
    u_xlat9.x = cos(u_xlat37.x);
    u_xlat10.x = (-u_xlat8.x);
    u_xlat10.y = u_xlat9.x;
    u_xlat10.z = u_xlat8.x;
    u_xlat8.x = dot(u_xlat7.xy, u_xlat10.yz);
    u_xlat8.y = dot(u_xlat7.xy, u_xlat10.xy);
    u_xlat7.xy = max(abs(u_xlat6.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlatb37.xy = greaterThanEqual(u_xlat6.xyxy, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat37.x = (u_xlatb37.x) ? float(1.0) : float(-1.0);
    u_xlat37.y = (u_xlatb37.y) ? float(1.0) : float(-1.0);
    u_xlat7.xy = u_xlat37.xy * u_xlat7.xy;
    vs_TEXCOORD2.xy = u_xlat8.xy / u_xlat7.xy;
    u_xlatb7.xy = equal(ivec4(uvec4(_FlowScale0Controller, _FlowScale1Controller, _FlowScale0Controller, _FlowScale0Controller)), ivec4(0, 0, 0, 0)).xy;
    u_xlatb37.xy = lessThan(uvec4(8u, 8u, 8u, 8u), uvec4(_FlowScale0Controller, _FlowScale1Controller, _FlowScale0Controller, _FlowScale1Controller)).xy;
    {
        bvec2 hlslcc_orTemp = u_xlatb7;
        hlslcc_orTemp.x = u_xlatb37.x || u_xlatb7.x;
        hlslcc_orTemp.y = u_xlatb37.y || u_xlatb7.y;
        u_xlatb7 = hlslcc_orTemp;
    }
    if(!u_xlatb7.x){
        u_xlatu7.x = _FlowScale0Controller + 4294967295u;
        u_xlatu37 = uint(u_xlatu7.x >> (1u & uint(0x1F)));
        u_xlati7 = int(uint(u_xlatu7.x & 1u));
        u_xlat2 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu37)].xxyy;
        u_xlat8.xy = u_xlat2.xy + u_xlat2.zw;
        u_xlat8.xy = ImmCB_1[int(u_xlatu37)].zz * in_TEXCOORD2.xy + u_xlat8.xy;
        u_xlat37.xy = ImmCB_1[int(u_xlatu37)].ww * in_TEXCOORD2.zw + u_xlat8.xy;
        u_xlat16_7 = dot(u_xlat37.xy, ImmCB_1[u_xlati7].xy);
    } else {
        u_xlat16_7 = _FlowScale0;
    }
    vs_TEXCOORD5.x = u_xlat16_7 * _SecondColor.w;
    if(!u_xlatb7.y){
        u_xlatu8 = _FlowScale1Controller + 4294967295u;
        u_xlatu23 = uint(u_xlatu8 >> (1u & uint(0x1F)));
        u_xlati8 = int(uint(u_xlatu8 & 1u));
        u_xlat2 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu23)].xxyy;
        u_xlat38.xy = u_xlat2.xy + u_xlat2.zw;
        u_xlat38.xy = ImmCB_1[int(u_xlatu23)].zz * in_TEXCOORD2.xy + u_xlat38.xy;
        u_xlat23.xy = ImmCB_1[int(u_xlatu23)].ww * in_TEXCOORD2.zw + u_xlat38.xy;
        u_xlat16_8 = dot(u_xlat23.xy, ImmCB_1[u_xlati8].xy);
    } else {
        u_xlat16_8 = _FlowScale1;
    }
    vs_TEXCOORD5.y = u_xlat16_8 * _SecondColor.w;
    u_xlatb9.xy = equal(ivec4(uvec4(_FlowScale2Controller, _EdgeMaskWidthController, _FlowScale2Controller, _FlowScale2Controller)), ivec4(0, 0, 0, 0)).xy;
    u_xlatb39.xy = lessThan(uvec4(8u, 8u, 8u, 8u), uvec4(_FlowScale2Controller, _EdgeMaskWidthController, _FlowScale2Controller, _EdgeMaskWidthController)).xy;
    {
        bvec3 hlslcc_orTemp = u_xlatb9;
        hlslcc_orTemp.x = u_xlatb39.x || u_xlatb9.x;
        hlslcc_orTemp.y = u_xlatb39.y || u_xlatb9.y;
        u_xlatb9 = hlslcc_orTemp;
    }
    if(!u_xlatb9.x){
        u_xlatu9 = _FlowScale2Controller + 4294967295u;
        u_xlatu39 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlati9 = int(uint(u_xlatu9 & 1u));
        u_xlat2 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu39)].xxyy;
        u_xlat10.xy = u_xlat2.xy + u_xlat2.zw;
        u_xlat10.xy = ImmCB_1[int(u_xlatu39)].zz * in_TEXCOORD2.xy + u_xlat10.xy;
        u_xlat39.xy = ImmCB_1[int(u_xlatu39)].ww * in_TEXCOORD2.zw + u_xlat10.xy;
        u_xlat16_9 = dot(u_xlat39.xy, ImmCB_1[u_xlati9].xy);
    } else {
        u_xlat16_9 = _FlowScale2;
    }
    vs_TEXCOORD5.z = u_xlat16_9 * _SecondColor.w;
    u_xlat10.x = dot(hlslcc_mtx4x4unity_ObjectToWorld[0].xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat10.w = dot(hlslcc_mtx4x4unity_ObjectToWorld[1].xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat10.xy = sqrt(u_xlat10.xw);
    u_xlat55 = dot(hlslcc_mtx4x4unity_ObjectToWorld[2].xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat10.z = sqrt(u_xlat55);
    u_xlat10.xyz = in_NORMAL0.xyz / u_xlat10.xyz;
    u_xlat12.xyz = u_xlat10.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat10.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat10.xxx + u_xlat12.xyz;
    u_xlat10.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat10.zzz + u_xlat10.xyw;
    u_xlat12.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat55 = dot(u_xlat12.xyz, u_xlat12.xyz);
    u_xlat55 = inversesqrt(u_xlat55);
    u_xlat12.xyz = vec3(u_xlat55) * u_xlat12.xyz;
    u_xlatb55 = int(_EdgeMaskOffsetController)==0;
    u_xlatb57 = 8u<_EdgeMaskOffsetController;
    u_xlatb55 = u_xlatb55 || u_xlatb57;
    if(!u_xlatb55){
        u_xlatu55 = _EdgeMaskOffsetController + 4294967295u;
        u_xlatu57 = uint(u_xlatu55 >> (1u & uint(0x1F)));
        u_xlati55 = int(uint(u_xlatu55 & 1u));
        u_xlat0 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu57)].xxyy;
        u_xlat13.xy = u_xlat0.xy + u_xlat0.zw;
        u_xlat13.xy = ImmCB_1[int(u_xlatu57)].zz * in_TEXCOORD2.xy + u_xlat13.xy;
        u_xlat13.xy = ImmCB_1[int(u_xlatu57)].ww * in_TEXCOORD2.zw + u_xlat13.xy;
        u_xlat16_55 = dot(u_xlat13.xy, ImmCB_1[u_xlati55].xy);
    } else {
        u_xlat16_55 = _EdgeMaskOffset;
    }
    if(!u_xlatb9.y){
        u_xlatu57 = _EdgeMaskWidthController + 4294967295u;
        u_xlatu13 = uint(u_xlatu57 >> (1u & uint(0x1F)));
        u_xlati57 = int(uint(u_xlatu57 & 1u));
        u_xlat0 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu13)].xxyy;
        u_xlat28.xy = u_xlat0.xy + u_xlat0.zw;
        u_xlat28.xy = ImmCB_1[int(u_xlatu13)].zz * in_TEXCOORD2.xy + u_xlat28.xy;
        u_xlat13.xy = ImmCB_1[int(u_xlatu13)].ww * in_TEXCOORD2.zw + u_xlat28.xy;
        u_xlat16_57 = dot(u_xlat13.xy, ImmCB_1[u_xlati57].xy);
    } else {
        u_xlat16_57 = _EdgeMaskWidth;
    }
    u_xlat13.x = u_xlat16_55 + u_xlat16_57;
    u_xlat13.x = clamp(u_xlat13.x, 0.0, 1.0);
    u_xlat28.x = dot(u_xlat10.xyz, u_xlat12.xyz);
    u_xlat13.x = max(u_xlat13.x, 9.99999975e-05);
    u_xlat13.x = float(1.0) / u_xlat13.x;
    u_xlat13.x = u_xlat13.x * abs(u_xlat28.x);
    u_xlat13.x = min(u_xlat13.x, 1.0);
    u_xlat13.x = (-u_xlat16_55) + u_xlat13.x;
    u_xlat28.x = (-u_xlat16_55) + 1.0;
    u_xlat28.x = max(u_xlat28.x, 9.99999975e-05);
    u_xlat28.x = float(1.0) / u_xlat28.x;
    u_xlat13.x = u_xlat28.x * u_xlat13.x;
    u_xlat13.x = max(u_xlat13.x, 0.0);
    u_xlat13.x = u_xlat34.x * u_xlat13.x;
    vs_TEXCOORD3.xyz = u_xlat13.xxx * _SecondColor.xyz;
    u_xlatb13 = int(_LuminanceController)==0;
    u_xlatb28 = 8u<_LuminanceController;
    u_xlatb13 = u_xlatb28 || u_xlatb13;
    if(!u_xlatb13){
        u_xlatu13 = _LuminanceController + 4294967295u;
        u_xlatu28 = uint(u_xlatu13 >> (1u & uint(0x1F)));
        u_xlati13 = int(uint(u_xlatu13 & 1u));
        u_xlat0 = in_TEXCOORD1 * ImmCB_1[int(u_xlatu28)].xxyy;
        u_xlat43.xy = u_xlat0.xy + u_xlat0.zw;
        u_xlat43.xy = ImmCB_1[int(u_xlatu28)].zz * in_TEXCOORD2.xy + u_xlat43.xy;
        u_xlat28.xy = ImmCB_1[int(u_xlatu28)].ww * in_TEXCOORD2.zw + u_xlat43.xy;
        u_xlat16_13 = dot(u_xlat28.xy, ImmCB_1[u_xlati13].xy);
    } else {
        u_xlat16_13 = _Luminance;
    }
    u_xlat14 = u_xlat16_13 + 1.0;
    vs_COLOR0.xyz = u_xlat5.xyz * vec3(u_xlat14);
    gl_Position = u_xlat1;
    vs_TEXCOORD2.zw = vec2(0.0, 0.0);
    vs_TEXCOORD6 = in_TEXCOORD1;
    vs_TEXCOORD7 = in_TEXCOORD2;
    vs_TEXCOORD4.y = u_xlat16_50;
    vs_TEXCOORD4.z = u_xlat16_36;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex0_ST;
	UNITY_UNIFORM float                _ColorTex0_R;
	UNITY_UNIFORM int                _ColorTex0Index;
	UNITY_UNIFORM vec4                _ColorTex0UVTileController;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex1_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex2_ST;
	UNITY_UNIFORM vec4                _MaskTex0_ST;
	UNITY_UNIFORM float                _MaskTex0_R;
	UNITY_UNIFORM int                _MaskTex0Index;
	UNITY_UNIFORM vec4                _MaskTex0UVTileController;
	UNITY_UNIFORM vec4                _MaskTex1_ST;
	UNITY_UNIFORM float                _MaskTex1_R;
	UNITY_UNIFORM int                _MaskTex1Index;
	UNITY_UNIFORM vec4                _MaskTex1UVTileController;
	UNITY_UNIFORM vec4                _FlowTex_ST;
	UNITY_UNIFORM float                _FlowTex_R;
	UNITY_UNIFORM int                _FlowTexIndex;
	UNITY_UNIFORM vec4                _FlowTexUVTileController;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM vec4                _SecondColor;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorRGIndex;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorBAIndex;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM uint                _TransparencyController;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM float                _VertexAlphaThresholdMode;
	UNITY_UNIFORM float                _ColorBorderMin0;
	UNITY_UNIFORM float                _ColorBorderMax0;
	UNITY_UNIFORM uint                _ColorBorderMax0Controller;
	UNITY_UNIFORM float                _ColorBorderMin1;
	UNITY_UNIFORM float                _ColorBorderMax1;
	UNITY_UNIFORM uint                _ColorBorderMax1Controller;
	UNITY_UNIFORM float                _ColorBorderMin2;
	UNITY_UNIFORM uint                _ColorBorderMin2Controller;
	UNITY_UNIFORM float                _ColorBorderMax2;
	UNITY_UNIFORM uint                _ColorBorderMax2Controller;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParThresholdMode;
	UNITY_UNIFORM float                _M0PatternX;
	UNITY_UNIFORM float                _M0PatternY;
	UNITY_UNIFORM float                _M0PatternFadeAnime;
	UNITY_UNIFORM uint                _M0PatternFadeAnimeController;
	UNITY_UNIFORM float                _M0FlowScale0;
	UNITY_UNIFORM uint                _M0FlowScale0Controller;
	UNITY_UNIFORM float                _M0FlowScale2;
	UNITY_UNIFORM uint                _M0FlowScale2Controller;
	UNITY_UNIFORM float                _FlowScale0;
	UNITY_UNIFORM uint                _FlowScale0Controller;
	UNITY_UNIFORM float                _FlowScale1;
	UNITY_UNIFORM uint                _FlowScale1Controller;
	UNITY_UNIFORM float                _FlowScale2;
	UNITY_UNIFORM uint                _FlowScale2Controller;
	UNITY_UNIFORM float                _EdgeMaskWidth;
	UNITY_UNIFORM uint                _EdgeMaskWidthController;
	UNITY_UNIFORM float                _EdgeMaskOffset;
	UNITY_UNIFORM uint                _EdgeMaskOffsetController;
	UNITY_UNIFORM float                _ColorProjType;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM uint                _LuminanceController;
	UNITY_UNIFORM float                _DebugMode;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex0;
UNITY_LOCATION(1) uniform mediump sampler2D _ColorTex1;
UNITY_LOCATION(2) uniform mediump sampler2D _ColorTex2;
UNITY_LOCATION(3) uniform mediump sampler2D _MaskTex0;
UNITY_LOCATION(4) uniform mediump sampler2D _MaskTex1;
UNITY_LOCATION(5) uniform mediump sampler2D _FlowTex;
in highp  vec4 vs_COLOR0;
in highp  vec4 vs_TEXCOORD0;
in highp  vec4 vs_TEXCOORD1;
in highp  vec4 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
in highp  vec3 vs_TEXCOORD5;
in highp  vec4 vs_TEXCOORD6;
in highp  vec4 vs_TEXCOORD7;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
int u_xlati0;
bool u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
uvec4 u_xlatu1;
vec4 u_xlat2;
mediump float u_xlat16_2;
int u_xlati2;
uvec4 u_xlatu2;
bvec4 u_xlatb2;
vec4 u_xlat3;
bvec4 u_xlatb3;
vec4 u_xlat4;
mediump vec3 u_xlat16_4;
int u_xlati4;
uint u_xlatu4;
bvec4 u_xlatb4;
vec4 u_xlat5;
mediump float u_xlat16_5;
int u_xlati5;
uint u_xlatu5;
bvec4 u_xlatb5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
float u_xlat8;
vec3 u_xlat9;
mediump vec2 u_xlat16_9;
uint u_xlatu9;
bool u_xlatb9;
vec2 u_xlat11;
uint u_xlatu11;
bool u_xlatb11;
vec3 u_xlat13;
uint u_xlatu13;
vec2 u_xlat14;
uint u_xlatu14;
bool u_xlatb14;
float u_xlat18;
int u_xlati18;
vec2 u_xlat19;
bvec2 u_xlatb19;
vec2 u_xlat20;
bvec2 u_xlatb20;
mediump float u_xlat16_21;
int u_xlati21;
uint u_xlatu21;
bvec2 u_xlatb21;
vec2 u_xlat23;
float u_xlat27;
mediump float u_xlat16_27;
bool u_xlatb27;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlati0 = int(_DebugMode);
    u_xlatb9 = u_xlati0==1;
    if(u_xlatb9){
        SV_Target0.xy = vs_TEXCOORD0.xy;
        SV_Target0.zw = vec2(0.0, 1.0);
        return;
    }
    u_xlatb9 = u_xlati0==2;
    if(u_xlatb9){
        SV_Target0.xyz = vs_COLOR0.xyz;
        SV_Target0.w = 1.0;
        return;
    }
    u_xlatb9 = u_xlati0==5;
    if(u_xlatb9){
        SV_Target0 = vec4(1.0, 0.0, 0.0, 1.0);
        return;
    }
    u_xlatb9 = u_xlati0==7;
    if(u_xlatb9){
        SV_Target0.xyz = vs_COLOR0.www;
        SV_Target0.w = 1.0;
        return;
    }
    u_xlatu1 = uvec4(_ColorTex0UVTileController);
    u_xlatb2 = lessThan(uvec4(uint(0u), uint(0u), uint(0u), uint(0u)), u_xlatu1);
    u_xlatb3 = greaterThanEqual(uvec4(8u, 8u, 8u, 8u), u_xlatu1);
    u_xlatb2.x = u_xlatb2.x && u_xlatb3.x;
    u_xlatb2.y = u_xlatb2.y && u_xlatb3.y;
    u_xlatb2.z = u_xlatb2.z && u_xlatb3.z;
    u_xlatb2.w = u_xlatb2.w && u_xlatb3.w;
    if(u_xlatb2.x){
        u_xlatu9 = u_xlatu1.x + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat3 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat3.xy = u_xlat3.xy + u_xlat3.zw;
        u_xlat3.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat3.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat3.xy;
        u_xlat9.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
        u_xlat3.x = u_xlat9.x * _ColorTex0_ST.x;
    } else {
        u_xlat3.x = _ColorTex0_ST.x;
    }
    if(u_xlatb2.y){
        u_xlatu9 = u_xlatu1.y + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat4 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat1.xy = u_xlat4.xy + u_xlat4.zw;
        u_xlat1.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat1.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat1.xy;
        u_xlat9.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
        u_xlat3.y = u_xlat9.x * _ColorTex0_ST.y;
    } else {
        u_xlat3.y = _ColorTex0_ST.y;
    }
    if(u_xlatb2.z){
        u_xlatu9 = u_xlatu1.z + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat4 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat1.xy = u_xlat4.xy + u_xlat4.zw;
        u_xlat1.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat1.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat1.xy;
        u_xlat1.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
    } else {
        u_xlat1.x = _ColorTex0_ST.z;
    }
    if(u_xlatb2.w){
        u_xlatu9 = u_xlatu1.w + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat2 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat19.xy = u_xlat2.xy + u_xlat2.zw;
        u_xlat19.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat19.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat19.xy;
        u_xlat1.y = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
    } else {
        u_xlat1.y = _ColorTex0_ST.w;
    }
    u_xlatu2 = uvec4(_MaskTex1UVTileController);
    u_xlatb4 = lessThan(uvec4(uint(0u), uint(0u), uint(0u), uint(0u)), u_xlatu2);
    u_xlatb5 = greaterThanEqual(uvec4(8u, 8u, 8u, 8u), u_xlatu2);
    u_xlatb4.x = u_xlatb4.x && u_xlatb5.x;
    u_xlatb4.y = u_xlatb4.y && u_xlatb5.y;
    u_xlatb4.z = u_xlatb4.z && u_xlatb5.z;
    u_xlatb4.w = u_xlatb4.w && u_xlatb5.w;
    if(u_xlatb4.x){
        u_xlatu9 = u_xlatu2.x + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat5 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat19.xy = u_xlat5.xy + u_xlat5.zw;
        u_xlat19.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat19.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat19.xy;
        u_xlat9.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
        u_xlat5.x = u_xlat9.x * _MaskTex1_ST.x;
    } else {
        u_xlat5.x = _MaskTex1_ST.x;
    }
    if(u_xlatb4.y){
        u_xlatu9 = u_xlatu2.y + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat6 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat19.xy = u_xlat6.xy + u_xlat6.zw;
        u_xlat19.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat19.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat19.xy;
        u_xlat9.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
        u_xlat5.y = u_xlat9.x * _MaskTex1_ST.y;
    } else {
        u_xlat5.y = _MaskTex1_ST.y;
    }
    if(u_xlatb4.z){
        u_xlatu9 = u_xlatu2.z + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat6 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat19.xy = u_xlat6.xy + u_xlat6.zw;
        u_xlat19.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat19.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat19.xy;
        u_xlat2.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
    } else {
        u_xlat2.x = _MaskTex1_ST.z;
    }
    if(u_xlatb4.w){
        u_xlatu9 = u_xlatu2.w + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat4 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat19.xy = u_xlat4.xy + u_xlat4.zw;
        u_xlat19.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat19.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat19.xy;
        u_xlat2.y = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
    } else {
        u_xlat2.y = _MaskTex1_ST.w;
    }
    u_xlat16_9.xy = texture(_FlowTex, vs_TEXCOORD2.xy, _GlobalMipBias.x).xy;
    u_xlat9.xy = u_xlat16_9.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat19.xy = u_xlat9.xy * vs_TEXCOORD5.yy + vs_TEXCOORD0.zw;
    u_xlat20.xy = u_xlat9.xy * vs_TEXCOORD5.yy + vs_TEXCOORD1.xy;
    u_xlat16_4.xyz = texture(_MaskTex0, u_xlat19.xy, _GlobalMipBias.x).xyw;
    u_xlat16_6.xyz = texture(_MaskTex0, u_xlat20.xy, _GlobalMipBias.x).xyw;
    u_xlat6.xyz = (-u_xlat16_4.xyz) + u_xlat16_6.xyz;
    u_xlat4.xyz = vs_TEXCOORD4.xxx * u_xlat6.xyz + u_xlat16_4.xyz;
    u_xlatb27 = u_xlati0==3;
    if(u_xlatb27){
        SV_Target0.xyz = u_xlat4.zzz;
        SV_Target0.w = 1.0;
        return;
    }
    u_xlat19.xy = u_xlat4.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat20.xy = u_xlat19.xy * vs_TEXCOORD4.zz + vs_TEXCOORD1.zw;
    u_xlat20.xy = u_xlat9.xy * vs_TEXCOORD5.zz + u_xlat20.xy;
    u_xlat2.xy = (-u_xlat2.xy) + u_xlat20.xy;
    u_xlat27 = _MaskTex1_R * 0.0174532924;
    u_xlat4.x = sin(u_xlat27);
    u_xlat6.x = cos(u_xlat27);
    u_xlat7.x = (-u_xlat4.x);
    u_xlat7.y = u_xlat6.x;
    u_xlat7.z = u_xlat4.x;
    u_xlat4.x = dot(u_xlat2.xy, u_xlat7.yz);
    u_xlat4.y = dot(u_xlat2.xy, u_xlat7.xy);
    u_xlat2.xy = max(abs(u_xlat5.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlatb20.xy = greaterThanEqual(u_xlat5.xyxy, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat20.x = (u_xlatb20.x) ? float(1.0) : float(-1.0);
    u_xlat20.y = (u_xlatb20.y) ? float(1.0) : float(-1.0);
    u_xlat2.xy = u_xlat20.xy * u_xlat2.xy;
    u_xlat2.xy = u_xlat4.xy / u_xlat2.xy;
    u_xlat16_27 = texture(_MaskTex1, u_xlat2.xy, _GlobalMipBias.x).x;
    u_xlatb2.x = u_xlati0==4;
    if(u_xlatb2.x){
        SV_Target0.xyz = vec3(u_xlat16_27);
        SV_Target0.w = 1.0;
        return;
    }
    u_xlatb2.x = int(_ColorBorderMax0Controller)==0;
    u_xlatb11 = 8u<_ColorBorderMax0Controller;
    u_xlatb2.x = u_xlatb11 || u_xlatb2.x;
    if(!u_xlatb2.x){
        u_xlatu2.x = _ColorBorderMax0Controller + 4294967295u;
        u_xlatu11 = uint(u_xlatu2.x >> (1u & uint(0x1F)));
        u_xlati2 = int(uint(u_xlatu2.x & 1u));
        u_xlat5 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu11)].xxyy;
        u_xlat20.xy = u_xlat5.xy + u_xlat5.zw;
        u_xlat20.xy = ImmCB_0[int(u_xlatu11)].zz * vs_TEXCOORD7.xy + u_xlat20.xy;
        u_xlat11.xy = ImmCB_0[int(u_xlatu11)].ww * vs_TEXCOORD7.zw + u_xlat20.xy;
        u_xlat16_2 = dot(u_xlat11.xy, ImmCB_0[u_xlati2].xy);
    } else {
        u_xlat16_2 = _ColorBorderMax0;
    }
    u_xlatb21.xy = equal(ivec4(uvec4(_ColorBorderMax1Controller, _ColorBorderMin2Controller, _ColorBorderMax1Controller, _ColorBorderMin2Controller)), ivec4(0, 0, 0, 0)).xy;
    u_xlatb4.xy = lessThan(uvec4(8u, 8u, uint(0u), uint(0u)), uvec4(_ColorBorderMax1Controller, _ColorBorderMin2Controller, _ColorBorderMax1Controller, _ColorBorderMax1Controller)).xy;
    {
        bvec2 hlslcc_orTemp = u_xlatb21;
        hlslcc_orTemp.x = u_xlatb21.x || u_xlatb4.x;
        hlslcc_orTemp.y = u_xlatb21.y || u_xlatb4.y;
        u_xlatb21 = hlslcc_orTemp;
    }
    if(!u_xlatb21.x){
        u_xlatu21 = _ColorBorderMax1Controller + 4294967295u;
        u_xlatu4 = uint(u_xlatu21 >> (1u & uint(0x1F)));
        u_xlati21 = int(uint(u_xlatu21 & 1u));
        u_xlat5 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu4)].xxyy;
        u_xlat13.xz = u_xlat5.xy + u_xlat5.zw;
        u_xlat13.xz = ImmCB_0[int(u_xlatu4)].zz * vs_TEXCOORD7.xy + u_xlat13.xz;
        u_xlat4.xy = ImmCB_0[int(u_xlatu4)].ww * vs_TEXCOORD7.zw + u_xlat13.xz;
        u_xlat16_21 = dot(u_xlat4.xy, ImmCB_0[u_xlati21].xy);
    } else {
        u_xlat16_21 = _ColorBorderMax1;
    }
    if(!u_xlatb21.y){
        u_xlatu4 = _ColorBorderMin2Controller + 4294967295u;
        u_xlatu13 = uint(u_xlatu4 >> (1u & uint(0x1F)));
        u_xlati4 = int(uint(u_xlatu4 & 1u));
        u_xlat5 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu13)].xxyy;
        u_xlat5.xy = u_xlat5.xy + u_xlat5.zw;
        u_xlat5.xy = ImmCB_0[int(u_xlatu13)].zz * vs_TEXCOORD7.xy + u_xlat5.xy;
        u_xlat13.xz = ImmCB_0[int(u_xlatu13)].ww * vs_TEXCOORD7.zw + u_xlat5.xy;
        u_xlat16_4.x = dot(u_xlat13.xz, ImmCB_0[u_xlati4].xy);
    } else {
        u_xlat16_4.x = _ColorBorderMin2;
    }
    u_xlatb5.x = int(_TransparencyController)==0;
    u_xlatb14 = 8u<_TransparencyController;
    u_xlatb5.x = u_xlatb14 || u_xlatb5.x;
    if(!u_xlatb5.x){
        u_xlatu5 = _TransparencyController + 4294967295u;
        u_xlatu14 = uint(u_xlatu5 >> (1u & uint(0x1F)));
        u_xlati5 = int(uint(u_xlatu5 & 1u));
        u_xlat6 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu14)].xxyy;
        u_xlat23.xy = u_xlat6.xy + u_xlat6.zw;
        u_xlat23.xy = ImmCB_0[int(u_xlatu14)].zz * vs_TEXCOORD7.xy + u_xlat23.xy;
        u_xlat14.xy = ImmCB_0[int(u_xlatu14)].ww * vs_TEXCOORD7.zw + u_xlat23.xy;
        u_xlat16_5 = dot(u_xlat14.xy, ImmCB_0[u_xlati5].xy);
    } else {
        u_xlat16_5 = _Transparency;
    }
    u_xlatb0 = u_xlati0==6;
    if(u_xlatb0){
        SV_Target0 = vec4(0.5, 0.5, 1.0, 1.0);
        return;
    }
    u_xlat0.xy = u_xlat9.xy * vs_TEXCOORD5.xx + vs_TEXCOORD0.xy;
    u_xlat0.xy = u_xlat19.xy * vs_TEXCOORD4.yy + u_xlat0.xy;
    u_xlat0.xy = (-u_xlat1.xy) + u_xlat0.xy;
    u_xlat18 = _ColorTex0_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18);
    u_xlat6.x = cos(u_xlat18);
    u_xlat7.x = (-u_xlat1.x);
    u_xlat7.y = u_xlat6.x;
    u_xlat7.z = u_xlat1.x;
    u_xlat1.x = dot(u_xlat0.xy, u_xlat7.yz);
    u_xlat1.y = dot(u_xlat0.xy, u_xlat7.xy);
    u_xlat0.xy = max(abs(u_xlat3.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlatb19.xy = greaterThanEqual(u_xlat3.xyxy, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat19.x = (u_xlatb19.x) ? float(1.0) : float(-1.0);
    u_xlat19.y = (u_xlatb19.y) ? float(1.0) : float(-1.0);
    u_xlat0.xy = u_xlat0.xy * u_xlat19.xy;
    u_xlat0.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlat16_1 = texture(_ColorTex0, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat16_6 = texture(_ColorTex1, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat16_7 = texture(_ColorTex2, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat0.xy = (-vec2(_ColorBorderMin0, _ColorBorderMin1)) + vec2(1.0, 1.0);
    u_xlat0.xy = max(u_xlat0.xy, vec2(0.00999999978, 0.00999999978));
    u_xlat0.xy = min(u_xlat0.xy, vec2(1.0, 1.0));
    u_xlat18 = (-u_xlat16_2) + 1.0;
    u_xlat18 = (-vs_TEXCOORD3.x) * u_xlat4.z + u_xlat18;
    u_xlat18 = u_xlat18 + 1.0;
    u_xlat8 = max(u_xlat18, u_xlat16_27);
    u_xlat18 = (-u_xlat18) + u_xlat8;
    u_xlat18 = min(u_xlat0.x, u_xlat18);
    u_xlat0.x = u_xlat18 / u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat18 = (-u_xlat16_21) + 1.0;
    u_xlat18 = (-vs_TEXCOORD3.y) * u_xlat4.z + u_xlat18;
    u_xlat18 = u_xlat18 + 1.0;
    u_xlat8 = max(u_xlat18, u_xlat16_27);
    u_xlat18 = (-u_xlat18) + u_xlat8;
    u_xlat18 = min(u_xlat0.y, u_xlat18);
    u_xlat9.x = u_xlat18 / u_xlat0.y;
    u_xlat9.x = clamp(u_xlat9.x, 0.0, 1.0);
    u_xlat1 = u_xlat16_1 + (-u_xlat16_6);
    u_xlat1 = u_xlat0.xxxx * u_xlat1 + u_xlat16_6;
    u_xlat1 = (-u_xlat16_7) + u_xlat1;
    u_xlat1 = u_xlat9.xxxx * u_xlat1 + u_xlat16_7;
    u_xlat0.x = u_xlat16_5 * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat9.x = (-u_xlat16_4.x) + 1.0;
    u_xlat9.x = max(u_xlat9.x, 0.00999999978);
    u_xlat9.x = min(u_xlat9.x, 1.0);
    u_xlat18 = (-vs_TEXCOORD3.z) * u_xlat4.z + 1.0;
    u_xlat27 = max(u_xlat18, u_xlat16_27);
    u_xlat18 = (-u_xlat18) + u_xlat27;
    u_xlat18 = min(u_xlat9.x, u_xlat18);
    u_xlat9.x = u_xlat18 / u_xlat9.x;
    u_xlat9.x = clamp(u_xlat9.x, 0.0, 1.0);
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat0.x = u_xlat0.x * u_xlat9.x;
    u_xlat1.w = u_xlat0.x * u_xlat1.w;
    u_xlat0 = u_xlat1 * vs_COLOR0;
    SV_Target0.xyz = u_xlat0.www * u_xlat0.xyz;
    SV_Target0.w = u_xlat0.w;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[4];
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4                _ColorTex0_ST;
	UNITY_UNIFORM float                _ColorTex0_R;
	UNITY_UNIFORM int                _ColorTex0Index;
	UNITY_UNIFORM vec4                _ColorTex0UVTileController;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex1_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_ColorTex2_ST;
	UNITY_UNIFORM vec4                _MaskTex0_ST;
	UNITY_UNIFORM float                _MaskTex0_R;
	UNITY_UNIFORM int                _MaskTex0Index;
	UNITY_UNIFORM vec4                _MaskTex0UVTileController;
	UNITY_UNIFORM vec4                _MaskTex1_ST;
	UNITY_UNIFORM float                _MaskTex1_R;
	UNITY_UNIFORM int                _MaskTex1Index;
	UNITY_UNIFORM vec4                _MaskTex1UVTileController;
	UNITY_UNIFORM vec4                _FlowTex_ST;
	UNITY_UNIFORM float                _FlowTex_R;
	UNITY_UNIFORM int                _FlowTexIndex;
	UNITY_UNIFORM vec4                _FlowTexUVTileController;
	UNITY_UNIFORM vec4                _Color;
	UNITY_UNIFORM vec4                _SecondColor;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorRGIndex;
	UNITY_UNIFORM int Xhlslcc_UnusedX_VtxColorBAIndex;
	UNITY_UNIFORM float                _IsGammaColor;
	UNITY_UNIFORM float                _Transparency;
	UNITY_UNIFORM uint                _TransparencyController;
	UNITY_UNIFORM float                _TransparencyMultiplier;
	UNITY_UNIFORM float                _TransparencyOffset;
	UNITY_UNIFORM float                _VertexAlphaThresholdMode;
	UNITY_UNIFORM float                _ColorBorderMin0;
	UNITY_UNIFORM float                _ColorBorderMax0;
	UNITY_UNIFORM uint                _ColorBorderMax0Controller;
	UNITY_UNIFORM float                _ColorBorderMin1;
	UNITY_UNIFORM float                _ColorBorderMax1;
	UNITY_UNIFORM uint                _ColorBorderMax1Controller;
	UNITY_UNIFORM float                _ColorBorderMin2;
	UNITY_UNIFORM uint                _ColorBorderMin2Controller;
	UNITY_UNIFORM float                _ColorBorderMax2;
	UNITY_UNIFORM uint                _ColorBorderMax2Controller;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParticleFade;
	UNITY_UNIFORM float Xhlslcc_UnusedX_SoftParThresholdMode;
	UNITY_UNIFORM float                _M0PatternX;
	UNITY_UNIFORM float                _M0PatternY;
	UNITY_UNIFORM float                _M0PatternFadeAnime;
	UNITY_UNIFORM uint                _M0PatternFadeAnimeController;
	UNITY_UNIFORM float                _M0FlowScale0;
	UNITY_UNIFORM uint                _M0FlowScale0Controller;
	UNITY_UNIFORM float                _M0FlowScale2;
	UNITY_UNIFORM uint                _M0FlowScale2Controller;
	UNITY_UNIFORM float                _FlowScale0;
	UNITY_UNIFORM uint                _FlowScale0Controller;
	UNITY_UNIFORM float                _FlowScale1;
	UNITY_UNIFORM uint                _FlowScale1Controller;
	UNITY_UNIFORM float                _FlowScale2;
	UNITY_UNIFORM uint                _FlowScale2Controller;
	UNITY_UNIFORM float                _EdgeMaskWidth;
	UNITY_UNIFORM uint                _EdgeMaskWidthController;
	UNITY_UNIFORM float                _EdgeMaskOffset;
	UNITY_UNIFORM uint                _EdgeMaskOffsetController;
	UNITY_UNIFORM float                _ColorProjType;
	UNITY_UNIFORM float                _Luminance;
	UNITY_UNIFORM uint                _LuminanceController;
	UNITY_UNIFORM float                _DebugMode;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex0;
UNITY_LOCATION(1) uniform mediump sampler2D _ColorTex1;
UNITY_LOCATION(2) uniform mediump sampler2D _ColorTex2;
UNITY_LOCATION(3) uniform mediump sampler2D _MaskTex0;
UNITY_LOCATION(4) uniform mediump sampler2D _MaskTex1;
UNITY_LOCATION(5) uniform mediump sampler2D _FlowTex;
in highp  vec4 vs_COLOR0;
in highp  vec4 vs_TEXCOORD0;
in highp  vec4 vs_TEXCOORD1;
in highp  vec4 vs_TEXCOORD2;
in highp  vec3 vs_TEXCOORD3;
in highp  vec3 vs_TEXCOORD4;
in highp  vec3 vs_TEXCOORD5;
in highp  vec4 vs_TEXCOORD6;
in highp  vec4 vs_TEXCOORD7;
layout(location = 0) out highp vec4 SV_Target0;
vec4 u_xlat0;
int u_xlati0;
bool u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
uvec4 u_xlatu1;
vec4 u_xlat2;
mediump float u_xlat16_2;
int u_xlati2;
uvec4 u_xlatu2;
bvec4 u_xlatb2;
vec4 u_xlat3;
bvec4 u_xlatb3;
vec4 u_xlat4;
mediump vec3 u_xlat16_4;
int u_xlati4;
uint u_xlatu4;
bvec4 u_xlatb4;
vec4 u_xlat5;
mediump float u_xlat16_5;
int u_xlati5;
uint u_xlatu5;
bvec4 u_xlatb5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
float u_xlat8;
vec3 u_xlat9;
mediump vec2 u_xlat16_9;
uint u_xlatu9;
bool u_xlatb9;
vec2 u_xlat11;
uint u_xlatu11;
bool u_xlatb11;
vec3 u_xlat13;
uint u_xlatu13;
vec2 u_xlat14;
uint u_xlatu14;
bool u_xlatb14;
float u_xlat18;
int u_xlati18;
vec2 u_xlat19;
bvec2 u_xlatb19;
vec2 u_xlat20;
bvec2 u_xlatb20;
mediump float u_xlat16_21;
int u_xlati21;
uint u_xlatu21;
bvec2 u_xlatb21;
vec2 u_xlat23;
float u_xlat27;
mediump float u_xlat16_27;
bool u_xlatb27;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
    u_xlati0 = int(_DebugMode);
    u_xlatb9 = u_xlati0==1;
    if(u_xlatb9){
        SV_Target0.xy = vs_TEXCOORD0.xy;
        SV_Target0.zw = vec2(0.0, 1.0);
        return;
    }
    u_xlatb9 = u_xlati0==2;
    if(u_xlatb9){
        SV_Target0.xyz = vs_COLOR0.xyz;
        SV_Target0.w = 1.0;
        return;
    }
    u_xlatb9 = u_xlati0==5;
    if(u_xlatb9){
        SV_Target0 = vec4(1.0, 0.0, 0.0, 1.0);
        return;
    }
    u_xlatb9 = u_xlati0==7;
    if(u_xlatb9){
        SV_Target0.xyz = vs_COLOR0.www;
        SV_Target0.w = 1.0;
        return;
    }
    u_xlatu1 = uvec4(_ColorTex0UVTileController);
    u_xlatb2 = lessThan(uvec4(uint(0u), uint(0u), uint(0u), uint(0u)), u_xlatu1);
    u_xlatb3 = greaterThanEqual(uvec4(8u, 8u, 8u, 8u), u_xlatu1);
    u_xlatb2.x = u_xlatb2.x && u_xlatb3.x;
    u_xlatb2.y = u_xlatb2.y && u_xlatb3.y;
    u_xlatb2.z = u_xlatb2.z && u_xlatb3.z;
    u_xlatb2.w = u_xlatb2.w && u_xlatb3.w;
    if(u_xlatb2.x){
        u_xlatu9 = u_xlatu1.x + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat3 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat3.xy = u_xlat3.xy + u_xlat3.zw;
        u_xlat3.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat3.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat3.xy;
        u_xlat9.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
        u_xlat3.x = u_xlat9.x * _ColorTex0_ST.x;
    } else {
        u_xlat3.x = _ColorTex0_ST.x;
    }
    if(u_xlatb2.y){
        u_xlatu9 = u_xlatu1.y + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat4 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat1.xy = u_xlat4.xy + u_xlat4.zw;
        u_xlat1.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat1.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat1.xy;
        u_xlat9.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
        u_xlat3.y = u_xlat9.x * _ColorTex0_ST.y;
    } else {
        u_xlat3.y = _ColorTex0_ST.y;
    }
    if(u_xlatb2.z){
        u_xlatu9 = u_xlatu1.z + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat4 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat1.xy = u_xlat4.xy + u_xlat4.zw;
        u_xlat1.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat1.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat1.xy;
        u_xlat1.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
    } else {
        u_xlat1.x = _ColorTex0_ST.z;
    }
    if(u_xlatb2.w){
        u_xlatu9 = u_xlatu1.w + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat2 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat19.xy = u_xlat2.xy + u_xlat2.zw;
        u_xlat19.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat19.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat19.xy;
        u_xlat1.y = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
    } else {
        u_xlat1.y = _ColorTex0_ST.w;
    }
    u_xlatu2 = uvec4(_MaskTex1UVTileController);
    u_xlatb4 = lessThan(uvec4(uint(0u), uint(0u), uint(0u), uint(0u)), u_xlatu2);
    u_xlatb5 = greaterThanEqual(uvec4(8u, 8u, 8u, 8u), u_xlatu2);
    u_xlatb4.x = u_xlatb4.x && u_xlatb5.x;
    u_xlatb4.y = u_xlatb4.y && u_xlatb5.y;
    u_xlatb4.z = u_xlatb4.z && u_xlatb5.z;
    u_xlatb4.w = u_xlatb4.w && u_xlatb5.w;
    if(u_xlatb4.x){
        u_xlatu9 = u_xlatu2.x + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat5 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat19.xy = u_xlat5.xy + u_xlat5.zw;
        u_xlat19.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat19.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat19.xy;
        u_xlat9.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
        u_xlat5.x = u_xlat9.x * _MaskTex1_ST.x;
    } else {
        u_xlat5.x = _MaskTex1_ST.x;
    }
    if(u_xlatb4.y){
        u_xlatu9 = u_xlatu2.y + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat6 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat19.xy = u_xlat6.xy + u_xlat6.zw;
        u_xlat19.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat19.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat19.xy;
        u_xlat9.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
        u_xlat5.y = u_xlat9.x * _MaskTex1_ST.y;
    } else {
        u_xlat5.y = _MaskTex1_ST.y;
    }
    if(u_xlatb4.z){
        u_xlatu9 = u_xlatu2.z + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat6 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat19.xy = u_xlat6.xy + u_xlat6.zw;
        u_xlat19.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat19.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat19.xy;
        u_xlat2.x = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
    } else {
        u_xlat2.x = _MaskTex1_ST.z;
    }
    if(u_xlatb4.w){
        u_xlatu9 = u_xlatu2.w + 4294967295u;
        u_xlati18 = int(uint(u_xlatu9 & 1u));
        u_xlatu9 = uint(u_xlatu9 >> (1u & uint(0x1F)));
        u_xlat4 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu9)].xxyy;
        u_xlat19.xy = u_xlat4.xy + u_xlat4.zw;
        u_xlat19.xy = ImmCB_0[int(u_xlatu9)].zz * vs_TEXCOORD7.xy + u_xlat19.xy;
        u_xlat9.xz = ImmCB_0[int(u_xlatu9)].ww * vs_TEXCOORD7.zw + u_xlat19.xy;
        u_xlat2.y = dot(u_xlat9.xz, ImmCB_0[u_xlati18].xy);
    } else {
        u_xlat2.y = _MaskTex1_ST.w;
    }
    u_xlat16_9.xy = texture(_FlowTex, vs_TEXCOORD2.xy, _GlobalMipBias.x).xy;
    u_xlat9.xy = u_xlat16_9.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat19.xy = u_xlat9.xy * vs_TEXCOORD5.yy + vs_TEXCOORD0.zw;
    u_xlat20.xy = u_xlat9.xy * vs_TEXCOORD5.yy + vs_TEXCOORD1.xy;
    u_xlat16_4.xyz = texture(_MaskTex0, u_xlat19.xy, _GlobalMipBias.x).xyw;
    u_xlat16_6.xyz = texture(_MaskTex0, u_xlat20.xy, _GlobalMipBias.x).xyw;
    u_xlat6.xyz = (-u_xlat16_4.xyz) + u_xlat16_6.xyz;
    u_xlat4.xyz = vs_TEXCOORD4.xxx * u_xlat6.xyz + u_xlat16_4.xyz;
    u_xlatb27 = u_xlati0==3;
    if(u_xlatb27){
        SV_Target0.xyz = u_xlat4.zzz;
        SV_Target0.w = 1.0;
        return;
    }
    u_xlat19.xy = u_xlat4.xy * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat20.xy = u_xlat19.xy * vs_TEXCOORD4.zz + vs_TEXCOORD1.zw;
    u_xlat20.xy = u_xlat9.xy * vs_TEXCOORD5.zz + u_xlat20.xy;
    u_xlat2.xy = (-u_xlat2.xy) + u_xlat20.xy;
    u_xlat27 = _MaskTex1_R * 0.0174532924;
    u_xlat4.x = sin(u_xlat27);
    u_xlat6.x = cos(u_xlat27);
    u_xlat7.x = (-u_xlat4.x);
    u_xlat7.y = u_xlat6.x;
    u_xlat7.z = u_xlat4.x;
    u_xlat4.x = dot(u_xlat2.xy, u_xlat7.yz);
    u_xlat4.y = dot(u_xlat2.xy, u_xlat7.xy);
    u_xlat2.xy = max(abs(u_xlat5.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlatb20.xy = greaterThanEqual(u_xlat5.xyxy, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat20.x = (u_xlatb20.x) ? float(1.0) : float(-1.0);
    u_xlat20.y = (u_xlatb20.y) ? float(1.0) : float(-1.0);
    u_xlat2.xy = u_xlat20.xy * u_xlat2.xy;
    u_xlat2.xy = u_xlat4.xy / u_xlat2.xy;
    u_xlat16_27 = texture(_MaskTex1, u_xlat2.xy, _GlobalMipBias.x).x;
    u_xlatb2.x = u_xlati0==4;
    if(u_xlatb2.x){
        SV_Target0.xyz = vec3(u_xlat16_27);
        SV_Target0.w = 1.0;
        return;
    }
    u_xlatb2.x = int(_ColorBorderMax0Controller)==0;
    u_xlatb11 = 8u<_ColorBorderMax0Controller;
    u_xlatb2.x = u_xlatb11 || u_xlatb2.x;
    if(!u_xlatb2.x){
        u_xlatu2.x = _ColorBorderMax0Controller + 4294967295u;
        u_xlatu11 = uint(u_xlatu2.x >> (1u & uint(0x1F)));
        u_xlati2 = int(uint(u_xlatu2.x & 1u));
        u_xlat5 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu11)].xxyy;
        u_xlat20.xy = u_xlat5.xy + u_xlat5.zw;
        u_xlat20.xy = ImmCB_0[int(u_xlatu11)].zz * vs_TEXCOORD7.xy + u_xlat20.xy;
        u_xlat11.xy = ImmCB_0[int(u_xlatu11)].ww * vs_TEXCOORD7.zw + u_xlat20.xy;
        u_xlat16_2 = dot(u_xlat11.xy, ImmCB_0[u_xlati2].xy);
    } else {
        u_xlat16_2 = _ColorBorderMax0;
    }
    u_xlatb21.xy = equal(ivec4(uvec4(_ColorBorderMax1Controller, _ColorBorderMin2Controller, _ColorBorderMax1Controller, _ColorBorderMin2Controller)), ivec4(0, 0, 0, 0)).xy;
    u_xlatb4.xy = lessThan(uvec4(8u, 8u, uint(0u), uint(0u)), uvec4(_ColorBorderMax1Controller, _ColorBorderMin2Controller, _ColorBorderMax1Controller, _ColorBorderMax1Controller)).xy;
    {
        bvec2 hlslcc_orTemp = u_xlatb21;
        hlslcc_orTemp.x = u_xlatb21.x || u_xlatb4.x;
        hlslcc_orTemp.y = u_xlatb21.y || u_xlatb4.y;
        u_xlatb21 = hlslcc_orTemp;
    }
    if(!u_xlatb21.x){
        u_xlatu21 = _ColorBorderMax1Controller + 4294967295u;
        u_xlatu4 = uint(u_xlatu21 >> (1u & uint(0x1F)));
        u_xlati21 = int(uint(u_xlatu21 & 1u));
        u_xlat5 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu4)].xxyy;
        u_xlat13.xz = u_xlat5.xy + u_xlat5.zw;
        u_xlat13.xz = ImmCB_0[int(u_xlatu4)].zz * vs_TEXCOORD7.xy + u_xlat13.xz;
        u_xlat4.xy = ImmCB_0[int(u_xlatu4)].ww * vs_TEXCOORD7.zw + u_xlat13.xz;
        u_xlat16_21 = dot(u_xlat4.xy, ImmCB_0[u_xlati21].xy);
    } else {
        u_xlat16_21 = _ColorBorderMax1;
    }
    if(!u_xlatb21.y){
        u_xlatu4 = _ColorBorderMin2Controller + 4294967295u;
        u_xlatu13 = uint(u_xlatu4 >> (1u & uint(0x1F)));
        u_xlati4 = int(uint(u_xlatu4 & 1u));
        u_xlat5 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu13)].xxyy;
        u_xlat5.xy = u_xlat5.xy + u_xlat5.zw;
        u_xlat5.xy = ImmCB_0[int(u_xlatu13)].zz * vs_TEXCOORD7.xy + u_xlat5.xy;
        u_xlat13.xz = ImmCB_0[int(u_xlatu13)].ww * vs_TEXCOORD7.zw + u_xlat5.xy;
        u_xlat16_4.x = dot(u_xlat13.xz, ImmCB_0[u_xlati4].xy);
    } else {
        u_xlat16_4.x = _ColorBorderMin2;
    }
    u_xlatb5.x = int(_TransparencyController)==0;
    u_xlatb14 = 8u<_TransparencyController;
    u_xlatb5.x = u_xlatb14 || u_xlatb5.x;
    if(!u_xlatb5.x){
        u_xlatu5 = _TransparencyController + 4294967295u;
        u_xlatu14 = uint(u_xlatu5 >> (1u & uint(0x1F)));
        u_xlati5 = int(uint(u_xlatu5 & 1u));
        u_xlat6 = vs_TEXCOORD6 * ImmCB_0[int(u_xlatu14)].xxyy;
        u_xlat23.xy = u_xlat6.xy + u_xlat6.zw;
        u_xlat23.xy = ImmCB_0[int(u_xlatu14)].zz * vs_TEXCOORD7.xy + u_xlat23.xy;
        u_xlat14.xy = ImmCB_0[int(u_xlatu14)].ww * vs_TEXCOORD7.zw + u_xlat23.xy;
        u_xlat16_5 = dot(u_xlat14.xy, ImmCB_0[u_xlati5].xy);
    } else {
        u_xlat16_5 = _Transparency;
    }
    u_xlatb0 = u_xlati0==6;
    if(u_xlatb0){
        SV_Target0 = vec4(0.5, 0.5, 1.0, 1.0);
        return;
    }
    u_xlat0.xy = u_xlat9.xy * vs_TEXCOORD5.xx + vs_TEXCOORD0.xy;
    u_xlat0.xy = u_xlat19.xy * vs_TEXCOORD4.yy + u_xlat0.xy;
    u_xlat0.xy = (-u_xlat1.xy) + u_xlat0.xy;
    u_xlat18 = _ColorTex0_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat18);
    u_xlat6.x = cos(u_xlat18);
    u_xlat7.x = (-u_xlat1.x);
    u_xlat7.y = u_xlat6.x;
    u_xlat7.z = u_xlat1.x;
    u_xlat1.x = dot(u_xlat0.xy, u_xlat7.yz);
    u_xlat1.y = dot(u_xlat0.xy, u_xlat7.xy);
    u_xlat0.xy = max(abs(u_xlat3.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlatb19.xy = greaterThanEqual(u_xlat3.xyxy, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat19.x = (u_xlatb19.x) ? float(1.0) : float(-1.0);
    u_xlat19.y = (u_xlatb19.y) ? float(1.0) : float(-1.0);
    u_xlat0.xy = u_xlat0.xy * u_xlat19.xy;
    u_xlat0.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlat16_1 = texture(_ColorTex0, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat16_6 = texture(_ColorTex1, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat16_7 = texture(_ColorTex2, u_xlat0.xy, _GlobalMipBias.x);
    u_xlat0.xy = (-vec2(_ColorBorderMin0, _ColorBorderMin1)) + vec2(1.0, 1.0);
    u_xlat0.xy = max(u_xlat0.xy, vec2(0.00999999978, 0.00999999978));
    u_xlat0.xy = min(u_xlat0.xy, vec2(1.0, 1.0));
    u_xlat18 = (-u_xlat16_2) + 1.0;
    u_xlat18 = (-vs_TEXCOORD3.x) * u_xlat4.z + u_xlat18;
    u_xlat18 = u_xlat18 + 1.0;
    u_xlat8 = max(u_xlat18, u_xlat16_27);
    u_xlat18 = (-u_xlat18) + u_xlat8;
    u_xlat18 = min(u_xlat0.x, u_xlat18);
    u_xlat0.x = u_xlat18 / u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat18 = (-u_xlat16_21) + 1.0;
    u_xlat18 = (-vs_TEXCOORD3.y) * u_xlat4.z + u_xlat18;
    u_xlat18 = u_xlat18 + 1.0;
    u_xlat8 = max(u_xlat18, u_xlat16_27);
    u_xlat18 = (-u_xlat18) + u_xlat8;
    u_xlat18 = min(u_xlat0.y, u_xlat18);
    u_xlat9.x = u_xlat18 / u_xlat0.y;
    u_xlat9.x = clamp(u_xlat9.x, 0.0, 1.0);
    u_xlat1 = u_xlat16_1 + (-u_xlat16_6);
    u_xlat1 = u_xlat0.xxxx * u_xlat1 + u_xlat16_6;
    u_xlat1 = (-u_xlat16_7) + u_xlat1;
    u_xlat1 = u_xlat9.xxxx * u_xlat1 + u_xlat16_7;
    u_xlat0.x = u_xlat16_5 * _TransparencyMultiplier + _TransparencyOffset;
    u_xlat9.x = (-u_xlat16_4.x) + 1.0;
    u_xlat9.x = max(u_xlat9.x, 0.00999999978);
    u_xlat9.x = min(u_xlat9.x, 1.0);
    u_xlat18 = (-vs_TEXCOORD3.z) * u_xlat4.z + 1.0;
    u_xlat27 = max(u_xlat18, u_xlat16_27);
    u_xlat18 = (-u_xlat18) + u_xlat27;
    u_xlat18 = min(u_xlat9.x, u_xlat18);
    u_xlat9.x = u_xlat18 / u_xlat9.x;
    u_xlat9.x = clamp(u_xlat9.x, 0.0, 1.0);
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat0.x = u_xlat0.x * u_xlat9.x;
    u_xlat1.w = u_xlat0.x * u_xlat1.w;
    u_xlat0 = u_xlat1 * vs_COLOR0;
    SV_Target0.xyz = u_xlat0.www * u_xlat0.xyz;
    SV_Target0.w = u_xlat0.w;
    return;
}

#endif

