#version 150
#define varying in
#define texture2D texture
#define textureCube texture
#define texture2DProj textureProj
precision mediump float;
precision mediump int;

struct DMP_OPERATION {
    bool enableClippingPlane;
    vec4 clippingPlane;
    bool enableAlphaTest;
    float alphaRefValue;
    int alphaTestFunc;
    int mode;
    float wScale;
    float penumbraScale;
    float penumbraBias;
};

uniform DMP_OPERATION dmp_FragOperation;

struct DMP_TEXTURE {
    int samplerType;
    bool perspectiveShadow;
    float shadowZScale;
    float shadowZBias;
    int texcoord;
};

uniform DMP_TEXTURE dmp_Texture[4];

struct DMP_COMBINER {
    int combineRgb;
    int combineAlpha;
    ivec3 srcRgb;
    ivec3 srcAlpha;
    ivec3 operandRgb;
    ivec3 operandAlpha;
    int scaleRgb;
    int scaleAlpha;
    vec4 constRgba;
    ivec2 bufferInput;
    vec4 bufferColor;
};

uniform DMP_COMBINER dmp_TexEnv[1];
uniform sampler2D unf_frg_txt_2d_0;
uniform sampler2D unf_frg_txt_2d_1;
uniform sampler2D unf_frg_txt_2d_2;
uniform samplerCube unf_frg_txt_cube;
uniform sampler2D unf_frg_txt_lut;
varying vec4 var_clr;
varying vec4 var_nrm;
varying vec4 var_tng;
varying vec4 var_tx0;
varying vec4 var_tx1;
varying vec4 var_tx2;
varying vec4 var_prm;
out vec4 outFragColor;

void main() {
    vec4 tex_clr[4];
    tex_clr[0] = (dmp_Texture[0].samplerType == 0) ? vec4(1.000000, 1.000000, 1.000000, 1.000000)
            : (dmp_Texture[0].samplerType == 3553) ? texture2D(unf_frg_txt_2d_0, var_tx0.xy) : (dmp_Texture[0].samplerType == 34067)
            ? textureCube(unf_frg_txt_cube, var_tx0.xyz) : (dmp_Texture[0].samplerType == 28160)
            ? texture2DProj(unf_frg_txt_2d_0, var_tx0.xyz) : (dmp_Texture[0].samplerType == 28161)
            ? texture2D(unf_frg_txt_2d_0, var_tx0.xy) : (dmp_Texture[0].samplerType == 28162)
            ? textureCube(unf_frg_txt_cube, var_tx0.xyz) : vec4(0.000000, 0.000000, 0.000000,
            0.000000);
    tex_clr[1] = (dmp_Texture[1].samplerType == 0) ? vec4(1.000000, 1.000000, 1.000000, 1.000000)
            : (dmp_Texture[1].samplerType == 3553) ? texture2D(unf_frg_txt_2d_1, var_tx1.xy) : vec4(0.000000,
            0.000000, 0.000000, 0.000000);
    tex_clr[2] = (dmp_Texture[2].samplerType == 0) ? vec4(1.000000, 1.000000, 1.000000, 1.000000)
            : (dmp_Texture[2].samplerType == 3553) ? texture2D(unf_frg_txt_2d_2, var_tx2.xy) : vec4(0.000000,
            0.000000, 0.000000, 0.000000);
    vec4 clr_prv = vec4(0.000000, 0.000000, 0.000000, 0.000000);
    vec4 buf_prv = dmp_TexEnv[0].bufferColor;
    for (int c = 0; c < 1; c++) {
        vec4 clr_arg[3];
        {
            for (int a = 0; a < 3; a++) {
                int src_rgb = dmp_TexEnv[c].srcRgb[a];
                int src_alp = dmp_TexEnv[c].srcAlpha[a];
                vec4 arg_rgb, arg_alp;
                arg_rgb = (src_rgb == 15) ? clr_prv : (src_rgb == 14) ? dmp_TexEnv[c].constRgba
                        : (src_rgb == 0) ? var_clr : (src_rgb == 3) ? tex_clr[0] : (src_rgb == 4)
                        ? tex_clr[1] : (src_rgb == 5) ? tex_clr[2] : (src_rgb == 13) ? buf_prv
                        : vec4(0.000000, 0.000000, 0.000000, 0.000000);
                if (src_rgb != src_alp) {
                    arg_alp = (src_alp == 15) ? clr_prv : (src_alp == 14) ? dmp_TexEnv[c].constRgba
                            : (src_alp == 0) ? var_clr : (src_alp == 3) ? tex_clr[0] : (src_alp == 4)
                            ? tex_clr[1] : (src_alp == 5) ? tex_clr[2] : (src_alp == 13) ? buf_prv
                            : vec4(0.000000, 0.000000, 0.000000, 0.000000);
                } else {
                    arg_alp = arg_rgb;
                }
                int opr_rgb = dmp_TexEnv[c].operandRgb[a];
                int opr_alp = dmp_TexEnv[c].operandAlpha[a];
                clr_arg[a].xyz = (opr_rgb == 0) ? arg_rgb.xyz : (opr_rgb == 1) ? 1.000000 - arg_rgb.xyz
                        : (opr_rgb == 2) ? vec3(arg_rgb.w, arg_rgb.w, arg_rgb.w) : (opr_rgb == 3)
                        ? 1.000000 - vec3(arg_rgb.w, arg_rgb.w, arg_rgb.w) : (opr_rgb == 4) ? vec3(arg_rgb.x,
                        arg_rgb.x, arg_rgb.x) : (opr_rgb == 5) ? 1.000000 - vec3(arg_rgb.x, arg_rgb.x,
                        arg_rgb.x) : (opr_rgb == 8) ? vec3(arg_rgb.y, arg_rgb.y, arg_rgb.y) : (opr_rgb == 9)
                        ? 1.000000 - vec3(arg_rgb.y, arg_rgb.y, arg_rgb.y) : (opr_rgb == 12) ? vec3(arg_rgb.z,
                        arg_rgb.z, arg_rgb.z) : (opr_rgb == 13) ? 1.000000 - vec3(arg_rgb.z, arg_rgb.z,
                        arg_rgb.z) : vec3(0.000000, 0.000000, 0.000000);
                clr_arg[a].w = (opr_alp == 0) ? arg_alp.w : (opr_alp == 1) ? 1.000000 - arg_alp.w
                        : (opr_alp == 2) ? arg_alp.x : (opr_alp == 3) ? 1.000000 - arg_alp.x : (opr_alp == 4)
                        ? arg_alp.y : (opr_alp == 5) ? 1.000000 - arg_alp.y : (opr_alp == 6) ? arg_alp.z
                        : (opr_alp == 7) ? 1.000000 - arg_alp.z : 0.000000;
            }
            if (0 < c && c < 1 - 1) {
                buf_prv.xyz = (dmp_TexEnv[c].bufferInput.x == 1) ? clr_prv.xyz : (dmp_TexEnv[c].bufferInput.x == 0)
                        ? buf_prv.xyz : vec3(1.000000, 1.000000, 1.000000);
                {
                    buf_prv.w = (dmp_TexEnv[c].bufferInput.y == 1) ? clr_prv.w : (dmp_TexEnv[c].bufferInput.y == 0)
                            ? buf_prv.w : 1.000000;
                }
            }
        }
        {
            int cmb_rgb = dmp_TexEnv[c].combineRgb;
            int cmb_alp = dmp_TexEnv[c].combineAlpha;
            clr_prv.xyz = (cmb_rgb == 0) ? clr_arg[0].xyz : (cmb_rgb == 1) ? clr_arg[0].xyz * clr_arg[1].xyz
                    : (cmb_rgb == 2) ? clr_arg[0].xyz + clr_arg[1].xyz : (cmb_rgb == 5) ? clr_arg[0].xyz
                    - clr_arg[1].xyz : (cmb_rgb == 3) ? clr_arg[0].xyz + clr_arg[1].xyz - 0.500000
                    : (cmb_rgb == 6) ? vec3(4.000000 * dot(clr_arg[0].xyz - 0.500000, clr_arg[1].xyz
                    - 0.500000)) : (cmb_rgb == 7) ? vec3(4.000000 * dot(clr_arg[0].xyz - 0.500000,
                    clr_arg[1].xyz - 0.500000)) : (cmb_rgb == 4) ? (clr_arg[0].xyz - clr_arg[1].xyz)
                    * clr_arg[2].xyz + clr_arg[1].xyz : (cmb_rgb == 9) ? clamp(clr_arg[0].xyz
                    + clr_arg[1].xyz, 0.000000, 1.000000) * clr_arg[2].xyz : (cmb_rgb == 8) ? (clr_arg[0].xyz
                    * clr_arg[1].xyz) + clr_arg[2].xyz : vec3(0.000000, 0.000000, 0.000000);
            clr_prv.xyz *= (dmp_TexEnv[c].scaleRgb == 0) ? 1.000000 : (dmp_TexEnv[c].scaleRgb == 1)
                    ? 2.000000 : (dmp_TexEnv[c].scaleRgb == 2) ? 4.000000 : 1.000000;
            clr_prv.w = clr_arg[0].w = (cmb_alp == 0) ? clr_arg[0].w : (cmb_alp == 1) ? clr_arg[0].w
                    * clr_arg[1].w : (cmb_alp == 2) ? clr_arg[0].w + clr_arg[1].w : (cmb_alp == 5)
                    ? clr_arg[0].w - clr_arg[1].w : (cmb_alp == 3) ? clr_arg[0].w + clr_arg[1].w
                    - 0.500000 : (cmb_alp == 7) ? 4.000000 * dot(clr_arg[0].xyz - 0.500000, clr_arg[1].xyz
                    - 0.500000) : (cmb_alp == 4) ? (clr_arg[0].w - clr_arg[1].w) * clr_arg[2].w
                    + clr_arg[1].w : (cmb_alp == 9) ? clamp(clr_arg[0].w + clr_arg[1].w, 0.000000,
                    1.000000) * clr_arg[2].w : (cmb_alp == 8) ? (clr_arg[0].w * clr_arg[1].w)
                    + clr_arg[2].w : 0.000000;
            clr_prv.w *= (dmp_TexEnv[c].scaleAlpha == 0) ? 1.000000 : (dmp_TexEnv[c].scaleAlpha == 1)
                    ? 2.000000 : (dmp_TexEnv[c].scaleAlpha == 2) ? 4.000000 : 1.000000;
            clr_prv = min(max(clr_prv, vec4(0.000000, 0.000000, 0.000000, 0.000000)), vec4(1.000000,
                    1.000000, 1.000000, 1.000000));
        }
    }
    if (true == dmp_FragOperation.enableAlphaTest) {
        bool pass = (dmp_FragOperation.alphaTestFunc == 519) ? true : (dmp_FragOperation.alphaTestFunc == 512)
                ? false : (dmp_FragOperation.alphaTestFunc == 518) ? (dmp_FragOperation.alphaRefValue <= clr_prv.a)
                : (dmp_FragOperation.alphaTestFunc == 516) ? (dmp_FragOperation.alphaRefValue < clr_prv.a)
                : (dmp_FragOperation.alphaTestFunc == 513) ? (dmp_FragOperation.alphaRefValue > clr_prv.a)
                : (dmp_FragOperation.alphaTestFunc == 515) ? (dmp_FragOperation.alphaRefValue >= clr_prv.a)
                : (dmp_FragOperation.alphaTestFunc == 514) ? (dmp_FragOperation.alphaRefValue == clr_prv.a)
                : (dmp_FragOperation.alphaTestFunc == 517) ? (dmp_FragOperation.alphaRefValue != clr_prv.a)
                : false;
        if (false == pass) {
            discard;
        }
    }
    outFragColor = clr_prv;
}
