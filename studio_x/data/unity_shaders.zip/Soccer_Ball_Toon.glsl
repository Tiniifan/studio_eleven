// Soccer/Ball_Toon (Shader path ID 989954322630815402, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	float _OutlineViewOffset;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float                _AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4                _OutlineColor;
	float                _OutlineNormalOffset;
	float                _OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec4 in_COLOR0;
in mediump vec2 in_TEXCOORD0;
layout(location = 0) out highp vec4 vs_COLOR0;
layout(location = 1) out highp vec4 vs_COLOR1;
layout(location = 2) out highp vec3 vs_TEXCOORD0;
layout(location = 3) out highp vec3 vs_TEXCOORD1;
layout(location = 4) out highp vec3 vs_TEXCOORD2;
layout(location = 5) out highp vec3 vs_TEXCOORD3;
layout(location = 6) out highp vec4 vs_TEXCOORD4;
layout(location = 7) out mediump vec2 vs_TEXCOORD5;
mediump  vec4 phase0_Output0_8;
layout(location = 8) out mediump vec2 vs_TEXCOORD6;
layout(location = 10) out mediump vec2 vs_TEXCOORD7;
mediump  vec4 phase0_Output0_9;
layout(location = 9) out mediump vec2 vs_TEXCOORD8;
vec4 u_xlat0;
bvec2 u_xlatb0;
vec4 u_xlat1;
bvec2 u_xlatb1;
vec3 u_xlat2;
mediump vec3 u_xlat16_3;
vec3 u_xlat4;
vec3 u_xlat5;
vec3 u_xlat6;
vec2 u_xlat12;
vec2 u_xlat13;
vec2 u_xlat14;
float u_xlat18;
float u_xlat19;
bool u_xlatb19;
mediump float u_xlat16_21;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat6.x = u_xlat0.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat0.x + u_xlat6.x;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat0.z + u_xlat0.x;
    u_xlat0.x = u_xlat0.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0.x = min(abs(u_xlat0.x), _OutlineDepthScaleMax);
    u_xlat6.x = dot(in_NORMAL0.xyz, in_NORMAL0.xyz);
    u_xlat6.x = inversesqrt(u_xlat6.x);
    u_xlat6.xyz = u_xlat6.xxx * in_NORMAL0.xyz;
    u_xlat6.xyz = u_xlat6.xyz * vec3(_OutlineNormalOffset);
    u_xlat0.xyz = u_xlat0.xxx * u_xlat6.xyz;
    u_xlat0.xyz = u_xlat0.xyz * in_COLOR0.zzz;
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.100000001, 0.100000001, 0.100000001) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1.xyz = (-u_xlat1.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat18 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat19 = sqrt(u_xlat18);
    u_xlat18 = inversesqrt(u_xlat18);
    u_xlat1.xyz = vec3(u_xlat18) * u_xlat1.xyz;
    u_xlat18 = min(u_xlat19, _OutlineViewOffset);
    u_xlat2.x = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat2.y = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat2.z = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat0.xyz = u_xlat2.xyz * vec3(u_xlat18) + u_xlat0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_TEXCOORD3.xyz = u_xlat0.xyz;
    u_xlat0 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    vs_COLOR0.xyz = _Color.xyz * _OutlineColor.xyz;
    vs_COLOR0.w = (-_Transparency) + 1.0;
    vs_COLOR1 = in_COLOR0;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat19 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat19 = max(u_xlat19, 1.17549435e-38);
    u_xlat19 = inversesqrt(u_xlat19);
    u_xlat1.xyz = vec3(u_xlat19) * u_xlat1.xyz;
    u_xlat19 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat19 = inversesqrt(u_xlat19);
    vs_TEXCOORD0.xyz = vec3(u_xlat19) * u_xlat1.xyz;
    u_xlat2.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat2.xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat2.xyz;
    u_xlat19 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat19 = max(u_xlat19, 1.17549435e-38);
    u_xlat19 = inversesqrt(u_xlat19);
    u_xlat2.xyz = vec3(u_xlat19) * u_xlat2.xyz;
    u_xlat16_3.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat16_3.x = inversesqrt(u_xlat16_3.x);
    u_xlat16_3.xyz = u_xlat2.xyz * u_xlat16_3.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_3.xyz;
    u_xlat4.xyz = u_xlat1.zxy * u_xlat2.yzx;
    u_xlat1.xyz = u_xlat1.yzx * u_xlat2.zxy + (-u_xlat4.xyz);
    u_xlatb19 = unity_WorldTransformParams.w>=0.0;
    u_xlat19 = (u_xlatb19) ? 1.0 : -1.0;
    u_xlat16_3.x = u_xlat19 * in_TANGENT0.w;
    u_xlat16_3.xyz = u_xlat1.xyz * u_xlat16_3.xxx;
    u_xlat16_21 = dot(u_xlat16_3.xyz, u_xlat16_3.xyz);
    u_xlat16_21 = inversesqrt(u_xlat16_21);
    u_xlat16_3.xyz = vec3(u_xlat16_21) * u_xlat16_3.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_3.xyz;
    u_xlat0.y = u_xlat0.y * _ProjectionParams.x;
    u_xlat1.xzw = u_xlat0.xwy * vec3(0.5, 0.5, 0.5);
    vs_TEXCOORD4.zw = u_xlat0.zw;
    vs_TEXCOORD4.xy = u_xlat1.zz + u_xlat1.xw;
    u_xlatb0.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = (u_xlatb0.x) ? float(1.0) : float(-1.0);
    u_xlat0.y = (u_xlatb0.y) ? float(1.0) : float(-1.0);
    u_xlat12.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat12.xy;
    u_xlat12.x = _ColorTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat12.x);
    u_xlat2.x = cos(u_xlat12.x);
    u_xlat4.z = u_xlat1.x;
    u_xlat12.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat4.y = u_xlat2.x;
    u_xlat4.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat12.xy, u_xlat4.xy);
    u_xlat1.x = dot(u_xlat12.xy, u_xlat4.yz);
    u_xlat0.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlatb1.xy = greaterThanEqual(_OcclusionTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = (u_xlatb1.x) ? float(1.0) : float(-1.0);
    u_xlat1.y = (u_xlatb1.y) ? float(1.0) : float(-1.0);
    u_xlat13.xy = max(abs(_OcclusionTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat13.xy;
    u_xlat13.x = _OcclusionTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat13.x);
    u_xlat4.x = cos(u_xlat13.x);
    u_xlat5.z = u_xlat2.x;
    u_xlat13.xy = in_TEXCOORD0.xy + (-_OcclusionTex_ST.zw);
    u_xlat5.y = u_xlat4.x;
    u_xlat5.x = (-u_xlat2.x);
    u_xlat14.y = dot(u_xlat13.xy, u_xlat5.xy);
    u_xlat14.x = dot(u_xlat13.xy, u_xlat5.yz);
    u_xlat0.zw = u_xlat14.xy / u_xlat1.xy;
    phase0_Output0_8 = u_xlat0;
    phase0_Output0_9 = vec4(0.0, 0.0, 0.0, 0.0);
vs_TEXCOORD5 = phase0_Output0_8.xy;
vs_TEXCOORD6 = phase0_Output0_8.zw;
vs_TEXCOORD7 = phase0_Output0_9.xy;
vs_TEXCOORD8 = phase0_Output0_9.zw;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float                _AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4                _OutlineColor;
	float                _OutlineNormalOffset;
	float                _OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2DArray _AdditionalFacialTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(3) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(4) uniform mediump sampler2D _ToonTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD8;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
int u_xlati0;
uvec2 u_xlatu0;
bool u_xlatb0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
vec3 u_xlat4;
mediump vec2 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
int u_xlati6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
int u_xlati7;
vec3 u_xlat8;
vec3 u_xlat9;
vec2 u_xlat10;
bool u_xlatb11;
float u_xlat12;
mediump vec2 u_xlat16_14;
float u_xlat17;
float u_xlat23;
float u_xlat28;
uint u_xlatu28;
float u_xlat34;
mediump float u_xlat16_36;
float u_xlat37;
float u_xlat38;
float u_xlat39;
int u_xlati39;
uint u_xlatu39;
bool u_xlatb39;
float u_xlat40;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat0.x = _AdditionalFacialTexIndex + 0.5;
    u_xlati0 = int(u_xlat0.x);
    u_xlatb11 = 0<u_xlati0;
    u_xlati0 = u_xlati0 + int(0xFFFFFFFFu);
    u_xlat1.z = float(u_xlati0);
    u_xlat1.xy = vs_TEXCOORD5.xy;
    u_xlat16_1 = texture(_AdditionalFacialTex, u_xlat1.xyz, _GlobalMipBias.x);
    u_xlat16_2 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat0 = (bool(u_xlatb11)) ? u_xlat16_1 : u_xlat16_2;
    u_xlat16_3.x = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_1.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat2 = u_xlat0 * vs_COLOR0;
    u_xlat1.x = dot(u_xlat16_1.xx, vs_COLOR1.ww);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat34 = u_xlat1.x + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_14.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_36 = dot(u_xlat16_14.xy, u_xlat16_14.xy);
    u_xlat16_36 = min(u_xlat16_36, 1.0);
    u_xlat16_36 = (-u_xlat16_36) + 1.0;
    u_xlat16_36 = sqrt(u_xlat16_36);
    u_xlat16_36 = max(u_xlat16_36, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_14.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_14.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_36) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat37 = inversesqrt(u_xlat37);
    u_xlat4.xyz = vec3(u_xlat37) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat38 = (-_ToonAmbient) + 1.0;
    u_xlat1.x = u_xlat1.x * _ToonAmbient;
    u_xlat37 = u_xlat37 * u_xlat38 + u_xlat1.x;
    u_xlat37 = u_xlat34 * _OcclusionAddScale + u_xlat37;
    u_xlat37 = clamp(u_xlat37, 0.0, 1.0);
    u_xlat37 = u_xlat37 * 0.5 + 0.5;
    u_xlat37 = u_xlat37 * unity_LightData.z;
    u_xlat16_14.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati6 = int(u_xlat16_14.x);
    u_xlat17 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati6) ; u_xlatu_loop_1++)
    {
        u_xlatu39 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati7 = int(u_xlatu_loop_1 & 3u);
        u_xlat39 = dot(unity_LightIndices[int(u_xlatu39)], ImmCB_0[u_xlati7]);
        u_xlati39 = int(u_xlat39);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati39].www + _AdditionalLightsPosition[u_xlati39].xyz;
        u_xlat40 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat40 = max(u_xlat40, 6.10351562e-05);
        u_xlat8.x = inversesqrt(u_xlat40);
        u_xlat7.xyz = u_xlat7.xyz * u_xlat8.xxx;
        u_xlat8.x = float(1.0) / float(u_xlat40);
        u_xlat40 = u_xlat40 * _AdditionalLightsAttenuation[u_xlati39].x;
        u_xlat16_14.x = (-u_xlat40) * u_xlat40 + 1.0;
        u_xlat16_14.x = max(u_xlat16_14.x, 0.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat40 = u_xlat16_14.x * u_xlat8.x;
        u_xlat16_14.x = dot(_AdditionalLightsSpotDir[u_xlati39].xyz, u_xlat7.xyz);
        u_xlat16_14.x = u_xlat16_14.x * _AdditionalLightsAttenuation[u_xlati39].z + _AdditionalLightsAttenuation[u_xlati39].w;
        u_xlat16_14.x = clamp(u_xlat16_14.x, 0.0, 1.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat39 = u_xlat16_14.x * u_xlat40;
        u_xlat7.x = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat7.x = clamp(u_xlat7.x, 0.0, 1.0);
        u_xlat7.x = u_xlat7.x * 0.5 + 0.5;
        u_xlat17 = u_xlat7.x * u_xlat39 + u_xlat17;
    }
    u_xlat6.x = u_xlat17 + vs_TEXCOORD8.x;
    u_xlat6.x = clamp(u_xlat6.x, 0.0, 1.0);
    u_xlat37 = max(u_xlat37, 0.0);
    u_xlat17 = u_xlat37 + (-u_charaShadowColor0.w);
    u_xlat28 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat39 = (-u_xlat37) + 1.0;
    u_xlat12 = u_xlat16_1.y * u_xlat39 + u_xlat37;
    u_xlat39 = 0.5;
    u_xlat7.x = u_xlat39 + u_xlat17;
    u_xlat7.y = u_xlat12 + u_xlat28;
    u_xlat12 = u_xlat6.x * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat8.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat2.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat9.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat10.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat7.xyz = (-u_xlat8.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat10.xxx * u_xlat7.xyz + u_xlat9.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat10.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = u_xlat6.xyz * u_xlat7.xyz;
    u_xlat16_3.x = u_xlat16_3.x * 0.200000003 + u_xlat16_1.z;
    u_xlat12 = min(u_xlat16_3.x, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vs_COLOR0.xyz + (-u_xlat6.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat6.xyz;
    u_xlat16_3.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_3.x = inversesqrt(u_xlat16_3.x);
    u_xlat16_3.xyz = u_xlat16_3.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_3.xyz);
    u_xlat5.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat23 = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat23 = inversesqrt(u_xlat23);
    u_xlat5.xyz = vec3(u_xlat23) * u_xlat5.xyz;
    u_xlat23 = dot(u_xlat5.xyz, u_xlat4.xyz);
    u_xlat23 = (-u_xlat23);
    u_xlat23 = clamp(u_xlat23, 0.0, 1.0);
    u_xlat23 = (-u_xlat23) + 1.0;
    u_xlat4.x = u_xlat12 * u_xlat23;
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x + u_xlat37;
    u_xlat1.x = (-u_xlat12) * u_xlat38 + u_xlat1.x;
    u_xlat1.x = u_xlat34 * _OcclusionAddScale + u_xlat1.x;
    u_xlat1.x = u_xlat1.x * 0.5 + 0.5;
    u_xlat12 = (-u_xlat12) * u_xlat23;
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat1.x = u_xlat12 + u_xlat1.x;
    u_xlat1.x = u_xlat1.x + (-u_charaUnderLightColor.w);
    u_xlat1.x = u_xlat1.x * _UnderLightToonFadeRange;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.xyz = u_xlat1.xxx * u_charaUnderLightColor.xyz;
    u_xlat34 = u_xlat4.x + (-u_charaHighLightColor.w);
    u_xlat34 = u_xlat34 * _CharaToonFadeRange;
    u_xlat34 = clamp(u_xlat34, 0.0, 1.0);
    u_xlat1.xyz = u_charaHighLightColor.xyz * vec3(u_xlat34) + u_xlat1.xyz;
    u_xlat4.xyz = u_xlat0.xyz + u_xlat1.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat1.xyz = (-u_xlat1.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat1.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat4.xyz) + u_xlat0.xyz;
    u_xlat2.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat4.xyz;
    u_xlat0.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat0.xy = u_xlat0.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu0.xy = uvec2(u_xlat0.xy);
    u_xlati0 = int(bitfieldInsert(0, int(u_xlatu0.x), 2 & int(0x1F), 2));
    u_xlati0 = int(bitfieldInsert(u_xlati0, int(u_xlatu0.y), 0 & int(0x1F), 2));
    u_xlat0.x = u_xlat0.w * vs_COLOR0.w + (-ImmCB_0[u_xlati0 + 4].x);
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    SV_Target0 = u_xlat2;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float                _AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4                _OutlineColor;
	float                _OutlineNormalOffset;
	float                _OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2DArray _AdditionalFacialTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(3) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(4) uniform mediump sampler2D _ToonTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD8;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
int u_xlati0;
uvec2 u_xlatu0;
bool u_xlatb0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
vec3 u_xlat4;
mediump vec2 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
int u_xlati6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
int u_xlati7;
vec3 u_xlat8;
vec3 u_xlat9;
vec2 u_xlat10;
bool u_xlatb11;
float u_xlat12;
mediump vec2 u_xlat16_14;
float u_xlat17;
float u_xlat23;
float u_xlat28;
uint u_xlatu28;
float u_xlat34;
mediump float u_xlat16_36;
float u_xlat37;
float u_xlat38;
float u_xlat39;
int u_xlati39;
uint u_xlatu39;
bool u_xlatb39;
float u_xlat40;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat0.x = _AdditionalFacialTexIndex + 0.5;
    u_xlati0 = int(u_xlat0.x);
    u_xlatb11 = 0<u_xlati0;
    u_xlati0 = u_xlati0 + int(0xFFFFFFFFu);
    u_xlat1.z = float(u_xlati0);
    u_xlat1.xy = vs_TEXCOORD5.xy;
    u_xlat16_1 = texture(_AdditionalFacialTex, u_xlat1.xyz, _GlobalMipBias.x);
    u_xlat16_2 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat0 = (bool(u_xlatb11)) ? u_xlat16_1 : u_xlat16_2;
    u_xlat16_3.x = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_1.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat2 = u_xlat0 * vs_COLOR0;
    u_xlat1.x = dot(u_xlat16_1.xx, vs_COLOR1.ww);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat34 = u_xlat1.x + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_14.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_36 = dot(u_xlat16_14.xy, u_xlat16_14.xy);
    u_xlat16_36 = min(u_xlat16_36, 1.0);
    u_xlat16_36 = (-u_xlat16_36) + 1.0;
    u_xlat16_36 = sqrt(u_xlat16_36);
    u_xlat16_36 = max(u_xlat16_36, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_14.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_14.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_36) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat37 = inversesqrt(u_xlat37);
    u_xlat4.xyz = vec3(u_xlat37) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat38 = (-_ToonAmbient) + 1.0;
    u_xlat1.x = u_xlat1.x * _ToonAmbient;
    u_xlat37 = u_xlat37 * u_xlat38 + u_xlat1.x;
    u_xlat37 = u_xlat34 * _OcclusionAddScale + u_xlat37;
    u_xlat37 = clamp(u_xlat37, 0.0, 1.0);
    u_xlat37 = u_xlat37 * 0.5 + 0.5;
    u_xlat37 = u_xlat37 * unity_LightData.z;
    u_xlat16_14.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati6 = int(u_xlat16_14.x);
    u_xlat17 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati6) ; u_xlatu_loop_1++)
    {
        u_xlatu39 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati7 = int(u_xlatu_loop_1 & 3u);
        u_xlat39 = dot(unity_LightIndices[int(u_xlatu39)], ImmCB_0[u_xlati7]);
        u_xlati39 = int(u_xlat39);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati39].www + _AdditionalLightsPosition[u_xlati39].xyz;
        u_xlat40 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat40 = max(u_xlat40, 6.10351562e-05);
        u_xlat8.x = inversesqrt(u_xlat40);
        u_xlat7.xyz = u_xlat7.xyz * u_xlat8.xxx;
        u_xlat8.x = float(1.0) / float(u_xlat40);
        u_xlat40 = u_xlat40 * _AdditionalLightsAttenuation[u_xlati39].x;
        u_xlat16_14.x = (-u_xlat40) * u_xlat40 + 1.0;
        u_xlat16_14.x = max(u_xlat16_14.x, 0.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat40 = u_xlat16_14.x * u_xlat8.x;
        u_xlat16_14.x = dot(_AdditionalLightsSpotDir[u_xlati39].xyz, u_xlat7.xyz);
        u_xlat16_14.x = u_xlat16_14.x * _AdditionalLightsAttenuation[u_xlati39].z + _AdditionalLightsAttenuation[u_xlati39].w;
        u_xlat16_14.x = clamp(u_xlat16_14.x, 0.0, 1.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat39 = u_xlat16_14.x * u_xlat40;
        u_xlat7.x = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat7.x = clamp(u_xlat7.x, 0.0, 1.0);
        u_xlat7.x = u_xlat7.x * 0.5 + 0.5;
        u_xlat17 = u_xlat7.x * u_xlat39 + u_xlat17;
    }
    u_xlat6.x = u_xlat17 + vs_TEXCOORD8.x;
    u_xlat6.x = clamp(u_xlat6.x, 0.0, 1.0);
    u_xlat37 = max(u_xlat37, 0.0);
    u_xlat17 = u_xlat37 + (-u_charaShadowColor0.w);
    u_xlat28 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat39 = (-u_xlat37) + 1.0;
    u_xlat12 = u_xlat16_1.y * u_xlat39 + u_xlat37;
    u_xlat39 = 0.5;
    u_xlat7.x = u_xlat39 + u_xlat17;
    u_xlat7.y = u_xlat12 + u_xlat28;
    u_xlat12 = u_xlat6.x * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat8.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat2.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat9.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat10.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat7.xyz = (-u_xlat8.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat10.xxx * u_xlat7.xyz + u_xlat9.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat10.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = u_xlat6.xyz * u_xlat7.xyz;
    u_xlat16_3.x = u_xlat16_3.x * 0.200000003 + u_xlat16_1.z;
    u_xlat12 = min(u_xlat16_3.x, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vs_COLOR0.xyz + (-u_xlat6.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat6.xyz;
    u_xlat16_3.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_3.x = inversesqrt(u_xlat16_3.x);
    u_xlat16_3.xyz = u_xlat16_3.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_3.xyz);
    u_xlat5.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat23 = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat23 = inversesqrt(u_xlat23);
    u_xlat5.xyz = vec3(u_xlat23) * u_xlat5.xyz;
    u_xlat23 = dot(u_xlat5.xyz, u_xlat4.xyz);
    u_xlat23 = (-u_xlat23);
    u_xlat23 = clamp(u_xlat23, 0.0, 1.0);
    u_xlat23 = (-u_xlat23) + 1.0;
    u_xlat4.x = u_xlat12 * u_xlat23;
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x + u_xlat37;
    u_xlat1.x = (-u_xlat12) * u_xlat38 + u_xlat1.x;
    u_xlat1.x = u_xlat34 * _OcclusionAddScale + u_xlat1.x;
    u_xlat1.x = u_xlat1.x * 0.5 + 0.5;
    u_xlat12 = (-u_xlat12) * u_xlat23;
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat1.x = u_xlat12 + u_xlat1.x;
    u_xlat1.x = u_xlat1.x + (-u_charaUnderLightColor.w);
    u_xlat1.x = u_xlat1.x * _UnderLightToonFadeRange;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.xyz = u_xlat1.xxx * u_charaUnderLightColor.xyz;
    u_xlat34 = u_xlat4.x + (-u_charaHighLightColor.w);
    u_xlat34 = u_xlat34 * _CharaToonFadeRange;
    u_xlat34 = clamp(u_xlat34, 0.0, 1.0);
    u_xlat1.xyz = u_charaHighLightColor.xyz * vec3(u_xlat34) + u_xlat1.xyz;
    u_xlat4.xyz = u_xlat0.xyz + u_xlat1.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat1.xyz = (-u_xlat1.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat1.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat4.xyz) + u_xlat0.xyz;
    u_xlat2.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat4.xyz;
    u_xlat0.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat0.xy = u_xlat0.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu0.xy = uvec2(u_xlat0.xy);
    u_xlati0 = int(bitfieldInsert(0, int(u_xlatu0.x), 2 & int(0x1F), 2));
    u_xlati0 = int(bitfieldInsert(u_xlati0, int(u_xlatu0.y), 0 & int(0x1F), 2));
    u_xlat0.x = u_xlat0.w * vs_COLOR0.w + (-ImmCB_0[u_xlati0 + 4].x);
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    SV_Target0 = u_xlat2;
    return;
}

#endif


// ===== program 2: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _Time;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 _ScreenParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	float _OutlineViewOffset;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float                _AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4                _OutlineColor;
	float                _OutlineNormalOffset;
	float                _OutlineDepthScaleMax;
	vec3                _StatesColor;
	vec4                _StatesRimColor;
	float                _StatesRimPow;
	float                _StatesTexRateIn;
	float                _StatesTexRateOut;
	float                _StatesTexDistortion;
	float                _StatesTexScaleU;
	float                _StatesTexScaleV;
	float                _StatesTexScrollSpeedU;
	float                _StatesTexScrollSpeedV;
	vec3                _StatesTexPos;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec4 in_COLOR0;
in mediump vec2 in_TEXCOORD0;
layout(location = 0) out highp vec4 vs_COLOR0;
layout(location = 1) out highp vec4 vs_COLOR1;
layout(location = 2) out highp vec3 vs_TEXCOORD0;
layout(location = 3) out highp vec3 vs_TEXCOORD1;
layout(location = 4) out highp vec3 vs_TEXCOORD2;
layout(location = 5) out highp vec3 vs_TEXCOORD3;
layout(location = 6) out highp vec4 vs_TEXCOORD4;
layout(location = 7) out mediump vec2 vs_TEXCOORD5;
mediump  vec4 phase0_Output0_8;
layout(location = 8) out mediump vec2 vs_TEXCOORD6;
layout(location = 9) out mediump vec2 vs_TEXCOORD7;
layout(location = 10) out mediump vec2 vs_TEXCOORD8;
vec4 u_xlat0;
vec4 u_xlat1;
bvec2 u_xlatb1;
vec4 u_xlat2;
bvec2 u_xlatb2;
vec3 u_xlat3;
mediump vec3 u_xlat16_4;
vec3 u_xlat5;
vec3 u_xlat6;
vec3 u_xlat7;
float u_xlat8;
vec2 u_xlat15;
vec2 u_xlat16;
vec2 u_xlat17;
float u_xlat21;
float u_xlat22;
float u_xlat23;
bool u_xlatb23;
mediump float u_xlat16_25;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat7.x = u_xlat0.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat0.x + u_xlat7.x;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat0.z + u_xlat0.x;
    u_xlat0.x = u_xlat0.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0.x = min(abs(u_xlat0.x), _OutlineDepthScaleMax);
    u_xlat7.x = dot(in_NORMAL0.xyz, in_NORMAL0.xyz);
    u_xlat7.x = inversesqrt(u_xlat7.x);
    u_xlat7.xyz = u_xlat7.xxx * in_NORMAL0.xyz;
    u_xlat7.xyz = u_xlat7.xyz * vec3(_OutlineNormalOffset);
    u_xlat0.xyz = u_xlat0.xxx * u_xlat7.xyz;
    u_xlat0.xyz = u_xlat0.xyz * in_COLOR0.zzz;
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.100000001, 0.100000001, 0.100000001) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1.xyz = (-u_xlat1.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat21 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat22 = sqrt(u_xlat21);
    u_xlat21 = inversesqrt(u_xlat21);
    u_xlat1.xyz = vec3(u_xlat21) * u_xlat1.xyz;
    u_xlat21 = min(u_xlat22, _OutlineViewOffset);
    u_xlat2.x = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat2.y = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat2.z = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat0.xyz = u_xlat2.xyz * vec3(u_xlat21) + u_xlat0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat1 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat1;
    vs_COLOR0.xyz = _Color.xyz * _OutlineColor.xyz;
    vs_COLOR0.w = (-_Transparency) + 1.0;
    vs_COLOR1 = in_COLOR0;
    u_xlat2.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat2.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat23 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat23 = max(u_xlat23, 1.17549435e-38);
    u_xlat23 = inversesqrt(u_xlat23);
    u_xlat2.xyz = vec3(u_xlat23) * u_xlat2.xyz;
    u_xlat23 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat23 = inversesqrt(u_xlat23);
    vs_TEXCOORD0.xyz = vec3(u_xlat23) * u_xlat2.xyz;
    u_xlat3.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat3.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat3.xyz;
    u_xlat3.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat3.xyz;
    u_xlat23 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat23 = max(u_xlat23, 1.17549435e-38);
    u_xlat23 = inversesqrt(u_xlat23);
    u_xlat3.xyz = vec3(u_xlat23) * u_xlat3.xyz;
    u_xlat16_4.x = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat16_4.x = inversesqrt(u_xlat16_4.x);
    u_xlat16_4.xyz = u_xlat3.xyz * u_xlat16_4.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_4.xyz;
    u_xlat5.xyz = u_xlat2.zxy * u_xlat3.yzx;
    u_xlat2.xyz = u_xlat2.yzx * u_xlat3.zxy + (-u_xlat5.xyz);
    u_xlatb23 = unity_WorldTransformParams.w>=0.0;
    u_xlat23 = (u_xlatb23) ? 1.0 : -1.0;
    u_xlat16_4.x = u_xlat23 * in_TANGENT0.w;
    u_xlat16_4.xyz = u_xlat2.xyz * u_xlat16_4.xxx;
    u_xlat16_25 = dot(u_xlat16_4.xyz, u_xlat16_4.xyz);
    u_xlat16_25 = inversesqrt(u_xlat16_25);
    u_xlat16_4.xyz = vec3(u_xlat16_25) * u_xlat16_4.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_4.xyz;
    vs_TEXCOORD3.xyz = u_xlat0.xyz;
    u_xlat1.y = u_xlat1.y * _ProjectionParams.x;
    u_xlat2.xzw = u_xlat1.xwy * vec3(0.5, 0.5, 0.5);
    vs_TEXCOORD4.zw = u_xlat1.zw;
    vs_TEXCOORD4.xy = u_xlat2.zz + u_xlat2.xw;
    u_xlatb1.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = (u_xlatb1.x) ? float(1.0) : float(-1.0);
    u_xlat1.y = (u_xlatb1.y) ? float(1.0) : float(-1.0);
    u_xlat15.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat15.xy;
    u_xlat15.x = _ColorTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat15.x);
    u_xlat3.x = cos(u_xlat15.x);
    u_xlat5.z = u_xlat2.x;
    u_xlat15.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat5.y = u_xlat3.x;
    u_xlat5.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat15.xy, u_xlat5.xy);
    u_xlat2.x = dot(u_xlat15.xy, u_xlat5.yz);
    u_xlat1.xy = u_xlat2.xy / u_xlat1.xy;
    u_xlatb2.xy = greaterThanEqual(_OcclusionTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat2.x = (u_xlatb2.x) ? float(1.0) : float(-1.0);
    u_xlat2.y = (u_xlatb2.y) ? float(1.0) : float(-1.0);
    u_xlat16.xy = max(abs(_OcclusionTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat2.xy = u_xlat2.xy * u_xlat16.xy;
    u_xlat16.x = _OcclusionTex_R * 0.0174532924;
    u_xlat3.x = sin(u_xlat16.x);
    u_xlat5.x = cos(u_xlat16.x);
    u_xlat6.z = u_xlat3.x;
    u_xlat16.xy = in_TEXCOORD0.xy + (-_OcclusionTex_ST.zw);
    u_xlat6.y = u_xlat5.x;
    u_xlat6.x = (-u_xlat3.x);
    u_xlat17.y = dot(u_xlat16.xy, u_xlat6.xy);
    u_xlat17.x = dot(u_xlat16.xy, u_xlat6.yz);
    u_xlat1.zw = u_xlat17.xy / u_xlat2.xy;
    phase0_Output0_8 = u_xlat1;
    u_xlat1.w = dot((-_StatesTexPos.xyz), hlslcc_mtx4x4unity_MatrixV[1].xyz);
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[0].y;
    u_xlat1.y = hlslcc_mtx4x4unity_MatrixV[1].y;
    u_xlat1.z = hlslcc_mtx4x4unity_MatrixV[2].y;
    u_xlat0.w = 1.0;
    u_xlat1.x = dot(u_xlat1, u_xlat0);
    u_xlat8 = _ScreenParams.x / _ScreenParams.y;
    u_xlat1.y = u_xlat1.x / (-u_xlat8);
    u_xlat2.w = dot((-_StatesTexPos.xyz), hlslcc_mtx4x4unity_MatrixV[0].xyz);
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[0].x;
    u_xlat2.y = hlslcc_mtx4x4unity_MatrixV[1].x;
    u_xlat2.z = hlslcc_mtx4x4unity_MatrixV[2].x;
    u_xlat1.x = dot(u_xlat2, u_xlat0);
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[0].w;
    u_xlat2.y = hlslcc_mtx4x4unity_MatrixV[1].w;
    u_xlat2.z = hlslcc_mtx4x4unity_MatrixV[2].w;
    u_xlat2.w = hlslcc_mtx4x4unity_MatrixV[3].w;
    u_xlat0.x = dot(u_xlat2, u_xlat0);
    u_xlat0.xy = u_xlat1.xy / u_xlat0.xx;
    u_xlat0.xy = u_xlat0.xy * vec2(_StatesTexScaleU, _StatesTexScaleV);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5) + vec2(0.5, 0.5);
    u_xlat0.xy = u_xlat0.xy * vec2(vec2(_StatesTexDistortion, _StatesTexDistortion)) + u_xlat0.xy;
    u_xlat0.x = _Time.x * (-_StatesTexScrollSpeedU) + u_xlat0.x;
    u_xlat0.y = _Time.x * _StatesTexScrollSpeedV + u_xlat0.y;
    vs_TEXCOORD7.xy = u_xlat0.xy;
    vs_TEXCOORD8.xy = vec2(0.0, 0.0);
vs_TEXCOORD5 = phase0_Output0_8.xy;
vs_TEXCOORD6 = phase0_Output0_8.zw;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
uniform 	float _UseCharacterLightDirection;
uniform 	vec3 _CharacterLightDirection;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float                _AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4                _OutlineColor;
	float                _OutlineNormalOffset;
	float                _OutlineDepthScaleMax;
	vec3                _StatesColor;
	vec4                _StatesRimColor;
	float                _StatesRimPow;
	float                _StatesTexRateIn;
	float                _StatesTexRateOut;
	float                _StatesTexDistortion;
	float                _StatesTexScaleU;
	float                _StatesTexScaleV;
	float                _StatesTexScrollSpeedU;
	float                _StatesTexScrollSpeedV;
	vec3                _StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2DArray _AdditionalFacialTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(3) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(4) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(5) uniform mediump sampler2D _StatesTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD7;
layout(location = 10) in mediump  vec2 vs_TEXCOORD8;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
int u_xlati0;
uvec2 u_xlatu0;
bool u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec4 u_xlat16_3;
vec3 u_xlat4;
mediump vec2 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
int u_xlati6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
int u_xlati7;
vec3 u_xlat8;
vec3 u_xlat9;
vec2 u_xlat10;
bool u_xlatb11;
float u_xlat12;
mediump vec2 u_xlat16_14;
float u_xlat17;
float u_xlat23;
float u_xlat28;
uint u_xlatu28;
float u_xlat34;
mediump float u_xlat16_36;
float u_xlat37;
float u_xlat38;
float u_xlat39;
int u_xlati39;
uint u_xlatu39;
bool u_xlatb39;
float u_xlat40;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat0.x = _AdditionalFacialTexIndex + 0.5;
    u_xlati0 = int(u_xlat0.x);
    u_xlatb11 = 0<u_xlati0;
    u_xlati0 = u_xlati0 + int(0xFFFFFFFFu);
    u_xlat1.z = float(u_xlati0);
    u_xlat1.xy = vs_TEXCOORD5.xy;
    u_xlat16_1 = texture(_AdditionalFacialTex, u_xlat1.xyz, _GlobalMipBias.x);
    u_xlat16_2 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat0 = (bool(u_xlatb11)) ? u_xlat16_1 : u_xlat16_2;
    u_xlat16_3.x = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_1.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat2 = u_xlat0 * vs_COLOR0;
    u_xlat1.x = dot(u_xlat16_1.xx, vs_COLOR1.ww);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat34 = u_xlat1.x + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_14.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_36 = dot(u_xlat16_14.xy, u_xlat16_14.xy);
    u_xlat16_36 = min(u_xlat16_36, 1.0);
    u_xlat16_36 = (-u_xlat16_36) + 1.0;
    u_xlat16_36 = sqrt(u_xlat16_36);
    u_xlat16_36 = max(u_xlat16_36, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_14.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_14.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_36) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat37 = inversesqrt(u_xlat37);
    u_xlat4.xyz = vec3(u_xlat37) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDirection.xyz;
    u_xlat5.xyz = vec3(vec3(_UseCharacterLightDirection, _UseCharacterLightDirection, _UseCharacterLightDirection)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat6.xyz = (-u_xlat5.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat6.xyz + u_xlat5.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat38 = (-_ToonAmbient) + 1.0;
    u_xlat1.x = u_xlat1.x * _ToonAmbient;
    u_xlat37 = u_xlat37 * u_xlat38 + u_xlat1.x;
    u_xlat37 = u_xlat34 * _OcclusionAddScale + u_xlat37;
    u_xlat37 = clamp(u_xlat37, 0.0, 1.0);
    u_xlat37 = u_xlat37 * 0.5 + 0.5;
    u_xlat37 = u_xlat37 * unity_LightData.z;
    u_xlat16_14.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati6 = int(u_xlat16_14.x);
    u_xlat17 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati6) ; u_xlatu_loop_1++)
    {
        u_xlatu39 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati7 = int(u_xlatu_loop_1 & 3u);
        u_xlat39 = dot(unity_LightIndices[int(u_xlatu39)], ImmCB_0[u_xlati7]);
        u_xlati39 = int(u_xlat39);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati39].www + _AdditionalLightsPosition[u_xlati39].xyz;
        u_xlat40 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat40 = max(u_xlat40, 6.10351562e-05);
        u_xlat8.x = inversesqrt(u_xlat40);
        u_xlat7.xyz = u_xlat7.xyz * u_xlat8.xxx;
        u_xlat8.x = float(1.0) / float(u_xlat40);
        u_xlat40 = u_xlat40 * _AdditionalLightsAttenuation[u_xlati39].x;
        u_xlat16_14.x = (-u_xlat40) * u_xlat40 + 1.0;
        u_xlat16_14.x = max(u_xlat16_14.x, 0.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat40 = u_xlat16_14.x * u_xlat8.x;
        u_xlat16_14.x = dot(_AdditionalLightsSpotDir[u_xlati39].xyz, u_xlat7.xyz);
        u_xlat16_14.x = u_xlat16_14.x * _AdditionalLightsAttenuation[u_xlati39].z + _AdditionalLightsAttenuation[u_xlati39].w;
        u_xlat16_14.x = clamp(u_xlat16_14.x, 0.0, 1.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat39 = u_xlat16_14.x * u_xlat40;
        u_xlat7.x = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat7.x = clamp(u_xlat7.x, 0.0, 1.0);
        u_xlat7.x = u_xlat7.x * 0.5 + 0.5;
        u_xlat17 = u_xlat7.x * u_xlat39 + u_xlat17;
    }
    u_xlat6.x = u_xlat17 + vs_TEXCOORD8.x;
    u_xlat6.x = clamp(u_xlat6.x, 0.0, 1.0);
    u_xlat37 = max(u_xlat37, 0.0);
    u_xlat17 = u_xlat37 + (-u_charaShadowColor0.w);
    u_xlat28 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat39 = (-u_xlat37) + 1.0;
    u_xlat12 = u_xlat16_1.y * u_xlat39 + u_xlat37;
    u_xlat39 = 0.5;
    u_xlat7.x = u_xlat39 + u_xlat17;
    u_xlat7.y = u_xlat12 + u_xlat28;
    u_xlat12 = u_xlat6.x * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat8.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat2.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat9.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat10.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat7.xyz = (-u_xlat8.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat10.xxx * u_xlat7.xyz + u_xlat9.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat10.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = u_xlat6.xyz * u_xlat7.xyz;
    u_xlat16_3.x = u_xlat16_3.x * 0.200000003 + u_xlat16_1.z;
    u_xlat12 = min(u_xlat16_3.x, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vs_COLOR0.xyz + (-u_xlat6.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat6.xyz;
    u_xlat16_3.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_3.x = inversesqrt(u_xlat16_3.x);
    u_xlat16_3.xyz = u_xlat16_3.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_3.xyz);
    u_xlat5.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat23 = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat23 = inversesqrt(u_xlat23);
    u_xlat5.xyz = vec3(u_xlat23) * u_xlat5.xyz;
    u_xlat23 = dot(u_xlat5.xyz, u_xlat4.xyz);
    u_xlat23 = (-u_xlat23);
    u_xlat23 = clamp(u_xlat23, 0.0, 1.0);
    u_xlat23 = (-u_xlat23) + 1.0;
    u_xlat5.x = u_xlat12 * u_xlat23;
    u_xlat5.x = clamp(u_xlat5.x, 0.0, 1.0);
    u_xlat37 = u_xlat37 + u_xlat5.x;
    u_xlat1.x = (-u_xlat12) * u_xlat38 + u_xlat1.x;
    u_xlat1.x = u_xlat34 * _OcclusionAddScale + u_xlat1.x;
    u_xlat1.x = u_xlat1.x * 0.5 + 0.5;
    u_xlat12 = (-u_xlat12) * u_xlat23;
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat1.x = u_xlat12 + u_xlat1.x;
    u_xlat1.x = u_xlat1.x + (-u_charaUnderLightColor.w);
    u_xlat1.x = u_xlat1.x * _UnderLightToonFadeRange;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.xyz = u_xlat1.xxx * u_charaUnderLightColor.xyz;
    u_xlat34 = u_xlat37 + (-u_charaHighLightColor.w);
    u_xlat34 = u_xlat34 * _CharaToonFadeRange;
    u_xlat34 = clamp(u_xlat34, 0.0, 1.0);
    u_xlat1.xyz = u_charaHighLightColor.xyz * vec3(u_xlat34) + u_xlat1.xyz;
    u_xlat5.xyz = u_xlat0.xyz + u_xlat1.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat1.xyz = (-u_xlat1.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat1.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat5.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat5.xyz;
    u_xlat1.xyz = (-vs_TEXCOORD3.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat34 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat34 = inversesqrt(u_xlat34);
    u_xlat1.xyz = vec3(u_xlat34) * u_xlat1.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat4.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat12 = u_xlat1.x * 5.0;
    u_xlat12 = min(u_xlat12, 1.0);
    u_xlat16_3 = texture(_StatesTex, vs_TEXCOORD7.xy, _GlobalMipBias.x);
    u_xlat23 = (-_StatesTexRateOut) + _StatesTexRateIn;
    u_xlat23 = u_xlat1.x * u_xlat23 + _StatesTexRateOut;
    u_xlat23 = max(u_xlat23, 0.0);
    u_xlat23 = u_xlat12 * u_xlat23;
    u_xlat4.xyz = vec3(u_xlat23) * u_xlat16_3.xyz;
    u_xlat23 = (-u_xlat16_3.w) * u_xlat23 + 1.0;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat23) + u_xlat4.xyz;
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = log2(u_xlat1.x);
    u_xlat1.x = u_xlat1.x * _StatesRimPow;
    u_xlat1.x = exp2(u_xlat1.x);
    u_xlat4.xyz = _StatesRimColor.www * _StatesRimColor.xyz;
    u_xlat5.xyz = u_xlat1.xxx * u_xlat4.xyz;
    u_xlat5.xyz = u_xlat5.xyz;
    u_xlat5.xyz = clamp(u_xlat5.xyz, 0.0, 1.0);
    u_xlat5.xyz = u_xlat5.xyz * vec3(0.300000012, 0.300000012, 0.300000012);
    u_xlat1.xzw = u_xlat1.xxx * u_xlat4.xyz + (-u_xlat5.xyz);
    u_xlat1.xyz = vec3(u_xlat12) * u_xlat1.xzw + u_xlat5.xyz;
    u_xlat2.xyz = u_xlat0.xyz * _StatesColor.xyz + u_xlat1.xyz;
    u_xlat0.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat0.xy = u_xlat0.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu0.xy = uvec2(u_xlat0.xy);
    u_xlati0 = int(bitfieldInsert(0, int(u_xlatu0.x), 2 & int(0x1F), 2));
    u_xlati0 = int(bitfieldInsert(u_xlati0, int(u_xlatu0.y), 0 & int(0x1F), 2));
    u_xlat0.x = u_xlat0.w * vs_COLOR0.w + (-ImmCB_0[u_xlati0 + 4].x);
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    SV_Target0 = u_xlat2;
    return;
}

#endif


// ===== program 3: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
uniform 	float _UseCharacterLightDirection;
uniform 	vec3 _CharacterLightDirection;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float                _AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4                _OutlineColor;
	float                _OutlineNormalOffset;
	float                _OutlineDepthScaleMax;
	vec3                _StatesColor;
	vec4                _StatesRimColor;
	float                _StatesRimPow;
	float                _StatesTexRateIn;
	float                _StatesTexRateOut;
	float                _StatesTexDistortion;
	float                _StatesTexScaleU;
	float                _StatesTexScaleV;
	float                _StatesTexScrollSpeedU;
	float                _StatesTexScrollSpeedV;
	vec3                _StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2DArray _AdditionalFacialTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(3) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(4) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(5) uniform mediump sampler2D _StatesTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD7;
layout(location = 10) in mediump  vec2 vs_TEXCOORD8;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
int u_xlati0;
uvec2 u_xlatu0;
bool u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec4 u_xlat16_3;
vec3 u_xlat4;
mediump vec2 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
int u_xlati6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
int u_xlati7;
vec3 u_xlat8;
vec3 u_xlat9;
vec2 u_xlat10;
bool u_xlatb11;
float u_xlat12;
mediump vec2 u_xlat16_14;
float u_xlat17;
float u_xlat23;
float u_xlat28;
uint u_xlatu28;
float u_xlat34;
mediump float u_xlat16_36;
float u_xlat37;
float u_xlat38;
float u_xlat39;
int u_xlati39;
uint u_xlatu39;
bool u_xlatb39;
float u_xlat40;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat0.x = _AdditionalFacialTexIndex + 0.5;
    u_xlati0 = int(u_xlat0.x);
    u_xlatb11 = 0<u_xlati0;
    u_xlati0 = u_xlati0 + int(0xFFFFFFFFu);
    u_xlat1.z = float(u_xlati0);
    u_xlat1.xy = vs_TEXCOORD5.xy;
    u_xlat16_1 = texture(_AdditionalFacialTex, u_xlat1.xyz, _GlobalMipBias.x);
    u_xlat16_2 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat0 = (bool(u_xlatb11)) ? u_xlat16_1 : u_xlat16_2;
    u_xlat16_3.x = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_1.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat2 = u_xlat0 * vs_COLOR0;
    u_xlat1.x = dot(u_xlat16_1.xx, vs_COLOR1.ww);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat34 = u_xlat1.x + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_14.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_36 = dot(u_xlat16_14.xy, u_xlat16_14.xy);
    u_xlat16_36 = min(u_xlat16_36, 1.0);
    u_xlat16_36 = (-u_xlat16_36) + 1.0;
    u_xlat16_36 = sqrt(u_xlat16_36);
    u_xlat16_36 = max(u_xlat16_36, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_14.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_14.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_36) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat37 = inversesqrt(u_xlat37);
    u_xlat4.xyz = vec3(u_xlat37) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDirection.xyz;
    u_xlat5.xyz = vec3(vec3(_UseCharacterLightDirection, _UseCharacterLightDirection, _UseCharacterLightDirection)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat6.xyz = (-u_xlat5.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat6.xyz + u_xlat5.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat38 = (-_ToonAmbient) + 1.0;
    u_xlat1.x = u_xlat1.x * _ToonAmbient;
    u_xlat37 = u_xlat37 * u_xlat38 + u_xlat1.x;
    u_xlat37 = u_xlat34 * _OcclusionAddScale + u_xlat37;
    u_xlat37 = clamp(u_xlat37, 0.0, 1.0);
    u_xlat37 = u_xlat37 * 0.5 + 0.5;
    u_xlat37 = u_xlat37 * unity_LightData.z;
    u_xlat16_14.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati6 = int(u_xlat16_14.x);
    u_xlat17 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati6) ; u_xlatu_loop_1++)
    {
        u_xlatu39 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati7 = int(u_xlatu_loop_1 & 3u);
        u_xlat39 = dot(unity_LightIndices[int(u_xlatu39)], ImmCB_0[u_xlati7]);
        u_xlati39 = int(u_xlat39);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati39].www + _AdditionalLightsPosition[u_xlati39].xyz;
        u_xlat40 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat40 = max(u_xlat40, 6.10351562e-05);
        u_xlat8.x = inversesqrt(u_xlat40);
        u_xlat7.xyz = u_xlat7.xyz * u_xlat8.xxx;
        u_xlat8.x = float(1.0) / float(u_xlat40);
        u_xlat40 = u_xlat40 * _AdditionalLightsAttenuation[u_xlati39].x;
        u_xlat16_14.x = (-u_xlat40) * u_xlat40 + 1.0;
        u_xlat16_14.x = max(u_xlat16_14.x, 0.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat40 = u_xlat16_14.x * u_xlat8.x;
        u_xlat16_14.x = dot(_AdditionalLightsSpotDir[u_xlati39].xyz, u_xlat7.xyz);
        u_xlat16_14.x = u_xlat16_14.x * _AdditionalLightsAttenuation[u_xlati39].z + _AdditionalLightsAttenuation[u_xlati39].w;
        u_xlat16_14.x = clamp(u_xlat16_14.x, 0.0, 1.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat39 = u_xlat16_14.x * u_xlat40;
        u_xlat7.x = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat7.x = clamp(u_xlat7.x, 0.0, 1.0);
        u_xlat7.x = u_xlat7.x * 0.5 + 0.5;
        u_xlat17 = u_xlat7.x * u_xlat39 + u_xlat17;
    }
    u_xlat6.x = u_xlat17 + vs_TEXCOORD8.x;
    u_xlat6.x = clamp(u_xlat6.x, 0.0, 1.0);
    u_xlat37 = max(u_xlat37, 0.0);
    u_xlat17 = u_xlat37 + (-u_charaShadowColor0.w);
    u_xlat28 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat39 = (-u_xlat37) + 1.0;
    u_xlat12 = u_xlat16_1.y * u_xlat39 + u_xlat37;
    u_xlat39 = 0.5;
    u_xlat7.x = u_xlat39 + u_xlat17;
    u_xlat7.y = u_xlat12 + u_xlat28;
    u_xlat12 = u_xlat6.x * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat8.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat2.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat9.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat10.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat7.xyz = (-u_xlat8.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat10.xxx * u_xlat7.xyz + u_xlat9.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat10.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = u_xlat6.xyz * u_xlat7.xyz;
    u_xlat16_3.x = u_xlat16_3.x * 0.200000003 + u_xlat16_1.z;
    u_xlat12 = min(u_xlat16_3.x, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vs_COLOR0.xyz + (-u_xlat6.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat6.xyz;
    u_xlat16_3.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_3.x = inversesqrt(u_xlat16_3.x);
    u_xlat16_3.xyz = u_xlat16_3.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_3.xyz);
    u_xlat5.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat23 = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat23 = inversesqrt(u_xlat23);
    u_xlat5.xyz = vec3(u_xlat23) * u_xlat5.xyz;
    u_xlat23 = dot(u_xlat5.xyz, u_xlat4.xyz);
    u_xlat23 = (-u_xlat23);
    u_xlat23 = clamp(u_xlat23, 0.0, 1.0);
    u_xlat23 = (-u_xlat23) + 1.0;
    u_xlat5.x = u_xlat12 * u_xlat23;
    u_xlat5.x = clamp(u_xlat5.x, 0.0, 1.0);
    u_xlat37 = u_xlat37 + u_xlat5.x;
    u_xlat1.x = (-u_xlat12) * u_xlat38 + u_xlat1.x;
    u_xlat1.x = u_xlat34 * _OcclusionAddScale + u_xlat1.x;
    u_xlat1.x = u_xlat1.x * 0.5 + 0.5;
    u_xlat12 = (-u_xlat12) * u_xlat23;
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat1.x = u_xlat12 + u_xlat1.x;
    u_xlat1.x = u_xlat1.x + (-u_charaUnderLightColor.w);
    u_xlat1.x = u_xlat1.x * _UnderLightToonFadeRange;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.xyz = u_xlat1.xxx * u_charaUnderLightColor.xyz;
    u_xlat34 = u_xlat37 + (-u_charaHighLightColor.w);
    u_xlat34 = u_xlat34 * _CharaToonFadeRange;
    u_xlat34 = clamp(u_xlat34, 0.0, 1.0);
    u_xlat1.xyz = u_charaHighLightColor.xyz * vec3(u_xlat34) + u_xlat1.xyz;
    u_xlat5.xyz = u_xlat0.xyz + u_xlat1.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat1.xyz = (-u_xlat1.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat1.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat5.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat5.xyz;
    u_xlat1.xyz = (-vs_TEXCOORD3.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat34 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat34 = inversesqrt(u_xlat34);
    u_xlat1.xyz = vec3(u_xlat34) * u_xlat1.xyz;
    u_xlat1.x = dot(u_xlat1.xyz, u_xlat4.xyz);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat12 = u_xlat1.x * 5.0;
    u_xlat12 = min(u_xlat12, 1.0);
    u_xlat16_3 = texture(_StatesTex, vs_TEXCOORD7.xy, _GlobalMipBias.x);
    u_xlat23 = (-_StatesTexRateOut) + _StatesTexRateIn;
    u_xlat23 = u_xlat1.x * u_xlat23 + _StatesTexRateOut;
    u_xlat23 = max(u_xlat23, 0.0);
    u_xlat23 = u_xlat12 * u_xlat23;
    u_xlat4.xyz = vec3(u_xlat23) * u_xlat16_3.xyz;
    u_xlat23 = (-u_xlat16_3.w) * u_xlat23 + 1.0;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat23) + u_xlat4.xyz;
    u_xlat1.x = (-u_xlat1.x) + 1.0;
    u_xlat1.x = log2(u_xlat1.x);
    u_xlat1.x = u_xlat1.x * _StatesRimPow;
    u_xlat1.x = exp2(u_xlat1.x);
    u_xlat4.xyz = _StatesRimColor.www * _StatesRimColor.xyz;
    u_xlat5.xyz = u_xlat1.xxx * u_xlat4.xyz;
    u_xlat5.xyz = u_xlat5.xyz;
    u_xlat5.xyz = clamp(u_xlat5.xyz, 0.0, 1.0);
    u_xlat5.xyz = u_xlat5.xyz * vec3(0.300000012, 0.300000012, 0.300000012);
    u_xlat1.xzw = u_xlat1.xxx * u_xlat4.xyz + (-u_xlat5.xyz);
    u_xlat1.xyz = vec3(u_xlat12) * u_xlat1.xzw + u_xlat5.xyz;
    u_xlat2.xyz = u_xlat0.xyz * _StatesColor.xyz + u_xlat1.xyz;
    u_xlat0.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat0.xy = u_xlat0.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu0.xy = uvec2(u_xlat0.xy);
    u_xlati0 = int(bitfieldInsert(0, int(u_xlatu0.x), 2 & int(0x1F), 2));
    u_xlati0 = int(bitfieldInsert(u_xlati0, int(u_xlatu0.y), 0 & int(0x1F), 2));
    u_xlat0.x = u_xlat0.w * vs_COLOR0.w + (-ImmCB_0[u_xlati0 + 4].x);
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    SV_Target0 = u_xlat2;
    return;
}

#endif


// ===== program 4: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	float _OutlineViewOffset;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float                _AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4                _OutlineColor;
	float                _OutlineNormalOffset;
	float                _OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec4 in_COLOR0;
in mediump vec2 in_TEXCOORD0;
layout(location = 0) out highp vec4 vs_COLOR0;
layout(location = 1) out highp vec4 vs_COLOR1;
layout(location = 2) out highp vec3 vs_TEXCOORD0;
layout(location = 3) out highp vec3 vs_TEXCOORD1;
layout(location = 4) out highp vec3 vs_TEXCOORD2;
layout(location = 5) out highp vec3 vs_TEXCOORD3;
layout(location = 6) out highp vec4 vs_TEXCOORD4;
layout(location = 7) out mediump vec2 vs_TEXCOORD5;
mediump  vec4 phase0_Output0_8;
layout(location = 8) out mediump vec2 vs_TEXCOORD6;
layout(location = 10) out mediump vec2 vs_TEXCOORD7;
mediump  vec4 phase0_Output0_9;
layout(location = 9) out mediump vec2 vs_TEXCOORD8;
vec4 u_xlat0;
bvec2 u_xlatb0;
vec4 u_xlat1;
bvec2 u_xlatb1;
vec3 u_xlat2;
mediump vec3 u_xlat16_3;
vec3 u_xlat4;
vec3 u_xlat5;
vec3 u_xlat6;
vec2 u_xlat12;
vec2 u_xlat13;
vec2 u_xlat14;
float u_xlat18;
float u_xlat19;
bool u_xlatb19;
mediump float u_xlat16_21;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat6.x = u_xlat0.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat0.x + u_xlat6.x;
    u_xlat0.x = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat0.z + u_xlat0.x;
    u_xlat0.x = u_xlat0.x + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat0.x = min(abs(u_xlat0.x), _OutlineDepthScaleMax);
    u_xlat6.x = dot(in_NORMAL0.xyz, in_NORMAL0.xyz);
    u_xlat6.x = inversesqrt(u_xlat6.x);
    u_xlat6.xyz = u_xlat6.xxx * in_NORMAL0.xyz;
    u_xlat6.xyz = u_xlat6.xyz * vec3(_OutlineNormalOffset);
    u_xlat0.xyz = u_xlat0.xxx * u_xlat6.xyz;
    u_xlat0.xyz = u_xlat0.xyz * in_COLOR0.zzz;
    u_xlat0.xyz = u_xlat0.xyz * vec3(0.100000001, 0.100000001, 0.100000001) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat1.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat1.xyz;
    u_xlat1.xyz = u_xlat1.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1.xyz = (-u_xlat1.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat18 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat19 = sqrt(u_xlat18);
    u_xlat18 = inversesqrt(u_xlat18);
    u_xlat1.xyz = vec3(u_xlat18) * u_xlat1.xyz;
    u_xlat18 = min(u_xlat19, _OutlineViewOffset);
    u_xlat2.x = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[0].xyz);
    u_xlat2.y = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[1].xyz);
    u_xlat2.z = dot(u_xlat1.xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat0.xyz = u_xlat2.xyz * vec3(u_xlat18) + u_xlat0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_TEXCOORD3.xyz = u_xlat0.xyz;
    u_xlat0 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat0;
    vs_COLOR0.xyz = _Color.xyz * _OutlineColor.xyz;
    vs_COLOR0.w = (-_Transparency) + 1.0;
    vs_COLOR1 = in_COLOR0;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat19 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat19 = max(u_xlat19, 1.17549435e-38);
    u_xlat19 = inversesqrt(u_xlat19);
    u_xlat1.xyz = vec3(u_xlat19) * u_xlat1.xyz;
    u_xlat19 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat19 = inversesqrt(u_xlat19);
    vs_TEXCOORD0.xyz = vec3(u_xlat19) * u_xlat1.xyz;
    u_xlat2.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat2.xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat2.xyz;
    u_xlat19 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat19 = max(u_xlat19, 1.17549435e-38);
    u_xlat19 = inversesqrt(u_xlat19);
    u_xlat2.xyz = vec3(u_xlat19) * u_xlat2.xyz;
    u_xlat16_3.x = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat16_3.x = inversesqrt(u_xlat16_3.x);
    u_xlat16_3.xyz = u_xlat2.xyz * u_xlat16_3.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_3.xyz;
    u_xlat4.xyz = u_xlat1.zxy * u_xlat2.yzx;
    u_xlat1.xyz = u_xlat1.yzx * u_xlat2.zxy + (-u_xlat4.xyz);
    u_xlatb19 = unity_WorldTransformParams.w>=0.0;
    u_xlat19 = (u_xlatb19) ? 1.0 : -1.0;
    u_xlat16_3.x = u_xlat19 * in_TANGENT0.w;
    u_xlat16_3.xyz = u_xlat1.xyz * u_xlat16_3.xxx;
    u_xlat16_21 = dot(u_xlat16_3.xyz, u_xlat16_3.xyz);
    u_xlat16_21 = inversesqrt(u_xlat16_21);
    u_xlat16_3.xyz = vec3(u_xlat16_21) * u_xlat16_3.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_3.xyz;
    u_xlat0.y = u_xlat0.y * _ProjectionParams.x;
    u_xlat1.xzw = u_xlat0.xwy * vec3(0.5, 0.5, 0.5);
    vs_TEXCOORD4.zw = u_xlat0.zw;
    vs_TEXCOORD4.xy = u_xlat1.zz + u_xlat1.xw;
    u_xlatb0.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = (u_xlatb0.x) ? float(1.0) : float(-1.0);
    u_xlat0.y = (u_xlatb0.y) ? float(1.0) : float(-1.0);
    u_xlat12.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat12.xy;
    u_xlat12.x = _ColorTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat12.x);
    u_xlat2.x = cos(u_xlat12.x);
    u_xlat4.z = u_xlat1.x;
    u_xlat12.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat4.y = u_xlat2.x;
    u_xlat4.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat12.xy, u_xlat4.xy);
    u_xlat1.x = dot(u_xlat12.xy, u_xlat4.yz);
    u_xlat0.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlatb1.xy = greaterThanEqual(_OcclusionTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = (u_xlatb1.x) ? float(1.0) : float(-1.0);
    u_xlat1.y = (u_xlatb1.y) ? float(1.0) : float(-1.0);
    u_xlat13.xy = max(abs(_OcclusionTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat13.xy;
    u_xlat13.x = _OcclusionTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat13.x);
    u_xlat4.x = cos(u_xlat13.x);
    u_xlat5.z = u_xlat2.x;
    u_xlat13.xy = in_TEXCOORD0.xy + (-_OcclusionTex_ST.zw);
    u_xlat5.y = u_xlat4.x;
    u_xlat5.x = (-u_xlat2.x);
    u_xlat14.y = dot(u_xlat13.xy, u_xlat5.xy);
    u_xlat14.x = dot(u_xlat13.xy, u_xlat5.yz);
    u_xlat0.zw = u_xlat14.xy / u_xlat1.xy;
    phase0_Output0_8 = u_xlat0;
    phase0_Output0_9 = vec4(0.0, 0.0, 0.0, 0.0);
vs_TEXCOORD5 = phase0_Output0_8.xy;
vs_TEXCOORD6 = phase0_Output0_8.zw;
vs_TEXCOORD7 = phase0_Output0_9.xy;
vs_TEXCOORD8 = phase0_Output0_9.zw;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
uniform 	float _UseCharacterLightDirection;
uniform 	vec3 _CharacterLightDirection;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float                _AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4                _OutlineColor;
	float                _OutlineNormalOffset;
	float                _OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2DArray _AdditionalFacialTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(3) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(4) uniform mediump sampler2D _ToonTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD8;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
int u_xlati0;
uvec2 u_xlatu0;
bool u_xlatb0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
vec3 u_xlat4;
mediump vec2 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
int u_xlati6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
int u_xlati7;
vec3 u_xlat8;
vec3 u_xlat9;
vec2 u_xlat10;
bool u_xlatb11;
float u_xlat12;
mediump vec2 u_xlat16_14;
float u_xlat17;
float u_xlat23;
float u_xlat28;
uint u_xlatu28;
float u_xlat34;
mediump float u_xlat16_36;
float u_xlat37;
float u_xlat38;
float u_xlat39;
int u_xlati39;
uint u_xlatu39;
bool u_xlatb39;
float u_xlat40;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat0.x = _AdditionalFacialTexIndex + 0.5;
    u_xlati0 = int(u_xlat0.x);
    u_xlatb11 = 0<u_xlati0;
    u_xlati0 = u_xlati0 + int(0xFFFFFFFFu);
    u_xlat1.z = float(u_xlati0);
    u_xlat1.xy = vs_TEXCOORD5.xy;
    u_xlat16_1 = texture(_AdditionalFacialTex, u_xlat1.xyz, _GlobalMipBias.x);
    u_xlat16_2 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat0 = (bool(u_xlatb11)) ? u_xlat16_1 : u_xlat16_2;
    u_xlat16_3.x = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_1.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat2 = u_xlat0 * vs_COLOR0;
    u_xlat1.x = dot(u_xlat16_1.xx, vs_COLOR1.ww);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat34 = u_xlat1.x + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_14.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_36 = dot(u_xlat16_14.xy, u_xlat16_14.xy);
    u_xlat16_36 = min(u_xlat16_36, 1.0);
    u_xlat16_36 = (-u_xlat16_36) + 1.0;
    u_xlat16_36 = sqrt(u_xlat16_36);
    u_xlat16_36 = max(u_xlat16_36, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_14.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_14.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_36) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat37 = inversesqrt(u_xlat37);
    u_xlat4.xyz = vec3(u_xlat37) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDirection.xyz;
    u_xlat5.xyz = vec3(vec3(_UseCharacterLightDirection, _UseCharacterLightDirection, _UseCharacterLightDirection)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat6.xyz = (-u_xlat5.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat6.xyz + u_xlat5.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat38 = (-_ToonAmbient) + 1.0;
    u_xlat1.x = u_xlat1.x * _ToonAmbient;
    u_xlat37 = u_xlat37 * u_xlat38 + u_xlat1.x;
    u_xlat37 = u_xlat34 * _OcclusionAddScale + u_xlat37;
    u_xlat37 = clamp(u_xlat37, 0.0, 1.0);
    u_xlat37 = u_xlat37 * 0.5 + 0.5;
    u_xlat37 = u_xlat37 * unity_LightData.z;
    u_xlat16_14.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati6 = int(u_xlat16_14.x);
    u_xlat17 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati6) ; u_xlatu_loop_1++)
    {
        u_xlatu39 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati7 = int(u_xlatu_loop_1 & 3u);
        u_xlat39 = dot(unity_LightIndices[int(u_xlatu39)], ImmCB_0[u_xlati7]);
        u_xlati39 = int(u_xlat39);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati39].www + _AdditionalLightsPosition[u_xlati39].xyz;
        u_xlat40 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat40 = max(u_xlat40, 6.10351562e-05);
        u_xlat8.x = inversesqrt(u_xlat40);
        u_xlat7.xyz = u_xlat7.xyz * u_xlat8.xxx;
        u_xlat8.x = float(1.0) / float(u_xlat40);
        u_xlat40 = u_xlat40 * _AdditionalLightsAttenuation[u_xlati39].x;
        u_xlat16_14.x = (-u_xlat40) * u_xlat40 + 1.0;
        u_xlat16_14.x = max(u_xlat16_14.x, 0.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat40 = u_xlat16_14.x * u_xlat8.x;
        u_xlat16_14.x = dot(_AdditionalLightsSpotDir[u_xlati39].xyz, u_xlat7.xyz);
        u_xlat16_14.x = u_xlat16_14.x * _AdditionalLightsAttenuation[u_xlati39].z + _AdditionalLightsAttenuation[u_xlati39].w;
        u_xlat16_14.x = clamp(u_xlat16_14.x, 0.0, 1.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat39 = u_xlat16_14.x * u_xlat40;
        u_xlat7.x = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat7.x = clamp(u_xlat7.x, 0.0, 1.0);
        u_xlat7.x = u_xlat7.x * 0.5 + 0.5;
        u_xlat17 = u_xlat7.x * u_xlat39 + u_xlat17;
    }
    u_xlat6.x = u_xlat17 + vs_TEXCOORD8.x;
    u_xlat6.x = clamp(u_xlat6.x, 0.0, 1.0);
    u_xlat37 = max(u_xlat37, 0.0);
    u_xlat17 = u_xlat37 + (-u_charaShadowColor0.w);
    u_xlat28 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat39 = (-u_xlat37) + 1.0;
    u_xlat12 = u_xlat16_1.y * u_xlat39 + u_xlat37;
    u_xlat39 = 0.5;
    u_xlat7.x = u_xlat39 + u_xlat17;
    u_xlat7.y = u_xlat12 + u_xlat28;
    u_xlat12 = u_xlat6.x * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat8.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat2.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat9.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat10.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat7.xyz = (-u_xlat8.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat10.xxx * u_xlat7.xyz + u_xlat9.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat10.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = u_xlat6.xyz * u_xlat7.xyz;
    u_xlat16_3.x = u_xlat16_3.x * 0.200000003 + u_xlat16_1.z;
    u_xlat12 = min(u_xlat16_3.x, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vs_COLOR0.xyz + (-u_xlat6.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat6.xyz;
    u_xlat16_3.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_3.x = inversesqrt(u_xlat16_3.x);
    u_xlat16_3.xyz = u_xlat16_3.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_3.xyz);
    u_xlat5.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat23 = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat23 = inversesqrt(u_xlat23);
    u_xlat5.xyz = vec3(u_xlat23) * u_xlat5.xyz;
    u_xlat23 = dot(u_xlat5.xyz, u_xlat4.xyz);
    u_xlat23 = (-u_xlat23);
    u_xlat23 = clamp(u_xlat23, 0.0, 1.0);
    u_xlat23 = (-u_xlat23) + 1.0;
    u_xlat4.x = u_xlat12 * u_xlat23;
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x + u_xlat37;
    u_xlat1.x = (-u_xlat12) * u_xlat38 + u_xlat1.x;
    u_xlat1.x = u_xlat34 * _OcclusionAddScale + u_xlat1.x;
    u_xlat1.x = u_xlat1.x * 0.5 + 0.5;
    u_xlat12 = (-u_xlat12) * u_xlat23;
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat1.x = u_xlat12 + u_xlat1.x;
    u_xlat1.x = u_xlat1.x + (-u_charaUnderLightColor.w);
    u_xlat1.x = u_xlat1.x * _UnderLightToonFadeRange;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.xyz = u_xlat1.xxx * u_charaUnderLightColor.xyz;
    u_xlat34 = u_xlat4.x + (-u_charaHighLightColor.w);
    u_xlat34 = u_xlat34 * _CharaToonFadeRange;
    u_xlat34 = clamp(u_xlat34, 0.0, 1.0);
    u_xlat1.xyz = u_charaHighLightColor.xyz * vec3(u_xlat34) + u_xlat1.xyz;
    u_xlat4.xyz = u_xlat0.xyz + u_xlat1.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat1.xyz = (-u_xlat1.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat1.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat4.xyz) + u_xlat0.xyz;
    u_xlat2.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat4.xyz;
    u_xlat0.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat0.xy = u_xlat0.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu0.xy = uvec2(u_xlat0.xy);
    u_xlati0 = int(bitfieldInsert(0, int(u_xlatu0.x), 2 & int(0x1F), 2));
    u_xlati0 = int(bitfieldInsert(u_xlati0, int(u_xlatu0.y), 0 & int(0x1F), 2));
    u_xlat0.x = u_xlat0.w * vs_COLOR0.w + (-ImmCB_0[u_xlati0 + 4].x);
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    SV_Target0 = u_xlat2;
    return;
}

#endif


// ===== program 5: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
uniform 	float _UseCharacterLightDirection;
uniform 	vec3 _CharacterLightDirection;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float                _AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4                _OutlineColor;
	float                _OutlineNormalOffset;
	float                _OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2DArray _AdditionalFacialTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(3) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(4) uniform mediump sampler2D _ToonTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD8;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
int u_xlati0;
uvec2 u_xlatu0;
bool u_xlatb0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
vec3 u_xlat4;
mediump vec2 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
int u_xlati6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
int u_xlati7;
vec3 u_xlat8;
vec3 u_xlat9;
vec2 u_xlat10;
bool u_xlatb11;
float u_xlat12;
mediump vec2 u_xlat16_14;
float u_xlat17;
float u_xlat23;
float u_xlat28;
uint u_xlatu28;
float u_xlat34;
mediump float u_xlat16_36;
float u_xlat37;
float u_xlat38;
float u_xlat39;
int u_xlati39;
uint u_xlatu39;
bool u_xlatb39;
float u_xlat40;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat0.x = _AdditionalFacialTexIndex + 0.5;
    u_xlati0 = int(u_xlat0.x);
    u_xlatb11 = 0<u_xlati0;
    u_xlati0 = u_xlati0 + int(0xFFFFFFFFu);
    u_xlat1.z = float(u_xlati0);
    u_xlat1.xy = vs_TEXCOORD5.xy;
    u_xlat16_1 = texture(_AdditionalFacialTex, u_xlat1.xyz, _GlobalMipBias.x);
    u_xlat16_2 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat0 = (bool(u_xlatb11)) ? u_xlat16_1 : u_xlat16_2;
    u_xlat16_3.x = dot(u_xlat0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_1.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat2 = u_xlat0 * vs_COLOR0;
    u_xlat1.x = dot(u_xlat16_1.xx, vs_COLOR1.ww);
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat34 = u_xlat1.x + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_14.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_36 = dot(u_xlat16_14.xy, u_xlat16_14.xy);
    u_xlat16_36 = min(u_xlat16_36, 1.0);
    u_xlat16_36 = (-u_xlat16_36) + 1.0;
    u_xlat16_36 = sqrt(u_xlat16_36);
    u_xlat16_36 = max(u_xlat16_36, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_14.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_14.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_36) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat37 = inversesqrt(u_xlat37);
    u_xlat4.xyz = vec3(u_xlat37) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDirection.xyz;
    u_xlat5.xyz = vec3(vec3(_UseCharacterLightDirection, _UseCharacterLightDirection, _UseCharacterLightDirection)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat6.xyz = (-u_xlat5.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat6.xyz + u_xlat5.xyz;
    u_xlat37 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat38 = (-_ToonAmbient) + 1.0;
    u_xlat1.x = u_xlat1.x * _ToonAmbient;
    u_xlat37 = u_xlat37 * u_xlat38 + u_xlat1.x;
    u_xlat37 = u_xlat34 * _OcclusionAddScale + u_xlat37;
    u_xlat37 = clamp(u_xlat37, 0.0, 1.0);
    u_xlat37 = u_xlat37 * 0.5 + 0.5;
    u_xlat37 = u_xlat37 * unity_LightData.z;
    u_xlat16_14.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati6 = int(u_xlat16_14.x);
    u_xlat17 = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati6) ; u_xlatu_loop_1++)
    {
        u_xlatu39 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati7 = int(u_xlatu_loop_1 & 3u);
        u_xlat39 = dot(unity_LightIndices[int(u_xlatu39)], ImmCB_0[u_xlati7]);
        u_xlati39 = int(u_xlat39);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati39].www + _AdditionalLightsPosition[u_xlati39].xyz;
        u_xlat40 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat40 = max(u_xlat40, 6.10351562e-05);
        u_xlat8.x = inversesqrt(u_xlat40);
        u_xlat7.xyz = u_xlat7.xyz * u_xlat8.xxx;
        u_xlat8.x = float(1.0) / float(u_xlat40);
        u_xlat40 = u_xlat40 * _AdditionalLightsAttenuation[u_xlati39].x;
        u_xlat16_14.x = (-u_xlat40) * u_xlat40 + 1.0;
        u_xlat16_14.x = max(u_xlat16_14.x, 0.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat40 = u_xlat16_14.x * u_xlat8.x;
        u_xlat16_14.x = dot(_AdditionalLightsSpotDir[u_xlati39].xyz, u_xlat7.xyz);
        u_xlat16_14.x = u_xlat16_14.x * _AdditionalLightsAttenuation[u_xlati39].z + _AdditionalLightsAttenuation[u_xlati39].w;
        u_xlat16_14.x = clamp(u_xlat16_14.x, 0.0, 1.0);
        u_xlat16_14.x = u_xlat16_14.x * u_xlat16_14.x;
        u_xlat39 = u_xlat16_14.x * u_xlat40;
        u_xlat7.x = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat7.x = clamp(u_xlat7.x, 0.0, 1.0);
        u_xlat7.x = u_xlat7.x * 0.5 + 0.5;
        u_xlat17 = u_xlat7.x * u_xlat39 + u_xlat17;
    }
    u_xlat6.x = u_xlat17 + vs_TEXCOORD8.x;
    u_xlat6.x = clamp(u_xlat6.x, 0.0, 1.0);
    u_xlat37 = max(u_xlat37, 0.0);
    u_xlat17 = u_xlat37 + (-u_charaShadowColor0.w);
    u_xlat28 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat39 = (-u_xlat37) + 1.0;
    u_xlat12 = u_xlat16_1.y * u_xlat39 + u_xlat37;
    u_xlat39 = 0.5;
    u_xlat7.x = u_xlat39 + u_xlat17;
    u_xlat7.y = u_xlat12 + u_xlat28;
    u_xlat12 = u_xlat6.x * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_3.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat8.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat2.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat9.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat10.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat7.xyz = (-u_xlat8.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat10.xxx * u_xlat7.xyz + u_xlat9.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat10.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = u_xlat6.xyz * u_xlat7.xyz;
    u_xlat16_3.x = u_xlat16_3.x * 0.200000003 + u_xlat16_1.z;
    u_xlat12 = min(u_xlat16_3.x, 1.0);
    u_xlat0.xyz = u_xlat0.xyz * vs_COLOR0.xyz + (-u_xlat6.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat6.xyz;
    u_xlat16_3.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_3.x = inversesqrt(u_xlat16_3.x);
    u_xlat16_3.xyz = u_xlat16_3.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_3.xyz);
    u_xlat5.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat23 = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat23 = inversesqrt(u_xlat23);
    u_xlat5.xyz = vec3(u_xlat23) * u_xlat5.xyz;
    u_xlat23 = dot(u_xlat5.xyz, u_xlat4.xyz);
    u_xlat23 = (-u_xlat23);
    u_xlat23 = clamp(u_xlat23, 0.0, 1.0);
    u_xlat23 = (-u_xlat23) + 1.0;
    u_xlat4.x = u_xlat12 * u_xlat23;
    u_xlat4.x = clamp(u_xlat4.x, 0.0, 1.0);
    u_xlat4.x = u_xlat4.x + u_xlat37;
    u_xlat1.x = (-u_xlat12) * u_xlat38 + u_xlat1.x;
    u_xlat1.x = u_xlat34 * _OcclusionAddScale + u_xlat1.x;
    u_xlat1.x = u_xlat1.x * 0.5 + 0.5;
    u_xlat12 = (-u_xlat12) * u_xlat23;
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat1.x = u_xlat12 + u_xlat1.x;
    u_xlat1.x = u_xlat1.x + (-u_charaUnderLightColor.w);
    u_xlat1.x = u_xlat1.x * _UnderLightToonFadeRange;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.xyz = u_xlat1.xxx * u_charaUnderLightColor.xyz;
    u_xlat34 = u_xlat4.x + (-u_charaHighLightColor.w);
    u_xlat34 = u_xlat34 * _CharaToonFadeRange;
    u_xlat34 = clamp(u_xlat34, 0.0, 1.0);
    u_xlat1.xyz = u_charaHighLightColor.xyz * vec3(u_xlat34) + u_xlat1.xyz;
    u_xlat4.xyz = u_xlat0.xyz + u_xlat1.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat1.xyz = (-u_xlat1.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat1.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat4.xyz) + u_xlat0.xyz;
    u_xlat2.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat4.xyz;
    u_xlat0.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat0.xy = u_xlat0.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu0.xy = uvec2(u_xlat0.xy);
    u_xlati0 = int(bitfieldInsert(0, int(u_xlatu0.x), 2 & int(0x1F), 2));
    u_xlati0 = int(bitfieldInsert(u_xlati0, int(u_xlatu0.y), 0 & int(0x1F), 2));
    u_xlat0.x = u_xlat0.w * vs_COLOR0.w + (-ImmCB_0[u_xlati0 + 4].x);
    u_xlatb0 = u_xlat0.x<0.0;
    if(u_xlatb0){discard;}
    SV_Target0 = u_xlat2;
    return;
}

#endif


// ===== program 6: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float Xhlslcc_UnusedX_AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4 Xhlslcc_UnusedX_OutlineColor;
	float Xhlslcc_UnusedX_OutlineNormalOffset;
	float Xhlslcc_UnusedX_OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec4 in_COLOR0;
in mediump vec2 in_TEXCOORD0;
layout(location = 0) out highp vec4 vs_COLOR0;
layout(location = 1) out highp vec4 vs_COLOR1;
layout(location = 2) out highp vec3 vs_TEXCOORD0;
layout(location = 3) out highp vec3 vs_TEXCOORD1;
layout(location = 4) out highp vec3 vs_TEXCOORD2;
layout(location = 5) out highp vec3 vs_TEXCOORD3;
layout(location = 6) out highp vec4 vs_TEXCOORD4;
layout(location = 7) out mediump vec2 vs_TEXCOORD5;
mediump  vec4 phase0_Output0_8;
layout(location = 8) out mediump vec2 vs_TEXCOORD6;
layout(location = 10) out mediump vec2 vs_TEXCOORD7;
mediump  vec4 phase0_Output0_9;
layout(location = 9) out mediump vec2 vs_TEXCOORD8;
layout(location = 11) out highp vec3 vs_TEXCOORD9;
layout(location = 12) out highp vec3 vs_TEXCOORD10;
vec4 u_xlat0;
bvec2 u_xlatb0;
vec4 u_xlat1;
bvec2 u_xlatb1;
vec3 u_xlat2;
vec3 u_xlat3;
mediump vec3 u_xlat16_4;
vec3 u_xlat5;
vec2 u_xlat12;
vec2 u_xlat13;
vec2 u_xlat14;
float u_xlat18;
bool u_xlatb18;
mediump float u_xlat16_22;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat1 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat1;
    vs_COLOR0 = vec4(_Color.x, _Color.y, _Color.z, _Transparency) * vec4(1.0, 1.0, 1.0, -1.0) + vec4(0.0, 0.0, 0.0, 1.0);
    vs_COLOR1 = in_COLOR0;
    u_xlat2.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat2.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat18 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat18 = max(u_xlat18, 1.17549435e-38);
    u_xlat18 = inversesqrt(u_xlat18);
    u_xlat2.xyz = vec3(u_xlat18) * u_xlat2.xyz;
    u_xlat18 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat18 = inversesqrt(u_xlat18);
    vs_TEXCOORD0.xyz = vec3(u_xlat18) * u_xlat2.xyz;
    u_xlat3.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat3.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat3.xyz;
    u_xlat3.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat3.xyz;
    u_xlat18 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat18 = max(u_xlat18, 1.17549435e-38);
    u_xlat18 = inversesqrt(u_xlat18);
    u_xlat3.xyz = vec3(u_xlat18) * u_xlat3.xyz;
    u_xlat16_4.x = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat16_4.x = inversesqrt(u_xlat16_4.x);
    u_xlat16_4.xyz = u_xlat3.xyz * u_xlat16_4.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_4.xyz;
    u_xlat5.xyz = u_xlat2.zxy * u_xlat3.yzx;
    u_xlat2.xyz = u_xlat2.yzx * u_xlat3.zxy + (-u_xlat5.xyz);
    u_xlatb18 = unity_WorldTransformParams.w>=0.0;
    u_xlat18 = (u_xlatb18) ? 1.0 : -1.0;
    u_xlat16_4.x = u_xlat18 * in_TANGENT0.w;
    u_xlat16_4.xyz = u_xlat2.xyz * u_xlat16_4.xxx;
    u_xlat16_22 = dot(u_xlat16_4.xyz, u_xlat16_4.xyz);
    u_xlat16_22 = inversesqrt(u_xlat16_22);
    u_xlat16_4.xyz = vec3(u_xlat16_22) * u_xlat16_4.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_4.xyz;
    vs_TEXCOORD3.xyz = u_xlat0.xyz;
    vs_TEXCOORD9.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat0.x = u_xlat1.y * _ProjectionParams.x;
    u_xlat0.w = u_xlat0.x * 0.5;
    u_xlat0.xz = u_xlat1.xw * vec2(0.5, 0.5);
    vs_TEXCOORD4.zw = u_xlat1.zw;
    vs_TEXCOORD4.xy = u_xlat0.zz + u_xlat0.xw;
    u_xlatb0.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat0.x = (u_xlatb0.x) ? float(1.0) : float(-1.0);
    u_xlat0.y = (u_xlatb0.y) ? float(1.0) : float(-1.0);
    u_xlat12.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat0.xy = u_xlat0.xy * u_xlat12.xy;
    u_xlat12.x = _ColorTex_R * 0.0174532924;
    u_xlat1.x = sin(u_xlat12.x);
    u_xlat2.x = cos(u_xlat12.x);
    u_xlat3.z = u_xlat1.x;
    u_xlat12.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat3.y = u_xlat2.x;
    u_xlat3.x = (-u_xlat1.x);
    u_xlat1.y = dot(u_xlat12.xy, u_xlat3.xy);
    u_xlat1.x = dot(u_xlat12.xy, u_xlat3.yz);
    u_xlat0.xy = u_xlat1.xy / u_xlat0.xy;
    u_xlatb1.xy = greaterThanEqual(_OcclusionTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = (u_xlatb1.x) ? float(1.0) : float(-1.0);
    u_xlat1.y = (u_xlatb1.y) ? float(1.0) : float(-1.0);
    u_xlat13.xy = max(abs(_OcclusionTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat13.xy;
    u_xlat13.x = _OcclusionTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat13.x);
    u_xlat3.x = cos(u_xlat13.x);
    u_xlat5.z = u_xlat2.x;
    u_xlat13.xy = in_TEXCOORD0.xy + (-_OcclusionTex_ST.zw);
    u_xlat5.y = u_xlat3.x;
    u_xlat5.x = (-u_xlat2.x);
    u_xlat14.y = dot(u_xlat13.xy, u_xlat5.xy);
    u_xlat14.x = dot(u_xlat13.xy, u_xlat5.yz);
    u_xlat0.zw = u_xlat14.xy / u_xlat1.xy;
    phase0_Output0_8 = u_xlat0;
    phase0_Output0_9 = vec4(0.0, 0.0, 0.0, 0.0);
    vs_TEXCOORD10.xyz = vec3(0.0, 0.0, 0.0);
vs_TEXCOORD5 = phase0_Output0_8.xy;
vs_TEXCOORD6 = phase0_Output0_8.zw;
vs_TEXCOORD7 = phase0_Output0_9.xy;
vs_TEXCOORD8 = phase0_Output0_9.zw;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float Xhlslcc_UnusedX_AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4 Xhlslcc_UnusedX_OutlineColor;
	float Xhlslcc_UnusedX_OutlineNormalOffset;
	float Xhlslcc_UnusedX_OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(3) uniform mediump sampler2D _ToonTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD8;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
mediump vec3 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
int u_xlati2;
uvec2 u_xlatu2;
bool u_xlatb2;
vec4 u_xlat3;
vec3 u_xlat4;
mediump vec2 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
vec3 u_xlat8;
vec2 u_xlat9;
mediump vec2 u_xlat16_11;
float u_xlat12;
float u_xlat16;
uint u_xlatu16;
float u_xlat22;
float u_xlat26;
int u_xlati26;
uint u_xlatu26;
bool u_xlatb26;
float u_xlat30;
mediump float u_xlat16_31;
float u_xlat32;
float u_xlat34;
float u_xlat35;
int u_xlati35;
float u_xlat36;
int u_xlati36;
float u_xlat37;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat16_1.x = dot(u_xlat16_0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_2.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat3 = u_xlat16_0 * vs_COLOR0;
    u_xlat30 = dot(u_xlat16_2.xx, vs_COLOR1.ww);
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.x = u_xlat30 + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_11.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_31 = dot(u_xlat16_11.xy, u_xlat16_11.xy);
    u_xlat16_31 = min(u_xlat16_31, 1.0);
    u_xlat16_31 = (-u_xlat16_31) + 1.0;
    u_xlat16_31 = sqrt(u_xlat16_31);
    u_xlat16_31 = max(u_xlat16_31, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_11.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_11.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_31) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat32 = inversesqrt(u_xlat32);
    u_xlat4.xyz = vec3(u_xlat32) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat34 = (-_ToonAmbient) + 1.0;
    u_xlat30 = u_xlat30 * _ToonAmbient;
    u_xlat32 = u_xlat32 * u_xlat34 + u_xlat30;
    u_xlat32 = u_xlat2.x * _OcclusionAddScale + u_xlat32;
    u_xlat32 = clamp(u_xlat32, 0.0, 1.0);
    u_xlat32 = u_xlat32 * 0.5 + 0.5;
    u_xlat32 = u_xlat32 * unity_LightData.z;
    u_xlat16_11.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati35 = int(u_xlat16_11.x);
    u_xlat6.x = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati35) ; u_xlatu_loop_1++)
    {
        u_xlatu26 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati36 = int(u_xlatu_loop_1 & 3u);
        u_xlat26 = dot(unity_LightIndices[int(u_xlatu26)], ImmCB_0[u_xlati36]);
        u_xlati26 = int(u_xlat26);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati26].www + _AdditionalLightsPosition[u_xlati26].xyz;
        u_xlat36 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat36 = max(u_xlat36, 6.10351562e-05);
        u_xlat37 = inversesqrt(u_xlat36);
        u_xlat7.xyz = vec3(u_xlat37) * u_xlat7.xyz;
        u_xlat37 = float(1.0) / float(u_xlat36);
        u_xlat36 = u_xlat36 * _AdditionalLightsAttenuation[u_xlati26].x;
        u_xlat16_11.x = (-u_xlat36) * u_xlat36 + 1.0;
        u_xlat16_11.x = max(u_xlat16_11.x, 0.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat36 = u_xlat16_11.x * u_xlat37;
        u_xlat16_11.x = dot(_AdditionalLightsSpotDir[u_xlati26].xyz, u_xlat7.xyz);
        u_xlat16_11.x = u_xlat16_11.x * _AdditionalLightsAttenuation[u_xlati26].z + _AdditionalLightsAttenuation[u_xlati26].w;
        u_xlat16_11.x = clamp(u_xlat16_11.x, 0.0, 1.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat26 = u_xlat16_11.x * u_xlat36;
        u_xlat36 = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat36 = clamp(u_xlat36, 0.0, 1.0);
        u_xlat36 = u_xlat36 * 0.5 + 0.5;
        u_xlat6.x = u_xlat36 * u_xlat26 + u_xlat6.x;
    }
    u_xlat35 = u_xlat6.x + vs_TEXCOORD8.x;
    u_xlat35 = clamp(u_xlat35, 0.0, 1.0);
    u_xlat32 = max(u_xlat32, 0.0);
    u_xlat6.x = u_xlat32 + (-u_charaShadowColor0.w);
    u_xlat16 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat26 = (-u_xlat32) + 1.0;
    u_xlat12 = u_xlat16_2.y * u_xlat26 + u_xlat32;
    u_xlat26 = 0.5;
    u_xlat7.x = u_xlat26 + u_xlat6.x;
    u_xlat7.y = u_xlat12 + u_xlat16;
    u_xlat12 = u_xlat35 * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat16_0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat3.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat3.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat3.xyz * u_xlat7.xyz;
    u_xlat9.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat3.xyz = (-u_xlat3.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat3.xyz = u_xlat9.xxx * u_xlat3.xyz + u_xlat8.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat9.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat3.xyz = u_xlat3.xyz * u_xlat6.xyz;
    u_xlat16_1.x = u_xlat16_1.x * 0.200000003 + u_xlat16_2.z;
    u_xlat12 = min(u_xlat16_1.x, 1.0);
    u_xlat0.xyz = u_xlat16_0.xyz * vs_COLOR0.xyz + (-u_xlat3.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat16_1.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_1.x = inversesqrt(u_xlat16_1.x);
    u_xlat16_1.xyz = u_xlat16_1.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_1.xyz);
    u_xlat3.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat22 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat22 = inversesqrt(u_xlat22);
    u_xlat3.xyz = vec3(u_xlat22) * u_xlat3.xyz;
    u_xlat22 = dot(u_xlat3.xyz, u_xlat4.xyz);
    u_xlat22 = (-u_xlat22);
    u_xlat22 = clamp(u_xlat22, 0.0, 1.0);
    u_xlat22 = (-u_xlat22) + 1.0;
    u_xlat3.x = u_xlat12 * u_xlat22;
    u_xlat3.x = clamp(u_xlat3.x, 0.0, 1.0);
    u_xlat32 = u_xlat32 + u_xlat3.x;
    u_xlat30 = (-u_xlat12) * u_xlat34 + u_xlat30;
    u_xlat30 = u_xlat2.x * _OcclusionAddScale + u_xlat30;
    u_xlat30 = u_xlat30 * 0.5 + 0.5;
    u_xlat2.x = (-u_xlat12) * u_xlat22;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat30 = u_xlat30 + u_xlat2.x;
    u_xlat30 = u_xlat30 + (-u_charaUnderLightColor.w);
    u_xlat30 = u_xlat30 * _UnderLightToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = vec3(u_xlat30) * u_charaUnderLightColor.xyz;
    u_xlat30 = u_xlat32 + (-u_charaHighLightColor.w);
    u_xlat30 = u_xlat30 * _CharaToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = u_charaHighLightColor.xyz * vec3(u_xlat30) + u_xlat2.xyz;
    u_xlat3.xyz = u_xlat0.xyz + u_xlat2.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat2.xyz = (-u_xlat2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat2.x = (-_Transparency) + 1.0;
    u_xlat0.w = u_xlat2.x * u_xlat3.w;
    u_xlat0.w = clamp(u_xlat0.w, 0.0, 1.0);
    u_xlat2.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat2.xy = u_xlat2.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu2.xy = uvec2(u_xlat2.xy);
    u_xlati2 = int(bitfieldInsert(0, int(u_xlatu2.x), 2 & int(0x1F), 2));
    u_xlati2 = int(bitfieldInsert(u_xlati2, int(u_xlatu2.y), 0 & int(0x1F), 2));
    u_xlat2.x = u_xlat0.w + (-ImmCB_0[u_xlati2 + 4].x);
    u_xlatb2 = u_xlat2.x<0.0;
    if(u_xlatb2){discard;}
    SV_Target0 = u_xlat0;
    return;
}

#endif


// ===== program 7: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float Xhlslcc_UnusedX_AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4 Xhlslcc_UnusedX_OutlineColor;
	float Xhlslcc_UnusedX_OutlineNormalOffset;
	float Xhlslcc_UnusedX_OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(3) uniform mediump sampler2D _ToonTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD8;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
mediump vec3 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
int u_xlati2;
uvec2 u_xlatu2;
bool u_xlatb2;
vec4 u_xlat3;
vec3 u_xlat4;
mediump vec2 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
vec3 u_xlat8;
vec2 u_xlat9;
mediump vec2 u_xlat16_11;
float u_xlat12;
float u_xlat16;
uint u_xlatu16;
float u_xlat22;
float u_xlat26;
int u_xlati26;
uint u_xlatu26;
bool u_xlatb26;
float u_xlat30;
mediump float u_xlat16_31;
float u_xlat32;
float u_xlat34;
float u_xlat35;
int u_xlati35;
float u_xlat36;
int u_xlati36;
float u_xlat37;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat16_1.x = dot(u_xlat16_0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_2.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat3 = u_xlat16_0 * vs_COLOR0;
    u_xlat30 = dot(u_xlat16_2.xx, vs_COLOR1.ww);
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.x = u_xlat30 + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_11.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_31 = dot(u_xlat16_11.xy, u_xlat16_11.xy);
    u_xlat16_31 = min(u_xlat16_31, 1.0);
    u_xlat16_31 = (-u_xlat16_31) + 1.0;
    u_xlat16_31 = sqrt(u_xlat16_31);
    u_xlat16_31 = max(u_xlat16_31, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_11.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_11.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_31) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat32 = inversesqrt(u_xlat32);
    u_xlat4.xyz = vec3(u_xlat32) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat34 = (-_ToonAmbient) + 1.0;
    u_xlat30 = u_xlat30 * _ToonAmbient;
    u_xlat32 = u_xlat32 * u_xlat34 + u_xlat30;
    u_xlat32 = u_xlat2.x * _OcclusionAddScale + u_xlat32;
    u_xlat32 = clamp(u_xlat32, 0.0, 1.0);
    u_xlat32 = u_xlat32 * 0.5 + 0.5;
    u_xlat32 = u_xlat32 * unity_LightData.z;
    u_xlat16_11.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati35 = int(u_xlat16_11.x);
    u_xlat6.x = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati35) ; u_xlatu_loop_1++)
    {
        u_xlatu26 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati36 = int(u_xlatu_loop_1 & 3u);
        u_xlat26 = dot(unity_LightIndices[int(u_xlatu26)], ImmCB_0[u_xlati36]);
        u_xlati26 = int(u_xlat26);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati26].www + _AdditionalLightsPosition[u_xlati26].xyz;
        u_xlat36 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat36 = max(u_xlat36, 6.10351562e-05);
        u_xlat37 = inversesqrt(u_xlat36);
        u_xlat7.xyz = vec3(u_xlat37) * u_xlat7.xyz;
        u_xlat37 = float(1.0) / float(u_xlat36);
        u_xlat36 = u_xlat36 * _AdditionalLightsAttenuation[u_xlati26].x;
        u_xlat16_11.x = (-u_xlat36) * u_xlat36 + 1.0;
        u_xlat16_11.x = max(u_xlat16_11.x, 0.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat36 = u_xlat16_11.x * u_xlat37;
        u_xlat16_11.x = dot(_AdditionalLightsSpotDir[u_xlati26].xyz, u_xlat7.xyz);
        u_xlat16_11.x = u_xlat16_11.x * _AdditionalLightsAttenuation[u_xlati26].z + _AdditionalLightsAttenuation[u_xlati26].w;
        u_xlat16_11.x = clamp(u_xlat16_11.x, 0.0, 1.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat26 = u_xlat16_11.x * u_xlat36;
        u_xlat36 = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat36 = clamp(u_xlat36, 0.0, 1.0);
        u_xlat36 = u_xlat36 * 0.5 + 0.5;
        u_xlat6.x = u_xlat36 * u_xlat26 + u_xlat6.x;
    }
    u_xlat35 = u_xlat6.x + vs_TEXCOORD8.x;
    u_xlat35 = clamp(u_xlat35, 0.0, 1.0);
    u_xlat32 = max(u_xlat32, 0.0);
    u_xlat6.x = u_xlat32 + (-u_charaShadowColor0.w);
    u_xlat16 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat26 = (-u_xlat32) + 1.0;
    u_xlat12 = u_xlat16_2.y * u_xlat26 + u_xlat32;
    u_xlat26 = 0.5;
    u_xlat7.x = u_xlat26 + u_xlat6.x;
    u_xlat7.y = u_xlat12 + u_xlat16;
    u_xlat12 = u_xlat35 * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat16_0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat3.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat3.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat3.xyz * u_xlat7.xyz;
    u_xlat9.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat3.xyz = (-u_xlat3.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat3.xyz = u_xlat9.xxx * u_xlat3.xyz + u_xlat8.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat9.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat3.xyz = u_xlat3.xyz * u_xlat6.xyz;
    u_xlat16_1.x = u_xlat16_1.x * 0.200000003 + u_xlat16_2.z;
    u_xlat12 = min(u_xlat16_1.x, 1.0);
    u_xlat0.xyz = u_xlat16_0.xyz * vs_COLOR0.xyz + (-u_xlat3.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat16_1.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_1.x = inversesqrt(u_xlat16_1.x);
    u_xlat16_1.xyz = u_xlat16_1.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_1.xyz);
    u_xlat3.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat22 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat22 = inversesqrt(u_xlat22);
    u_xlat3.xyz = vec3(u_xlat22) * u_xlat3.xyz;
    u_xlat22 = dot(u_xlat3.xyz, u_xlat4.xyz);
    u_xlat22 = (-u_xlat22);
    u_xlat22 = clamp(u_xlat22, 0.0, 1.0);
    u_xlat22 = (-u_xlat22) + 1.0;
    u_xlat3.x = u_xlat12 * u_xlat22;
    u_xlat3.x = clamp(u_xlat3.x, 0.0, 1.0);
    u_xlat32 = u_xlat32 + u_xlat3.x;
    u_xlat30 = (-u_xlat12) * u_xlat34 + u_xlat30;
    u_xlat30 = u_xlat2.x * _OcclusionAddScale + u_xlat30;
    u_xlat30 = u_xlat30 * 0.5 + 0.5;
    u_xlat2.x = (-u_xlat12) * u_xlat22;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat30 = u_xlat30 + u_xlat2.x;
    u_xlat30 = u_xlat30 + (-u_charaUnderLightColor.w);
    u_xlat30 = u_xlat30 * _UnderLightToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = vec3(u_xlat30) * u_charaUnderLightColor.xyz;
    u_xlat30 = u_xlat32 + (-u_charaHighLightColor.w);
    u_xlat30 = u_xlat30 * _CharaToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = u_charaHighLightColor.xyz * vec3(u_xlat30) + u_xlat2.xyz;
    u_xlat3.xyz = u_xlat0.xyz + u_xlat2.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat2.xyz = (-u_xlat2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat2.x = (-_Transparency) + 1.0;
    u_xlat0.w = u_xlat2.x * u_xlat3.w;
    u_xlat0.w = clamp(u_xlat0.w, 0.0, 1.0);
    u_xlat2.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat2.xy = u_xlat2.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu2.xy = uvec2(u_xlat2.xy);
    u_xlati2 = int(bitfieldInsert(0, int(u_xlatu2.x), 2 & int(0x1F), 2));
    u_xlati2 = int(bitfieldInsert(u_xlati2, int(u_xlatu2.y), 0 & int(0x1F), 2));
    u_xlat2.x = u_xlat0.w + (-ImmCB_0[u_xlati2 + 4].x);
    u_xlatb2 = u_xlat2.x<0.0;
    if(u_xlatb2){discard;}
    SV_Target0 = u_xlat0;
    return;
}

#endif


// ===== program 8: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _Time;
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 _ScreenParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float Xhlslcc_UnusedX_AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4 Xhlslcc_UnusedX_OutlineColor;
	float Xhlslcc_UnusedX_OutlineNormalOffset;
	float Xhlslcc_UnusedX_OutlineDepthScaleMax;
	vec3                _StatesColor;
	vec4                _StatesRimColor;
	float                _StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float                _StatesTexDistortion;
	float                _StatesTexScaleU;
	float                _StatesTexScaleV;
	float                _StatesTexScrollSpeedU;
	float                _StatesTexScrollSpeedV;
	vec3                _StatesTexPos;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec4 in_COLOR0;
in mediump vec2 in_TEXCOORD0;
layout(location = 0) out highp vec4 vs_COLOR0;
layout(location = 1) out highp vec4 vs_COLOR1;
layout(location = 2) out highp vec3 vs_TEXCOORD0;
layout(location = 3) out highp vec3 vs_TEXCOORD1;
layout(location = 4) out highp vec3 vs_TEXCOORD2;
layout(location = 5) out highp vec3 vs_TEXCOORD3;
layout(location = 6) out highp vec4 vs_TEXCOORD4;
layout(location = 7) out mediump vec2 vs_TEXCOORD5;
mediump  vec4 phase0_Output0_8;
layout(location = 8) out mediump vec2 vs_TEXCOORD6;
layout(location = 9) out mediump vec2 vs_TEXCOORD7;
layout(location = 10) out mediump vec2 vs_TEXCOORD8;
layout(location = 11) out highp vec3 vs_TEXCOORD9;
layout(location = 12) out highp vec3 vs_TEXCOORD10;
vec4 u_xlat0;
vec4 u_xlat1;
bvec2 u_xlatb1;
vec4 u_xlat2;
bvec2 u_xlatb2;
vec3 u_xlat3;
mediump vec3 u_xlat16_4;
vec3 u_xlat5;
vec3 u_xlat6;
float u_xlat8;
vec2 u_xlat15;
vec2 u_xlat16;
vec2 u_xlat17;
float u_xlat21;
float u_xlat23;
bool u_xlatb23;
mediump float u_xlat16_25;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat1 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat1;
    vs_COLOR0 = vec4(_Color.x, _Color.y, _Color.z, _Transparency) * vec4(1.0, 1.0, 1.0, -1.0) + vec4(0.0, 0.0, 0.0, 1.0);
    vs_COLOR1 = in_COLOR0;
    u_xlat2.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat2.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat23 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat23 = max(u_xlat23, 1.17549435e-38);
    u_xlat23 = inversesqrt(u_xlat23);
    u_xlat2.xyz = vec3(u_xlat23) * u_xlat2.xyz;
    u_xlat23 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat23 = inversesqrt(u_xlat23);
    vs_TEXCOORD0.xyz = vec3(u_xlat23) * u_xlat2.xyz;
    u_xlat3.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat3.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat3.xyz;
    u_xlat3.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat3.xyz;
    u_xlat23 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat23 = max(u_xlat23, 1.17549435e-38);
    u_xlat23 = inversesqrt(u_xlat23);
    u_xlat3.xyz = vec3(u_xlat23) * u_xlat3.xyz;
    u_xlat16_4.x = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat16_4.x = inversesqrt(u_xlat16_4.x);
    u_xlat16_4.xyz = u_xlat3.xyz * u_xlat16_4.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_4.xyz;
    u_xlat5.xyz = u_xlat2.zxy * u_xlat3.yzx;
    u_xlat2.xyz = u_xlat2.yzx * u_xlat3.zxy + (-u_xlat5.xyz);
    u_xlatb23 = unity_WorldTransformParams.w>=0.0;
    u_xlat23 = (u_xlatb23) ? 1.0 : -1.0;
    u_xlat16_4.x = u_xlat23 * in_TANGENT0.w;
    u_xlat16_4.xyz = u_xlat2.xyz * u_xlat16_4.xxx;
    u_xlat16_25 = dot(u_xlat16_4.xyz, u_xlat16_4.xyz);
    u_xlat16_25 = inversesqrt(u_xlat16_25);
    u_xlat16_4.xyz = vec3(u_xlat16_25) * u_xlat16_4.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_4.xyz;
    vs_TEXCOORD3.xyz = u_xlat0.xyz;
    u_xlat1.y = u_xlat1.y * _ProjectionParams.x;
    u_xlat2.xzw = u_xlat1.xwy * vec3(0.5, 0.5, 0.5);
    vs_TEXCOORD4.zw = u_xlat1.zw;
    vs_TEXCOORD4.xy = u_xlat2.zz + u_xlat2.xw;
    u_xlatb1.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = (u_xlatb1.x) ? float(1.0) : float(-1.0);
    u_xlat1.y = (u_xlatb1.y) ? float(1.0) : float(-1.0);
    u_xlat15.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat15.xy;
    u_xlat15.x = _ColorTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat15.x);
    u_xlat3.x = cos(u_xlat15.x);
    u_xlat5.z = u_xlat2.x;
    u_xlat15.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat5.y = u_xlat3.x;
    u_xlat5.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat15.xy, u_xlat5.xy);
    u_xlat2.x = dot(u_xlat15.xy, u_xlat5.yz);
    u_xlat1.xy = u_xlat2.xy / u_xlat1.xy;
    u_xlatb2.xy = greaterThanEqual(_OcclusionTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat2.x = (u_xlatb2.x) ? float(1.0) : float(-1.0);
    u_xlat2.y = (u_xlatb2.y) ? float(1.0) : float(-1.0);
    u_xlat16.xy = max(abs(_OcclusionTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat2.xy = u_xlat2.xy * u_xlat16.xy;
    u_xlat16.x = _OcclusionTex_R * 0.0174532924;
    u_xlat3.x = sin(u_xlat16.x);
    u_xlat5.x = cos(u_xlat16.x);
    u_xlat6.z = u_xlat3.x;
    u_xlat16.xy = in_TEXCOORD0.xy + (-_OcclusionTex_ST.zw);
    u_xlat6.y = u_xlat5.x;
    u_xlat6.x = (-u_xlat3.x);
    u_xlat17.y = dot(u_xlat16.xy, u_xlat6.xy);
    u_xlat17.x = dot(u_xlat16.xy, u_xlat6.yz);
    u_xlat1.zw = u_xlat17.xy / u_xlat2.xy;
    phase0_Output0_8 = u_xlat1;
    u_xlat1.w = dot((-_StatesTexPos.xyz), hlslcc_mtx4x4unity_MatrixV[1].xyz);
    u_xlat1.x = hlslcc_mtx4x4unity_MatrixV[0].y;
    u_xlat1.y = hlslcc_mtx4x4unity_MatrixV[1].y;
    u_xlat1.z = hlslcc_mtx4x4unity_MatrixV[2].y;
    u_xlat0.w = 1.0;
    u_xlat1.x = dot(u_xlat1, u_xlat0);
    u_xlat8 = _ScreenParams.x / _ScreenParams.y;
    u_xlat1.y = u_xlat1.x / (-u_xlat8);
    u_xlat2.w = dot((-_StatesTexPos.xyz), hlslcc_mtx4x4unity_MatrixV[0].xyz);
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[0].x;
    u_xlat2.y = hlslcc_mtx4x4unity_MatrixV[1].x;
    u_xlat2.z = hlslcc_mtx4x4unity_MatrixV[2].x;
    u_xlat1.x = dot(u_xlat2, u_xlat0);
    u_xlat2.x = hlslcc_mtx4x4unity_MatrixV[0].w;
    u_xlat2.y = hlslcc_mtx4x4unity_MatrixV[1].w;
    u_xlat2.z = hlslcc_mtx4x4unity_MatrixV[2].w;
    u_xlat2.w = hlslcc_mtx4x4unity_MatrixV[3].w;
    u_xlat21 = dot(u_xlat2, u_xlat0);
    vs_TEXCOORD9.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat0.xy = u_xlat1.xy / vec2(u_xlat21);
    u_xlat0.xy = u_xlat0.xy * vec2(_StatesTexScaleU, _StatesTexScaleV);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5) + vec2(0.5, 0.5);
    u_xlat0.xy = u_xlat0.xy * vec2(vec2(_StatesTexDistortion, _StatesTexDistortion)) + u_xlat0.xy;
    u_xlat0.x = _Time.x * (-_StatesTexScrollSpeedU) + u_xlat0.x;
    u_xlat0.y = _Time.x * _StatesTexScrollSpeedV + u_xlat0.y;
    vs_TEXCOORD7.xy = u_xlat0.xy;
    vs_TEXCOORD8.xy = vec2(0.0, 0.0);
    vs_TEXCOORD10.xyz = vec3(0.0, 0.0, 0.0);
vs_TEXCOORD5 = phase0_Output0_8.xy;
vs_TEXCOORD6 = phase0_Output0_8.zw;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
uniform 	float _UseCharacterLightDirection;
uniform 	vec3 _CharacterLightDirection;
uniform 	float _StatesPow;
uniform 	float _StatesAdd;
uniform 	float _StatesRimWidth;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float Xhlslcc_UnusedX_AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4 Xhlslcc_UnusedX_OutlineColor;
	float Xhlslcc_UnusedX_OutlineNormalOffset;
	float Xhlslcc_UnusedX_OutlineDepthScaleMax;
	vec3                _StatesColor;
	vec4                _StatesRimColor;
	float                _StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float                _StatesTexDistortion;
	float                _StatesTexScaleU;
	float                _StatesTexScaleV;
	float                _StatesTexScrollSpeedU;
	float                _StatesTexScrollSpeedV;
	vec3                _StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(3) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(4) uniform mediump sampler2D _StatesTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD7;
layout(location = 10) in mediump  vec2 vs_TEXCOORD8;
layout(location = 11) in highp  vec3 vs_TEXCOORD9;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
mediump vec3 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
int u_xlati2;
uvec2 u_xlatu2;
bool u_xlatb2;
vec4 u_xlat3;
vec3 u_xlat4;
mediump vec2 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
vec3 u_xlat8;
vec2 u_xlat9;
mediump vec2 u_xlat16_11;
float u_xlat12;
float u_xlat16;
uint u_xlatu16;
float u_xlat22;
float u_xlat26;
int u_xlati26;
uint u_xlatu26;
bool u_xlatb26;
float u_xlat30;
mediump float u_xlat16_31;
float u_xlat32;
float u_xlat34;
float u_xlat35;
int u_xlati35;
float u_xlat36;
int u_xlati36;
float u_xlat37;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat16_1.x = dot(u_xlat16_0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_2.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat3 = u_xlat16_0 * vs_COLOR0;
    u_xlat30 = dot(u_xlat16_2.xx, vs_COLOR1.ww);
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.x = u_xlat30 + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_11.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_31 = dot(u_xlat16_11.xy, u_xlat16_11.xy);
    u_xlat16_31 = min(u_xlat16_31, 1.0);
    u_xlat16_31 = (-u_xlat16_31) + 1.0;
    u_xlat16_31 = sqrt(u_xlat16_31);
    u_xlat16_31 = max(u_xlat16_31, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_11.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_11.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_31) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat32 = inversesqrt(u_xlat32);
    u_xlat4.xyz = vec3(u_xlat32) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDirection.xyz;
    u_xlat5.xyz = vec3(vec3(_UseCharacterLightDirection, _UseCharacterLightDirection, _UseCharacterLightDirection)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat6.xyz = (-u_xlat5.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat6.xyz + u_xlat5.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat34 = (-_ToonAmbient) + 1.0;
    u_xlat30 = u_xlat30 * _ToonAmbient;
    u_xlat32 = u_xlat32 * u_xlat34 + u_xlat30;
    u_xlat32 = u_xlat2.x * _OcclusionAddScale + u_xlat32;
    u_xlat32 = clamp(u_xlat32, 0.0, 1.0);
    u_xlat32 = u_xlat32 * 0.5 + 0.5;
    u_xlat32 = u_xlat32 * unity_LightData.z;
    u_xlat16_11.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati35 = int(u_xlat16_11.x);
    u_xlat6.x = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati35) ; u_xlatu_loop_1++)
    {
        u_xlatu26 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati36 = int(u_xlatu_loop_1 & 3u);
        u_xlat26 = dot(unity_LightIndices[int(u_xlatu26)], ImmCB_0[u_xlati36]);
        u_xlati26 = int(u_xlat26);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati26].www + _AdditionalLightsPosition[u_xlati26].xyz;
        u_xlat36 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat36 = max(u_xlat36, 6.10351562e-05);
        u_xlat37 = inversesqrt(u_xlat36);
        u_xlat7.xyz = vec3(u_xlat37) * u_xlat7.xyz;
        u_xlat37 = float(1.0) / float(u_xlat36);
        u_xlat36 = u_xlat36 * _AdditionalLightsAttenuation[u_xlati26].x;
        u_xlat16_11.x = (-u_xlat36) * u_xlat36 + 1.0;
        u_xlat16_11.x = max(u_xlat16_11.x, 0.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat36 = u_xlat16_11.x * u_xlat37;
        u_xlat16_11.x = dot(_AdditionalLightsSpotDir[u_xlati26].xyz, u_xlat7.xyz);
        u_xlat16_11.x = u_xlat16_11.x * _AdditionalLightsAttenuation[u_xlati26].z + _AdditionalLightsAttenuation[u_xlati26].w;
        u_xlat16_11.x = clamp(u_xlat16_11.x, 0.0, 1.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat26 = u_xlat16_11.x * u_xlat36;
        u_xlat36 = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat36 = clamp(u_xlat36, 0.0, 1.0);
        u_xlat36 = u_xlat36 * 0.5 + 0.5;
        u_xlat6.x = u_xlat36 * u_xlat26 + u_xlat6.x;
    }
    u_xlat35 = u_xlat6.x + vs_TEXCOORD8.x;
    u_xlat35 = clamp(u_xlat35, 0.0, 1.0);
    u_xlat32 = max(u_xlat32, 0.0);
    u_xlat6.x = u_xlat32 + (-u_charaShadowColor0.w);
    u_xlat16 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat26 = (-u_xlat32) + 1.0;
    u_xlat12 = u_xlat16_2.y * u_xlat26 + u_xlat32;
    u_xlat26 = 0.5;
    u_xlat7.x = u_xlat26 + u_xlat6.x;
    u_xlat7.y = u_xlat12 + u_xlat16;
    u_xlat12 = u_xlat35 * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat16_0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat3.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat3.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat3.xyz * u_xlat7.xyz;
    u_xlat9.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat3.xyz = (-u_xlat3.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat3.xyz = u_xlat9.xxx * u_xlat3.xyz + u_xlat8.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat9.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat3.xyz = u_xlat3.xyz * u_xlat6.xyz;
    u_xlat16_1.x = u_xlat16_1.x * 0.200000003 + u_xlat16_2.z;
    u_xlat12 = min(u_xlat16_1.x, 1.0);
    u_xlat0.xyz = u_xlat16_0.xyz * vs_COLOR0.xyz + (-u_xlat3.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat16_1.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_1.x = inversesqrt(u_xlat16_1.x);
    u_xlat16_1.xyz = u_xlat16_1.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_1.xyz);
    u_xlat3.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat22 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat22 = inversesqrt(u_xlat22);
    u_xlat3.xyz = vec3(u_xlat22) * u_xlat3.xyz;
    u_xlat22 = dot(u_xlat3.xyz, u_xlat4.xyz);
    u_xlat22 = (-u_xlat22);
    u_xlat22 = clamp(u_xlat22, 0.0, 1.0);
    u_xlat22 = (-u_xlat22) + 1.0;
    u_xlat3.x = u_xlat12 * u_xlat22;
    u_xlat3.x = clamp(u_xlat3.x, 0.0, 1.0);
    u_xlat32 = u_xlat32 + u_xlat3.x;
    u_xlat30 = (-u_xlat12) * u_xlat34 + u_xlat30;
    u_xlat30 = u_xlat2.x * _OcclusionAddScale + u_xlat30;
    u_xlat30 = u_xlat30 * 0.5 + 0.5;
    u_xlat2.x = (-u_xlat12) * u_xlat22;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat30 = u_xlat30 + u_xlat2.x;
    u_xlat30 = u_xlat30 + (-u_charaUnderLightColor.w);
    u_xlat30 = u_xlat30 * _UnderLightToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = vec3(u_xlat30) * u_charaUnderLightColor.xyz;
    u_xlat30 = u_xlat32 + (-u_charaHighLightColor.w);
    u_xlat30 = u_xlat30 * _CharaToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = u_charaHighLightColor.xyz * vec3(u_xlat30) + u_xlat2.xyz;
    u_xlat3.xyz = u_xlat0.xyz + u_xlat2.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat2.xyz = (-u_xlat2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat16_2.xyz = texture(_StatesTex, vs_TEXCOORD7.xy, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat16_2.xyz * _StatesColor.xyz;
    u_xlat2.xyz = _StatesColor.xyz * u_xlat16_2.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(vec3(_StatesPow, _StatesPow, _StatesPow)) * u_xlat2.xyz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat3.xyz * vec3(_StatesAdd) + u_xlat0.xyz;
    u_xlat30 = dot(vs_TEXCOORD9.xyz, vs_TEXCOORD9.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat2.xyz = vec3(u_xlat30) * vs_TEXCOORD9.xyz;
    u_xlat30 = (-_StatesRimWidth) + 10.0;
    u_xlat3.xyz = vec3(u_xlat30) * u_xlat4.xyz;
    u_xlat30 = dot(u_xlat3.xyz, u_xlat2.xyz);
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat30 = log2(u_xlat30);
    u_xlat30 = u_xlat30 * _StatesRimPow;
    u_xlat30 = exp2(u_xlat30);
    u_xlat30 = (-u_xlat30) + 1.0;
    u_xlat30 = max(u_xlat30, 0.0);
    u_xlat2.xyz = (-u_xlat0.xyz) + _StatesRimColor.xyz;
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat2.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat2.x = (-_Transparency) + 1.0;
    u_xlat0.w = u_xlat2.x * u_xlat3.w;
    u_xlat0.w = clamp(u_xlat0.w, 0.0, 1.0);
    u_xlat2.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat2.xy = u_xlat2.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu2.xy = uvec2(u_xlat2.xy);
    u_xlati2 = int(bitfieldInsert(0, int(u_xlatu2.x), 2 & int(0x1F), 2));
    u_xlati2 = int(bitfieldInsert(u_xlati2, int(u_xlatu2.y), 0 & int(0x1F), 2));
    u_xlat2.x = u_xlat0.w + (-ImmCB_0[u_xlati2 + 4].x);
    u_xlatb2 = u_xlat2.x<0.0;
    if(u_xlatb2){discard;}
    SV_Target0 = u_xlat0;
    return;
}

#endif


// ===== program 9: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
uniform 	float _UseCharacterLightDirection;
uniform 	vec3 _CharacterLightDirection;
uniform 	float _StatesPow;
uniform 	float _StatesAdd;
uniform 	float _StatesRimWidth;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float Xhlslcc_UnusedX_AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4 Xhlslcc_UnusedX_OutlineColor;
	float Xhlslcc_UnusedX_OutlineNormalOffset;
	float Xhlslcc_UnusedX_OutlineDepthScaleMax;
	vec3                _StatesColor;
	vec4                _StatesRimColor;
	float                _StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float                _StatesTexDistortion;
	float                _StatesTexScaleU;
	float                _StatesTexScaleV;
	float                _StatesTexScrollSpeedU;
	float                _StatesTexScrollSpeedV;
	vec3                _StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(3) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(4) uniform mediump sampler2D _StatesTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD7;
layout(location = 10) in mediump  vec2 vs_TEXCOORD8;
layout(location = 11) in highp  vec3 vs_TEXCOORD9;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
mediump vec3 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
int u_xlati2;
uvec2 u_xlatu2;
bool u_xlatb2;
vec4 u_xlat3;
vec3 u_xlat4;
mediump vec2 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
vec3 u_xlat8;
vec2 u_xlat9;
mediump vec2 u_xlat16_11;
float u_xlat12;
float u_xlat16;
uint u_xlatu16;
float u_xlat22;
float u_xlat26;
int u_xlati26;
uint u_xlatu26;
bool u_xlatb26;
float u_xlat30;
mediump float u_xlat16_31;
float u_xlat32;
float u_xlat34;
float u_xlat35;
int u_xlati35;
float u_xlat36;
int u_xlati36;
float u_xlat37;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat16_1.x = dot(u_xlat16_0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_2.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat3 = u_xlat16_0 * vs_COLOR0;
    u_xlat30 = dot(u_xlat16_2.xx, vs_COLOR1.ww);
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.x = u_xlat30 + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_11.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_31 = dot(u_xlat16_11.xy, u_xlat16_11.xy);
    u_xlat16_31 = min(u_xlat16_31, 1.0);
    u_xlat16_31 = (-u_xlat16_31) + 1.0;
    u_xlat16_31 = sqrt(u_xlat16_31);
    u_xlat16_31 = max(u_xlat16_31, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_11.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_11.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_31) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat32 = inversesqrt(u_xlat32);
    u_xlat4.xyz = vec3(u_xlat32) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDirection.xyz;
    u_xlat5.xyz = vec3(vec3(_UseCharacterLightDirection, _UseCharacterLightDirection, _UseCharacterLightDirection)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat6.xyz = (-u_xlat5.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat6.xyz + u_xlat5.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat34 = (-_ToonAmbient) + 1.0;
    u_xlat30 = u_xlat30 * _ToonAmbient;
    u_xlat32 = u_xlat32 * u_xlat34 + u_xlat30;
    u_xlat32 = u_xlat2.x * _OcclusionAddScale + u_xlat32;
    u_xlat32 = clamp(u_xlat32, 0.0, 1.0);
    u_xlat32 = u_xlat32 * 0.5 + 0.5;
    u_xlat32 = u_xlat32 * unity_LightData.z;
    u_xlat16_11.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati35 = int(u_xlat16_11.x);
    u_xlat6.x = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati35) ; u_xlatu_loop_1++)
    {
        u_xlatu26 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati36 = int(u_xlatu_loop_1 & 3u);
        u_xlat26 = dot(unity_LightIndices[int(u_xlatu26)], ImmCB_0[u_xlati36]);
        u_xlati26 = int(u_xlat26);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati26].www + _AdditionalLightsPosition[u_xlati26].xyz;
        u_xlat36 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat36 = max(u_xlat36, 6.10351562e-05);
        u_xlat37 = inversesqrt(u_xlat36);
        u_xlat7.xyz = vec3(u_xlat37) * u_xlat7.xyz;
        u_xlat37 = float(1.0) / float(u_xlat36);
        u_xlat36 = u_xlat36 * _AdditionalLightsAttenuation[u_xlati26].x;
        u_xlat16_11.x = (-u_xlat36) * u_xlat36 + 1.0;
        u_xlat16_11.x = max(u_xlat16_11.x, 0.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat36 = u_xlat16_11.x * u_xlat37;
        u_xlat16_11.x = dot(_AdditionalLightsSpotDir[u_xlati26].xyz, u_xlat7.xyz);
        u_xlat16_11.x = u_xlat16_11.x * _AdditionalLightsAttenuation[u_xlati26].z + _AdditionalLightsAttenuation[u_xlati26].w;
        u_xlat16_11.x = clamp(u_xlat16_11.x, 0.0, 1.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat26 = u_xlat16_11.x * u_xlat36;
        u_xlat36 = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat36 = clamp(u_xlat36, 0.0, 1.0);
        u_xlat36 = u_xlat36 * 0.5 + 0.5;
        u_xlat6.x = u_xlat36 * u_xlat26 + u_xlat6.x;
    }
    u_xlat35 = u_xlat6.x + vs_TEXCOORD8.x;
    u_xlat35 = clamp(u_xlat35, 0.0, 1.0);
    u_xlat32 = max(u_xlat32, 0.0);
    u_xlat6.x = u_xlat32 + (-u_charaShadowColor0.w);
    u_xlat16 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat26 = (-u_xlat32) + 1.0;
    u_xlat12 = u_xlat16_2.y * u_xlat26 + u_xlat32;
    u_xlat26 = 0.5;
    u_xlat7.x = u_xlat26 + u_xlat6.x;
    u_xlat7.y = u_xlat12 + u_xlat16;
    u_xlat12 = u_xlat35 * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat16_0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat3.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat3.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat3.xyz * u_xlat7.xyz;
    u_xlat9.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat3.xyz = (-u_xlat3.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat3.xyz = u_xlat9.xxx * u_xlat3.xyz + u_xlat8.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat9.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat3.xyz = u_xlat3.xyz * u_xlat6.xyz;
    u_xlat16_1.x = u_xlat16_1.x * 0.200000003 + u_xlat16_2.z;
    u_xlat12 = min(u_xlat16_1.x, 1.0);
    u_xlat0.xyz = u_xlat16_0.xyz * vs_COLOR0.xyz + (-u_xlat3.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat16_1.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_1.x = inversesqrt(u_xlat16_1.x);
    u_xlat16_1.xyz = u_xlat16_1.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_1.xyz);
    u_xlat3.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat22 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat22 = inversesqrt(u_xlat22);
    u_xlat3.xyz = vec3(u_xlat22) * u_xlat3.xyz;
    u_xlat22 = dot(u_xlat3.xyz, u_xlat4.xyz);
    u_xlat22 = (-u_xlat22);
    u_xlat22 = clamp(u_xlat22, 0.0, 1.0);
    u_xlat22 = (-u_xlat22) + 1.0;
    u_xlat3.x = u_xlat12 * u_xlat22;
    u_xlat3.x = clamp(u_xlat3.x, 0.0, 1.0);
    u_xlat32 = u_xlat32 + u_xlat3.x;
    u_xlat30 = (-u_xlat12) * u_xlat34 + u_xlat30;
    u_xlat30 = u_xlat2.x * _OcclusionAddScale + u_xlat30;
    u_xlat30 = u_xlat30 * 0.5 + 0.5;
    u_xlat2.x = (-u_xlat12) * u_xlat22;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat30 = u_xlat30 + u_xlat2.x;
    u_xlat30 = u_xlat30 + (-u_charaUnderLightColor.w);
    u_xlat30 = u_xlat30 * _UnderLightToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = vec3(u_xlat30) * u_charaUnderLightColor.xyz;
    u_xlat30 = u_xlat32 + (-u_charaHighLightColor.w);
    u_xlat30 = u_xlat30 * _CharaToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = u_charaHighLightColor.xyz * vec3(u_xlat30) + u_xlat2.xyz;
    u_xlat3.xyz = u_xlat0.xyz + u_xlat2.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat2.xyz = (-u_xlat2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat16_2.xyz = texture(_StatesTex, vs_TEXCOORD7.xy, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = u_xlat16_2.xyz * _StatesColor.xyz;
    u_xlat2.xyz = _StatesColor.xyz * u_xlat16_2.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(vec3(_StatesPow, _StatesPow, _StatesPow)) * u_xlat2.xyz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat3.xyz * vec3(_StatesAdd) + u_xlat0.xyz;
    u_xlat30 = dot(vs_TEXCOORD9.xyz, vs_TEXCOORD9.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat2.xyz = vec3(u_xlat30) * vs_TEXCOORD9.xyz;
    u_xlat30 = (-_StatesRimWidth) + 10.0;
    u_xlat3.xyz = vec3(u_xlat30) * u_xlat4.xyz;
    u_xlat30 = dot(u_xlat3.xyz, u_xlat2.xyz);
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat30 = log2(u_xlat30);
    u_xlat30 = u_xlat30 * _StatesRimPow;
    u_xlat30 = exp2(u_xlat30);
    u_xlat30 = (-u_xlat30) + 1.0;
    u_xlat30 = max(u_xlat30, 0.0);
    u_xlat2.xyz = (-u_xlat0.xyz) + _StatesRimColor.xyz;
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat2.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat2.x = (-_Transparency) + 1.0;
    u_xlat0.w = u_xlat2.x * u_xlat3.w;
    u_xlat0.w = clamp(u_xlat0.w, 0.0, 1.0);
    u_xlat2.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat2.xy = u_xlat2.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu2.xy = uvec2(u_xlat2.xy);
    u_xlati2 = int(bitfieldInsert(0, int(u_xlatu2.x), 2 & int(0x1F), 2));
    u_xlati2 = int(bitfieldInsert(u_xlati2, int(u_xlatu2.y), 0 & int(0x1F), 2));
    u_xlat2.x = u_xlat0.w + (-ImmCB_0[u_xlati2 + 4].x);
    u_xlatb2 = u_xlat2.x<0.0;
    if(u_xlatb2){discard;}
    SV_Target0 = u_xlat0;
    return;
}

#endif


// ===== program 10: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	float _AuraCenterStart;
uniform 	float _AuraCenterWidth;
uniform 	float _AuraEdgeStart;
uniform 	float _AuraEdgeWidth;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float Xhlslcc_UnusedX_AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4 Xhlslcc_UnusedX_OutlineColor;
	float Xhlslcc_UnusedX_OutlineNormalOffset;
	float Xhlslcc_UnusedX_OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TANGENT0;
in highp vec4 in_COLOR0;
in mediump vec2 in_TEXCOORD0;
layout(location = 0) out highp vec4 vs_COLOR0;
layout(location = 1) out highp vec4 vs_COLOR1;
layout(location = 2) out highp vec3 vs_TEXCOORD0;
layout(location = 3) out highp vec3 vs_TEXCOORD1;
layout(location = 4) out highp vec3 vs_TEXCOORD2;
layout(location = 5) out highp vec3 vs_TEXCOORD3;
layout(location = 6) out highp vec4 vs_TEXCOORD4;
layout(location = 7) out mediump vec2 vs_TEXCOORD5;
mediump  vec4 phase0_Output0_8;
layout(location = 8) out mediump vec2 vs_TEXCOORD6;
layout(location = 11) out mediump vec2 vs_TEXCOORD7;
mediump  vec4 phase0_Output0_9;
layout(location = 9) out mediump vec2 vs_TEXCOORD8;
layout(location = 12) out highp vec3 vs_TEXCOORD9;
layout(location = 10) out highp vec3 vs_TEXCOORD10;
vec4 u_xlat0;
vec4 u_xlat1;
bvec2 u_xlatb1;
vec4 u_xlat2;
bvec2 u_xlatb2;
vec3 u_xlat3;
vec3 u_xlat4;
mediump vec3 u_xlat16_5;
vec3 u_xlat6;
vec3 u_xlat7;
vec2 u_xlat8;
float u_xlat16;
vec2 u_xlat17;
vec2 u_xlat18;
vec2 u_xlat20;
float u_xlat24;
bool u_xlatb24;
mediump float u_xlat16_29;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat1 = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    gl_Position = u_xlat1;
    vs_COLOR0 = vec4(_Color.x, _Color.y, _Color.z, _Transparency) * vec4(1.0, 1.0, 1.0, -1.0) + vec4(0.0, 0.0, 0.0, 1.0);
    vs_COLOR1 = in_COLOR0;
    u_xlat2.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat2.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat24 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat24 = max(u_xlat24, 1.17549435e-38);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat2.xyz = vec3(u_xlat24) * u_xlat2.xyz;
    u_xlat24 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat3.xyz = vec3(u_xlat24) * u_xlat2.xyz;
    vs_TEXCOORD0.xyz = u_xlat3.xyz;
    u_xlat4.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat4.xyz;
    u_xlat4.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat4.xyz;
    u_xlat24 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat24 = max(u_xlat24, 1.17549435e-38);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat4.xyz = vec3(u_xlat24) * u_xlat4.xyz;
    u_xlat16_5.x = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat16_5.x = inversesqrt(u_xlat16_5.x);
    u_xlat16_5.xyz = u_xlat4.xyz * u_xlat16_5.xxx;
    vs_TEXCOORD1.xyz = u_xlat16_5.xyz;
    u_xlat6.xyz = u_xlat2.zxy * u_xlat4.yzx;
    u_xlat2.xyz = u_xlat2.yzx * u_xlat4.zxy + (-u_xlat6.xyz);
    u_xlatb24 = unity_WorldTransformParams.w>=0.0;
    u_xlat24 = (u_xlatb24) ? 1.0 : -1.0;
    u_xlat16_5.x = u_xlat24 * in_TANGENT0.w;
    u_xlat16_5.xyz = u_xlat2.xyz * u_xlat16_5.xxx;
    u_xlat16_29 = dot(u_xlat16_5.xyz, u_xlat16_5.xyz);
    u_xlat16_29 = inversesqrt(u_xlat16_29);
    u_xlat16_5.xyz = vec3(u_xlat16_29) * u_xlat16_5.xyz;
    vs_TEXCOORD2.xyz = u_xlat16_5.xyz;
    vs_TEXCOORD3.xyz = u_xlat0.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + _WorldSpaceCameraPos.xyz;
    u_xlat24 = u_xlat1.y * _ProjectionParams.x;
    u_xlat2.w = u_xlat24 * 0.5;
    u_xlat2.xz = u_xlat1.xw * vec2(0.5, 0.5);
    vs_TEXCOORD4.zw = u_xlat1.zw;
    vs_TEXCOORD4.xy = u_xlat2.zz + u_xlat2.xw;
    u_xlatb1.xy = greaterThanEqual(_ColorTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat1.x = (u_xlatb1.x) ? float(1.0) : float(-1.0);
    u_xlat1.y = (u_xlatb1.y) ? float(1.0) : float(-1.0);
    u_xlat17.xy = max(abs(_ColorTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat1.xy = u_xlat1.xy * u_xlat17.xy;
    u_xlat24 = _ColorTex_R * 0.0174532924;
    u_xlat2.x = sin(u_xlat24);
    u_xlat4.x = cos(u_xlat24);
    u_xlat6.z = u_xlat2.x;
    u_xlat17.xy = in_TEXCOORD0.xy + (-_ColorTex_ST.zw);
    u_xlat6.y = u_xlat4.x;
    u_xlat6.x = (-u_xlat2.x);
    u_xlat2.y = dot(u_xlat17.xy, u_xlat6.xy);
    u_xlat2.x = dot(u_xlat17.xy, u_xlat6.yz);
    u_xlat1.xy = u_xlat2.xy / u_xlat1.xy;
    u_xlatb2.xy = greaterThanEqual(_OcclusionTex_ST.xyxx, vec4(0.0, 0.0, 0.0, 0.0)).xy;
    u_xlat2.x = (u_xlatb2.x) ? float(1.0) : float(-1.0);
    u_xlat2.y = (u_xlatb2.y) ? float(1.0) : float(-1.0);
    u_xlat18.xy = max(abs(_OcclusionTex_ST.xy), vec2(9.99999975e-05, 9.99999975e-05));
    u_xlat2.xy = u_xlat2.xy * u_xlat18.xy;
    u_xlat24 = _OcclusionTex_R * 0.0174532924;
    u_xlat4.x = sin(u_xlat24);
    u_xlat6.x = cos(u_xlat24);
    u_xlat7.z = u_xlat4.x;
    u_xlat18.xy = in_TEXCOORD0.xy + (-_OcclusionTex_ST.zw);
    u_xlat7.y = u_xlat6.x;
    u_xlat7.x = (-u_xlat4.x);
    u_xlat20.y = dot(u_xlat18.xy, u_xlat7.xy);
    u_xlat20.x = dot(u_xlat18.xy, u_xlat7.yz);
    u_xlat1.zw = u_xlat20.xy / u_xlat2.xy;
    phase0_Output0_8 = u_xlat1;
    phase0_Output0_9 = vec4(0.0, 0.0, 0.0, 0.0);
    vs_TEXCOORD9.xyz = u_xlat0.xyz;
    u_xlat24 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat24 = inversesqrt(u_xlat24);
    u_xlat0.xyz = vec3(u_xlat24) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat3.xyz, u_xlat0.xyz);
    u_xlat8.xy = vec2(1.0, 1.0) / vec2(_AuraCenterWidth, _AuraEdgeWidth);
    u_xlat0.xw = u_xlat0.xx * u_xlat8.xy;
    u_xlat16 = (-_AuraEdgeStart) * u_xlat8.y + u_xlat0.w;
    u_xlat16 = clamp(u_xlat16, 0.0, 1.0);
    u_xlat1.x = (-_AuraCenterStart) * u_xlat8.x + u_xlat0.x;
    u_xlat1.x = clamp(u_xlat1.x, 0.0, 1.0);
    u_xlat1.z = (-u_xlat16) + 1.0;
    u_xlat0.x = (-u_xlat1.x) + 1.0;
    vs_TEXCOORD10.xz = u_xlat1.xz;
    u_xlat0.x = (-u_xlat1.z) + u_xlat0.x;
    vs_TEXCOORD10.y = max(u_xlat0.x, 0.0);
vs_TEXCOORD5 = phase0_Output0_8.xy;
vs_TEXCOORD6 = phase0_Output0_8.zw;
vs_TEXCOORD7 = phase0_Output0_9.xy;
vs_TEXCOORD8 = phase0_Output0_9.zw;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
uniform 	float _UseCharacterLightDirection;
uniform 	vec3 _CharacterLightDirection;
uniform 	vec4 _AuraUv;
uniform 	vec4 _AuraCenterColor;
uniform 	vec4 _AuraMiddleColor;
uniform 	vec4 _AuraEdgeColor;
uniform 	float _AuraHradlightBlend;
uniform 	float _AuraAddBlend;
uniform 	float _AuraTexBlend;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float Xhlslcc_UnusedX_AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4 Xhlslcc_UnusedX_OutlineColor;
	float Xhlslcc_UnusedX_OutlineNormalOffset;
	float Xhlslcc_UnusedX_OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(3) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(4) uniform mediump sampler2D _AuraTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD8;
layout(location = 10) in highp  vec3 vs_TEXCOORD10;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
mediump vec3 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
int u_xlati2;
uvec2 u_xlatu2;
bool u_xlatb2;
vec4 u_xlat3;
mediump vec3 u_xlat16_3;
vec3 u_xlat4;
mediump vec3 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
vec3 u_xlat8;
vec2 u_xlat9;
mediump vec2 u_xlat16_11;
float u_xlat12;
float u_xlat16;
uint u_xlatu16;
float u_xlat22;
float u_xlat26;
int u_xlati26;
uint u_xlatu26;
bool u_xlatb26;
float u_xlat30;
bool u_xlatb30;
mediump float u_xlat16_31;
float u_xlat32;
float u_xlat34;
float u_xlat35;
int u_xlati35;
float u_xlat36;
int u_xlati36;
float u_xlat37;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat16_1.x = dot(u_xlat16_0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_2.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat3 = u_xlat16_0 * vs_COLOR0;
    u_xlat30 = dot(u_xlat16_2.xx, vs_COLOR1.ww);
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.x = u_xlat30 + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_11.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_31 = dot(u_xlat16_11.xy, u_xlat16_11.xy);
    u_xlat16_31 = min(u_xlat16_31, 1.0);
    u_xlat16_31 = (-u_xlat16_31) + 1.0;
    u_xlat16_31 = sqrt(u_xlat16_31);
    u_xlat16_31 = max(u_xlat16_31, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_11.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_11.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_31) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat32 = inversesqrt(u_xlat32);
    u_xlat4.xyz = vec3(u_xlat32) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDirection.xyz;
    u_xlat5.xyz = vec3(vec3(_UseCharacterLightDirection, _UseCharacterLightDirection, _UseCharacterLightDirection)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat6.xyz = (-u_xlat5.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat6.xyz + u_xlat5.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat34 = (-_ToonAmbient) + 1.0;
    u_xlat30 = u_xlat30 * _ToonAmbient;
    u_xlat32 = u_xlat32 * u_xlat34 + u_xlat30;
    u_xlat32 = u_xlat2.x * _OcclusionAddScale + u_xlat32;
    u_xlat32 = clamp(u_xlat32, 0.0, 1.0);
    u_xlat32 = u_xlat32 * 0.5 + 0.5;
    u_xlat32 = u_xlat32 * unity_LightData.z;
    u_xlat16_11.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati35 = int(u_xlat16_11.x);
    u_xlat6.x = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati35) ; u_xlatu_loop_1++)
    {
        u_xlatu26 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati36 = int(u_xlatu_loop_1 & 3u);
        u_xlat26 = dot(unity_LightIndices[int(u_xlatu26)], ImmCB_0[u_xlati36]);
        u_xlati26 = int(u_xlat26);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati26].www + _AdditionalLightsPosition[u_xlati26].xyz;
        u_xlat36 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat36 = max(u_xlat36, 6.10351562e-05);
        u_xlat37 = inversesqrt(u_xlat36);
        u_xlat7.xyz = vec3(u_xlat37) * u_xlat7.xyz;
        u_xlat37 = float(1.0) / float(u_xlat36);
        u_xlat36 = u_xlat36 * _AdditionalLightsAttenuation[u_xlati26].x;
        u_xlat16_11.x = (-u_xlat36) * u_xlat36 + 1.0;
        u_xlat16_11.x = max(u_xlat16_11.x, 0.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat36 = u_xlat16_11.x * u_xlat37;
        u_xlat16_11.x = dot(_AdditionalLightsSpotDir[u_xlati26].xyz, u_xlat7.xyz);
        u_xlat16_11.x = u_xlat16_11.x * _AdditionalLightsAttenuation[u_xlati26].z + _AdditionalLightsAttenuation[u_xlati26].w;
        u_xlat16_11.x = clamp(u_xlat16_11.x, 0.0, 1.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat26 = u_xlat16_11.x * u_xlat36;
        u_xlat36 = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat36 = clamp(u_xlat36, 0.0, 1.0);
        u_xlat36 = u_xlat36 * 0.5 + 0.5;
        u_xlat6.x = u_xlat36 * u_xlat26 + u_xlat6.x;
    }
    u_xlat35 = u_xlat6.x + vs_TEXCOORD8.x;
    u_xlat35 = clamp(u_xlat35, 0.0, 1.0);
    u_xlat32 = max(u_xlat32, 0.0);
    u_xlat6.x = u_xlat32 + (-u_charaShadowColor0.w);
    u_xlat16 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat26 = (-u_xlat32) + 1.0;
    u_xlat12 = u_xlat16_2.y * u_xlat26 + u_xlat32;
    u_xlat26 = 0.5;
    u_xlat7.x = u_xlat26 + u_xlat6.x;
    u_xlat7.y = u_xlat12 + u_xlat16;
    u_xlat12 = u_xlat35 * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat16_0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat3.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat3.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat3.xyz * u_xlat7.xyz;
    u_xlat9.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat3.xyz = (-u_xlat3.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat3.xyz = u_xlat9.xxx * u_xlat3.xyz + u_xlat8.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat9.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat3.xyz = u_xlat3.xyz * u_xlat6.xyz;
    u_xlat16_1.x = u_xlat16_1.x * 0.200000003 + u_xlat16_2.z;
    u_xlat12 = min(u_xlat16_1.x, 1.0);
    u_xlat0.xyz = u_xlat16_0.xyz * vs_COLOR0.xyz + (-u_xlat3.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat16_1.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_1.x = inversesqrt(u_xlat16_1.x);
    u_xlat16_1.xyz = u_xlat16_1.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_1.xyz);
    u_xlat3.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat22 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat22 = inversesqrt(u_xlat22);
    u_xlat3.xyz = vec3(u_xlat22) * u_xlat3.xyz;
    u_xlat22 = dot(u_xlat3.xyz, u_xlat4.xyz);
    u_xlat22 = (-u_xlat22);
    u_xlat22 = clamp(u_xlat22, 0.0, 1.0);
    u_xlat22 = (-u_xlat22) + 1.0;
    u_xlat3.x = u_xlat12 * u_xlat22;
    u_xlat3.x = clamp(u_xlat3.x, 0.0, 1.0);
    u_xlat32 = u_xlat32 + u_xlat3.x;
    u_xlat30 = (-u_xlat12) * u_xlat34 + u_xlat30;
    u_xlat30 = u_xlat2.x * _OcclusionAddScale + u_xlat30;
    u_xlat30 = u_xlat30 * 0.5 + 0.5;
    u_xlat2.x = (-u_xlat12) * u_xlat22;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat30 = u_xlat30 + u_xlat2.x;
    u_xlat30 = u_xlat30 + (-u_charaUnderLightColor.w);
    u_xlat30 = u_xlat30 * _UnderLightToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = vec3(u_xlat30) * u_charaUnderLightColor.xyz;
    u_xlat30 = u_xlat32 + (-u_charaHighLightColor.w);
    u_xlat30 = u_xlat30 * _CharaToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = u_charaHighLightColor.xyz * vec3(u_xlat30) + u_xlat2.xyz;
    u_xlat3.xyz = u_xlat0.xyz + u_xlat2.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat2.xyz = (-u_xlat2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat2.xyz = vs_TEXCOORD10.yyy * _AuraMiddleColor.xyz;
    u_xlat2.xyz = vs_TEXCOORD10.xxx * _AuraCenterColor.xyz + u_xlat2.xyz;
    u_xlat2.xyz = vs_TEXCOORD10.zzz * _AuraEdgeColor.xyz + u_xlat2.xyz;
    u_xlat16_3.xyz = texture(_AuraTex, _AuraUv.wx, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = texture(_AuraTex, _AuraUv.wy, _GlobalMipBias.x).xyz;
    u_xlat4.xyz = u_xlat16_4.xyz * vs_TEXCOORD10.yyy;
    u_xlat3.xyz = vs_TEXCOORD10.xxx * u_xlat16_3.xyz + u_xlat4.xyz;
    u_xlat16_4.xyz = texture(_AuraTex, _AuraUv.wz, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = vs_TEXCOORD10.zzz * u_xlat16_4.xyz + u_xlat3.xyz;
    u_xlat3.xyz = (-u_xlat2.xyz) + u_xlat3.xyz;
    u_xlat2.xyz = vec3(vec3(_AuraTexBlend, _AuraTexBlend, _AuraTexBlend)) * u_xlat3.xyz + u_xlat2.xyz;
    u_xlat3.xyz = u_xlat0.xyz * u_xlat2.xyz;
    u_xlat4.xyz = u_xlat3.xyz + u_xlat3.xyz;
    u_xlat5.xyz = u_xlat0.xyz + vec3(-0.5, -0.5, -0.5);
    u_xlat5.xyz = (-u_xlat5.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = (-u_xlat2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat5.xyz = (-u_xlat5.xyz) * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlatb30 = 0.5>=u_xlat0.x;
    u_xlat30 = u_xlatb30 ? 1.0 : float(0.0);
    u_xlat3.xyz = (-u_xlat3.xyz) * vec3(2.0, 2.0, 2.0) + u_xlat5.xyz;
    u_xlat3.xyz = vec3(u_xlat30) * u_xlat3.xyz + u_xlat4.xyz;
    u_xlat3.xyz = (-u_xlat0.xyz) + u_xlat3.xyz;
    u_xlat0.xyz = vec3(_AuraHradlightBlend) * u_xlat3.xyz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat2.xyz * vec3(vec3(_AuraAddBlend, _AuraAddBlend, _AuraAddBlend)) + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat2.x = (-_Transparency) + 1.0;
    u_xlat0.w = u_xlat2.x * u_xlat3.w;
    u_xlat0.w = clamp(u_xlat0.w, 0.0, 1.0);
    u_xlat2.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat2.xy = u_xlat2.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu2.xy = uvec2(u_xlat2.xy);
    u_xlati2 = int(bitfieldInsert(0, int(u_xlatu2.x), 2 & int(0x1F), 2));
    u_xlati2 = int(bitfieldInsert(u_xlati2, int(u_xlatu2.y), 0 & int(0x1F), 2));
    u_xlat2.x = u_xlat0.w + (-ImmCB_0[u_xlati2 + 4].x);
    u_xlatb2 = u_xlat2.x<0.0;
    if(u_xlatb2){discard;}
    SV_Target0 = u_xlat0;
    return;
}

#endif


// ===== program 11: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
vec4 ImmCB_0[20];
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec3 _WorldSpaceCameraPos;
uniform 	vec4 _ScreenParams;
uniform 	float _UseCharacterLightDirection;
uniform 	vec3 _CharacterLightDirection;
uniform 	vec4 _AuraUv;
uniform 	vec4 _AuraCenterColor;
uniform 	vec4 _AuraMiddleColor;
uniform 	vec4 _AuraEdgeColor;
uniform 	float _AuraHradlightBlend;
uniform 	float _AuraAddBlend;
uniform 	float _AuraTexBlend;
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4                unity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4                unity_LightData;
	mediump vec4                unity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
UNITY_BINDING(1) uniform CharacterLightingParametersConstantBuffer {
	vec4                u_charaAmbient;
	vec4                u_charaHighLightColor;
	vec4                u_charaUnderLightColor;
	vec4                u_charaShadowColor0;
	vec4                u_charaShadowColor1;
};
UNITY_BINDING(2) uniform UnityPerMaterial {
	vec4                _ColorTex_ST;
	float                _ColorTex_R;
	float Xhlslcc_UnusedX_AdditionalFacialTexIndex;
	vec4 Xhlslcc_UnusedX_MaskTex_ST;
	vec3 Xhlslcc_UnusedX_MaskColor;
	vec4                _OcclusionTex_ST;
	float                _OcclusionTex_R;
	float                _OcclusionAddScale;
	vec4 Xhlslcc_UnusedX_ToonTex_TexelSize;
	vec3                _Color;
	float                _Transparency;
	float Xhlslcc_UnusedX_Separatable_Character_Lighting;
	float                _PerMaterialCharacterLighting;
	vec3                _CharacterLightDir;
	float                _ShadowGrd0;
	float                _ShadowGrd1;
	float                _ShadowMultiplyRate;
	float                _ShadowAlphaRate;
	float                _PointLightShadowOffScale;
	float                _ToonAmbient;
	float                _AmbientMultiplyRate;
	float                _AmbientAlphaRate;
	float                _LightProbeBlend;
	float                _ScreenLightRate;
	float                _CharaToonFadeRange;
	float                _UnderLightToonFadeRange;
	vec4 Xhlslcc_UnusedX_SpecularMaskTex_ST;
	float Xhlslcc_UnusedX_SpecularMaskTex_R;
	vec4 Xhlslcc_UnusedX_CharacterEditMaskTex_ST;
	float Xhlslcc_UnusedX_CharacterEditMaskTex_R;
	mediump vec4 Xhlslcc_UnusedX_SkinColor;
	mediump vec3 Xhlslcc_UnusedX_SubColor1;
	mediump vec3 Xhlslcc_UnusedX_SubColor2;
	mediump vec4 Xhlslcc_UnusedX_OutlineColor;
	float Xhlslcc_UnusedX_OutlineNormalOffset;
	float Xhlslcc_UnusedX_OutlineDepthScaleMax;
	vec3 Xhlslcc_UnusedX_StatesColor;
	vec4 Xhlslcc_UnusedX_StatesRimColor;
	float Xhlslcc_UnusedX_StatesRimPow;
	float Xhlslcc_UnusedX_StatesTexRateIn;
	float Xhlslcc_UnusedX_StatesTexRateOut;
	float Xhlslcc_UnusedX_StatesTexDistortion;
	float Xhlslcc_UnusedX_StatesTexScaleU;
	float Xhlslcc_UnusedX_StatesTexScaleV;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedU;
	float Xhlslcc_UnusedX_StatesTexScrollSpeedV;
	vec3 Xhlslcc_UnusedX_StatesTexPos;
};
UNITY_LOCATION(0) uniform mediump sampler2D _ColorTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalTex;
UNITY_LOCATION(2) uniform mediump sampler2D _OcclusionTex;
UNITY_LOCATION(3) uniform mediump sampler2D _ToonTex;
UNITY_LOCATION(4) uniform mediump sampler2D _AuraTex;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 1) in highp  vec4 vs_COLOR1;
layout(location = 2) in highp  vec3 vs_TEXCOORD0;
layout(location = 3) in highp  vec3 vs_TEXCOORD1;
layout(location = 4) in highp  vec3 vs_TEXCOORD2;
layout(location = 5) in highp  vec3 vs_TEXCOORD3;
layout(location = 6) in highp  vec4 vs_TEXCOORD4;
layout(location = 7) in mediump  vec2 vs_TEXCOORD5;
layout(location = 8) in mediump  vec2 vs_TEXCOORD6;
layout(location = 9) in mediump  vec2 vs_TEXCOORD8;
layout(location = 10) in highp  vec3 vs_TEXCOORD10;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
mediump vec3 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
int u_xlati2;
uvec2 u_xlatu2;
bool u_xlatb2;
vec4 u_xlat3;
mediump vec3 u_xlat16_3;
vec3 u_xlat4;
mediump vec3 u_xlat16_4;
vec3 u_xlat5;
vec4 u_xlat6;
mediump vec4 u_xlat16_6;
vec3 u_xlat7;
mediump vec4 u_xlat16_7;
vec3 u_xlat8;
vec2 u_xlat9;
mediump vec2 u_xlat16_11;
float u_xlat12;
float u_xlat16;
uint u_xlatu16;
float u_xlat22;
float u_xlat26;
int u_xlati26;
uint u_xlatu26;
bool u_xlatb26;
float u_xlat30;
bool u_xlatb30;
mediump float u_xlat16_31;
float u_xlat32;
float u_xlat34;
float u_xlat35;
int u_xlati35;
float u_xlat36;
int u_xlati36;
float u_xlat37;
void main()
{
ImmCB_0[0] = vec4(1.0,0.0,0.0,0.0);
ImmCB_0[1] = vec4(0.0,1.0,0.0,0.0);
ImmCB_0[2] = vec4(0.0,0.0,1.0,0.0);
ImmCB_0[3] = vec4(0.0,0.0,0.0,1.0);
ImmCB_0[4] = vec4(0.0588235296,0.0,0.0,0.0);
ImmCB_0[5] = vec4(0.529411793,0.0,0.0,0.0);
ImmCB_0[6] = vec4(0.176470593,0.0,0.0,0.0);
ImmCB_0[7] = vec4(0.647058845,0.0,0.0,0.0);
ImmCB_0[8] = vec4(0.764705896,0.0,0.0,0.0);
ImmCB_0[9] = vec4(0.294117659,0.0,0.0,0.0);
ImmCB_0[10] = vec4(0.882352948,0.0,0.0,0.0);
ImmCB_0[11] = vec4(0.411764711,0.0,0.0,0.0);
ImmCB_0[12] = vec4(0.235294119,0.0,0.0,0.0);
ImmCB_0[13] = vec4(0.70588237,0.0,0.0,0.0);
ImmCB_0[14] = vec4(0.117647059,0.0,0.0,0.0);
ImmCB_0[15] = vec4(0.588235319,0.0,0.0,0.0);
ImmCB_0[16] = vec4(0.941176474,0.0,0.0,0.0);
ImmCB_0[17] = vec4(0.470588237,0.0,0.0,0.0);
ImmCB_0[18] = vec4(0.823529422,0.0,0.0,0.0);
ImmCB_0[19] = vec4(0.352941185,0.0,0.0,0.0);
    u_xlat16_0 = texture(_ColorTex, vs_TEXCOORD5.xy, _GlobalMipBias.x);
    u_xlat16_1.x = dot(u_xlat16_0.xyz, vec3(0.298909992, 0.586610019, 0.114480004));
    u_xlat16_2.xyz = texture(_OcclusionTex, vs_TEXCOORD6.xy, _GlobalMipBias.x).xyz;
    u_xlat3 = u_xlat16_0 * vs_COLOR0;
    u_xlat30 = dot(u_xlat16_2.xx, vs_COLOR1.ww);
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.x = u_xlat30 + -1.0;
    u_xlat16_4.xy = texture(_NormalTex, vs_TEXCOORD5.xy, _GlobalMipBias.x).yw;
    u_xlat16_11.xy = u_xlat16_4.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_31 = dot(u_xlat16_11.xy, u_xlat16_11.xy);
    u_xlat16_31 = min(u_xlat16_31, 1.0);
    u_xlat16_31 = (-u_xlat16_31) + 1.0;
    u_xlat16_31 = sqrt(u_xlat16_31);
    u_xlat16_31 = max(u_xlat16_31, 1.00000002e-16);
    u_xlat4.xyz = u_xlat16_11.yyy * vs_TEXCOORD2.xyz;
    u_xlat4.xyz = u_xlat16_11.xxx * vs_TEXCOORD1.xyz + u_xlat4.xyz;
    u_xlat4.xyz = vec3(u_xlat16_31) * vs_TEXCOORD0.xyz + u_xlat4.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat4.xyz);
    u_xlat32 = inversesqrt(u_xlat32);
    u_xlat4.xyz = vec3(u_xlat32) * u_xlat4.xyz;
    u_xlat5.xyz = (-_MainLightPosition.xyz) + _CharacterLightDirection.xyz;
    u_xlat5.xyz = vec3(vec3(_UseCharacterLightDirection, _UseCharacterLightDirection, _UseCharacterLightDirection)) * u_xlat5.xyz + _MainLightPosition.xyz;
    u_xlat6.xyz = (-u_xlat5.xyz) + _CharacterLightDir.xyz;
    u_xlat5.xyz = vec3(vec3(_PerMaterialCharacterLighting, _PerMaterialCharacterLighting, _PerMaterialCharacterLighting)) * u_xlat6.xyz + u_xlat5.xyz;
    u_xlat32 = dot(u_xlat4.xyz, u_xlat5.xyz);
    u_xlat34 = (-_ToonAmbient) + 1.0;
    u_xlat30 = u_xlat30 * _ToonAmbient;
    u_xlat32 = u_xlat32 * u_xlat34 + u_xlat30;
    u_xlat32 = u_xlat2.x * _OcclusionAddScale + u_xlat32;
    u_xlat32 = clamp(u_xlat32, 0.0, 1.0);
    u_xlat32 = u_xlat32 * 0.5 + 0.5;
    u_xlat32 = u_xlat32 * unity_LightData.z;
    u_xlat16_11.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlati35 = int(u_xlat16_11.x);
    u_xlat6.x = float(0.0);
    for(uint u_xlatu_loop_1 = uint(0u) ; u_xlatu_loop_1<uint(u_xlati35) ; u_xlatu_loop_1++)
    {
        u_xlatu26 = u_xlatu_loop_1 >> (2u & uint(0x1F));
        u_xlati36 = int(u_xlatu_loop_1 & 3u);
        u_xlat26 = dot(unity_LightIndices[int(u_xlatu26)], ImmCB_0[u_xlati36]);
        u_xlati26 = int(u_xlat26);
        u_xlat7.xyz = (-vs_TEXCOORD3.xyz) * _AdditionalLightsPosition[u_xlati26].www + _AdditionalLightsPosition[u_xlati26].xyz;
        u_xlat36 = dot(u_xlat7.xyz, u_xlat7.xyz);
        u_xlat36 = max(u_xlat36, 6.10351562e-05);
        u_xlat37 = inversesqrt(u_xlat36);
        u_xlat7.xyz = vec3(u_xlat37) * u_xlat7.xyz;
        u_xlat37 = float(1.0) / float(u_xlat36);
        u_xlat36 = u_xlat36 * _AdditionalLightsAttenuation[u_xlati26].x;
        u_xlat16_11.x = (-u_xlat36) * u_xlat36 + 1.0;
        u_xlat16_11.x = max(u_xlat16_11.x, 0.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat36 = u_xlat16_11.x * u_xlat37;
        u_xlat16_11.x = dot(_AdditionalLightsSpotDir[u_xlati26].xyz, u_xlat7.xyz);
        u_xlat16_11.x = u_xlat16_11.x * _AdditionalLightsAttenuation[u_xlati26].z + _AdditionalLightsAttenuation[u_xlati26].w;
        u_xlat16_11.x = clamp(u_xlat16_11.x, 0.0, 1.0);
        u_xlat16_11.x = u_xlat16_11.x * u_xlat16_11.x;
        u_xlat26 = u_xlat16_11.x * u_xlat36;
        u_xlat36 = dot(u_xlat4.xyz, u_xlat7.xyz);
        u_xlat36 = clamp(u_xlat36, 0.0, 1.0);
        u_xlat36 = u_xlat36 * 0.5 + 0.5;
        u_xlat6.x = u_xlat36 * u_xlat26 + u_xlat6.x;
    }
    u_xlat35 = u_xlat6.x + vs_TEXCOORD8.x;
    u_xlat35 = clamp(u_xlat35, 0.0, 1.0);
    u_xlat32 = max(u_xlat32, 0.0);
    u_xlat6.x = u_xlat32 + (-u_charaShadowColor0.w);
    u_xlat16 = (-u_charaShadowColor1.w) + 0.5;
    u_xlat26 = (-u_xlat32) + 1.0;
    u_xlat12 = u_xlat16_2.y * u_xlat26 + u_xlat32;
    u_xlat26 = 0.5;
    u_xlat7.x = u_xlat26 + u_xlat6.x;
    u_xlat7.y = u_xlat12 + u_xlat16;
    u_xlat12 = u_xlat35 * _PointLightShadowOffScale;
    u_xlat6.xy = (-u_xlat7.xy) + vec2(1.0, 1.0);
    u_xlat6.xy = vec2(u_xlat12) * u_xlat6.xy + u_xlat7.xy;
    u_xlat6.z = (-_ShadowGrd0) + 1.0;
    u_xlat16_7 = texture(_ToonTex, u_xlat6.xz, _GlobalMipBias.x);
    u_xlat6.w = (-_ShadowGrd1) + 1.0;
    u_xlat16_6 = texture(_ToonTex, u_xlat6.yw, _GlobalMipBias.x);
    u_xlat7.xyz = u_xlat16_7.xyz * u_charaShadowColor0.xyz;
    u_xlat6.xyz = u_charaShadowColor1.xyz * u_xlat16_6.xyz + (-u_xlat7.xyz);
    u_xlat6.xyz = u_xlat16_6.www * u_xlat6.xyz + u_xlat7.xyz;
    u_xlat6.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_xlat6.xyz;
    u_xlat7.xyz = u_xlat16_1.xxx * vec3(0.100000001, 0.100000001, 0.100000001) + u_charaAmbient.xyz;
    u_xlat8.xyz = (-u_xlat7.xyz) + vs_TEXCOORD8.yyy;
    u_xlat7.xyz = vec3(vec3(_LightProbeBlend, _LightProbeBlend, _LightProbeBlend)) * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat8.xyz = (-u_xlat16_0.xyz) * vs_COLOR0.xyz + u_xlat7.xyz;
    u_xlat3.xyz = vec3(vec3(_AmbientAlphaRate, _AmbientAlphaRate, _AmbientAlphaRate)) * u_xlat8.xyz + u_xlat3.xyz;
    u_xlat7.xyz = u_xlat7.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat7.xyz = vec3(vec3(_AmbientMultiplyRate, _AmbientMultiplyRate, _AmbientMultiplyRate)) * u_xlat7.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat3.xyz * u_xlat7.xyz;
    u_xlat9.xy = u_xlat16_7.ww * vec2(_ShadowAlphaRate, _ShadowMultiplyRate);
    u_xlat3.xyz = (-u_xlat3.xyz) * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat3.xyz = u_xlat9.xxx * u_xlat3.xyz + u_xlat8.xyz;
    u_xlat6.xyz = u_xlat6.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat6.xyz = u_xlat9.yyy * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat3.xyz = u_xlat3.xyz * u_xlat6.xyz;
    u_xlat16_1.x = u_xlat16_1.x * 0.200000003 + u_xlat16_2.z;
    u_xlat12 = min(u_xlat16_1.x, 1.0);
    u_xlat0.xyz = u_xlat16_0.xyz * vs_COLOR0.xyz + (-u_xlat3.xyz);
    u_xlat0.xyz = vec3(u_xlat12) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat16_1.x = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat16_1.x = inversesqrt(u_xlat16_1.x);
    u_xlat16_1.xyz = u_xlat16_1.xxx * u_xlat5.xyz;
    u_xlat12 = dot(u_xlat4.xyz, u_xlat16_1.xyz);
    u_xlat3.xyz = vs_TEXCOORD3.xyz + (-_WorldSpaceCameraPos.xyz);
    u_xlat22 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat22 = inversesqrt(u_xlat22);
    u_xlat3.xyz = vec3(u_xlat22) * u_xlat3.xyz;
    u_xlat22 = dot(u_xlat3.xyz, u_xlat4.xyz);
    u_xlat22 = (-u_xlat22);
    u_xlat22 = clamp(u_xlat22, 0.0, 1.0);
    u_xlat22 = (-u_xlat22) + 1.0;
    u_xlat3.x = u_xlat12 * u_xlat22;
    u_xlat3.x = clamp(u_xlat3.x, 0.0, 1.0);
    u_xlat32 = u_xlat32 + u_xlat3.x;
    u_xlat30 = (-u_xlat12) * u_xlat34 + u_xlat30;
    u_xlat30 = u_xlat2.x * _OcclusionAddScale + u_xlat30;
    u_xlat30 = u_xlat30 * 0.5 + 0.5;
    u_xlat2.x = (-u_xlat12) * u_xlat22;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat30 = u_xlat30 + u_xlat2.x;
    u_xlat30 = u_xlat30 + (-u_charaUnderLightColor.w);
    u_xlat30 = u_xlat30 * _UnderLightToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = vec3(u_xlat30) * u_charaUnderLightColor.xyz;
    u_xlat30 = u_xlat32 + (-u_charaHighLightColor.w);
    u_xlat30 = u_xlat30 * _CharaToonFadeRange;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat2.xyz = u_charaHighLightColor.xyz * vec3(u_xlat30) + u_xlat2.xyz;
    u_xlat3.xyz = u_xlat0.xyz + u_xlat2.xyz;
    u_xlat0.xyz = (-u_xlat0.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat2.xyz = (-u_xlat2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat0.xyz) * u_xlat2.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat0.xyz = (-u_xlat3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(_ScreenLightRate) * u_xlat0.xyz + u_xlat3.xyz;
    u_xlat2.xyz = vs_TEXCOORD10.yyy * _AuraMiddleColor.xyz;
    u_xlat2.xyz = vs_TEXCOORD10.xxx * _AuraCenterColor.xyz + u_xlat2.xyz;
    u_xlat2.xyz = vs_TEXCOORD10.zzz * _AuraEdgeColor.xyz + u_xlat2.xyz;
    u_xlat16_3.xyz = texture(_AuraTex, _AuraUv.wx, _GlobalMipBias.x).xyz;
    u_xlat16_4.xyz = texture(_AuraTex, _AuraUv.wy, _GlobalMipBias.x).xyz;
    u_xlat4.xyz = u_xlat16_4.xyz * vs_TEXCOORD10.yyy;
    u_xlat3.xyz = vs_TEXCOORD10.xxx * u_xlat16_3.xyz + u_xlat4.xyz;
    u_xlat16_4.xyz = texture(_AuraTex, _AuraUv.wz, _GlobalMipBias.x).xyz;
    u_xlat3.xyz = vs_TEXCOORD10.zzz * u_xlat16_4.xyz + u_xlat3.xyz;
    u_xlat3.xyz = (-u_xlat2.xyz) + u_xlat3.xyz;
    u_xlat2.xyz = vec3(vec3(_AuraTexBlend, _AuraTexBlend, _AuraTexBlend)) * u_xlat3.xyz + u_xlat2.xyz;
    u_xlat3.xyz = u_xlat0.xyz * u_xlat2.xyz;
    u_xlat4.xyz = u_xlat3.xyz + u_xlat3.xyz;
    u_xlat5.xyz = u_xlat0.xyz + vec3(-0.5, -0.5, -0.5);
    u_xlat5.xyz = (-u_xlat5.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat6.xyz = (-u_xlat2.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat5.xyz = (-u_xlat5.xyz) * u_xlat6.xyz + vec3(1.0, 1.0, 1.0);
    u_xlatb30 = 0.5>=u_xlat0.x;
    u_xlat30 = u_xlatb30 ? 1.0 : float(0.0);
    u_xlat3.xyz = (-u_xlat3.xyz) * vec3(2.0, 2.0, 2.0) + u_xlat5.xyz;
    u_xlat3.xyz = vec3(u_xlat30) * u_xlat3.xyz + u_xlat4.xyz;
    u_xlat3.xyz = (-u_xlat0.xyz) + u_xlat3.xyz;
    u_xlat0.xyz = vec3(_AuraHradlightBlend) * u_xlat3.xyz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat2.xyz * vec3(vec3(_AuraAddBlend, _AuraAddBlend, _AuraAddBlend)) + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat2.x = (-_Transparency) + 1.0;
    u_xlat0.w = u_xlat2.x * u_xlat3.w;
    u_xlat0.w = clamp(u_xlat0.w, 0.0, 1.0);
    u_xlat2.xy = vs_TEXCOORD4.xy / vs_TEXCOORD4.ww;
    u_xlat2.xy = u_xlat2.xy * _ScreenParams.xy + vec2(0.00100000005, 0.00100000005);
    u_xlatu2.xy = uvec2(u_xlat2.xy);
    u_xlati2 = int(bitfieldInsert(0, int(u_xlatu2.x), 2 & int(0x1F), 2));
    u_xlati2 = int(bitfieldInsert(u_xlati2, int(u_xlatu2.y), 0 & int(0x1F), 2));
    u_xlat2.x = u_xlat0.w + (-ImmCB_0[u_xlati2 + 4].x);
    u_xlatb2 = u_xlat2.x<0.0;
    if(u_xlatb2){discard;}
    SV_Target0 = u_xlat0;
    return;
}

#endif


// ===== program 12: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec4 in_COLOR0;
layout(location = 0) out highp vec4 vs_COLOR0;
vec4 u_xlat0;
vec4 u_xlat1;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_COLOR0 = in_COLOR0;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 0) out highp vec4 SV_Target0;
void main()
{
    SV_Target0 = vs_COLOR0;
    return;
}

#endif


// ===== program 13: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) in highp  vec4 vs_COLOR0;
layout(location = 0) out highp vec4 SV_Target0;
void main()
{
    SV_Target0 = vs_COLOR0;
    return;
}

#endif


// ===== program 14: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
in highp vec3 in_NORMAL0;
layout(location = 0) out highp vec3 vs_NORMAL0;
layout(location = 1) out highp vec3 vs_TEXCOORD0;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_NORMAL0.xyz = vec3(u_xlat6) * u_xlat1.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_MatrixV[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_MatrixV[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_MatrixV[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    vs_TEXCOORD0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_MatrixV[3].xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _ProjectionParams;
layout(location = 0) in highp  vec3 vs_NORMAL0;
layout(location = 1) in highp  vec3 vs_TEXCOORD0;
layout(location = 0) out highp vec4 SV_Target0;
vec3 u_xlat0;
float u_xlat1;
void main()
{
    u_xlat0.x = dot(vs_NORMAL0.xyz, vs_NORMAL0.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_NORMAL0.xyz;
    SV_Target0.xyz = u_xlat0.xyz * vec3(0.5, 0.5, 0.5) + vec3(0.5, 0.5, 0.5);
    u_xlat0.x = (-vs_TEXCOORD0.z) + (-_ProjectionParams.y);
    u_xlat1 = (-_ProjectionParams.y) + _ProjectionParams.z;
    SV_Target0.w = u_xlat0.x / u_xlat1;
    return;
}

#endif


// ===== program 15: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _ProjectionParams;
layout(location = 0) in highp  vec3 vs_NORMAL0;
layout(location = 1) in highp  vec3 vs_TEXCOORD0;
layout(location = 0) out highp vec4 SV_Target0;
vec3 u_xlat0;
float u_xlat1;
void main()
{
    u_xlat0.x = dot(vs_NORMAL0.xyz, vs_NORMAL0.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_NORMAL0.xyz;
    SV_Target0.xyz = u_xlat0.xyz * vec3(0.5, 0.5, 0.5) + vec3(0.5, 0.5, 0.5);
    u_xlat0.x = (-vs_TEXCOORD0.z) + (-_ProjectionParams.y);
    u_xlat1 = (-_ProjectionParams.y) + _ProjectionParams.z;
    SV_Target0.w = u_xlat0.x / u_xlat1;
    return;
}

#endif


// ===== program 16: VERTEX =====
#ifdef VERTEX
#version 310 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
UNITY_BINDING(0) uniform UnityPerDraw {
	vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	vec4 Xhlslcc_UnusedXunity_LODFade;
	mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	mediump vec4 Xhlslcc_UnusedXunity_LightData;
	mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	vec4 Xhlslcc_UnusedXunity_LightmapST;
	vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	mediump vec4 Xhlslcc_UnusedXunity_SHC;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	vec4 Xhlslcc_UnusedXunity_SpriteColor;
	vec4 Xhlslcc_UnusedXunity_SpriteProps;
};
in highp vec4 in_POSITION0;
layout(location = 0) out highp vec3 vs_TEXCOORD1;
vec3 u_xlat0;
vec4 u_xlat1;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_TEXCOORD1.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    return;
}

#endif
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) out highp vec4 SV_Target0;
void main()
{
    SV_Target0 = vec4(1.0, 1.0, 1.0, 1.0);
    return;
}

#endif


// ===== program 17: FRAGMENT =====
#ifdef FRAGMENT
#version 310 es

precision highp float;
precision highp int;
layout(location = 0) out highp vec4 SV_Target0;
void main()
{
    SV_Target0 = vec4(1.0, 1.0, 1.0, 1.0);
    return;
}

#endif

