// BackGround/BG_Lit_Tree (Shader path ID 7851288486261416314, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
highp vec4 vs_INTERP1;
highp vec4 vs_INTERP2;
out highp vec4 vs_INTERP3;
out highp vec3 vs_INTERP4;
out highp vec3 vs_INTERP5;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP4.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_TEXCOORD1;
    vs_INTERP2 = in_TEXCOORD2;
    vs_INTERP3 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    vs_INTERP5.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 unity_FogColor;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
in highp  vec3 vs_INTERP5;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec2 u_xlat16_0;
bvec3 u_xlatb0;
mediump vec3 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
vec3 u_xlat6;
vec3 u_xlat7;
bvec3 u_xlatb7;
vec3 u_xlat8;
float u_xlat9;
float u_xlat18;
float u_xlat27;
mediump float u_xlat16_28;
void main()
{
    u_xlat0.x = dot(vs_INTERP5.xyz, vs_INTERP5.xyz);
    u_xlat0.x = sqrt(u_xlat0.x);
    u_xlat0.x = float(1.0) / u_xlat0.x;
    u_xlat0 = u_xlat0.xxxx * vs_INTERP5.xyzz;
    u_xlat16_1.x = u_xlat0.y * u_xlat0.y;
    u_xlat16_1.x = u_xlat0.x * u_xlat0.x + (-u_xlat16_1.x);
    u_xlat16_2 = u_xlat0.yzwx * u_xlat0.xywz;
    u_xlat16_3.x = dot(unity_SHBr, u_xlat16_2);
    u_xlat16_3.y = dot(unity_SHBg, u_xlat16_2);
    u_xlat16_3.z = dot(unity_SHBb, u_xlat16_2);
    u_xlat16_1.xyz = unity_SHC.xyz * u_xlat16_1.xxx + u_xlat16_3.xyz;
    u_xlat0.w = 1.0;
    u_xlat16_2.x = dot(unity_SHAr, u_xlat0);
    u_xlat16_2.y = dot(unity_SHAg, u_xlat0);
    u_xlat16_2.z = dot(unity_SHAb, u_xlat0);
    u_xlat16_1.xyz = u_xlat16_1.xyz + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_2.xyz = u_xlat16_2.xyz + u_xlat16_2.xyz;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_2.xyz = (-u_xlat16_2.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlatb0.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_1.xyzx).xyz;
    u_xlat16_3.x = (u_xlatb0.x) ? float(0.0) : float(1.0);
    u_xlat16_3.y = (u_xlatb0.y) ? float(0.0) : float(1.0);
    u_xlat16_3.z = (u_xlatb0.z) ? float(0.0) : float(1.0);
    u_xlat16_4.x = (u_xlatb0.x) ? float(1.0) : float(0.0);
    u_xlat16_4.y = (u_xlatb0.y) ? float(1.0) : float(0.0);
    u_xlat16_4.z = (u_xlatb0.z) ? float(1.0) : float(0.0);
    u_xlat16_2.xyz = u_xlat16_2.xyz * u_xlat16_3.xyz;
    u_xlat16_3.xyz = u_xlat16_1.xyz * unity_FogColor.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz + u_xlat16_3.xyz;
    u_xlat16_2.xyz = u_xlat16_3.xyz * u_xlat16_4.xyz + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + u_xlat16_2.xyz;
    u_xlat16_1.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_2.xyz + u_xlat16_1.xyz;
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_28 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_28 = min(u_xlat16_28, 1.0);
    u_xlat16_28 = (-u_xlat16_28) + 1.0;
    u_xlat16_28 = sqrt(u_xlat16_28);
    u_xlat16_28 = max(u_xlat16_28, 1.00000002e-16);
    u_xlat27 = u_xlat16_28 + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat5.x = _NormalIntensity;
    u_xlat5.x = clamp(u_xlat5.x, 0.0, 1.0);
    u_xlat0.z = u_xlat5.x * u_xlat27 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_28 = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat9 = u_xlat0.x + (-u_xlat16_28);
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat18 = (-u_xlat16_28) + u_xlat16_3.z;
    u_xlat18 = float(1.0) / u_xlat18;
    u_xlat9 = u_xlat18 * u_xlat9;
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat18 = u_xlat9 * -2.0 + 3.0;
    u_xlat9 = u_xlat9 * u_xlat9;
    u_xlat9 = u_xlat9 * u_xlat18;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat18 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat18 = float(1.0) / u_xlat18;
    u_xlat0.x = u_xlat18 * u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat18 = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat18;
    u_xlat16_5.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_5.xyz + (-u_xlat16_3.xyz);
    u_xlat16_3.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat0.xzw = _LightColor.xyz * u_xlat0.xxx + u_xlat16_3.xyz;
    u_xlat0.xzw = u_xlat0.xzw + (-_ShdowColor.xyz);
    u_xlat0.xyz = vec3(u_xlat9) * u_xlat0.xzw + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyz;
    u_xlat5.xyz = u_xlat16_1.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat5.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat5.xyz = sqrt(u_xlat0.xyz);
    u_xlat6.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat7.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat7.xyz = u_xlat6.xyz * u_xlat7.xyz;
    u_xlat8.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat5.xyz = u_xlat5.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat7.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat7.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat6.xyz = u_xlat6.xyz * unity_FogColor.xyz + u_xlat7.xyz;
    u_xlatb7.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat8.x = (u_xlatb7.x) ? float(0.0) : float(1.0);
    u_xlat8.y = (u_xlatb7.y) ? float(0.0) : float(1.0);
    u_xlat8.z = (u_xlatb7.z) ? float(0.0) : float(1.0);
    u_xlat7.x = u_xlatb7.x ? float(1.0) : 0.0;
    u_xlat7.y = u_xlatb7.y ? float(1.0) : 0.0;
    u_xlat7.z = u_xlatb7.z ? float(1.0) : 0.0;
;
    u_xlat6.xyz = u_xlat6.xyz * u_xlat8.xyz;
    u_xlat5.xyz = u_xlat5.xyz * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat5.xyz = (-u_xlat0.xyz) + u_xlat5.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat5.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 unity_FogColor;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
in highp  vec3 vs_INTERP5;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec2 u_xlat16_0;
bvec3 u_xlatb0;
mediump vec3 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
vec3 u_xlat6;
vec3 u_xlat7;
bvec3 u_xlatb7;
vec3 u_xlat8;
float u_xlat9;
float u_xlat18;
float u_xlat27;
mediump float u_xlat16_28;
void main()
{
    u_xlat0.x = dot(vs_INTERP5.xyz, vs_INTERP5.xyz);
    u_xlat0.x = sqrt(u_xlat0.x);
    u_xlat0.x = float(1.0) / u_xlat0.x;
    u_xlat0 = u_xlat0.xxxx * vs_INTERP5.xyzz;
    u_xlat16_1.x = u_xlat0.y * u_xlat0.y;
    u_xlat16_1.x = u_xlat0.x * u_xlat0.x + (-u_xlat16_1.x);
    u_xlat16_2 = u_xlat0.yzwx * u_xlat0.xywz;
    u_xlat16_3.x = dot(unity_SHBr, u_xlat16_2);
    u_xlat16_3.y = dot(unity_SHBg, u_xlat16_2);
    u_xlat16_3.z = dot(unity_SHBb, u_xlat16_2);
    u_xlat16_1.xyz = unity_SHC.xyz * u_xlat16_1.xxx + u_xlat16_3.xyz;
    u_xlat0.w = 1.0;
    u_xlat16_2.x = dot(unity_SHAr, u_xlat0);
    u_xlat16_2.y = dot(unity_SHAg, u_xlat0);
    u_xlat16_2.z = dot(unity_SHAb, u_xlat0);
    u_xlat16_1.xyz = u_xlat16_1.xyz + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_2.xyz = u_xlat16_2.xyz + u_xlat16_2.xyz;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_2.xyz = (-u_xlat16_2.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlatb0.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_1.xyzx).xyz;
    u_xlat16_3.x = (u_xlatb0.x) ? float(0.0) : float(1.0);
    u_xlat16_3.y = (u_xlatb0.y) ? float(0.0) : float(1.0);
    u_xlat16_3.z = (u_xlatb0.z) ? float(0.0) : float(1.0);
    u_xlat16_4.x = (u_xlatb0.x) ? float(1.0) : float(0.0);
    u_xlat16_4.y = (u_xlatb0.y) ? float(1.0) : float(0.0);
    u_xlat16_4.z = (u_xlatb0.z) ? float(1.0) : float(0.0);
    u_xlat16_2.xyz = u_xlat16_2.xyz * u_xlat16_3.xyz;
    u_xlat16_3.xyz = u_xlat16_1.xyz * unity_FogColor.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz + u_xlat16_3.xyz;
    u_xlat16_2.xyz = u_xlat16_3.xyz * u_xlat16_4.xyz + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + u_xlat16_2.xyz;
    u_xlat16_1.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_2.xyz + u_xlat16_1.xyz;
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_28 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_28 = min(u_xlat16_28, 1.0);
    u_xlat16_28 = (-u_xlat16_28) + 1.0;
    u_xlat16_28 = sqrt(u_xlat16_28);
    u_xlat16_28 = max(u_xlat16_28, 1.00000002e-16);
    u_xlat27 = u_xlat16_28 + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat5.x = _NormalIntensity;
    u_xlat5.x = clamp(u_xlat5.x, 0.0, 1.0);
    u_xlat0.z = u_xlat5.x * u_xlat27 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_28 = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat9 = u_xlat0.x + (-u_xlat16_28);
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat18 = (-u_xlat16_28) + u_xlat16_3.z;
    u_xlat18 = float(1.0) / u_xlat18;
    u_xlat9 = u_xlat18 * u_xlat9;
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat18 = u_xlat9 * -2.0 + 3.0;
    u_xlat9 = u_xlat9 * u_xlat9;
    u_xlat9 = u_xlat9 * u_xlat18;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat18 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat18 = float(1.0) / u_xlat18;
    u_xlat0.x = u_xlat18 * u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat18 = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat18;
    u_xlat16_5.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_5.xyz + (-u_xlat16_3.xyz);
    u_xlat16_3.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat0.xzw = _LightColor.xyz * u_xlat0.xxx + u_xlat16_3.xyz;
    u_xlat0.xzw = u_xlat0.xzw + (-_ShdowColor.xyz);
    u_xlat0.xyz = vec3(u_xlat9) * u_xlat0.xzw + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyz;
    u_xlat5.xyz = u_xlat16_1.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat5.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat5.xyz = sqrt(u_xlat0.xyz);
    u_xlat6.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat7.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat7.xyz = u_xlat6.xyz * u_xlat7.xyz;
    u_xlat8.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat5.xyz = u_xlat5.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat7.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat7.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat6.xyz = u_xlat6.xyz * unity_FogColor.xyz + u_xlat7.xyz;
    u_xlatb7.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat8.x = (u_xlatb7.x) ? float(0.0) : float(1.0);
    u_xlat8.y = (u_xlatb7.y) ? float(0.0) : float(1.0);
    u_xlat8.z = (u_xlatb7.z) ? float(0.0) : float(1.0);
    u_xlat7.x = u_xlatb7.x ? float(1.0) : 0.0;
    u_xlat7.y = u_xlatb7.y ? float(1.0) : 0.0;
    u_xlat7.z = u_xlatb7.z ? float(1.0) : 0.0;
;
    u_xlat6.xyz = u_xlat6.xyz * u_xlat8.xyz;
    u_xlat5.xyz = u_xlat5.xyz * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat5.xyz = (-u_xlat0.xyz) + u_xlat5.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat5.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 2: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
highp vec4 vs_INTERP1;
highp vec4 vs_INTERP2;
out highp vec4 vs_INTERP3;
out highp vec3 vs_INTERP4;
out highp vec3 vs_INTERP5;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP4.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_TEXCOORD1;
    vs_INTERP2 = in_TEXCOORD2;
    vs_INTERP3 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    vs_INTERP5.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 unity_FogColor;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
in highp  vec3 vs_INTERP5;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
bool u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec4 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
vec3 u_xlat7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
vec3 u_xlat10;
mediump float u_xlat16_12;
float u_xlat20;
mediump float u_xlat16_22;
float u_xlat30;
float u_xlat31;
void main()
{
    u_xlat16_0.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_1 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_2.x = u_xlat16_0.x + (-u_xlat16_1.w);
    u_xlat16_2.x = _BaseA0_AlphaR1 * u_xlat16_2.x + u_xlat16_1.w;
    u_xlat16_2.x = dot(u_xlat16_2.xx, vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_12 = dFdx(u_xlat16_2.x);
    u_xlat16_22 = dFdy(u_xlat16_2.x);
    u_xlat16_2.x = u_xlat16_2.x + -0.5;
    u_xlat16_12 = abs(u_xlat16_22) + abs(u_xlat16_12);
    u_xlat16_22 = (-u_xlat16_12) * 0.5 + u_xlat16_2.x;
    u_xlat16_12 = max(u_xlat16_12, 9.99999975e-05);
    u_xlat16_12 = u_xlat16_22 / u_xlat16_12;
    u_xlat16_12 = u_xlat16_12 + 1.0;
    u_xlat16_12 = clamp(u_xlat16_12, 0.0, 1.0);
    u_xlat16_22 = u_xlat16_12 + -9.99999975e-05;
    u_xlatb0 = _AlphaToMaskAvailable!=0.0;
    u_xlat16_2.x = (u_xlatb0) ? u_xlat16_22 : u_xlat16_2.x;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_12 : 1.0;
    u_xlatb0 = u_xlat16_2.x<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_22 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_2.x = min(u_xlat16_22, 1.0);
    u_xlat16_2.x = (-u_xlat16_2.x) + 1.0;
    u_xlat16_2.x = sqrt(u_xlat16_2.x);
    u_xlat16_2.x = max(u_xlat16_2.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_2.x + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat31 = _NormalIntensity;
    u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
    u_xlat0.z = u_xlat31 * u_xlat30 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat10.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10.x = u_xlat20 * u_xlat10.x;
    u_xlat10.x = clamp(u_xlat10.x, 0.0, 1.0);
    u_xlat20 = u_xlat10.x * -2.0 + 3.0;
    u_xlat10.x = u_xlat10.x * u_xlat10.x;
    u_xlat10.x = u_xlat10.x * u_xlat20;
    u_xlat16_3.xyw = u_xlat16_1.xyz * _Color.xyz;
    u_xlat16_3.xyw = u_xlat16_3.xyw * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_1.xyz + (-u_xlat16_3.xyw);
    u_xlat16_3.xyw = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyw;
    u_xlat10.xyz = _LightColor.xyz * u_xlat10.xxx + u_xlat16_3.xyw;
    u_xlat10.xyz = u_xlat10.xyz + (-_ShdowColor.xyz);
    u_xlat16_4.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_4.x);
    u_xlat1.x = u_xlat16_3.z + (-u_xlat16_4.x);
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat1.x = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.xyz = u_xlat0.xxx * u_xlat10.xyz + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyw) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyw;
    u_xlat30 = dot(vs_INTERP5.xyz, vs_INTERP5.xyz);
    u_xlat30 = sqrt(u_xlat30);
    u_xlat30 = float(1.0) / u_xlat30;
    u_xlat1 = vec4(u_xlat30) * vs_INTERP5.xyzz;
    u_xlat16_3.x = u_xlat1.y * u_xlat1.y;
    u_xlat16_3.x = u_xlat1.x * u_xlat1.x + (-u_xlat16_3.x);
    u_xlat16_2 = u_xlat1.yzwx * u_xlat1.xywz;
    u_xlat16_4.x = dot(unity_SHBr, u_xlat16_2);
    u_xlat16_4.y = dot(unity_SHBg, u_xlat16_2);
    u_xlat16_4.z = dot(unity_SHBb, u_xlat16_2);
    u_xlat16_3.xyz = unity_SHC.xyz * u_xlat16_3.xxx + u_xlat16_4.xyz;
    u_xlat1.w = 1.0;
    u_xlat16_4.x = dot(unity_SHAr, u_xlat1);
    u_xlat16_4.y = dot(unity_SHAg, u_xlat1);
    u_xlat16_4.z = dot(unity_SHAb, u_xlat1);
    u_xlat16_3.xyz = u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_5.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = (-u_xlat16_4.xyz) * u_xlat16_5.xyz + vec3(1.0, 1.0, 1.0);
    u_xlatb1.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_3.xyzx).xyz;
    u_xlat16_5.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_5.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_5.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_6.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_6.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_6.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz * u_xlat16_5.xyz;
    u_xlat16_5.xyz = u_xlat16_3.xyz * unity_FogColor.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz + u_xlat16_5.xyz;
    u_xlat16_4.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + u_xlat16_4.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat1.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat1.xyz = sqrt(u_xlat0.xyz);
    u_xlat7.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat1.xyz = u_xlat1.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat7.xyz = u_xlat7.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat7.xyz = u_xlat7.xyz * u_xlat9.xyz;
    u_xlat1.xyz = u_xlat1.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + u_xlat1.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat1.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    return;
}

#endif
{

// ===== program 3: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 unity_FogColor;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
in highp  vec3 vs_INTERP5;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
bool u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec4 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
vec3 u_xlat7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
vec3 u_xlat10;
mediump float u_xlat16_12;
float u_xlat20;
mediump float u_xlat16_22;
float u_xlat30;
float u_xlat31;
void main()
{
    u_xlat16_0.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_1 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_2.x = u_xlat16_0.x + (-u_xlat16_1.w);
    u_xlat16_2.x = _BaseA0_AlphaR1 * u_xlat16_2.x + u_xlat16_1.w;
    u_xlat16_2.x = dot(u_xlat16_2.xx, vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_12 = dFdx(u_xlat16_2.x);
    u_xlat16_22 = dFdy(u_xlat16_2.x);
    u_xlat16_2.x = u_xlat16_2.x + -0.5;
    u_xlat16_12 = abs(u_xlat16_22) + abs(u_xlat16_12);
    u_xlat16_22 = (-u_xlat16_12) * 0.5 + u_xlat16_2.x;
    u_xlat16_12 = max(u_xlat16_12, 9.99999975e-05);
    u_xlat16_12 = u_xlat16_22 / u_xlat16_12;
    u_xlat16_12 = u_xlat16_12 + 1.0;
    u_xlat16_12 = clamp(u_xlat16_12, 0.0, 1.0);
    u_xlat16_22 = u_xlat16_12 + -9.99999975e-05;
    u_xlatb0 = _AlphaToMaskAvailable!=0.0;
    u_xlat16_2.x = (u_xlatb0) ? u_xlat16_22 : u_xlat16_2.x;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_12 : 1.0;
    u_xlatb0 = u_xlat16_2.x<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_22 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_2.x = min(u_xlat16_22, 1.0);
    u_xlat16_2.x = (-u_xlat16_2.x) + 1.0;
    u_xlat16_2.x = sqrt(u_xlat16_2.x);
    u_xlat16_2.x = max(u_xlat16_2.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_2.x + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat31 = _NormalIntensity;
    u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
    u_xlat0.z = u_xlat31 * u_xlat30 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat10.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10.x = u_xlat20 * u_xlat10.x;
    u_xlat10.x = clamp(u_xlat10.x, 0.0, 1.0);
    u_xlat20 = u_xlat10.x * -2.0 + 3.0;
    u_xlat10.x = u_xlat10.x * u_xlat10.x;
    u_xlat10.x = u_xlat10.x * u_xlat20;
    u_xlat16_3.xyw = u_xlat16_1.xyz * _Color.xyz;
    u_xlat16_3.xyw = u_xlat16_3.xyw * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_1.xyz + (-u_xlat16_3.xyw);
    u_xlat16_3.xyw = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyw;
    u_xlat10.xyz = _LightColor.xyz * u_xlat10.xxx + u_xlat16_3.xyw;
    u_xlat10.xyz = u_xlat10.xyz + (-_ShdowColor.xyz);
    u_xlat16_4.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_4.x);
    u_xlat1.x = u_xlat16_3.z + (-u_xlat16_4.x);
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat1.x = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.xyz = u_xlat0.xxx * u_xlat10.xyz + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyw) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyw;
    u_xlat30 = dot(vs_INTERP5.xyz, vs_INTERP5.xyz);
    u_xlat30 = sqrt(u_xlat30);
    u_xlat30 = float(1.0) / u_xlat30;
    u_xlat1 = vec4(u_xlat30) * vs_INTERP5.xyzz;
    u_xlat16_3.x = u_xlat1.y * u_xlat1.y;
    u_xlat16_3.x = u_xlat1.x * u_xlat1.x + (-u_xlat16_3.x);
    u_xlat16_2 = u_xlat1.yzwx * u_xlat1.xywz;
    u_xlat16_4.x = dot(unity_SHBr, u_xlat16_2);
    u_xlat16_4.y = dot(unity_SHBg, u_xlat16_2);
    u_xlat16_4.z = dot(unity_SHBb, u_xlat16_2);
    u_xlat16_3.xyz = unity_SHC.xyz * u_xlat16_3.xxx + u_xlat16_4.xyz;
    u_xlat1.w = 1.0;
    u_xlat16_4.x = dot(unity_SHAr, u_xlat1);
    u_xlat16_4.y = dot(unity_SHAg, u_xlat1);
    u_xlat16_4.z = dot(unity_SHAb, u_xlat1);
    u_xlat16_3.xyz = u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_5.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = (-u_xlat16_4.xyz) * u_xlat16_5.xyz + vec3(1.0, 1.0, 1.0);
    u_xlatb1.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_3.xyzx).xyz;
    u_xlat16_5.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_5.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_5.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_6.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_6.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_6.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz * u_xlat16_5.xyz;
    u_xlat16_5.xyz = u_xlat16_3.xyz * unity_FogColor.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz + u_xlat16_5.xyz;
    u_xlat16_4.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + u_xlat16_4.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat1.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat1.xyz = sqrt(u_xlat0.xyz);
    u_xlat7.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat1.xyz = u_xlat1.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat7.xyz = u_xlat7.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat7.xyz = u_xlat7.xyz * u_xlat9.xyz;
    u_xlat1.xyz = u_xlat1.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + u_xlat1.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat1.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    return;
}

#endif
{

// ===== program 4: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
highp vec4 vs_INTERP1;
highp vec4 vs_INTERP2;
out highp vec4 vs_INTERP3;
out highp vec3 vs_INTERP4;
out highp vec3 vs_INTERP5;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP4.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_TEXCOORD1;
    vs_INTERP2 = in_TEXCOORD2;
    vs_INTERP3 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    vs_INTERP5.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
in highp  vec3 vs_INTERP5;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec2 u_xlat16_0;
bvec3 u_xlatb0;
mediump vec3 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
vec4 u_xlat6;
vec3 u_xlat7;
bvec3 u_xlatb7;
vec3 u_xlat8;
float u_xlat9;
float u_xlat18;
float u_xlat27;
mediump float u_xlat16_28;
void main()
{
    u_xlat0.x = dot(vs_INTERP5.xyz, vs_INTERP5.xyz);
    u_xlat0.x = sqrt(u_xlat0.x);
    u_xlat0.x = float(1.0) / u_xlat0.x;
    u_xlat0 = u_xlat0.xxxx * vs_INTERP5.xyzz;
    u_xlat16_1.x = u_xlat0.y * u_xlat0.y;
    u_xlat16_1.x = u_xlat0.x * u_xlat0.x + (-u_xlat16_1.x);
    u_xlat16_2 = u_xlat0.yzwx * u_xlat0.xywz;
    u_xlat16_3.x = dot(unity_SHBr, u_xlat16_2);
    u_xlat16_3.y = dot(unity_SHBg, u_xlat16_2);
    u_xlat16_3.z = dot(unity_SHBb, u_xlat16_2);
    u_xlat16_1.xyz = unity_SHC.xyz * u_xlat16_1.xxx + u_xlat16_3.xyz;
    u_xlat0.w = 1.0;
    u_xlat16_2.x = dot(unity_SHAr, u_xlat0);
    u_xlat16_2.y = dot(unity_SHAg, u_xlat0);
    u_xlat16_2.z = dot(unity_SHAb, u_xlat0);
    u_xlat16_1.xyz = u_xlat16_1.xyz + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_2.xyz = u_xlat16_2.xyz + u_xlat16_2.xyz;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_2.xyz = (-u_xlat16_2.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlatb0.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_1.xyzx).xyz;
    u_xlat16_3.x = (u_xlatb0.x) ? float(0.0) : float(1.0);
    u_xlat16_3.y = (u_xlatb0.y) ? float(0.0) : float(1.0);
    u_xlat16_3.z = (u_xlatb0.z) ? float(0.0) : float(1.0);
    u_xlat16_4.x = (u_xlatb0.x) ? float(1.0) : float(0.0);
    u_xlat16_4.y = (u_xlatb0.y) ? float(1.0) : float(0.0);
    u_xlat16_4.z = (u_xlatb0.z) ? float(1.0) : float(0.0);
    u_xlat16_2.xyz = u_xlat16_2.xyz * u_xlat16_3.xyz;
    u_xlat16_3.xyz = u_xlat16_1.xyz * unity_FogColor.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz + u_xlat16_3.xyz;
    u_xlat16_2.xyz = u_xlat16_3.xyz * u_xlat16_4.xyz + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + u_xlat16_2.xyz;
    u_xlat16_1.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_2.xyz + u_xlat16_1.xyz;
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_28 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_28 = min(u_xlat16_28, 1.0);
    u_xlat16_28 = (-u_xlat16_28) + 1.0;
    u_xlat16_28 = sqrt(u_xlat16_28);
    u_xlat16_28 = max(u_xlat16_28, 1.00000002e-16);
    u_xlat27 = u_xlat16_28 + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat5.x = _NormalIntensity;
    u_xlat5.x = clamp(u_xlat5.x, 0.0, 1.0);
    u_xlat0.z = u_xlat5.x * u_xlat27 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_28 = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat9 = u_xlat0.x + (-u_xlat16_28);
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat18 = (-u_xlat16_28) + u_xlat16_3.z;
    u_xlat18 = float(1.0) / u_xlat18;
    u_xlat9 = u_xlat18 * u_xlat9;
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat18 = u_xlat9 * -2.0 + 3.0;
    u_xlat9 = u_xlat9 * u_xlat9;
    u_xlat9 = u_xlat9 * u_xlat18;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat18 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat18 = float(1.0) / u_xlat18;
    u_xlat0.x = u_xlat18 * u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat18 = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat18;
    u_xlat16_5.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_5.xyz + (-u_xlat16_3.xyz);
    u_xlat16_3.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat0.xzw = _LightColor.xyz * u_xlat0.xxx + u_xlat16_3.xyz;
    u_xlat0.xzw = u_xlat0.xzw + (-_ShdowColor.xyz);
    u_xlat0.xyz = vec3(u_xlat9) * u_xlat0.xzw + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyz;
    u_xlat5.xyz = u_xlat16_1.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat5.xyz + u_xlat0.xyz;
    u_xlat5.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat6.xyz = vs_INTERP4.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat6.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP4.xxx + u_xlat6.xyz;
    u_xlat6.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP4.zzz + u_xlat6.xyz;
    u_xlat6.xyz = u_xlat6.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat7.xyz = u_xlat6.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat6.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat6.xxx + u_xlat7.xyz;
    u_xlat6.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat6.zzz + u_xlat6.xyw;
    u_xlat6.xyz = u_xlat6.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat27 = u_xlat6.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat27 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat6.x + u_xlat27;
    u_xlat27 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat6.z + u_xlat27;
    u_xlat27 = u_xlat27 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat27 = (-u_xlat27) + (-_ProjectionParams.y);
    u_xlat27 = max(u_xlat27, 0.0);
    u_xlat27 = u_xlat27 * unity_FogParams.z + unity_FogParams.w;
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = (-u_xlat27) + 1.0;
    u_xlat0.xyz = vec3(u_xlat27) * u_xlat5.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat5.xyz = sqrt(u_xlat0.xyz);
    u_xlat6.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat7.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat7.xyz = u_xlat6.xyz * u_xlat7.xyz;
    u_xlat8.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat5.xyz = u_xlat5.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat7.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat7.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat6.xyz = u_xlat6.xyz * unity_FogColor.xyz + u_xlat7.xyz;
    u_xlatb7.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat8.x = (u_xlatb7.x) ? float(0.0) : float(1.0);
    u_xlat8.y = (u_xlatb7.y) ? float(0.0) : float(1.0);
    u_xlat8.z = (u_xlatb7.z) ? float(0.0) : float(1.0);
    u_xlat7.x = u_xlatb7.x ? float(1.0) : 0.0;
    u_xlat7.y = u_xlatb7.y ? float(1.0) : 0.0;
    u_xlat7.z = u_xlatb7.z ? float(1.0) : 0.0;
;
    u_xlat6.xyz = u_xlat6.xyz * u_xlat8.xyz;
    u_xlat5.xyz = u_xlat5.xyz * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat5.xyz = (-u_xlat0.xyz) + u_xlat5.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat5.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 5: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(1) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
in highp  vec3 vs_INTERP5;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec2 u_xlat16_0;
bvec3 u_xlatb0;
mediump vec3 u_xlat16_1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
vec3 u_xlat5;
mediump vec3 u_xlat16_5;
vec4 u_xlat6;
vec3 u_xlat7;
bvec3 u_xlatb7;
vec3 u_xlat8;
float u_xlat9;
float u_xlat18;
float u_xlat27;
mediump float u_xlat16_28;
void main()
{
    u_xlat0.x = dot(vs_INTERP5.xyz, vs_INTERP5.xyz);
    u_xlat0.x = sqrt(u_xlat0.x);
    u_xlat0.x = float(1.0) / u_xlat0.x;
    u_xlat0 = u_xlat0.xxxx * vs_INTERP5.xyzz;
    u_xlat16_1.x = u_xlat0.y * u_xlat0.y;
    u_xlat16_1.x = u_xlat0.x * u_xlat0.x + (-u_xlat16_1.x);
    u_xlat16_2 = u_xlat0.yzwx * u_xlat0.xywz;
    u_xlat16_3.x = dot(unity_SHBr, u_xlat16_2);
    u_xlat16_3.y = dot(unity_SHBg, u_xlat16_2);
    u_xlat16_3.z = dot(unity_SHBb, u_xlat16_2);
    u_xlat16_1.xyz = unity_SHC.xyz * u_xlat16_1.xxx + u_xlat16_3.xyz;
    u_xlat0.w = 1.0;
    u_xlat16_2.x = dot(unity_SHAr, u_xlat0);
    u_xlat16_2.y = dot(unity_SHAg, u_xlat0);
    u_xlat16_2.z = dot(unity_SHAb, u_xlat0);
    u_xlat16_1.xyz = u_xlat16_1.xyz + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_2.xyz = u_xlat16_2.xyz + u_xlat16_2.xyz;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_2.xyz = (-u_xlat16_2.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlatb0.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_1.xyzx).xyz;
    u_xlat16_3.x = (u_xlatb0.x) ? float(0.0) : float(1.0);
    u_xlat16_3.y = (u_xlatb0.y) ? float(0.0) : float(1.0);
    u_xlat16_3.z = (u_xlatb0.z) ? float(0.0) : float(1.0);
    u_xlat16_4.x = (u_xlatb0.x) ? float(1.0) : float(0.0);
    u_xlat16_4.y = (u_xlatb0.y) ? float(1.0) : float(0.0);
    u_xlat16_4.z = (u_xlatb0.z) ? float(1.0) : float(0.0);
    u_xlat16_2.xyz = u_xlat16_2.xyz * u_xlat16_3.xyz;
    u_xlat16_3.xyz = u_xlat16_1.xyz * unity_FogColor.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz + u_xlat16_3.xyz;
    u_xlat16_2.xyz = u_xlat16_3.xyz * u_xlat16_4.xyz + u_xlat16_2.xyz;
    u_xlat16_2.xyz = (-u_xlat16_1.xyz) + u_xlat16_2.xyz;
    u_xlat16_1.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_2.xyz + u_xlat16_1.xyz;
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_28 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_28 = min(u_xlat16_28, 1.0);
    u_xlat16_28 = (-u_xlat16_28) + 1.0;
    u_xlat16_28 = sqrt(u_xlat16_28);
    u_xlat16_28 = max(u_xlat16_28, 1.00000002e-16);
    u_xlat27 = u_xlat16_28 + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat5.x = _NormalIntensity;
    u_xlat5.x = clamp(u_xlat5.x, 0.0, 1.0);
    u_xlat0.z = u_xlat5.x * u_xlat27 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat27 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat27 = inversesqrt(u_xlat27);
    u_xlat0.xyz = vec3(u_xlat27) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_28 = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat9 = u_xlat0.x + (-u_xlat16_28);
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat18 = (-u_xlat16_28) + u_xlat16_3.z;
    u_xlat18 = float(1.0) / u_xlat18;
    u_xlat9 = u_xlat18 * u_xlat9;
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat18 = u_xlat9 * -2.0 + 3.0;
    u_xlat9 = u_xlat9 * u_xlat9;
    u_xlat9 = u_xlat9 * u_xlat18;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat18 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat18 = float(1.0) / u_xlat18;
    u_xlat0.x = u_xlat18 * u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat18 = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat18;
    u_xlat16_5.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = u_xlat16_5.xyz * _Color.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_5.xyz + (-u_xlat16_3.xyz);
    u_xlat16_3.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat0.xzw = _LightColor.xyz * u_xlat0.xxx + u_xlat16_3.xyz;
    u_xlat0.xzw = u_xlat0.xzw + (-_ShdowColor.xyz);
    u_xlat0.xyz = vec3(u_xlat9) * u_xlat0.xzw + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyz;
    u_xlat5.xyz = u_xlat16_1.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat5.xyz + u_xlat0.xyz;
    u_xlat5.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat6.xyz = vs_INTERP4.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat6.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP4.xxx + u_xlat6.xyz;
    u_xlat6.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP4.zzz + u_xlat6.xyz;
    u_xlat6.xyz = u_xlat6.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat7.xyz = u_xlat6.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat6.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat6.xxx + u_xlat7.xyz;
    u_xlat6.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat6.zzz + u_xlat6.xyw;
    u_xlat6.xyz = u_xlat6.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat27 = u_xlat6.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat27 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat6.x + u_xlat27;
    u_xlat27 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat6.z + u_xlat27;
    u_xlat27 = u_xlat27 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat27 = (-u_xlat27) + (-_ProjectionParams.y);
    u_xlat27 = max(u_xlat27, 0.0);
    u_xlat27 = u_xlat27 * unity_FogParams.z + unity_FogParams.w;
    u_xlat27 = clamp(u_xlat27, 0.0, 1.0);
    u_xlat27 = (-u_xlat27) + 1.0;
    u_xlat0.xyz = vec3(u_xlat27) * u_xlat5.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat5.xyz = sqrt(u_xlat0.xyz);
    u_xlat6.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat7.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat7.xyz = u_xlat6.xyz * u_xlat7.xyz;
    u_xlat8.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat5.xyz = u_xlat5.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat7.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat7.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat6.xyz = u_xlat6.xyz * unity_FogColor.xyz + u_xlat7.xyz;
    u_xlatb7.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat8.x = (u_xlatb7.x) ? float(0.0) : float(1.0);
    u_xlat8.y = (u_xlatb7.y) ? float(0.0) : float(1.0);
    u_xlat8.z = (u_xlatb7.z) ? float(0.0) : float(1.0);
    u_xlat7.x = u_xlatb7.x ? float(1.0) : 0.0;
    u_xlat7.y = u_xlatb7.y ? float(1.0) : 0.0;
    u_xlat7.z = u_xlatb7.z ? float(1.0) : 0.0;
;
    u_xlat6.xyz = u_xlat6.xyz * u_xlat8.xyz;
    u_xlat5.xyz = u_xlat5.xyz * u_xlat7.xyz + u_xlat6.xyz;
    u_xlat5.xyz = (-u_xlat0.xyz) + u_xlat5.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat5.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 6: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
highp vec4 vs_INTERP1;
highp vec4 vs_INTERP2;
out highp vec4 vs_INTERP3;
out highp vec3 vs_INTERP4;
out highp vec3 vs_INTERP5;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP4.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_TEXCOORD1;
    vs_INTERP2 = in_TEXCOORD2;
    vs_INTERP3 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    vs_INTERP5.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
in highp  vec3 vs_INTERP5;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
bool u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec4 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
vec4 u_xlat7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
vec3 u_xlat10;
mediump float u_xlat16_12;
float u_xlat20;
mediump float u_xlat16_22;
float u_xlat30;
float u_xlat31;
void main()
{
    u_xlat16_0.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_1 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_2.x = u_xlat16_0.x + (-u_xlat16_1.w);
    u_xlat16_2.x = _BaseA0_AlphaR1 * u_xlat16_2.x + u_xlat16_1.w;
    u_xlat16_2.x = dot(u_xlat16_2.xx, vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_12 = dFdx(u_xlat16_2.x);
    u_xlat16_22 = dFdy(u_xlat16_2.x);
    u_xlat16_2.x = u_xlat16_2.x + -0.5;
    u_xlat16_12 = abs(u_xlat16_22) + abs(u_xlat16_12);
    u_xlat16_22 = (-u_xlat16_12) * 0.5 + u_xlat16_2.x;
    u_xlat16_12 = max(u_xlat16_12, 9.99999975e-05);
    u_xlat16_12 = u_xlat16_22 / u_xlat16_12;
    u_xlat16_12 = u_xlat16_12 + 1.0;
    u_xlat16_12 = clamp(u_xlat16_12, 0.0, 1.0);
    u_xlat16_22 = u_xlat16_12 + -9.99999975e-05;
    u_xlatb0 = _AlphaToMaskAvailable!=0.0;
    u_xlat16_2.x = (u_xlatb0) ? u_xlat16_22 : u_xlat16_2.x;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_12 : 1.0;
    u_xlatb0 = u_xlat16_2.x<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_22 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_2.x = min(u_xlat16_22, 1.0);
    u_xlat16_2.x = (-u_xlat16_2.x) + 1.0;
    u_xlat16_2.x = sqrt(u_xlat16_2.x);
    u_xlat16_2.x = max(u_xlat16_2.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_2.x + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat31 = _NormalIntensity;
    u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
    u_xlat0.z = u_xlat31 * u_xlat30 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat10.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10.x = u_xlat20 * u_xlat10.x;
    u_xlat10.x = clamp(u_xlat10.x, 0.0, 1.0);
    u_xlat20 = u_xlat10.x * -2.0 + 3.0;
    u_xlat10.x = u_xlat10.x * u_xlat10.x;
    u_xlat10.x = u_xlat10.x * u_xlat20;
    u_xlat16_3.xyw = u_xlat16_1.xyz * _Color.xyz;
    u_xlat16_3.xyw = u_xlat16_3.xyw * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_1.xyz + (-u_xlat16_3.xyw);
    u_xlat16_3.xyw = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyw;
    u_xlat10.xyz = _LightColor.xyz * u_xlat10.xxx + u_xlat16_3.xyw;
    u_xlat10.xyz = u_xlat10.xyz + (-_ShdowColor.xyz);
    u_xlat16_4.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_4.x);
    u_xlat1.x = u_xlat16_3.z + (-u_xlat16_4.x);
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat1.x = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.xyz = u_xlat0.xxx * u_xlat10.xyz + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyw) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyw;
    u_xlat30 = dot(vs_INTERP5.xyz, vs_INTERP5.xyz);
    u_xlat30 = sqrt(u_xlat30);
    u_xlat30 = float(1.0) / u_xlat30;
    u_xlat1 = vec4(u_xlat30) * vs_INTERP5.xyzz;
    u_xlat16_3.x = u_xlat1.y * u_xlat1.y;
    u_xlat16_3.x = u_xlat1.x * u_xlat1.x + (-u_xlat16_3.x);
    u_xlat16_2 = u_xlat1.yzwx * u_xlat1.xywz;
    u_xlat16_4.x = dot(unity_SHBr, u_xlat16_2);
    u_xlat16_4.y = dot(unity_SHBg, u_xlat16_2);
    u_xlat16_4.z = dot(unity_SHBb, u_xlat16_2);
    u_xlat16_3.xyz = unity_SHC.xyz * u_xlat16_3.xxx + u_xlat16_4.xyz;
    u_xlat1.w = 1.0;
    u_xlat16_4.x = dot(unity_SHAr, u_xlat1);
    u_xlat16_4.y = dot(unity_SHAg, u_xlat1);
    u_xlat16_4.z = dot(unity_SHAb, u_xlat1);
    u_xlat16_3.xyz = u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_5.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = (-u_xlat16_4.xyz) * u_xlat16_5.xyz + vec3(1.0, 1.0, 1.0);
    u_xlatb1.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_3.xyzx).xyz;
    u_xlat16_5.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_5.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_5.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_6.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_6.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_6.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz * u_xlat16_5.xyz;
    u_xlat16_5.xyz = u_xlat16_3.xyz * unity_FogColor.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz + u_xlat16_5.xyz;
    u_xlat16_4.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + u_xlat16_4.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat1.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat7.xyz = vs_INTERP4.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP4.xxx + u_xlat7.xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP4.zzz + u_xlat7.xyz;
    u_xlat7.xyz = u_xlat7.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat8.xyz = u_xlat7.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat7.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat7.xxx + u_xlat8.xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat7.zzz + u_xlat7.xyw;
    u_xlat7.xyz = u_xlat7.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat30 = u_xlat7.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat7.x + u_xlat30;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat7.z + u_xlat30;
    u_xlat30 = u_xlat30 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat30 = (-u_xlat30) + (-_ProjectionParams.y);
    u_xlat30 = max(u_xlat30, 0.0);
    u_xlat30 = u_xlat30 * unity_FogParams.z + unity_FogParams.w;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat30 = (-u_xlat30) + 1.0;
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat1.xyz = sqrt(u_xlat0.xyz);
    u_xlat7.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat1.xyz = u_xlat1.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat7.xyz = u_xlat7.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat7.xyz = u_xlat7.xyz * u_xlat9.xyz;
    u_xlat1.xyz = u_xlat1.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + u_xlat1.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat1.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    return;
}

#endif


// ===== program 7: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
in highp  vec3 vs_INTERP5;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
bool u_xlatb0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
bvec3 u_xlatb1;
vec4 u_xlat2;
mediump vec4 u_xlat16_2;
mediump vec4 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
vec4 u_xlat7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
vec3 u_xlat10;
mediump float u_xlat16_12;
float u_xlat20;
mediump float u_xlat16_22;
float u_xlat30;
float u_xlat31;
void main()
{
    u_xlat16_0.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_1 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_2.x = u_xlat16_0.x + (-u_xlat16_1.w);
    u_xlat16_2.x = _BaseA0_AlphaR1 * u_xlat16_2.x + u_xlat16_1.w;
    u_xlat16_2.x = dot(u_xlat16_2.xx, vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_12 = dFdx(u_xlat16_2.x);
    u_xlat16_22 = dFdy(u_xlat16_2.x);
    u_xlat16_2.x = u_xlat16_2.x + -0.5;
    u_xlat16_12 = abs(u_xlat16_22) + abs(u_xlat16_12);
    u_xlat16_22 = (-u_xlat16_12) * 0.5 + u_xlat16_2.x;
    u_xlat16_12 = max(u_xlat16_12, 9.99999975e-05);
    u_xlat16_12 = u_xlat16_22 / u_xlat16_12;
    u_xlat16_12 = u_xlat16_12 + 1.0;
    u_xlat16_12 = clamp(u_xlat16_12, 0.0, 1.0);
    u_xlat16_22 = u_xlat16_12 + -9.99999975e-05;
    u_xlatb0 = _AlphaToMaskAvailable!=0.0;
    u_xlat16_2.x = (u_xlatb0) ? u_xlat16_22 : u_xlat16_2.x;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_12 : 1.0;
    u_xlatb0 = u_xlat16_2.x<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_22 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_2.x = min(u_xlat16_22, 1.0);
    u_xlat16_2.x = (-u_xlat16_2.x) + 1.0;
    u_xlat16_2.x = sqrt(u_xlat16_2.x);
    u_xlat16_2.x = max(u_xlat16_2.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_2.x + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat31 = _NormalIntensity;
    u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
    u_xlat0.z = u_xlat31 * u_xlat30 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat10.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10.x = u_xlat20 * u_xlat10.x;
    u_xlat10.x = clamp(u_xlat10.x, 0.0, 1.0);
    u_xlat20 = u_xlat10.x * -2.0 + 3.0;
    u_xlat10.x = u_xlat10.x * u_xlat10.x;
    u_xlat10.x = u_xlat10.x * u_xlat20;
    u_xlat16_3.xyw = u_xlat16_1.xyz * _Color.xyz;
    u_xlat16_3.xyw = u_xlat16_3.xyw * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_1.xyz + (-u_xlat16_3.xyw);
    u_xlat16_3.xyw = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyw;
    u_xlat10.xyz = _LightColor.xyz * u_xlat10.xxx + u_xlat16_3.xyw;
    u_xlat10.xyz = u_xlat10.xyz + (-_ShdowColor.xyz);
    u_xlat16_4.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_4.x);
    u_xlat1.x = u_xlat16_3.z + (-u_xlat16_4.x);
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat1.x = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.xyz = u_xlat0.xxx * u_xlat10.xyz + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyw) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyw;
    u_xlat30 = dot(vs_INTERP5.xyz, vs_INTERP5.xyz);
    u_xlat30 = sqrt(u_xlat30);
    u_xlat30 = float(1.0) / u_xlat30;
    u_xlat1 = vec4(u_xlat30) * vs_INTERP5.xyzz;
    u_xlat16_3.x = u_xlat1.y * u_xlat1.y;
    u_xlat16_3.x = u_xlat1.x * u_xlat1.x + (-u_xlat16_3.x);
    u_xlat16_2 = u_xlat1.yzwx * u_xlat1.xywz;
    u_xlat16_4.x = dot(unity_SHBr, u_xlat16_2);
    u_xlat16_4.y = dot(unity_SHBg, u_xlat16_2);
    u_xlat16_4.z = dot(unity_SHBb, u_xlat16_2);
    u_xlat16_3.xyz = unity_SHC.xyz * u_xlat16_3.xxx + u_xlat16_4.xyz;
    u_xlat1.w = 1.0;
    u_xlat16_4.x = dot(unity_SHAr, u_xlat1);
    u_xlat16_4.y = dot(unity_SHAg, u_xlat1);
    u_xlat16_4.z = dot(unity_SHAb, u_xlat1);
    u_xlat16_3.xyz = u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_5.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = (-u_xlat16_4.xyz) * u_xlat16_5.xyz + vec3(1.0, 1.0, 1.0);
    u_xlatb1.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_3.xyzx).xyz;
    u_xlat16_5.x = (u_xlatb1.x) ? float(0.0) : float(1.0);
    u_xlat16_5.y = (u_xlatb1.y) ? float(0.0) : float(1.0);
    u_xlat16_5.z = (u_xlatb1.z) ? float(0.0) : float(1.0);
    u_xlat16_6.x = (u_xlatb1.x) ? float(1.0) : float(0.0);
    u_xlat16_6.y = (u_xlatb1.y) ? float(1.0) : float(0.0);
    u_xlat16_6.z = (u_xlatb1.z) ? float(1.0) : float(0.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz * u_xlat16_5.xyz;
    u_xlat16_5.xyz = u_xlat16_3.xyz * unity_FogColor.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz + u_xlat16_5.xyz;
    u_xlat16_4.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz + u_xlat16_4.xyz;
    u_xlat16_4.xyz = (-u_xlat16_3.xyz) + u_xlat16_4.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat1.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat7.xyz = vs_INTERP4.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP4.xxx + u_xlat7.xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP4.zzz + u_xlat7.xyz;
    u_xlat7.xyz = u_xlat7.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat8.xyz = u_xlat7.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat7.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat7.xxx + u_xlat8.xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat7.zzz + u_xlat7.xyw;
    u_xlat7.xyz = u_xlat7.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat30 = u_xlat7.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat7.x + u_xlat30;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat7.z + u_xlat30;
    u_xlat30 = u_xlat30 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat30 = (-u_xlat30) + (-_ProjectionParams.y);
    u_xlat30 = max(u_xlat30, 0.0);
    u_xlat30 = u_xlat30 * unity_FogParams.z + unity_FogParams.w;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat30 = (-u_xlat30) + 1.0;
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat1.xyz = sqrt(u_xlat0.xyz);
    u_xlat7.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat1.xyz = u_xlat1.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat7.xyz = u_xlat7.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat7.xyz = u_xlat7.xyz * u_xlat9.xyz;
    u_xlat1.xyz = u_xlat1.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + u_xlat1.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat1.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    return;
}

#endif


// ===== program 8: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
highp vec4 vs_INTERP2;
out highp vec4 vs_INTERP3;
out highp vec3 vs_INTERP4;
highp vec3 vs_INTERP5;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP4.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_TEXCOORD1;
    vs_INTERP2 = in_TEXCOORD2;
    vs_INTERP3 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    vs_INTERP5.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 unity_FogColor;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D unity_Lightmap;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec2 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
bvec3 u_xlatb2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
vec3 u_xlat7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
float u_xlat10;
mediump vec3 u_xlat16_13;
float u_xlat20;
mediump float u_xlat16_21;
float u_xlat30;
mediump float u_xlat16_33;
void main()
{
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_1.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_21 = dot(u_xlat16_1.xy, u_xlat16_1.xy);
    u_xlat0.xy = u_xlat16_1.xy * vec2(_NormalIntensity);
    u_xlat16_1.x = min(u_xlat16_21, 1.0);
    u_xlat16_1.x = (-u_xlat16_1.x) + 1.0;
    u_xlat16_1.x = sqrt(u_xlat16_1.x);
    u_xlat16_1.x = max(u_xlat16_1.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_1.x + -1.0;
    u_xlat16_1.xz = _PrefabCenterWS.xz;
    u_xlat16_1.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat1.xyz = u_xlat16_1.xyz + (-vs_INTERP4.xyz);
    u_xlat2.x = _NormalIntensity;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat0.z = u_xlat2.x * u_xlat30 + u_xlat1.z;
    u_xlat1.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat1.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat10 = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat16_13.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_13.z;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10 = u_xlat20 * u_xlat10;
    u_xlat10 = clamp(u_xlat10, 0.0, 1.0);
    u_xlat20 = u_xlat10 * -2.0 + 3.0;
    u_xlat10 = u_xlat10 * u_xlat10;
    u_xlat10 = u_xlat10 * u_xlat20;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_13.x);
    u_xlat20 = (-u_xlat16_13.x) + u_xlat16_13.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat0.x = u_xlat20 * u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat20 = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat20;
    u_xlat16_2.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = u_xlat16_2.xyz * _Color.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_2.xyz + (-u_xlat16_3.xyz);
    u_xlat16_3.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat0.xzw = _LightColor.xyz * u_xlat0.xxx + u_xlat16_3.xyz;
    u_xlat0.xzw = u_xlat0.xzw + (-_ShdowColor.xyz);
    u_xlat0.xyz = vec3(u_xlat10) * u_xlat0.xzw + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat2.xy = vs_INTERP1.xy * unity_LightmapST.xy + unity_LightmapST.zw;
    u_xlat16_1 = texture(unity_Lightmap, u_xlat2.xy, _GlobalMipBias.x);
    u_xlat16_33 = log2(abs(u_xlat16_1.w));
    u_xlat16_33 = u_xlat16_33 * 2.20000005;
    u_xlat16_33 = exp2(u_xlat16_33);
    u_xlat16_33 = u_xlat16_33 * 34.4932404;
    u_xlat16_4.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_3.xyz = (-u_xlat16_4.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_1.xyz * vec3(u_xlat16_33);
    u_xlatb2.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_4.xyzx).xyz;
    u_xlat16_5.x = (u_xlatb2.x) ? float(0.0) : float(1.0);
    u_xlat16_5.y = (u_xlatb2.y) ? float(0.0) : float(1.0);
    u_xlat16_5.z = (u_xlatb2.z) ? float(0.0) : float(1.0);
    u_xlat16_6.x = (u_xlatb2.x) ? float(1.0) : float(0.0);
    u_xlat16_6.y = (u_xlatb2.y) ? float(1.0) : float(0.0);
    u_xlat16_6.z = (u_xlatb2.z) ? float(1.0) : float(0.0);
    u_xlat16_3.xyz = u_xlat16_3.xyz * u_xlat16_5.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * unity_FogColor.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz + u_xlat16_5.xyz;
    u_xlat16_3.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + u_xlat16_3.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat2.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat2.xyz = sqrt(u_xlat0.xyz);
    u_xlat7.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat2.xyz = u_xlat2.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat7.xyz = u_xlat7.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat7.xyz = u_xlat7.xyz * u_xlat9.xyz;
    u_xlat2.xyz = u_xlat2.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat2.xyz = (-u_xlat0.xyz) + u_xlat2.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat2.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 9: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 unity_FogColor;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D unity_Lightmap;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec2 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
bvec3 u_xlatb2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
vec3 u_xlat7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
float u_xlat10;
mediump vec3 u_xlat16_13;
float u_xlat20;
mediump float u_xlat16_21;
float u_xlat30;
mediump float u_xlat16_33;
void main()
{
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_1.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_21 = dot(u_xlat16_1.xy, u_xlat16_1.xy);
    u_xlat0.xy = u_xlat16_1.xy * vec2(_NormalIntensity);
    u_xlat16_1.x = min(u_xlat16_21, 1.0);
    u_xlat16_1.x = (-u_xlat16_1.x) + 1.0;
    u_xlat16_1.x = sqrt(u_xlat16_1.x);
    u_xlat16_1.x = max(u_xlat16_1.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_1.x + -1.0;
    u_xlat16_1.xz = _PrefabCenterWS.xz;
    u_xlat16_1.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat1.xyz = u_xlat16_1.xyz + (-vs_INTERP4.xyz);
    u_xlat2.x = _NormalIntensity;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat0.z = u_xlat2.x * u_xlat30 + u_xlat1.z;
    u_xlat1.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat1.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat10 = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat16_13.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_13.z;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10 = u_xlat20 * u_xlat10;
    u_xlat10 = clamp(u_xlat10, 0.0, 1.0);
    u_xlat20 = u_xlat10 * -2.0 + 3.0;
    u_xlat10 = u_xlat10 * u_xlat10;
    u_xlat10 = u_xlat10 * u_xlat20;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_13.x);
    u_xlat20 = (-u_xlat16_13.x) + u_xlat16_13.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat0.x = u_xlat20 * u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat20 = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat20;
    u_xlat16_2.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = u_xlat16_2.xyz * _Color.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_2.xyz + (-u_xlat16_3.xyz);
    u_xlat16_3.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat0.xzw = _LightColor.xyz * u_xlat0.xxx + u_xlat16_3.xyz;
    u_xlat0.xzw = u_xlat0.xzw + (-_ShdowColor.xyz);
    u_xlat0.xyz = vec3(u_xlat10) * u_xlat0.xzw + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat2.xy = vs_INTERP1.xy * unity_LightmapST.xy + unity_LightmapST.zw;
    u_xlat16_1 = texture(unity_Lightmap, u_xlat2.xy, _GlobalMipBias.x);
    u_xlat16_33 = log2(abs(u_xlat16_1.w));
    u_xlat16_33 = u_xlat16_33 * 2.20000005;
    u_xlat16_33 = exp2(u_xlat16_33);
    u_xlat16_33 = u_xlat16_33 * 34.4932404;
    u_xlat16_4.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_3.xyz = (-u_xlat16_4.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_1.xyz * vec3(u_xlat16_33);
    u_xlatb2.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_4.xyzx).xyz;
    u_xlat16_5.x = (u_xlatb2.x) ? float(0.0) : float(1.0);
    u_xlat16_5.y = (u_xlatb2.y) ? float(0.0) : float(1.0);
    u_xlat16_5.z = (u_xlatb2.z) ? float(0.0) : float(1.0);
    u_xlat16_6.x = (u_xlatb2.x) ? float(1.0) : float(0.0);
    u_xlat16_6.y = (u_xlatb2.y) ? float(1.0) : float(0.0);
    u_xlat16_6.z = (u_xlatb2.z) ? float(1.0) : float(0.0);
    u_xlat16_3.xyz = u_xlat16_3.xyz * u_xlat16_5.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * unity_FogColor.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz + u_xlat16_5.xyz;
    u_xlat16_3.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + u_xlat16_3.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat2.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat2.xyz = sqrt(u_xlat0.xyz);
    u_xlat7.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat2.xyz = u_xlat2.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat7.xyz = u_xlat7.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat7.xyz = u_xlat7.xyz * u_xlat9.xyz;
    u_xlat2.xyz = u_xlat2.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat2.xyz = (-u_xlat0.xyz) + u_xlat2.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat2.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 10: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
highp vec4 vs_INTERP2;
out highp vec4 vs_INTERP3;
out highp vec3 vs_INTERP4;
highp vec3 vs_INTERP5;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP4.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_TEXCOORD1;
    vs_INTERP2 = in_TEXCOORD2;
    vs_INTERP3 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    vs_INTERP5.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 unity_FogColor;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D unity_Lightmap;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(3) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
bool u_xlatb0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec3 u_xlat16_2;
mediump vec4 u_xlat16_3;
mediump vec3 u_xlat16_4;
vec3 u_xlat5;
bvec3 u_xlatb5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
vec3 u_xlat10;
mediump float u_xlat16_12;
float u_xlat20;
mediump float u_xlat16_22;
float u_xlat30;
float u_xlat31;
mediump float u_xlat16_33;
void main()
{
    u_xlat16_0.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_1 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_2.x = u_xlat16_0.x + (-u_xlat16_1.w);
    u_xlat16_2.x = _BaseA0_AlphaR1 * u_xlat16_2.x + u_xlat16_1.w;
    u_xlat16_2.x = dot(u_xlat16_2.xx, vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_12 = dFdx(u_xlat16_2.x);
    u_xlat16_22 = dFdy(u_xlat16_2.x);
    u_xlat16_2.x = u_xlat16_2.x + -0.5;
    u_xlat16_12 = abs(u_xlat16_22) + abs(u_xlat16_12);
    u_xlat16_22 = (-u_xlat16_12) * 0.5 + u_xlat16_2.x;
    u_xlat16_12 = max(u_xlat16_12, 9.99999975e-05);
    u_xlat16_12 = u_xlat16_22 / u_xlat16_12;
    u_xlat16_12 = u_xlat16_12 + 1.0;
    u_xlat16_12 = clamp(u_xlat16_12, 0.0, 1.0);
    u_xlat16_22 = u_xlat16_12 + -9.99999975e-05;
    u_xlatb0 = _AlphaToMaskAvailable!=0.0;
    u_xlat16_2.x = (u_xlatb0) ? u_xlat16_22 : u_xlat16_2.x;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_12 : 1.0;
    u_xlatb0 = u_xlat16_2.x<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_22 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_2.x = min(u_xlat16_22, 1.0);
    u_xlat16_2.x = (-u_xlat16_2.x) + 1.0;
    u_xlat16_2.x = sqrt(u_xlat16_2.x);
    u_xlat16_2.x = max(u_xlat16_2.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_2.x + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat31 = _NormalIntensity;
    u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
    u_xlat0.z = u_xlat31 * u_xlat30 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat10.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10.x = u_xlat20 * u_xlat10.x;
    u_xlat10.x = clamp(u_xlat10.x, 0.0, 1.0);
    u_xlat20 = u_xlat10.x * -2.0 + 3.0;
    u_xlat10.x = u_xlat10.x * u_xlat10.x;
    u_xlat10.x = u_xlat10.x * u_xlat20;
    u_xlat16_3.xyw = u_xlat16_1.xyz * _Color.xyz;
    u_xlat16_3.xyw = u_xlat16_3.xyw * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_1.xyz + (-u_xlat16_3.xyw);
    u_xlat16_3.xyw = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyw;
    u_xlat10.xyz = _LightColor.xyz * u_xlat10.xxx + u_xlat16_3.xyw;
    u_xlat10.xyz = u_xlat10.xyz + (-_ShdowColor.xyz);
    u_xlat16_4.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_4.x);
    u_xlat1.x = u_xlat16_3.z + (-u_xlat16_4.x);
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat1.x = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.xyz = u_xlat0.xxx * u_xlat10.xyz + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyw) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyw;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat1.xy = vs_INTERP1.xy * unity_LightmapST.xy + unity_LightmapST.zw;
    u_xlat16_1 = texture(unity_Lightmap, u_xlat1.xy, _GlobalMipBias.x);
    u_xlat16_33 = log2(abs(u_xlat16_1.w));
    u_xlat16_33 = u_xlat16_33 * 2.20000005;
    u_xlat16_33 = exp2(u_xlat16_33);
    u_xlat16_33 = u_xlat16_33 * 34.4932404;
    u_xlat16_4.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_3.xyz = (-u_xlat16_4.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_1.xyz * vec3(u_xlat16_33);
    u_xlatb5.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_4.xyzx).xyz;
    u_xlat16_6.x = (u_xlatb5.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb5.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb5.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb5.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb5.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb5.z) ? float(1.0) : float(0.0);
    u_xlat16_3.xyz = u_xlat16_3.xyz * u_xlat16_6.xyz;
    u_xlat16_6.xyz = u_xlat16_4.xyz * unity_FogColor.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz + u_xlat16_6.xyz;
    u_xlat16_3.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + u_xlat16_3.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat1.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat1.xyz = sqrt(u_xlat0.xyz);
    u_xlat5.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat5.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat1.xyz = u_xlat1.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat5.xyz = u_xlat5.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat5.xyz = u_xlat5.xyz * u_xlat9.xyz;
    u_xlat1.xyz = u_xlat1.xyz * u_xlat8.xyz + u_xlat5.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + u_xlat1.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat1.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    return;
}

#endif


// ===== program 11: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 unity_FogColor;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D unity_Lightmap;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(3) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
bool u_xlatb0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec3 u_xlat16_2;
mediump vec4 u_xlat16_3;
mediump vec3 u_xlat16_4;
vec3 u_xlat5;
bvec3 u_xlatb5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
vec3 u_xlat10;
mediump float u_xlat16_12;
float u_xlat20;
mediump float u_xlat16_22;
float u_xlat30;
float u_xlat31;
mediump float u_xlat16_33;
void main()
{
    u_xlat16_0.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_1 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_2.x = u_xlat16_0.x + (-u_xlat16_1.w);
    u_xlat16_2.x = _BaseA0_AlphaR1 * u_xlat16_2.x + u_xlat16_1.w;
    u_xlat16_2.x = dot(u_xlat16_2.xx, vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_12 = dFdx(u_xlat16_2.x);
    u_xlat16_22 = dFdy(u_xlat16_2.x);
    u_xlat16_2.x = u_xlat16_2.x + -0.5;
    u_xlat16_12 = abs(u_xlat16_22) + abs(u_xlat16_12);
    u_xlat16_22 = (-u_xlat16_12) * 0.5 + u_xlat16_2.x;
    u_xlat16_12 = max(u_xlat16_12, 9.99999975e-05);
    u_xlat16_12 = u_xlat16_22 / u_xlat16_12;
    u_xlat16_12 = u_xlat16_12 + 1.0;
    u_xlat16_12 = clamp(u_xlat16_12, 0.0, 1.0);
    u_xlat16_22 = u_xlat16_12 + -9.99999975e-05;
    u_xlatb0 = _AlphaToMaskAvailable!=0.0;
    u_xlat16_2.x = (u_xlatb0) ? u_xlat16_22 : u_xlat16_2.x;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_12 : 1.0;
    u_xlatb0 = u_xlat16_2.x<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_22 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_2.x = min(u_xlat16_22, 1.0);
    u_xlat16_2.x = (-u_xlat16_2.x) + 1.0;
    u_xlat16_2.x = sqrt(u_xlat16_2.x);
    u_xlat16_2.x = max(u_xlat16_2.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_2.x + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat31 = _NormalIntensity;
    u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
    u_xlat0.z = u_xlat31 * u_xlat30 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat10.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10.x = u_xlat20 * u_xlat10.x;
    u_xlat10.x = clamp(u_xlat10.x, 0.0, 1.0);
    u_xlat20 = u_xlat10.x * -2.0 + 3.0;
    u_xlat10.x = u_xlat10.x * u_xlat10.x;
    u_xlat10.x = u_xlat10.x * u_xlat20;
    u_xlat16_3.xyw = u_xlat16_1.xyz * _Color.xyz;
    u_xlat16_3.xyw = u_xlat16_3.xyw * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_1.xyz + (-u_xlat16_3.xyw);
    u_xlat16_3.xyw = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyw;
    u_xlat10.xyz = _LightColor.xyz * u_xlat10.xxx + u_xlat16_3.xyw;
    u_xlat10.xyz = u_xlat10.xyz + (-_ShdowColor.xyz);
    u_xlat16_4.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_4.x);
    u_xlat1.x = u_xlat16_3.z + (-u_xlat16_4.x);
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat1.x = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.xyz = u_xlat0.xxx * u_xlat10.xyz + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyw) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyw;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat1.xy = vs_INTERP1.xy * unity_LightmapST.xy + unity_LightmapST.zw;
    u_xlat16_1 = texture(unity_Lightmap, u_xlat1.xy, _GlobalMipBias.x);
    u_xlat16_33 = log2(abs(u_xlat16_1.w));
    u_xlat16_33 = u_xlat16_33 * 2.20000005;
    u_xlat16_33 = exp2(u_xlat16_33);
    u_xlat16_33 = u_xlat16_33 * 34.4932404;
    u_xlat16_4.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_3.xyz = (-u_xlat16_4.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_1.xyz * vec3(u_xlat16_33);
    u_xlatb5.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_4.xyzx).xyz;
    u_xlat16_6.x = (u_xlatb5.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb5.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb5.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb5.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb5.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb5.z) ? float(1.0) : float(0.0);
    u_xlat16_3.xyz = u_xlat16_3.xyz * u_xlat16_6.xyz;
    u_xlat16_6.xyz = u_xlat16_4.xyz * unity_FogColor.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz + u_xlat16_6.xyz;
    u_xlat16_3.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + u_xlat16_3.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat1.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat1.xyz = sqrt(u_xlat0.xyz);
    u_xlat5.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat5.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat1.xyz = u_xlat1.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat5.xyz = u_xlat5.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat5.xyz = u_xlat5.xyz * u_xlat9.xyz;
    u_xlat1.xyz = u_xlat1.xyz * u_xlat8.xyz + u_xlat5.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + u_xlat1.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat1.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    return;
}

#endif


// ===== program 12: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
highp vec4 vs_INTERP2;
out highp vec4 vs_INTERP3;
out highp vec3 vs_INTERP4;
highp vec3 vs_INTERP5;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP4.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_TEXCOORD1;
    vs_INTERP2 = in_TEXCOORD2;
    vs_INTERP3 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    vs_INTERP5.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D unity_Lightmap;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec2 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
bvec3 u_xlatb2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
vec4 u_xlat7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
float u_xlat10;
mediump vec3 u_xlat16_13;
float u_xlat20;
mediump float u_xlat16_21;
float u_xlat30;
mediump float u_xlat16_33;
void main()
{
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_1.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_21 = dot(u_xlat16_1.xy, u_xlat16_1.xy);
    u_xlat0.xy = u_xlat16_1.xy * vec2(_NormalIntensity);
    u_xlat16_1.x = min(u_xlat16_21, 1.0);
    u_xlat16_1.x = (-u_xlat16_1.x) + 1.0;
    u_xlat16_1.x = sqrt(u_xlat16_1.x);
    u_xlat16_1.x = max(u_xlat16_1.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_1.x + -1.0;
    u_xlat16_1.xz = _PrefabCenterWS.xz;
    u_xlat16_1.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat1.xyz = u_xlat16_1.xyz + (-vs_INTERP4.xyz);
    u_xlat2.x = _NormalIntensity;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat0.z = u_xlat2.x * u_xlat30 + u_xlat1.z;
    u_xlat1.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat1.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat10 = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat16_13.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_13.z;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10 = u_xlat20 * u_xlat10;
    u_xlat10 = clamp(u_xlat10, 0.0, 1.0);
    u_xlat20 = u_xlat10 * -2.0 + 3.0;
    u_xlat10 = u_xlat10 * u_xlat10;
    u_xlat10 = u_xlat10 * u_xlat20;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_13.x);
    u_xlat20 = (-u_xlat16_13.x) + u_xlat16_13.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat0.x = u_xlat20 * u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat20 = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat20;
    u_xlat16_2.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = u_xlat16_2.xyz * _Color.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_2.xyz + (-u_xlat16_3.xyz);
    u_xlat16_3.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat0.xzw = _LightColor.xyz * u_xlat0.xxx + u_xlat16_3.xyz;
    u_xlat0.xzw = u_xlat0.xzw + (-_ShdowColor.xyz);
    u_xlat0.xyz = vec3(u_xlat10) * u_xlat0.xzw + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat2.xy = vs_INTERP1.xy * unity_LightmapST.xy + unity_LightmapST.zw;
    u_xlat16_1 = texture(unity_Lightmap, u_xlat2.xy, _GlobalMipBias.x);
    u_xlat16_33 = log2(abs(u_xlat16_1.w));
    u_xlat16_33 = u_xlat16_33 * 2.20000005;
    u_xlat16_33 = exp2(u_xlat16_33);
    u_xlat16_33 = u_xlat16_33 * 34.4932404;
    u_xlat16_4.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_3.xyz = (-u_xlat16_4.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_1.xyz * vec3(u_xlat16_33);
    u_xlatb2.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_4.xyzx).xyz;
    u_xlat16_5.x = (u_xlatb2.x) ? float(0.0) : float(1.0);
    u_xlat16_5.y = (u_xlatb2.y) ? float(0.0) : float(1.0);
    u_xlat16_5.z = (u_xlatb2.z) ? float(0.0) : float(1.0);
    u_xlat16_6.x = (u_xlatb2.x) ? float(1.0) : float(0.0);
    u_xlat16_6.y = (u_xlatb2.y) ? float(1.0) : float(0.0);
    u_xlat16_6.z = (u_xlatb2.z) ? float(1.0) : float(0.0);
    u_xlat16_3.xyz = u_xlat16_3.xyz * u_xlat16_5.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * unity_FogColor.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz + u_xlat16_5.xyz;
    u_xlat16_3.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + u_xlat16_3.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat2.xyz + u_xlat0.xyz;
    u_xlat2.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat7.xyz = vs_INTERP4.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP4.xxx + u_xlat7.xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP4.zzz + u_xlat7.xyz;
    u_xlat7.xyz = u_xlat7.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat8.xyz = u_xlat7.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat7.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat7.xxx + u_xlat8.xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat7.zzz + u_xlat7.xyw;
    u_xlat7.xyz = u_xlat7.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat30 = u_xlat7.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat7.x + u_xlat30;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat7.z + u_xlat30;
    u_xlat30 = u_xlat30 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat30 = (-u_xlat30) + (-_ProjectionParams.y);
    u_xlat30 = max(u_xlat30, 0.0);
    u_xlat30 = u_xlat30 * unity_FogParams.z + unity_FogParams.w;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat30 = (-u_xlat30) + 1.0;
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat2.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat2.xyz = sqrt(u_xlat0.xyz);
    u_xlat7.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat2.xyz = u_xlat2.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat7.xyz = u_xlat7.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat7.xyz = u_xlat7.xyz * u_xlat9.xyz;
    u_xlat2.xyz = u_xlat2.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat2.xyz = (-u_xlat0.xyz) + u_xlat2.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat2.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 13: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D unity_Lightmap;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(2) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec2 u_xlat16_0;
vec4 u_xlat1;
mediump vec4 u_xlat16_1;
vec3 u_xlat2;
mediump vec3 u_xlat16_2;
bvec3 u_xlatb2;
mediump vec3 u_xlat16_3;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
mediump vec3 u_xlat16_6;
vec4 u_xlat7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
float u_xlat10;
mediump vec3 u_xlat16_13;
float u_xlat20;
mediump float u_xlat16_21;
float u_xlat30;
mediump float u_xlat16_33;
void main()
{
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_1.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_21 = dot(u_xlat16_1.xy, u_xlat16_1.xy);
    u_xlat0.xy = u_xlat16_1.xy * vec2(_NormalIntensity);
    u_xlat16_1.x = min(u_xlat16_21, 1.0);
    u_xlat16_1.x = (-u_xlat16_1.x) + 1.0;
    u_xlat16_1.x = sqrt(u_xlat16_1.x);
    u_xlat16_1.x = max(u_xlat16_1.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_1.x + -1.0;
    u_xlat16_1.xz = _PrefabCenterWS.xz;
    u_xlat16_1.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat1.xyz = u_xlat16_1.xyz + (-vs_INTERP4.xyz);
    u_xlat2.x = _NormalIntensity;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat0.z = u_xlat2.x * u_xlat30 + u_xlat1.z;
    u_xlat1.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat1.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat10 = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat16_13.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_13.z;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10 = u_xlat20 * u_xlat10;
    u_xlat10 = clamp(u_xlat10, 0.0, 1.0);
    u_xlat20 = u_xlat10 * -2.0 + 3.0;
    u_xlat10 = u_xlat10 * u_xlat10;
    u_xlat10 = u_xlat10 * u_xlat20;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_13.x);
    u_xlat20 = (-u_xlat16_13.x) + u_xlat16_13.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat0.x = u_xlat20 * u_xlat0.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat20 = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat20;
    u_xlat16_2.xyz = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).xyz;
    u_xlat16_3.xyz = u_xlat16_2.xyz * _Color.xyz;
    u_xlat16_3.xyz = u_xlat16_3.xyz * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_2.xyz + (-u_xlat16_3.xyz);
    u_xlat16_3.xyz = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyz;
    u_xlat0.xzw = _LightColor.xyz * u_xlat0.xxx + u_xlat16_3.xyz;
    u_xlat0.xzw = u_xlat0.xzw + (-_ShdowColor.xyz);
    u_xlat0.xyz = vec3(u_xlat10) * u_xlat0.xzw + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyz) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat2.xy = vs_INTERP1.xy * unity_LightmapST.xy + unity_LightmapST.zw;
    u_xlat16_1 = texture(unity_Lightmap, u_xlat2.xy, _GlobalMipBias.x);
    u_xlat16_33 = log2(abs(u_xlat16_1.w));
    u_xlat16_33 = u_xlat16_33 * 2.20000005;
    u_xlat16_33 = exp2(u_xlat16_33);
    u_xlat16_33 = u_xlat16_33 * 34.4932404;
    u_xlat16_4.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_3.xyz = (-u_xlat16_4.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_1.xyz * vec3(u_xlat16_33);
    u_xlatb2.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_4.xyzx).xyz;
    u_xlat16_5.x = (u_xlatb2.x) ? float(0.0) : float(1.0);
    u_xlat16_5.y = (u_xlatb2.y) ? float(0.0) : float(1.0);
    u_xlat16_5.z = (u_xlatb2.z) ? float(0.0) : float(1.0);
    u_xlat16_6.x = (u_xlatb2.x) ? float(1.0) : float(0.0);
    u_xlat16_6.y = (u_xlatb2.y) ? float(1.0) : float(0.0);
    u_xlat16_6.z = (u_xlatb2.z) ? float(1.0) : float(0.0);
    u_xlat16_3.xyz = u_xlat16_3.xyz * u_xlat16_5.xyz;
    u_xlat16_5.xyz = u_xlat16_4.xyz * unity_FogColor.xyz;
    u_xlat16_5.xyz = u_xlat16_5.xyz + u_xlat16_5.xyz;
    u_xlat16_3.xyz = u_xlat16_5.xyz * u_xlat16_6.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + u_xlat16_3.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat2.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat2.xyz + u_xlat0.xyz;
    u_xlat2.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat7.xyz = vs_INTERP4.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP4.xxx + u_xlat7.xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP4.zzz + u_xlat7.xyz;
    u_xlat7.xyz = u_xlat7.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat8.xyz = u_xlat7.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat7.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat7.xxx + u_xlat8.xyz;
    u_xlat7.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat7.zzz + u_xlat7.xyw;
    u_xlat7.xyz = u_xlat7.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat30 = u_xlat7.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat7.x + u_xlat30;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat7.z + u_xlat30;
    u_xlat30 = u_xlat30 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat30 = (-u_xlat30) + (-_ProjectionParams.y);
    u_xlat30 = max(u_xlat30, 0.0);
    u_xlat30 = u_xlat30 * unity_FogParams.z + unity_FogParams.w;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat30 = (-u_xlat30) + 1.0;
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat2.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat2.xyz = sqrt(u_xlat0.xyz);
    u_xlat7.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat7.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat2.xyz = u_xlat2.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat7.xyz = u_xlat7.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat7.xyz = u_xlat7.xyz * u_xlat9.xyz;
    u_xlat2.xyz = u_xlat2.xyz * u_xlat8.xyz + u_xlat7.xyz;
    u_xlat2.xyz = (-u_xlat0.xyz) + u_xlat2.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat2.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 14: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
highp vec4 vs_INTERP2;
out highp vec4 vs_INTERP3;
out highp vec3 vs_INTERP4;
highp vec3 vs_INTERP5;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP4.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_TEXCOORD1;
    vs_INTERP2 = in_TEXCOORD2;
    vs_INTERP3 = in_COLOR0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    vs_INTERP5.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D unity_Lightmap;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(3) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
bool u_xlatb0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec3 u_xlat16_2;
mediump vec4 u_xlat16_3;
mediump vec3 u_xlat16_4;
vec4 u_xlat5;
bvec3 u_xlatb5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
vec3 u_xlat10;
mediump float u_xlat16_12;
float u_xlat20;
mediump float u_xlat16_22;
float u_xlat30;
float u_xlat31;
mediump float u_xlat16_33;
void main()
{
    u_xlat16_0.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_1 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_2.x = u_xlat16_0.x + (-u_xlat16_1.w);
    u_xlat16_2.x = _BaseA0_AlphaR1 * u_xlat16_2.x + u_xlat16_1.w;
    u_xlat16_2.x = dot(u_xlat16_2.xx, vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_12 = dFdx(u_xlat16_2.x);
    u_xlat16_22 = dFdy(u_xlat16_2.x);
    u_xlat16_2.x = u_xlat16_2.x + -0.5;
    u_xlat16_12 = abs(u_xlat16_22) + abs(u_xlat16_12);
    u_xlat16_22 = (-u_xlat16_12) * 0.5 + u_xlat16_2.x;
    u_xlat16_12 = max(u_xlat16_12, 9.99999975e-05);
    u_xlat16_12 = u_xlat16_22 / u_xlat16_12;
    u_xlat16_12 = u_xlat16_12 + 1.0;
    u_xlat16_12 = clamp(u_xlat16_12, 0.0, 1.0);
    u_xlat16_22 = u_xlat16_12 + -9.99999975e-05;
    u_xlatb0 = _AlphaToMaskAvailable!=0.0;
    u_xlat16_2.x = (u_xlatb0) ? u_xlat16_22 : u_xlat16_2.x;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_12 : 1.0;
    u_xlatb0 = u_xlat16_2.x<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_22 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_2.x = min(u_xlat16_22, 1.0);
    u_xlat16_2.x = (-u_xlat16_2.x) + 1.0;
    u_xlat16_2.x = sqrt(u_xlat16_2.x);
    u_xlat16_2.x = max(u_xlat16_2.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_2.x + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat31 = _NormalIntensity;
    u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
    u_xlat0.z = u_xlat31 * u_xlat30 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat10.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10.x = u_xlat20 * u_xlat10.x;
    u_xlat10.x = clamp(u_xlat10.x, 0.0, 1.0);
    u_xlat20 = u_xlat10.x * -2.0 + 3.0;
    u_xlat10.x = u_xlat10.x * u_xlat10.x;
    u_xlat10.x = u_xlat10.x * u_xlat20;
    u_xlat16_3.xyw = u_xlat16_1.xyz * _Color.xyz;
    u_xlat16_3.xyw = u_xlat16_3.xyw * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_1.xyz + (-u_xlat16_3.xyw);
    u_xlat16_3.xyw = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyw;
    u_xlat10.xyz = _LightColor.xyz * u_xlat10.xxx + u_xlat16_3.xyw;
    u_xlat10.xyz = u_xlat10.xyz + (-_ShdowColor.xyz);
    u_xlat16_4.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_4.x);
    u_xlat1.x = u_xlat16_3.z + (-u_xlat16_4.x);
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat1.x = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.xyz = u_xlat0.xxx * u_xlat10.xyz + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyw) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyw;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat1.xy = vs_INTERP1.xy * unity_LightmapST.xy + unity_LightmapST.zw;
    u_xlat16_1 = texture(unity_Lightmap, u_xlat1.xy, _GlobalMipBias.x);
    u_xlat16_33 = log2(abs(u_xlat16_1.w));
    u_xlat16_33 = u_xlat16_33 * 2.20000005;
    u_xlat16_33 = exp2(u_xlat16_33);
    u_xlat16_33 = u_xlat16_33 * 34.4932404;
    u_xlat16_4.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_3.xyz = (-u_xlat16_4.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_1.xyz * vec3(u_xlat16_33);
    u_xlatb5.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_4.xyzx).xyz;
    u_xlat16_6.x = (u_xlatb5.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb5.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb5.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb5.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb5.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb5.z) ? float(1.0) : float(0.0);
    u_xlat16_3.xyz = u_xlat16_3.xyz * u_xlat16_6.xyz;
    u_xlat16_6.xyz = u_xlat16_4.xyz * unity_FogColor.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz + u_xlat16_6.xyz;
    u_xlat16_3.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + u_xlat16_3.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat1.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat5.xyz = vs_INTERP4.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat5.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP4.xxx + u_xlat5.xyz;
    u_xlat5.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP4.zzz + u_xlat5.xyz;
    u_xlat5.xyz = u_xlat5.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat8.xyz = u_xlat5.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat5.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat5.xxx + u_xlat8.xyz;
    u_xlat5.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat5.zzz + u_xlat5.xyw;
    u_xlat5.xyz = u_xlat5.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat30 = u_xlat5.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat5.x + u_xlat30;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat5.z + u_xlat30;
    u_xlat30 = u_xlat30 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat30 = (-u_xlat30) + (-_ProjectionParams.y);
    u_xlat30 = max(u_xlat30, 0.0);
    u_xlat30 = u_xlat30 * unity_FogParams.z + unity_FogParams.w;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat30 = (-u_xlat30) + 1.0;
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat1.xyz = sqrt(u_xlat0.xyz);
    u_xlat5.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat5.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat1.xyz = u_xlat1.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat5.xyz = u_xlat5.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat5.xyz = u_xlat5.xyz * u_xlat9.xyz;
    u_xlat1.xyz = u_xlat1.xyz * u_xlat8.xyz + u_xlat5.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + u_xlat1.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat1.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    return;
}

#endif
{

// ===== program 15: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	float _AlphaToMaskAvailable;
uniform 	vec4 _MainLightPosition;
uniform 	vec4 _ProjectionParams;
uniform 	vec4 unity_FogParams;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4                unity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4                _Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float                _VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float                _Lightmap_Intensity;
	UNITY_UNIFORM mediump float                _GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3                _PrefabCenterWS;
	UNITY_UNIFORM mediump float                _PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float                _SmoothEdge_1;
	UNITY_UNIFORM mediump float                _SmoothEdge_2;
	UNITY_UNIFORM mediump vec4                _LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float                _NormalIntensity;
	UNITY_UNIFORM mediump float                _WorldNormal_UV;
	UNITY_UNIFORM mediump vec4                _ShdowColor;
	UNITY_UNIFORM mediump float                _ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float                _Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float                _FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D unity_Lightmap;
UNITY_LOCATION(1) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(2) uniform mediump sampler2D _BaseTex;
UNITY_LOCATION(3) uniform mediump sampler2D _NormalMap_Noise;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump vec2 u_xlat16_0;
bool u_xlatb0;
vec3 u_xlat1;
mediump vec4 u_xlat16_1;
vec4 u_xlat2;
mediump vec3 u_xlat16_2;
mediump vec4 u_xlat16_3;
mediump vec3 u_xlat16_4;
vec4 u_xlat5;
bvec3 u_xlatb5;
mediump vec3 u_xlat16_6;
mediump vec3 u_xlat16_7;
vec3 u_xlat8;
bvec3 u_xlatb8;
vec3 u_xlat9;
vec3 u_xlat10;
mediump float u_xlat16_12;
float u_xlat20;
mediump float u_xlat16_22;
float u_xlat30;
float u_xlat31;
mediump float u_xlat16_33;
void main()
{
    u_xlat16_0.x = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_1 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x);
    u_xlat16_2.x = u_xlat16_0.x + (-u_xlat16_1.w);
    u_xlat16_2.x = _BaseA0_AlphaR1 * u_xlat16_2.x + u_xlat16_1.w;
    u_xlat16_2.x = dot(u_xlat16_2.xx, vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_12 = dFdx(u_xlat16_2.x);
    u_xlat16_22 = dFdy(u_xlat16_2.x);
    u_xlat16_2.x = u_xlat16_2.x + -0.5;
    u_xlat16_12 = abs(u_xlat16_22) + abs(u_xlat16_12);
    u_xlat16_22 = (-u_xlat16_12) * 0.5 + u_xlat16_2.x;
    u_xlat16_12 = max(u_xlat16_12, 9.99999975e-05);
    u_xlat16_12 = u_xlat16_22 / u_xlat16_12;
    u_xlat16_12 = u_xlat16_12 + 1.0;
    u_xlat16_12 = clamp(u_xlat16_12, 0.0, 1.0);
    u_xlat16_22 = u_xlat16_12 + -9.99999975e-05;
    u_xlatb0 = _AlphaToMaskAvailable!=0.0;
    u_xlat16_2.x = (u_xlatb0) ? u_xlat16_22 : u_xlat16_2.x;
    SV_Target0.w = (u_xlatb0) ? u_xlat16_12 : 1.0;
    u_xlatb0 = u_xlat16_2.x<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.xy = vs_INTERP4.xy * vec2(vec2(_WorldNormal_UV, _WorldNormal_UV));
    u_xlat16_0.xy = texture(_NormalMap_Noise, u_xlat0.xy, _GlobalMipBias.x).yw;
    u_xlat16_2.xy = u_xlat16_0.yx * vec2(2.0, 2.0) + vec2(-1.0, -1.0);
    u_xlat16_22 = dot(u_xlat16_2.xy, u_xlat16_2.xy);
    u_xlat0.xy = u_xlat16_2.xy * vec2(_NormalIntensity);
    u_xlat16_2.x = min(u_xlat16_22, 1.0);
    u_xlat16_2.x = (-u_xlat16_2.x) + 1.0;
    u_xlat16_2.x = sqrt(u_xlat16_2.x);
    u_xlat16_2.x = max(u_xlat16_2.x, 1.00000002e-16);
    u_xlat30 = u_xlat16_2.x + -1.0;
    u_xlat16_2.xz = _PrefabCenterWS.xz;
    u_xlat16_2.y = _PrefabCenter_PlusW + _PrefabCenterWS.y;
    u_xlat2.xyz = u_xlat16_2.xyz + (-vs_INTERP4.xyz);
    u_xlat31 = _NormalIntensity;
    u_xlat31 = clamp(u_xlat31, 0.0, 1.0);
    u_xlat0.z = u_xlat31 * u_xlat30 + u_xlat2.z;
    u_xlat2.w = 1.0;
    u_xlat0.xyz = u_xlat0.xyz + u_xlat2.xyw;
    u_xlat30 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat0.xyz;
    u_xlat0.x = dot(u_xlat0.xyz, (-_MainLightPosition.xyz));
    u_xlat0.x = (-u_xlat0.x) + 1.0;
    u_xlat16_3.xyz = vec3(_SmoothEdge_1, _SmoothEdge_2, _SmoothEdge_2) + vec3(1.24000001, -0.180000007, 2.4000001);
    u_xlat10.x = u_xlat0.x + (-u_xlat16_3.x);
    u_xlat20 = (-u_xlat16_3.x) + u_xlat16_3.y;
    u_xlat20 = float(1.0) / u_xlat20;
    u_xlat10.x = u_xlat20 * u_xlat10.x;
    u_xlat10.x = clamp(u_xlat10.x, 0.0, 1.0);
    u_xlat20 = u_xlat10.x * -2.0 + 3.0;
    u_xlat10.x = u_xlat10.x * u_xlat10.x;
    u_xlat10.x = u_xlat10.x * u_xlat20;
    u_xlat16_3.xyw = u_xlat16_1.xyz * _Color.xyz;
    u_xlat16_3.xyw = u_xlat16_3.xyw * vs_INTERP3.xyz;
    u_xlat16_4.xyz = _Color.xyz * u_xlat16_1.xyz + (-u_xlat16_3.xyw);
    u_xlat16_3.xyw = vec3(vec3(_VC_Intensity, _VC_Intensity, _VC_Intensity)) * u_xlat16_4.xyz + u_xlat16_3.xyw;
    u_xlat10.xyz = _LightColor.xyz * u_xlat10.xxx + u_xlat16_3.xyw;
    u_xlat10.xyz = u_xlat10.xyz + (-_ShdowColor.xyz);
    u_xlat16_4.x = _SmoothEdge_1 + _ShadowSmoothEdge_1;
    u_xlat0.x = u_xlat0.x + (-u_xlat16_4.x);
    u_xlat1.x = u_xlat16_3.z + (-u_xlat16_4.x);
    u_xlat1.x = float(1.0) / u_xlat1.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.x = clamp(u_xlat0.x, 0.0, 1.0);
    u_xlat1.x = u_xlat0.x * -2.0 + 3.0;
    u_xlat0.x = u_xlat0.x * u_xlat0.x;
    u_xlat0.x = u_xlat0.x * u_xlat1.x;
    u_xlat0.xyz = u_xlat0.xxx * u_xlat10.xyz + _ShdowColor.xyz;
    u_xlat0.xyz = (-u_xlat16_3.xyw) + u_xlat0.xyz;
    u_xlat0.xyz = vec3(vec3(_Lighting_0Off_1ON, _Lighting_0Off_1ON, _Lighting_0Off_1ON)) * u_xlat0.xyz + u_xlat16_3.xyw;
    u_xlat16_3.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat1.xy = vs_INTERP1.xy * unity_LightmapST.xy + unity_LightmapST.zw;
    u_xlat16_1 = texture(unity_Lightmap, u_xlat1.xy, _GlobalMipBias.x);
    u_xlat16_33 = log2(abs(u_xlat16_1.w));
    u_xlat16_33 = u_xlat16_33 * 2.20000005;
    u_xlat16_33 = exp2(u_xlat16_33);
    u_xlat16_33 = u_xlat16_33 * 34.4932404;
    u_xlat16_4.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_4.xyz + u_xlat16_4.xyz;
    u_xlat16_3.xyz = (-u_xlat16_4.xyz) * u_xlat16_3.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat16_4.xyz = u_xlat16_1.xyz * vec3(u_xlat16_33);
    u_xlatb5.xyz = greaterThanEqual(vec4(0.5, 0.5, 0.5, 0.0), u_xlat16_4.xyzx).xyz;
    u_xlat16_6.x = (u_xlatb5.x) ? float(0.0) : float(1.0);
    u_xlat16_6.y = (u_xlatb5.y) ? float(0.0) : float(1.0);
    u_xlat16_6.z = (u_xlatb5.z) ? float(0.0) : float(1.0);
    u_xlat16_7.x = (u_xlatb5.x) ? float(1.0) : float(0.0);
    u_xlat16_7.y = (u_xlatb5.y) ? float(1.0) : float(0.0);
    u_xlat16_7.z = (u_xlatb5.z) ? float(1.0) : float(0.0);
    u_xlat16_3.xyz = u_xlat16_3.xyz * u_xlat16_6.xyz;
    u_xlat16_6.xyz = u_xlat16_4.xyz * unity_FogColor.xyz;
    u_xlat16_6.xyz = u_xlat16_6.xyz + u_xlat16_6.xyz;
    u_xlat16_3.xyz = u_xlat16_6.xyz * u_xlat16_7.xyz + u_xlat16_3.xyz;
    u_xlat16_3.xyz = (-u_xlat16_1.xyz) * vec3(u_xlat16_33) + u_xlat16_3.xyz;
    u_xlat16_3.xyz = vec3(vec3(_GI_FogGolor_Intensity, _GI_FogGolor_Intensity, _GI_FogGolor_Intensity)) * u_xlat16_3.xyz + u_xlat16_4.xyz;
    u_xlat1.xyz = u_xlat16_3.xyz * u_xlat0.xyz + (-u_xlat0.xyz);
    u_xlat0.xyz = vec3(_Lightmap_Intensity) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + unity_FogColor.xyz;
    u_xlat5.xyz = vs_INTERP4.yyy * hlslcc_mtx4x4unity_WorldToObject[1].xyz;
    u_xlat5.xyz = hlslcc_mtx4x4unity_WorldToObject[0].xyz * vs_INTERP4.xxx + u_xlat5.xyz;
    u_xlat5.xyz = hlslcc_mtx4x4unity_WorldToObject[2].xyz * vs_INTERP4.zzz + u_xlat5.xyz;
    u_xlat5.xyz = u_xlat5.xyz + hlslcc_mtx4x4unity_WorldToObject[3].xyz;
    u_xlat8.xyz = u_xlat5.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat5.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat5.xxx + u_xlat8.xyz;
    u_xlat5.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat5.zzz + u_xlat5.xyw;
    u_xlat5.xyz = u_xlat5.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat30 = u_xlat5.y * hlslcc_mtx4x4unity_MatrixV[1].z;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[0].z * u_xlat5.x + u_xlat30;
    u_xlat30 = hlslcc_mtx4x4unity_MatrixV[2].z * u_xlat5.z + u_xlat30;
    u_xlat30 = u_xlat30 + hlslcc_mtx4x4unity_MatrixV[3].z;
    u_xlat30 = (-u_xlat30) + (-_ProjectionParams.y);
    u_xlat30 = max(u_xlat30, 0.0);
    u_xlat30 = u_xlat30 * unity_FogParams.z + unity_FogParams.w;
    u_xlat30 = clamp(u_xlat30, 0.0, 1.0);
    u_xlat30 = (-u_xlat30) + 1.0;
    u_xlat0.xyz = vec3(u_xlat30) * u_xlat1.xyz + u_xlat0.xyz;
    u_xlat0.xyz = clamp(u_xlat0.xyz, 0.0, 1.0);
    u_xlat1.xyz = sqrt(u_xlat0.xyz);
    u_xlat5.xyz = u_xlat0.xyz + u_xlat0.xyz;
    u_xlat8.xyz = (-unity_FogColor.xyz) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat5.xyz * u_xlat8.xyz;
    u_xlat9.xyz = unity_FogColor.xyz * vec3(2.0, 2.0, 2.0) + vec3(-1.0, -1.0, -1.0);
    u_xlat1.xyz = u_xlat1.xyz * u_xlat9.xyz + u_xlat8.xyz;
    u_xlat8.xyz = u_xlat0.xyz * u_xlat0.xyz;
    u_xlat9.xyz = (-unity_FogColor.xyz) * vec3(2.0, 2.0, 2.0) + vec3(1.0, 1.0, 1.0);
    u_xlat8.xyz = u_xlat8.xyz * u_xlat9.xyz;
    u_xlat5.xyz = u_xlat5.xyz * unity_FogColor.xyz + u_xlat8.xyz;
    u_xlatb8.xyz = greaterThanEqual(unity_FogColor.xyzx, vec4(0.5, 0.5, 0.5, 0.0)).xyz;
    u_xlat9.x = (u_xlatb8.x) ? float(0.0) : float(1.0);
    u_xlat9.y = (u_xlatb8.y) ? float(0.0) : float(1.0);
    u_xlat9.z = (u_xlatb8.z) ? float(0.0) : float(1.0);
    u_xlat8.x = u_xlatb8.x ? float(1.0) : 0.0;
    u_xlat8.y = u_xlatb8.y ? float(1.0) : 0.0;
    u_xlat8.z = u_xlatb8.z ? float(1.0) : 0.0;
;
    u_xlat5.xyz = u_xlat5.xyz * u_xlat9.xyz;
    u_xlat1.xyz = u_xlat1.xyz * u_xlat8.xyz + u_xlat5.xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + u_xlat1.xyz;
    u_xlat0.xyz = vec3(vec3(_FogSofLighting, _FogSofLighting, _FogSofLighting)) * u_xlat1.xyz + u_xlat0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    return;
}

#endif
{

// ===== program 16: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 17: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 18: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_1 = dot(vec2(u_xlat16_1), vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_1 = u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 19: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_1 = dot(vec2(u_xlat16_1), vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_1 = u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 20: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 hlslcc_mtx4x4_PrevViewProjMatrix[4];
uniform 	vec4 hlslcc_mtx4x4_NonJitteredViewProjMatrix[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
in highp vec3 in_TEXCOORD4;
out highp vec3 vs_CLIP_POSITION_NO_JITTER0;
out highp vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
highp vec4 vs_INTERP0;
vec4 u_xlat0;
vec4 u_xlat1;
mediump float u_xlat16_1;
vec4 u_xlat2;
vec4 u_xlat3;
vec4 u_xlat4;
float u_xlat5;
float u_xlat10;
float u_xlat13;
float u_xlat15;
float u_xlat17;
bool u_xlatb17;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat16_1 = in_COLOR0.w * _WindStrength;
    u_xlat2 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat10 = dot(u_xlat2.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = sin(u_xlat10);
    u_xlat15 = dot(u_xlat2.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.w = sin(u_xlat15);
    u_xlat0 = u_xlat0 * vec4(20.0, 20.0, 43758.5469, 43758.5469);
    u_xlat0.x = dot(u_xlat0.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.xzw = fract(u_xlat0.xzw);
    u_xlat5 = _TimeParameters.x * _WindSpeed;
    u_xlat10 = u_xlat0.z * 10.0 + u_xlat5;
    u_xlat10 = sin(u_xlat10);
    u_xlat2.x = u_xlat10 * 0.300000012;
    u_xlat10 = u_xlat0.w * 10.0 + u_xlat5;
    u_xlat0.z = sin(u_xlat10);
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat5;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.yz = u_xlat0.zx * vec2(0.300000012, 0.300000012);
    u_xlat0.xzw = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat0.xzw = u_xlat0.xzw * vec3(u_xlat16_1) + in_POSITION0.xyz;
    u_xlat2.xyz = u_xlat0.zzz * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat2.xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.www + u_xlat2.xyz;
    u_xlat2.xyz = u_xlat2.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat3 = u_xlat2.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat3 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat2.xxxx + u_xlat3;
    u_xlat3 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat2.zzzz + u_xlat3;
    gl_Position = u_xlat3 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlatb17 = unity_MotionVectorsParams.y!=0.0;
    if(u_xlatb17){
        u_xlatb17 = unity_MotionVectorsParams.x==1.0;
        if(u_xlatb17){
            u_xlat3.xy = in_TEXCOORD4.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
            u_xlat3.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_TEXCOORD4.xx + u_xlat3.xy;
            u_xlat3.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_TEXCOORD4.zz + u_xlat3.xy;
            u_xlat3.xy = u_xlat3.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
            u_xlat4 = u_xlat3.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
            u_xlat17 = dot(u_xlat4.xy, vec2(12.9898005, 78.2330017));
            u_xlat17 = sin(u_xlat17);
            u_xlat17 = u_xlat17 * 43758.5469;
            u_xlat17 = fract(u_xlat17);
            u_xlat13 = dot(u_xlat4.zw, vec2(12.9898005, 78.2330017));
            u_xlat3.z = sin(u_xlat13);
            u_xlat3.xyz = u_xlat3.xyz * vec3(20.0, 20.0, 43758.5469);
            u_xlat3.x = dot(u_xlat3.xy, vec2(12.9898005, 78.2330017));
            u_xlat3.x = sin(u_xlat3.x);
            u_xlat3.x = u_xlat3.x * 43758.5469;
            u_xlat3.xz = fract(u_xlat3.xz);
            u_xlat17 = u_xlat17 * 10.0 + u_xlat5;
            u_xlat17 = sin(u_xlat17);
            u_xlat4.x = u_xlat17 * 0.300000012;
            u_xlat17 = u_xlat3.z * 10.0 + u_xlat5;
            u_xlat17 = sin(u_xlat17);
            u_xlat4.y = u_xlat17 * 0.300000012;
            u_xlat5 = u_xlat3.x * 10.0 + u_xlat5;
            u_xlat5 = sin(u_xlat5);
            u_xlat4.z = u_xlat5 * 0.300000012;
            u_xlat3.xyz = u_xlat4.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
            u_xlat0.xzw = u_xlat3.xyz * vec3(u_xlat16_1) + in_TEXCOORD4.xyz;
        }
        u_xlat3.xyz = u_xlat2.yyy * hlslcc_mtx4x4_NonJitteredViewProjMatrix[1].xyw;
        u_xlat2.xyw = hlslcc_mtx4x4_NonJitteredViewProjMatrix[0].xyw * u_xlat2.xxx + u_xlat3.xyz;
        u_xlat2.xyz = hlslcc_mtx4x4_NonJitteredViewProjMatrix[2].xyw * u_xlat2.zzz + u_xlat2.xyw;
        vs_CLIP_POSITION_NO_JITTER0.xyz = u_xlat2.xyz + hlslcc_mtx4x4_NonJitteredViewProjMatrix[3].xyw;
        u_xlat1 = u_xlat0.zzzz * hlslcc_mtx4x4unity_MatrixPreviousM[1];
        u_xlat1 = hlslcc_mtx4x4unity_MatrixPreviousM[0] * u_xlat0.xxxx + u_xlat1;
        u_xlat0 = hlslcc_mtx4x4unity_MatrixPreviousM[2] * u_xlat0.wwww + u_xlat1;
        u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixPreviousM[3];
        u_xlat2.xyz = u_xlat0.yyy * hlslcc_mtx4x4_PrevViewProjMatrix[1].xyw;
        u_xlat2.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[0].xyw * u_xlat0.xxx + u_xlat2.xyz;
        u_xlat0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[2].xyw * u_xlat0.zzz + u_xlat2.xyz;
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[3].xyw * u_xlat0.www + u_xlat0.xyz;
    } else {
        vs_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
    }
    vs_INTERP0 = in_TEXCOORD0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
float u_xlat2;
bool u_xlatb2;
void main()
{
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat2 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat2) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb2 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb2) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 21: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
float u_xlat2;
bool u_xlatb2;
void main()
{
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat2 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat2) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb2 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb2) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 22: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 hlslcc_mtx4x4_PrevViewProjMatrix[4];
uniform 	vec4 hlslcc_mtx4x4_NonJitteredViewProjMatrix[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
in highp vec3 in_TEXCOORD4;
out highp vec3 vs_CLIP_POSITION_NO_JITTER0;
out highp vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
out highp vec4 vs_INTERP0;
vec4 u_xlat0;
vec4 u_xlat1;
mediump float u_xlat16_1;
vec4 u_xlat2;
vec4 u_xlat3;
vec4 u_xlat4;
float u_xlat5;
float u_xlat10;
float u_xlat13;
float u_xlat15;
float u_xlat17;
bool u_xlatb17;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat16_1 = in_COLOR0.w * _WindStrength;
    u_xlat2 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat10 = dot(u_xlat2.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = sin(u_xlat10);
    u_xlat15 = dot(u_xlat2.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.w = sin(u_xlat15);
    u_xlat0 = u_xlat0 * vec4(20.0, 20.0, 43758.5469, 43758.5469);
    u_xlat0.x = dot(u_xlat0.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.xzw = fract(u_xlat0.xzw);
    u_xlat5 = _TimeParameters.x * _WindSpeed;
    u_xlat10 = u_xlat0.z * 10.0 + u_xlat5;
    u_xlat10 = sin(u_xlat10);
    u_xlat2.x = u_xlat10 * 0.300000012;
    u_xlat10 = u_xlat0.w * 10.0 + u_xlat5;
    u_xlat0.z = sin(u_xlat10);
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat5;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.yz = u_xlat0.zx * vec2(0.300000012, 0.300000012);
    u_xlat0.xzw = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat0.xzw = u_xlat0.xzw * vec3(u_xlat16_1) + in_POSITION0.xyz;
    u_xlat2.xyz = u_xlat0.zzz * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat2.xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.www + u_xlat2.xyz;
    u_xlat2.xyz = u_xlat2.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat3 = u_xlat2.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat3 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat2.xxxx + u_xlat3;
    u_xlat3 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat2.zzzz + u_xlat3;
    gl_Position = u_xlat3 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlatb17 = unity_MotionVectorsParams.y!=0.0;
    if(u_xlatb17){
        u_xlatb17 = unity_MotionVectorsParams.x==1.0;
        if(u_xlatb17){
            u_xlat3.xy = in_TEXCOORD4.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
            u_xlat3.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_TEXCOORD4.xx + u_xlat3.xy;
            u_xlat3.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_TEXCOORD4.zz + u_xlat3.xy;
            u_xlat3.xy = u_xlat3.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
            u_xlat4 = u_xlat3.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
            u_xlat17 = dot(u_xlat4.xy, vec2(12.9898005, 78.2330017));
            u_xlat17 = sin(u_xlat17);
            u_xlat17 = u_xlat17 * 43758.5469;
            u_xlat17 = fract(u_xlat17);
            u_xlat13 = dot(u_xlat4.zw, vec2(12.9898005, 78.2330017));
            u_xlat3.z = sin(u_xlat13);
            u_xlat3.xyz = u_xlat3.xyz * vec3(20.0, 20.0, 43758.5469);
            u_xlat3.x = dot(u_xlat3.xy, vec2(12.9898005, 78.2330017));
            u_xlat3.x = sin(u_xlat3.x);
            u_xlat3.x = u_xlat3.x * 43758.5469;
            u_xlat3.xz = fract(u_xlat3.xz);
            u_xlat17 = u_xlat17 * 10.0 + u_xlat5;
            u_xlat17 = sin(u_xlat17);
            u_xlat4.x = u_xlat17 * 0.300000012;
            u_xlat17 = u_xlat3.z * 10.0 + u_xlat5;
            u_xlat17 = sin(u_xlat17);
            u_xlat4.y = u_xlat17 * 0.300000012;
            u_xlat5 = u_xlat3.x * 10.0 + u_xlat5;
            u_xlat5 = sin(u_xlat5);
            u_xlat4.z = u_xlat5 * 0.300000012;
            u_xlat3.xyz = u_xlat4.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
            u_xlat0.xzw = u_xlat3.xyz * vec3(u_xlat16_1) + in_TEXCOORD4.xyz;
        }
        u_xlat3.xyz = u_xlat2.yyy * hlslcc_mtx4x4_NonJitteredViewProjMatrix[1].xyw;
        u_xlat2.xyw = hlslcc_mtx4x4_NonJitteredViewProjMatrix[0].xyw * u_xlat2.xxx + u_xlat3.xyz;
        u_xlat2.xyz = hlslcc_mtx4x4_NonJitteredViewProjMatrix[2].xyw * u_xlat2.zzz + u_xlat2.xyw;
        vs_CLIP_POSITION_NO_JITTER0.xyz = u_xlat2.xyz + hlslcc_mtx4x4_NonJitteredViewProjMatrix[3].xyw;
        u_xlat1 = u_xlat0.zzzz * hlslcc_mtx4x4unity_MatrixPreviousM[1];
        u_xlat1 = hlslcc_mtx4x4unity_MatrixPreviousM[0] * u_xlat0.xxxx + u_xlat1;
        u_xlat0 = hlslcc_mtx4x4unity_MatrixPreviousM[2] * u_xlat0.wwww + u_xlat1;
        u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixPreviousM[3];
        u_xlat2.xyz = u_xlat0.yyy * hlslcc_mtx4x4_PrevViewProjMatrix[1].xyw;
        u_xlat2.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[0].xyw * u_xlat0.xxx + u_xlat2.xyz;
        u_xlat0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[2].xyw * u_xlat0.zzz + u_xlat2.xyz;
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[3].xyw * u_xlat0.www + u_xlat0.xyz;
    } else {
        vs_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
    }
    vs_INTERP0 = in_TEXCOORD0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
in highp  vec4 vs_INTERP0;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
float u_xlat4;
bool u_xlatb4;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_1 = dot(vec2(u_xlat16_1), vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_1 = u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat4 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat4) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb4 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb4) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 23: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
in highp  vec4 vs_INTERP0;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
float u_xlat4;
bool u_xlatb4;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_1 = dot(vec2(u_xlat16_1), vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_1 = u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat4 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat4) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb4 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb4) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 24: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
out highp vec3 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    vs_INTERP1.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
in highp  vec3 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_INTERP1.xyz, vs_INTERP1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP1.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 25: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
in highp  vec3 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_INTERP1.xyz, vs_INTERP1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP1.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 26: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
out highp vec3 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    vs_INTERP1.xyz = vec3(u_xlat12) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec3 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_1 = dot(vec2(u_xlat16_1), vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_1 = u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.x = dot(vs_INTERP1.xyz, vs_INTERP1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP1.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 27: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
in highp  vec3 vs_INTERP1;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_1 = dot(vec2(u_xlat16_1), vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_1 = u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    u_xlat0.x = dot(vs_INTERP1.xyz, vs_INTERP1.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP1.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 28: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightDirection;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
highp vec3 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
float u_xlat5;
bool u_xlatb5;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat0.xyz = vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z) * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat1.xyz = vec3(u_xlat12) * u_xlat1.xyz;
    u_xlat12 = dot(vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z), u_xlat1.xyz);
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat12 = (-u_xlat12) + 1.0;
    u_xlat12 = u_xlat12 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat1.xyz * vec3(u_xlat12) + u_xlat0.xyz;
    vs_INTERP1.xyz = u_xlat1.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat5 = roundEven(_ShadowBias.z);
    u_xlatb5 = u_xlat5==1.0;
    u_xlat16_3 = (u_xlatb5) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_3 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    vs_INTERP0 = in_TEXCOORD0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 29: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 30: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightDirection;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
highp vec3 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
float u_xlat5;
bool u_xlatb5;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat0.xyz = vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z) * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat1.xyz = vec3(u_xlat12) * u_xlat1.xyz;
    u_xlat12 = dot(vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z), u_xlat1.xyz);
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat12 = (-u_xlat12) + 1.0;
    u_xlat12 = u_xlat12 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat1.xyz * vec3(u_xlat12) + u_xlat0.xyz;
    vs_INTERP1.xyz = u_xlat1.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat5 = roundEven(_ShadowBias.z);
    u_xlatb5 = u_xlat5==1.0;
    u_xlat16_3 = (u_xlatb5) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_3 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    vs_INTERP0 = in_TEXCOORD0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_1 = dot(vec2(u_xlat16_1), vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_1 = u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 31: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_1 = dot(vec2(u_xlat16_1), vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_1 = u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 32: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightPosition;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
highp vec4 vs_INTERP0;
highp vec3 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
float u_xlat5;
bool u_xlatb5;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + _LightPosition.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat1.xyz = vec3(u_xlat12) * u_xlat1.xyz;
    u_xlat0.xyz = u_xlat1.xyz * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat2.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat2.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat2.xyz = vec3(u_xlat12) * u_xlat2.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat2.xyz);
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat12 = (-u_xlat12) + 1.0;
    u_xlat12 = u_xlat12 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat2.xyz * vec3(u_xlat12) + u_xlat0.xyz;
    vs_INTERP1.xyz = u_xlat2.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat5 = roundEven(_ShadowBias.z);
    u_xlatb5 = u_xlat5==1.0;
    u_xlat16_3 = (u_xlatb5) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_3 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    vs_INTERP0 = in_TEXCOORD0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 33: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 34: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _TimeParameters;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightPosition;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_COLOR0;
out highp vec4 vs_INTERP0;
highp vec3 vs_INTERP1;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat4;
float u_xlat5;
bool u_xlatb5;
vec2 u_xlat8;
float u_xlat12;
void main()
{
    u_xlat0.xy = in_POSITION0.yy * hlslcc_mtx4x4unity_ObjectToWorld[1].xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[0].xy * in_POSITION0.xx + u_xlat0.xy;
    u_xlat0.xy = hlslcc_mtx4x4unity_ObjectToWorld[2].xy * in_POSITION0.zz + u_xlat0.xy;
    u_xlat0.xy = u_xlat0.xy + hlslcc_mtx4x4unity_ObjectToWorld[3].xy;
    u_xlat8.xy = u_xlat0.xy * vec2(20.0, 20.0);
    u_xlat1 = u_xlat0.xyxy * vec4(10.0, 10.0, 15.0, 15.0);
    u_xlat0.x = dot(u_xlat8.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat0.x = u_xlat0.x * 43758.5469;
    u_xlat0.x = fract(u_xlat0.x);
    u_xlat4 = _TimeParameters.x * _WindSpeed;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.x = sin(u_xlat0.x);
    u_xlat2.z = u_xlat0.x * 0.300000012;
    u_xlat0.x = dot(u_xlat1.xy, vec2(12.9898005, 78.2330017));
    u_xlat0.z = dot(u_xlat1.zw, vec2(12.9898005, 78.2330017));
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat0.xz = u_xlat0.xz * vec2(43758.5469, 43758.5469);
    u_xlat0.xz = fract(u_xlat0.xz);
    u_xlat0.z = u_xlat0.z * 10.0 + u_xlat4;
    u_xlat0.x = u_xlat0.x * 10.0 + u_xlat4;
    u_xlat0.xz = sin(u_xlat0.xz);
    u_xlat2.xy = u_xlat0.xz * vec2(0.300000012, 0.300000012);
    u_xlat0.xyz = u_xlat2.xyz * vec3(_windDirection.x, _windDirection.y, _windDirection.z);
    u_xlat16_3 = in_COLOR0.w * _WindStrength;
    u_xlat0.xyz = u_xlat0.xyz * vec3(u_xlat16_3) + in_POSITION0.xyz;
    u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyw = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * u_xlat0.xxx + u_xlat1.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * u_xlat0.zzz + u_xlat0.xyw;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + _LightPosition.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat1.xyz = vec3(u_xlat12) * u_xlat1.xyz;
    u_xlat0.xyz = u_xlat1.xyz * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat2.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat2.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat2.xyz = vec3(u_xlat12) * u_xlat2.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat2.xyz);
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat12 = (-u_xlat12) + 1.0;
    u_xlat12 = u_xlat12 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat2.xyz * vec3(u_xlat12) + u_xlat0.xyz;
    vs_INTERP1.xyz = u_xlat2.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat5 = roundEven(_ShadowBias.z);
    u_xlatb5 = u_xlat5==1.0;
    u_xlat16_3 = (u_xlatb5) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_3 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    vs_INTERP0 = in_TEXCOORD0;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_1 = dot(vec2(u_xlat16_1), vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_1 = u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 35: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_AlphaTex_TexelSize;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_Color;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_BaseTex_TexelSize;
	UNITY_UNIFORM mediump float                _BaseA0_AlphaR1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_VC_Intensity;
	UNITY_UNIFORM mediump float                _BakeAlpha;
	UNITY_UNIFORM mediump float                _WindSpeed;
	UNITY_UNIFORM mediump float                _WindStrength;
	UNITY_UNIFORM mediump vec3                _windDirection;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lightmap_Intensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_GI_FogGolor_Intensity;
	UNITY_UNIFORM mediump vec3 Xhlslcc_UnusedX_PrefabCenterWS;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_PrefabCenter_PlusW;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_SmoothEdge_2;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_LightColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_NormalMap_Noise_TexelSize;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_NormalIntensity;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_WorldNormal_UV;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedX_ShdowColor;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_ShadowSmoothEdge_1;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_Lighting_0Off_1ON;
	UNITY_UNIFORM mediump float Xhlslcc_UnusedX_FogSofLighting;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _AlphaTex;
UNITY_LOCATION(1) uniform mediump sampler2D _BaseTex;
in highp  vec4 vs_INTERP0;
layout(location = 0) out mediump vec4 SV_TARGET0;
mediump float u_xlat16_0;
bool u_xlatb0;
mediump float u_xlat16_1;
mediump float u_xlat16_2;
void main()
{
    u_xlat16_0 = texture(_AlphaTex, vs_INTERP0.xy, _GlobalMipBias.x).x;
    u_xlat16_2 = texture(_BaseTex, vs_INTERP0.xy, _GlobalMipBias.x).w;
    u_xlat16_1 = (-u_xlat16_2) + u_xlat16_0;
    u_xlat16_1 = _BaseA0_AlphaR1 * u_xlat16_1 + u_xlat16_2;
    u_xlat16_1 = dot(vec2(u_xlat16_1), vec2(vec2(_BakeAlpha, _BakeAlpha)));
    u_xlat16_1 = u_xlat16_1 + -0.5;
    u_xlatb0 = u_xlat16_1<0.0;
    if(u_xlatb0){discard;}
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif

