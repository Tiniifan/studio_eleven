#version 150
#define attribute in
#define varying out
precision mediump float;
precision mediump int;
uniform vec4 unf_vtx_cmr_prj[4];
uniform vec4 unf_vtx_glb_cmr[3];
uniform vec4 unf_vtx_lcl_glb[3];
uniform vec4 unf_vtx_txt[6];
uniform vec4 unf_vtx_clr;
attribute vec4 atr_pos;
attribute vec4 atr_clr;
attribute vec3 atr_nrm;
attribute vec3 atr_tng;
attribute vec4 atr_tx0;
attribute vec4 atr_pr0;
attribute vec4 atr_pr1;
attribute vec4 atr_pr2;
varying vec4 var_clr;
varying vec4 var_nrm;
varying vec4 var_tng;
varying vec4 var_tx0;
varying vec4 var_tx1;
varying vec4 var_tx2;
varying vec4 var_prm;
varying vec4 var_gen;

void main() {
    vec4 w_tmp;
    w_tmp.x = dot(atr_pos.xyz, unf_vtx_lcl_glb[0].xyz) + unf_vtx_lcl_glb[0].w;
    w_tmp.y = dot(atr_pos.xyz, unf_vtx_lcl_glb[1].xyz) + unf_vtx_lcl_glb[1].w;
    w_tmp.z = dot(atr_pos.xyz, unf_vtx_lcl_glb[2].xyz) + unf_vtx_lcl_glb[2].w;
    w_tmp.w = 1.000000;
    vec4 v_tmp;
    v_tmp.x = dot(w_tmp.xyz, unf_vtx_glb_cmr[0].xyz) + unf_vtx_glb_cmr[0].w;
    v_tmp.y = dot(w_tmp.xyz, unf_vtx_glb_cmr[1].xyz) + unf_vtx_glb_cmr[1].w;
    v_tmp.z = dot(w_tmp.xyz, unf_vtx_glb_cmr[2].xyz) + unf_vtx_glb_cmr[2].w;
    v_tmp.w = 1.000000;
    gl_Position.x = dot(v_tmp, unf_vtx_cmr_prj[0]);
    gl_Position.y = dot(v_tmp, unf_vtx_cmr_prj[1]);
    gl_Position.z = dot(v_tmp, unf_vtx_cmr_prj[2]);
    gl_Position.w = dot(v_tmp, unf_vtx_cmr_prj[3]);
    var_clr = unf_vtx_clr * atr_clr * 0.500000;
    var_tx0.x = dot(atr_tx0, unf_vtx_txt[0]);
    var_tx0.y = dot(atr_tx0, unf_vtx_txt[1]);
    var_tx0.z = 0.000000;
    var_tx0.w = 0.000000;
    vec4 txt = vec4(0.500000, 0.500000, 0.000000, 1.000000);
    var_tx2.x = dot(txt, unf_vtx_txt[4]);
    var_tx2.y = dot(txt, unf_vtx_txt[5]);
    var_tx2.z = 0.000000;
    var_tx2.w = 0.000000;
    txt.y += atr_tx0.z;
    var_tx1.x = dot(txt, unf_vtx_txt[2]);
    var_tx1.y = dot(txt, unf_vtx_txt[3]);
    var_tx1.z = 0.000000;
    var_tx1.w = 0.000000;
    var_nrm = vec4(0.000000, 0.000000, 0.000000, 0.000000);
    var_tng = vec4(0.000000, 0.000000, 0.000000, 0.000000);
    var_prm = vec4(0.000000, 0.000000, 0.000000, 0.000000);
    var_gen = vec4(0.000000, 0.000000, 0.000000, 0.000000);
}
