// BackGround/BG_Unlit_Sky (Shader path ID -4126464957174484792, CAB-12ec70e4e3e31653e4f80978f3841e82)

// ===== program 0: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
in highp vec4 in_TEXCOORD0;
in highp vec4 in_TEXCOORD1;
in highp vec4 in_TEXCOORD2;
in highp vec4 in_TEXCOORD3;
out highp vec4 vs_INTERP0;
out highp vec4 vs_INTERP1;
out highp vec4 vs_INTERP2;
out highp vec4 vs_INTERP3;
out highp vec3 vs_INTERP4;
highp vec3 vs_INTERP5;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    vs_INTERP4.xyz = u_xlat0.xyz;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    vs_INTERP0 = in_TEXCOORD0;
    vs_INTERP1 = in_TEXCOORD1;
    vs_INTERP2 = in_TEXCOORD2;
    vs_INTERP3 = in_TEXCOORD3;
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP5.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _TimeParameters;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CloudTex_1_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CloudTex_2_TexelSize;
	UNITY_UNIFORM mediump vec2                _CloudTilling_1;
	UNITY_UNIFORM mediump float                _CloudOffset_1;
	UNITY_UNIFORM mediump vec2                _CloudTilling_2;
	UNITY_UNIFORM mediump float                _CloudOffset_2;
	UNITY_UNIFORM mediump vec2                _CloudTilling_3;
	UNITY_UNIFORM mediump float                _CloudOffset_3;
	UNITY_UNIFORM mediump vec2                _ColudTilling_4;
	UNITY_UNIFORM mediump float                _CloudOffset_4;
	UNITY_UNIFORM mediump float                _Cloud_Scroll_3;
	UNITY_UNIFORM mediump float                _Cloud_Scroll_4;
	UNITY_UNIFORM mediump vec4                _SkyColor_1;
	UNITY_UNIFORM mediump vec4                _SkyColor_2;
	UNITY_UNIFORM mediump float                _HorizonPosition;
	UNITY_UNIFORM mediump float                _SkyPower;
	UNITY_UNIFORM mediump vec4                _HorizonColor;
	UNITY_UNIFORM mediump vec4                _CloudColor;
	UNITY_UNIFORM mediump float                _HorizonPower;
	UNITY_UNIFORM mediump float                _Cloud_Scroll_1;
	UNITY_UNIFORM mediump float                _Cloud_Scroll_2;
	UNITY_UNIFORM mediump float                _SkyCloud_Power;
	UNITY_UNIFORM mediump float                _CloudEdgeNoise;
	UNITY_UNIFORM mediump vec4                _Cloud_Shadow;
	UNITY_UNIFORM mediump vec4                _SkyCloud_Color;
	UNITY_UNIFORM mediump float                _SkyCloud_Tiling;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_Cloud_Noise_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SunTexture_TexelSize;
	UNITY_UNIFORM mediump vec2                _Sun_Offset;
	UNITY_UNIFORM mediump float                _Sun_Tilling;
	UNITY_UNIFORM mediump float                _Halow_Intensity;
	UNITY_UNIFORM mediump vec4                _Sun_Color;
	UNITY_UNIFORM mediump float                _Sun_Intensity_B;
	UNITY_UNIFORM mediump vec2                _Flare_Scale;
	UNITY_UNIFORM mediump float                _Sun_Intensity_G;
	UNITY_UNIFORM mediump float                _SkyNoisePower;
	UNITY_UNIFORM mediump vec4                _Flare_Color;
	UNITY_UNIFORM mediump vec2                _Flare_Position;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _CloudTex_1;
UNITY_LOCATION(1) uniform mediump sampler2D _CloudTex_2;
UNITY_LOCATION(2) uniform mediump sampler2D _Cloud_Noise;
UNITY_LOCATION(3) uniform mediump sampler2D _SunTexture;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec4 vs_INTERP2;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec2 u_xlat16_0;
vec4 u_xlat1;
mediump vec3 u_xlat16_1;
vec3 u_xlat2;
vec3 u_xlat3;
mediump vec2 u_xlat16_3;
vec3 u_xlat4;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
vec4 u_xlat6;
mediump vec2 u_xlat16_6;
vec3 u_xlat7;
mediump vec2 u_xlat16_8;
float u_xlat9;
float u_xlat10;
mediump float u_xlat16_16;
float u_xlat17;
vec2 u_xlat22;
float u_xlat25;
mediump float u_xlat16_25;
float u_xlat26;
bool u_xlatb26;
void main()
{
    u_xlat16_0.xy = vs_INTERP2.xy * vec2(_SkyCloud_Tiling);
    u_xlat16_1.xyz = texture(_Cloud_Noise, u_xlat16_0.xy).yzw;
    u_xlat16_0.x = (-u_xlat16_1.x) + 1.0;
    u_xlat16_0.x = float(1.0) / u_xlat16_0.x;
    u_xlat16_8.x = (-u_xlat16_1.x) + _SkyCloud_Power;
    u_xlat16_0.x = u_xlat16_0.x * u_xlat16_8.x;
    u_xlat16_0.x = clamp(u_xlat16_0.x, 0.0, 1.0);
    u_xlat16_8.x = u_xlat16_0.x * -2.0 + 3.0;
    u_xlat16_0.x = u_xlat16_0.x * u_xlat16_0.x;
    u_xlat16_0.x = u_xlat16_0.x * u_xlat16_8.x;
    u_xlat1.x = log2(_SkyPower);
    u_xlat25 = dot(vs_INTERP4.xyz, vs_INTERP4.xyz);
    u_xlat25 = inversesqrt(u_xlat25);
    u_xlat2.x = vs_INTERP4.y * u_xlat25 + _HorizonPosition;
    u_xlat25 = u_xlat25 * vs_INTERP4.y;
    u_xlat10 = u_xlat2.x;
    u_xlat10 = clamp(u_xlat10, 0.0, 1.0);
    u_xlat2.x = u_xlat2.x + 0.150000006;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat2.xz = (-u_xlat2.xx) + vec2(1.0, 0.519999981);
    u_xlat1.x = u_xlat1.x * u_xlat10;
    u_xlat1.x = exp2(u_xlat1.x);
    u_xlat3.xyz = unity_FogColor.xyz + (-_SkyColor_1.xyz);
    u_xlat3.xyz = u_xlat1.xxx * u_xlat3.xyz + _SkyColor_1.xyz;
    u_xlat16_8.xy = vec2(vec2(_Sun_Tilling, _Sun_Tilling)) * vs_INTERP3.xy + _Sun_Offset.xy;
    u_xlat16_4.xyz = texture(_SunTexture, u_xlat16_8.xy, _GlobalMipBias.x).xyz;
    u_xlat16_8.x = dot(u_xlat16_4.zy, vec2(_Sun_Intensity_B, _Sun_Intensity_G));
    u_xlat16_5.xyz = u_xlat16_4.xxx * _Sun_Color.xyz;
    u_xlat3.xyz = _Sun_Color.xyz * u_xlat16_8.xxx + u_xlat3.xyz;
    u_xlat16_8.xy = vs_INTERP2.xy * vec2(_SkyCloud_Tiling) + vec2(0.949999988, 0.949999988);
    u_xlat16_1.x = texture(_Cloud_Noise, u_xlat16_8.xy).y;
    u_xlat16_8.x = u_xlat16_1.y * u_xlat16_1.x;
    u_xlat16_1.xy = texture(_Cloud_Noise, vs_INTERP0.xy).xw;
    u_xlat16_16 = u_xlat16_1.x + _SkyNoisePower;
    u_xlat25 = u_xlat16_16 * u_xlat25;
    u_xlat25 = clamp(u_xlat25, 0.0, 1.0);
    u_xlat4.xyz = (-unity_FogColor.xyz) + _SkyColor_2.xyz;
    u_xlat4.xyz = vec3(u_xlat25) * u_xlat4.xyz + unity_FogColor.xyz;
    u_xlat6.xyz = u_xlat4.xyz + (-_SkyCloud_Color.xyz);
    u_xlat4.xyz = u_xlat4.xyz + (-_Cloud_Shadow.xyz);
    u_xlat6.xyz = u_xlat16_8.xxx * u_xlat6.xyz + _SkyCloud_Color.xyz;
    u_xlat3.xyz = (-_CloudColor.xyz) * u_xlat6.xyz + u_xlat3.xyz;
    u_xlat6.xyz = u_xlat6.xyz * _CloudColor.xyz;
    u_xlat3.xyz = u_xlat16_0.xxx * u_xlat3.xyz + u_xlat6.xyz;
    u_xlat16_0.x = vs_INTERP1.x * _CloudTilling_3.x;
    u_xlat25 = _TimeParameters.x * 9.99999975e-05;
    u_xlatb26 = u_xlat25>=(-u_xlat25);
    u_xlat25 = fract(abs(u_xlat25));
    u_xlat25 = (u_xlatb26) ? u_xlat25 : (-u_xlat25);
    u_xlat25 = u_xlat25 * 10.0;
    u_xlat6.x = _Cloud_Scroll_3 * u_xlat25 + u_xlat16_0.x;
    u_xlat6.y = vs_INTERP1.y * _CloudTilling_3.y + _CloudOffset_3;
    u_xlat16_6.xy = texture(_CloudTex_2, u_xlat6.xy).zw;
    u_xlat6.xzw = u_xlat16_6.xxx * u_xlat4.xyz + _Cloud_Shadow.xyz;
    u_xlat6.xzw = u_xlat6.xzw * _CloudColor.xyz + (-u_xlat3.xyz);
    u_xlat3.xyz = u_xlat16_6.yyy * u_xlat6.xzw + u_xlat3.xyz;
    u_xlat26 = vs_INTERP1.x * _ColudTilling_4.x;
    u_xlat6.x = u_xlat25 * _Cloud_Scroll_4 + u_xlat26;
    u_xlat22.xy = vec2(u_xlat25) * vec2(_Cloud_Scroll_1, _Cloud_Scroll_2);
    u_xlat6.y = vs_INTERP1.y * _ColudTilling_4.y + _CloudOffset_4;
    u_xlat16_6.xy = texture(_CloudTex_2, u_xlat6.xy).xy;
    u_xlat7.xyz = u_xlat16_6.xxx * u_xlat4.xyz + _Cloud_Shadow.xyz;
    u_xlat7.xyz = _CloudColor.xyz * u_xlat7.xyz + (-u_xlat3.xyz);
    u_xlat3.xyz = u_xlat16_6.yyy * u_xlat7.xyz + u_xlat3.xyz;
    u_xlat6.x = vs_INTERP0.x * _CloudTilling_1.x + u_xlat22.x;
    u_xlat7.x = vs_INTERP0.x * _CloudTilling_2.x + u_xlat22.y;
    u_xlat6.y = vs_INTERP0.y * _CloudTilling_1.y + _CloudOffset_1;
    u_xlat16_6.xy = texture(_CloudTex_1, u_xlat6.xy).zw;
    u_xlat9 = u_xlat16_1.y + u_xlat16_6.x;
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat16_0.x = log2(u_xlat16_1.x);
    u_xlat16_0.x = u_xlat16_0.x * _CloudEdgeNoise;
    u_xlat16_0.x = exp2(u_xlat16_0.x);
    u_xlat1.xyw = vec3(u_xlat9) * u_xlat4.xyz + _Cloud_Shadow.xyz;
    u_xlat1.xyw = u_xlat1.xyw * _CloudColor.xyz + (-u_xlat3.xyz);
    u_xlat1.xyw = u_xlat16_6.yyy * u_xlat1.xyw + u_xlat3.xyz;
    u_xlat7.y = vs_INTERP0.y * _CloudTilling_2.y + _CloudOffset_2;
    u_xlat16_3.xy = texture(_CloudTex_1, u_xlat7.xy).xy;
    u_xlat17 = u_xlat16_1.z + u_xlat16_3.x;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat4.xyz = vec3(u_xlat17) * u_xlat4.xyz + _Cloud_Shadow.xyz;
    u_xlat4.xyz = _CloudColor.xyz * u_xlat4.xyz + (-u_xlat1.xyw);
    u_xlat17 = u_xlat16_0.x * u_xlat16_3.x;
    u_xlat17 = u_xlat16_3.y * 0.800000012 + u_xlat17;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat1.xyz = vec3(u_xlat17) * u_xlat4.xyz + u_xlat1.xyw;
    u_xlat1.xyz = clamp(u_xlat1.xyz, 0.0, 1.0);
    u_xlat1.xyz = u_xlat16_5.xyz * vec3(vec3(_Halow_Intensity, _Halow_Intensity, _Halow_Intensity)) + u_xlat1.xyz;
    u_xlat3.xyz = (-u_xlat1.xyz) + _HorizonColor.xyz;
    u_xlat25 = float(1.0) / u_xlat2.x;
    u_xlat25 = u_xlat25 * u_xlat2.z;
    u_xlat25 = clamp(u_xlat25, 0.0, 1.0);
    u_xlat2.x = u_xlat25 * -2.0 + 3.0;
    u_xlat25 = u_xlat25 * u_xlat25;
    u_xlat25 = u_xlat25 * u_xlat2.x;
    u_xlat25 = u_xlat25 * u_xlat10;
    u_xlat25 = log2(u_xlat25);
    u_xlat25 = u_xlat25 * _HorizonPower;
    u_xlat25 = exp2(u_xlat25);
    u_xlat1.xyz = vec3(u_xlat25) * u_xlat3.xyz + u_xlat1.xyz;
    u_xlat2.xyz = (-u_xlat1.xyz) + _Flare_Color.xyz;
    u_xlat3.xy = vs_INTERP4.yy * hlslcc_mtx4x4unity_MatrixV[1].xy;
    u_xlat3.xy = hlslcc_mtx4x4unity_MatrixV[0].xy * vs_INTERP4.xx + u_xlat3.xy;
    u_xlat3.xy = hlslcc_mtx4x4unity_MatrixV[2].xy * vs_INTERP4.zz + u_xlat3.xy;
    u_xlat3.xy = u_xlat3.xy + hlslcc_mtx4x4unity_MatrixV[3].xy;
    u_xlat16_0.x = dot(hlslcc_mtx4x4unity_ObjectToWorld[2].xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_0.x = sqrt(u_xlat16_0.x);
    u_xlat3.xy = u_xlat3.xy / u_xlat16_0.xx;
    u_xlat16_0.xy = _Flare_Position.xy + vec2(340.0, 154.0);
    u_xlat3.xy = u_xlat3.xy + u_xlat16_0.xy;
    u_xlat3.xy = u_xlat3.xy * vec2(9.99999975e-05, 9.99999975e-05);
    u_xlat3.xy = u_xlat3.xy * vec2(_Flare_Scale.x, _Flare_Scale.y);
    u_xlat3.xy = clamp(u_xlat3.xy, 0.0, 1.0);
    u_xlat16_25 = texture(_SunTexture, u_xlat3.xy, _GlobalMipBias.x).z;
    u_xlat1.xyz = vec3(u_xlat16_25) * u_xlat2.xyz + u_xlat1.xyz;
    SV_Target0.xyz = u_xlat1.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 1: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _TimeParameters;
uniform 	mediump vec4 unity_FogColor;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixV[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(1) uniform UnityPerMaterial {
#endif
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CloudTex_1_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_CloudTex_2_TexelSize;
	UNITY_UNIFORM mediump vec2                _CloudTilling_1;
	UNITY_UNIFORM mediump float                _CloudOffset_1;
	UNITY_UNIFORM mediump vec2                _CloudTilling_2;
	UNITY_UNIFORM mediump float                _CloudOffset_2;
	UNITY_UNIFORM mediump vec2                _CloudTilling_3;
	UNITY_UNIFORM mediump float                _CloudOffset_3;
	UNITY_UNIFORM mediump vec2                _ColudTilling_4;
	UNITY_UNIFORM mediump float                _CloudOffset_4;
	UNITY_UNIFORM mediump float                _Cloud_Scroll_3;
	UNITY_UNIFORM mediump float                _Cloud_Scroll_4;
	UNITY_UNIFORM mediump vec4                _SkyColor_1;
	UNITY_UNIFORM mediump vec4                _SkyColor_2;
	UNITY_UNIFORM mediump float                _HorizonPosition;
	UNITY_UNIFORM mediump float                _SkyPower;
	UNITY_UNIFORM mediump vec4                _HorizonColor;
	UNITY_UNIFORM mediump vec4                _CloudColor;
	UNITY_UNIFORM mediump float                _HorizonPower;
	UNITY_UNIFORM mediump float                _Cloud_Scroll_1;
	UNITY_UNIFORM mediump float                _Cloud_Scroll_2;
	UNITY_UNIFORM mediump float                _SkyCloud_Power;
	UNITY_UNIFORM mediump float                _CloudEdgeNoise;
	UNITY_UNIFORM mediump vec4                _Cloud_Shadow;
	UNITY_UNIFORM mediump vec4                _SkyCloud_Color;
	UNITY_UNIFORM mediump float                _SkyCloud_Tiling;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_Cloud_Noise_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedX_SunTexture_TexelSize;
	UNITY_UNIFORM mediump vec2                _Sun_Offset;
	UNITY_UNIFORM mediump float                _Sun_Tilling;
	UNITY_UNIFORM mediump float                _Halow_Intensity;
	UNITY_UNIFORM mediump vec4                _Sun_Color;
	UNITY_UNIFORM mediump float                _Sun_Intensity_B;
	UNITY_UNIFORM mediump vec2                _Flare_Scale;
	UNITY_UNIFORM mediump float                _Sun_Intensity_G;
	UNITY_UNIFORM mediump float                _SkyNoisePower;
	UNITY_UNIFORM mediump vec4                _Flare_Color;
	UNITY_UNIFORM mediump vec2                _Flare_Position;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_ST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_TexelSize;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_MipInfo;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MipmapStreaming_DebugTex_StreamInfo;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D _CloudTex_1;
UNITY_LOCATION(1) uniform mediump sampler2D _CloudTex_2;
UNITY_LOCATION(2) uniform mediump sampler2D _Cloud_Noise;
UNITY_LOCATION(3) uniform mediump sampler2D _SunTexture;
in highp  vec4 vs_INTERP0;
in highp  vec4 vs_INTERP1;
in highp  vec4 vs_INTERP2;
in highp  vec4 vs_INTERP3;
in highp  vec3 vs_INTERP4;
layout(location = 0) out mediump vec4 SV_Target0;
mediump vec2 u_xlat16_0;
vec4 u_xlat1;
mediump vec3 u_xlat16_1;
vec3 u_xlat2;
vec3 u_xlat3;
mediump vec2 u_xlat16_3;
vec3 u_xlat4;
mediump vec3 u_xlat16_4;
mediump vec3 u_xlat16_5;
vec4 u_xlat6;
mediump vec2 u_xlat16_6;
vec3 u_xlat7;
mediump vec2 u_xlat16_8;
float u_xlat9;
float u_xlat10;
mediump float u_xlat16_16;
float u_xlat17;
vec2 u_xlat22;
float u_xlat25;
mediump float u_xlat16_25;
float u_xlat26;
bool u_xlatb26;
void main()
{
    u_xlat16_0.xy = vs_INTERP2.xy * vec2(_SkyCloud_Tiling);
    u_xlat16_1.xyz = texture(_Cloud_Noise, u_xlat16_0.xy).yzw;
    u_xlat16_0.x = (-u_xlat16_1.x) + 1.0;
    u_xlat16_0.x = float(1.0) / u_xlat16_0.x;
    u_xlat16_8.x = (-u_xlat16_1.x) + _SkyCloud_Power;
    u_xlat16_0.x = u_xlat16_0.x * u_xlat16_8.x;
    u_xlat16_0.x = clamp(u_xlat16_0.x, 0.0, 1.0);
    u_xlat16_8.x = u_xlat16_0.x * -2.0 + 3.0;
    u_xlat16_0.x = u_xlat16_0.x * u_xlat16_0.x;
    u_xlat16_0.x = u_xlat16_0.x * u_xlat16_8.x;
    u_xlat1.x = log2(_SkyPower);
    u_xlat25 = dot(vs_INTERP4.xyz, vs_INTERP4.xyz);
    u_xlat25 = inversesqrt(u_xlat25);
    u_xlat2.x = vs_INTERP4.y * u_xlat25 + _HorizonPosition;
    u_xlat25 = u_xlat25 * vs_INTERP4.y;
    u_xlat10 = u_xlat2.x;
    u_xlat10 = clamp(u_xlat10, 0.0, 1.0);
    u_xlat2.x = u_xlat2.x + 0.150000006;
    u_xlat2.x = clamp(u_xlat2.x, 0.0, 1.0);
    u_xlat2.xz = (-u_xlat2.xx) + vec2(1.0, 0.519999981);
    u_xlat1.x = u_xlat1.x * u_xlat10;
    u_xlat1.x = exp2(u_xlat1.x);
    u_xlat3.xyz = unity_FogColor.xyz + (-_SkyColor_1.xyz);
    u_xlat3.xyz = u_xlat1.xxx * u_xlat3.xyz + _SkyColor_1.xyz;
    u_xlat16_8.xy = vec2(vec2(_Sun_Tilling, _Sun_Tilling)) * vs_INTERP3.xy + _Sun_Offset.xy;
    u_xlat16_4.xyz = texture(_SunTexture, u_xlat16_8.xy, _GlobalMipBias.x).xyz;
    u_xlat16_8.x = dot(u_xlat16_4.zy, vec2(_Sun_Intensity_B, _Sun_Intensity_G));
    u_xlat16_5.xyz = u_xlat16_4.xxx * _Sun_Color.xyz;
    u_xlat3.xyz = _Sun_Color.xyz * u_xlat16_8.xxx + u_xlat3.xyz;
    u_xlat16_8.xy = vs_INTERP2.xy * vec2(_SkyCloud_Tiling) + vec2(0.949999988, 0.949999988);
    u_xlat16_1.x = texture(_Cloud_Noise, u_xlat16_8.xy).y;
    u_xlat16_8.x = u_xlat16_1.y * u_xlat16_1.x;
    u_xlat16_1.xy = texture(_Cloud_Noise, vs_INTERP0.xy).xw;
    u_xlat16_16 = u_xlat16_1.x + _SkyNoisePower;
    u_xlat25 = u_xlat16_16 * u_xlat25;
    u_xlat25 = clamp(u_xlat25, 0.0, 1.0);
    u_xlat4.xyz = (-unity_FogColor.xyz) + _SkyColor_2.xyz;
    u_xlat4.xyz = vec3(u_xlat25) * u_xlat4.xyz + unity_FogColor.xyz;
    u_xlat6.xyz = u_xlat4.xyz + (-_SkyCloud_Color.xyz);
    u_xlat4.xyz = u_xlat4.xyz + (-_Cloud_Shadow.xyz);
    u_xlat6.xyz = u_xlat16_8.xxx * u_xlat6.xyz + _SkyCloud_Color.xyz;
    u_xlat3.xyz = (-_CloudColor.xyz) * u_xlat6.xyz + u_xlat3.xyz;
    u_xlat6.xyz = u_xlat6.xyz * _CloudColor.xyz;
    u_xlat3.xyz = u_xlat16_0.xxx * u_xlat3.xyz + u_xlat6.xyz;
    u_xlat16_0.x = vs_INTERP1.x * _CloudTilling_3.x;
    u_xlat25 = _TimeParameters.x * 9.99999975e-05;
    u_xlatb26 = u_xlat25>=(-u_xlat25);
    u_xlat25 = fract(abs(u_xlat25));
    u_xlat25 = (u_xlatb26) ? u_xlat25 : (-u_xlat25);
    u_xlat25 = u_xlat25 * 10.0;
    u_xlat6.x = _Cloud_Scroll_3 * u_xlat25 + u_xlat16_0.x;
    u_xlat6.y = vs_INTERP1.y * _CloudTilling_3.y + _CloudOffset_3;
    u_xlat16_6.xy = texture(_CloudTex_2, u_xlat6.xy).zw;
    u_xlat6.xzw = u_xlat16_6.xxx * u_xlat4.xyz + _Cloud_Shadow.xyz;
    u_xlat6.xzw = u_xlat6.xzw * _CloudColor.xyz + (-u_xlat3.xyz);
    u_xlat3.xyz = u_xlat16_6.yyy * u_xlat6.xzw + u_xlat3.xyz;
    u_xlat26 = vs_INTERP1.x * _ColudTilling_4.x;
    u_xlat6.x = u_xlat25 * _Cloud_Scroll_4 + u_xlat26;
    u_xlat22.xy = vec2(u_xlat25) * vec2(_Cloud_Scroll_1, _Cloud_Scroll_2);
    u_xlat6.y = vs_INTERP1.y * _ColudTilling_4.y + _CloudOffset_4;
    u_xlat16_6.xy = texture(_CloudTex_2, u_xlat6.xy).xy;
    u_xlat7.xyz = u_xlat16_6.xxx * u_xlat4.xyz + _Cloud_Shadow.xyz;
    u_xlat7.xyz = _CloudColor.xyz * u_xlat7.xyz + (-u_xlat3.xyz);
    u_xlat3.xyz = u_xlat16_6.yyy * u_xlat7.xyz + u_xlat3.xyz;
    u_xlat6.x = vs_INTERP0.x * _CloudTilling_1.x + u_xlat22.x;
    u_xlat7.x = vs_INTERP0.x * _CloudTilling_2.x + u_xlat22.y;
    u_xlat6.y = vs_INTERP0.y * _CloudTilling_1.y + _CloudOffset_1;
    u_xlat16_6.xy = texture(_CloudTex_1, u_xlat6.xy).zw;
    u_xlat9 = u_xlat16_1.y + u_xlat16_6.x;
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat16_0.x = log2(u_xlat16_1.x);
    u_xlat16_0.x = u_xlat16_0.x * _CloudEdgeNoise;
    u_xlat16_0.x = exp2(u_xlat16_0.x);
    u_xlat1.xyw = vec3(u_xlat9) * u_xlat4.xyz + _Cloud_Shadow.xyz;
    u_xlat1.xyw = u_xlat1.xyw * _CloudColor.xyz + (-u_xlat3.xyz);
    u_xlat1.xyw = u_xlat16_6.yyy * u_xlat1.xyw + u_xlat3.xyz;
    u_xlat7.y = vs_INTERP0.y * _CloudTilling_2.y + _CloudOffset_2;
    u_xlat16_3.xy = texture(_CloudTex_1, u_xlat7.xy).xy;
    u_xlat17 = u_xlat16_1.z + u_xlat16_3.x;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat4.xyz = vec3(u_xlat17) * u_xlat4.xyz + _Cloud_Shadow.xyz;
    u_xlat4.xyz = _CloudColor.xyz * u_xlat4.xyz + (-u_xlat1.xyw);
    u_xlat17 = u_xlat16_0.x * u_xlat16_3.x;
    u_xlat17 = u_xlat16_3.y * 0.800000012 + u_xlat17;
    u_xlat17 = clamp(u_xlat17, 0.0, 1.0);
    u_xlat1.xyz = vec3(u_xlat17) * u_xlat4.xyz + u_xlat1.xyw;
    u_xlat1.xyz = clamp(u_xlat1.xyz, 0.0, 1.0);
    u_xlat1.xyz = u_xlat16_5.xyz * vec3(vec3(_Halow_Intensity, _Halow_Intensity, _Halow_Intensity)) + u_xlat1.xyz;
    u_xlat3.xyz = (-u_xlat1.xyz) + _HorizonColor.xyz;
    u_xlat25 = float(1.0) / u_xlat2.x;
    u_xlat25 = u_xlat25 * u_xlat2.z;
    u_xlat25 = clamp(u_xlat25, 0.0, 1.0);
    u_xlat2.x = u_xlat25 * -2.0 + 3.0;
    u_xlat25 = u_xlat25 * u_xlat25;
    u_xlat25 = u_xlat25 * u_xlat2.x;
    u_xlat25 = u_xlat25 * u_xlat10;
    u_xlat25 = log2(u_xlat25);
    u_xlat25 = u_xlat25 * _HorizonPower;
    u_xlat25 = exp2(u_xlat25);
    u_xlat1.xyz = vec3(u_xlat25) * u_xlat3.xyz + u_xlat1.xyz;
    u_xlat2.xyz = (-u_xlat1.xyz) + _Flare_Color.xyz;
    u_xlat3.xy = vs_INTERP4.yy * hlslcc_mtx4x4unity_MatrixV[1].xy;
    u_xlat3.xy = hlslcc_mtx4x4unity_MatrixV[0].xy * vs_INTERP4.xx + u_xlat3.xy;
    u_xlat3.xy = hlslcc_mtx4x4unity_MatrixV[2].xy * vs_INTERP4.zz + u_xlat3.xy;
    u_xlat3.xy = u_xlat3.xy + hlslcc_mtx4x4unity_MatrixV[3].xy;
    u_xlat16_0.x = dot(hlslcc_mtx4x4unity_ObjectToWorld[2].xyz, hlslcc_mtx4x4unity_ObjectToWorld[2].xyz);
    u_xlat16_0.x = sqrt(u_xlat16_0.x);
    u_xlat3.xy = u_xlat3.xy / u_xlat16_0.xx;
    u_xlat16_0.xy = _Flare_Position.xy + vec2(340.0, 154.0);
    u_xlat3.xy = u_xlat3.xy + u_xlat16_0.xy;
    u_xlat3.xy = u_xlat3.xy * vec2(9.99999975e-05, 9.99999975e-05);
    u_xlat3.xy = u_xlat3.xy * vec2(_Flare_Scale.x, _Flare_Scale.y);
    u_xlat3.xy = clamp(u_xlat3.xy, 0.0, 1.0);
    u_xlat16_25 = texture(_SunTexture, u_xlat3.xy, _GlobalMipBias.x).z;
    u_xlat1.xyz = vec3(u_xlat16_25) * u_xlat2.xyz + u_xlat1.xyz;
    SV_Target0.xyz = u_xlat1.xyz;
    SV_Target0.w = 1.0;
    return;
}

#endif


// ===== program 2: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
vec4 u_xlat0;
vec4 u_xlat1;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 3: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
vec4 hlslcc_FragCoord = vec4(gl_FragCoord.xyz, 1.0/gl_FragCoord.w);
    SV_TARGET0 = hlslcc_FragCoord.zzzz;
    return;
}

#endif


// ===== program 4: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 hlslcc_mtx4x4_PrevViewProjMatrix[4];
uniform 	vec4 hlslcc_mtx4x4_NonJitteredViewProjMatrix[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_TEXCOORD4;
out highp vec3 vs_CLIP_POSITION_NO_JITTER0;
out highp vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
bool u_xlatb9;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat1 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlatb9 = unity_MotionVectorsParams.y!=0.0;
    if(u_xlatb9){
        u_xlatb9 = unity_MotionVectorsParams.x==1.0;
        u_xlat1.xyz = (bool(u_xlatb9)) ? in_TEXCOORD4.xyz : in_POSITION0.xyz;
        u_xlat2.xyz = u_xlat0.yyy * hlslcc_mtx4x4_NonJitteredViewProjMatrix[1].xyw;
        u_xlat0.xyw = hlslcc_mtx4x4_NonJitteredViewProjMatrix[0].xyw * u_xlat0.xxx + u_xlat2.xyz;
        u_xlat0.xyz = hlslcc_mtx4x4_NonJitteredViewProjMatrix[2].xyw * u_xlat0.zzz + u_xlat0.xyw;
        vs_CLIP_POSITION_NO_JITTER0.xyz = u_xlat0.xyz + hlslcc_mtx4x4_NonJitteredViewProjMatrix[3].xyw;
        u_xlat0 = u_xlat1.yyyy * hlslcc_mtx4x4unity_MatrixPreviousM[1];
        u_xlat0 = hlslcc_mtx4x4unity_MatrixPreviousM[0] * u_xlat1.xxxx + u_xlat0;
        u_xlat0 = hlslcc_mtx4x4unity_MatrixPreviousM[2] * u_xlat1.zzzz + u_xlat0;
        u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixPreviousM[3];
        u_xlat1.xyz = u_xlat0.yyy * hlslcc_mtx4x4_PrevViewProjMatrix[1].xyw;
        u_xlat1.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[0].xyw * u_xlat0.xxx + u_xlat1.xyz;
        u_xlat0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[2].xyw * u_xlat0.zzz + u_xlat1.xyz;
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = hlslcc_mtx4x4_PrevViewProjMatrix[3].xyw * u_xlat0.www + u_xlat0.xyz;
    } else {
        vs_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
        vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xyz = vec3(0.0, 0.0, 0.0);
    }
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
float u_xlat2;
bool u_xlatb2;
void main()
{
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat2 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat2) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb2 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb2) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 5: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4                unity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp  vec3 vs_CLIP_POSITION_NO_JITTER0;
in highp  vec3 vs_PREVIOUS_CLIP_POSITION_NO_JITTER0;
layout(location = 0) out highp vec4 SV_Target0;
vec2 u_xlat0;
float u_xlat2;
bool u_xlatb2;
void main()
{
    u_xlat0.x = float(1.0) / float(vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = u_xlat0.xx * vs_PREVIOUS_CLIP_POSITION_NO_JITTER0.xy;
    u_xlat2 = float(1.0) / float(vs_CLIP_POSITION_NO_JITTER0.z);
    u_xlat0.xy = vs_CLIP_POSITION_NO_JITTER0.xy * vec2(u_xlat2) + (-u_xlat0.xy);
    u_xlat0.xy = u_xlat0.xy * vec2(0.5, 0.5);
    u_xlatb2 = unity_MotionVectorsParams.y!=0.0;
    SV_Target0.xy = bool(u_xlatb2) ? u_xlat0.xy : vec2(0.0, 0.0);
    SV_Target0.zw = vec2(0.0, 0.0);
    return;
}

#endif


// ===== program 6: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
out highp vec3 vs_INTERP0;
vec4 u_xlat0;
vec4 u_xlat1;
float u_xlat6;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    gl_Position = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat0.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat0.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat0.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat6 = dot(u_xlat0.xyz, u_xlat0.xyz);
    u_xlat6 = max(u_xlat6, 1.17549435e-38);
    u_xlat6 = inversesqrt(u_xlat6);
    vs_INTERP0.xyz = vec3(u_xlat6) * u_xlat0.xyz;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
in highp  vec3 vs_INTERP0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_INTERP0.xyz, vs_INTERP0.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 7: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
in highp  vec3 vs_INTERP0;
layout(location = 0) out mediump vec4 SV_Target0;
vec3 u_xlat0;
void main()
{
    u_xlat0.x = dot(vs_INTERP0.xyz, vs_INTERP0.xyz);
    u_xlat0.x = inversesqrt(u_xlat0.x);
    u_xlat0.xyz = u_xlat0.xxx * vs_INTERP0.xyz;
    SV_Target0.xyz = u_xlat0.xyz;
    SV_Target0.w = 0.0;
    return;
}

#endif


// ===== program 8: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightDirection;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
highp vec3 vs_INTERP0;
vec4 u_xlat0;
vec4 u_xlat1;
mediump float u_xlat16_2;
float u_xlat4;
bool u_xlatb4;
float u_xlat9;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat0.xyz = vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z) * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat1.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat1.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat1.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat9 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat9 = max(u_xlat9, 1.17549435e-38);
    u_xlat9 = inversesqrt(u_xlat9);
    u_xlat1.xyz = vec3(u_xlat9) * u_xlat1.xyz;
    u_xlat9 = dot(vec3(_LightDirection.x, _LightDirection.y, _LightDirection.z), u_xlat1.xyz);
    u_xlat9 = clamp(u_xlat9, 0.0, 1.0);
    u_xlat9 = (-u_xlat9) + 1.0;
    u_xlat9 = u_xlat9 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat1.xyz * vec3(u_xlat9) + u_xlat0.xyz;
    vs_INTERP0.xyz = u_xlat1.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat4 = roundEven(_ShadowBias.z);
    u_xlatb4 = u_xlat4==1.0;
    u_xlat16_2 = (u_xlatb4) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_2 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 9: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 10: VERTEX =====
#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 _ShadowBias;
uniform 	vec3 _LightPosition;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHAb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBr;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBg;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHBb;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec3 in_POSITION0;
in highp vec3 in_NORMAL0;
highp vec3 vs_INTERP0;
vec4 u_xlat0;
vec4 u_xlat1;
vec3 u_xlat2;
mediump float u_xlat16_3;
float u_xlat5;
bool u_xlatb5;
float u_xlat12;
void main()
{
    u_xlat0.xyz = in_POSITION0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_POSITION0.xxx + u_xlat0.xyz;
    u_xlat0.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_POSITION0.zzz + u_xlat0.xyz;
    u_xlat0.xyz = u_xlat0.xyz + hlslcc_mtx4x4unity_ObjectToWorld[3].xyz;
    u_xlat1.xyz = (-u_xlat0.xyz) + _LightPosition.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat1.xyz);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat1.xyz = vec3(u_xlat12) * u_xlat1.xyz;
    u_xlat0.xyz = u_xlat1.xyz * _ShadowBias.xxx + u_xlat0.xyz;
    u_xlat2.x = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[0].xyz);
    u_xlat2.y = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[1].xyz);
    u_xlat2.z = dot(in_NORMAL0.xyz, hlslcc_mtx4x4unity_WorldToObject[2].xyz);
    u_xlat12 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat12 = max(u_xlat12, 1.17549435e-38);
    u_xlat12 = inversesqrt(u_xlat12);
    u_xlat2.xyz = vec3(u_xlat12) * u_xlat2.xyz;
    u_xlat12 = dot(u_xlat1.xyz, u_xlat2.xyz);
    u_xlat12 = clamp(u_xlat12, 0.0, 1.0);
    u_xlat12 = (-u_xlat12) + 1.0;
    u_xlat12 = u_xlat12 * _ShadowBias.y;
    u_xlat0.xyz = u_xlat2.xyz * vec3(u_xlat12) + u_xlat0.xyz;
    vs_INTERP0.xyz = u_xlat2.xyz;
    u_xlat1 = u_xlat0.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat0.xxxx + u_xlat1;
    u_xlat0 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat0.zzzz + u_xlat1;
    u_xlat0 = u_xlat0 + hlslcc_mtx4x4unity_MatrixVP[3];
    u_xlat1.x = max((-u_xlat0.w), u_xlat0.z);
    u_xlat1.x = (-u_xlat0.z) + u_xlat1.x;
    u_xlat5 = roundEven(_ShadowBias.z);
    u_xlatb5 = u_xlat5==1.0;
    u_xlat16_3 = (u_xlatb5) ? 1.0 : 0.0;
    gl_Position.z = u_xlat16_3 * u_xlat1.x + u_xlat0.z;
    gl_Position.xyw = u_xlat0.xyw;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif


// ===== program 11: FRAGMENT =====
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
layout(location = 0) out mediump vec4 SV_TARGET0;
void main()
{
    SV_TARGET0 = vec4(0.0, 0.0, 0.0, 0.0);
    return;
}

#endif

