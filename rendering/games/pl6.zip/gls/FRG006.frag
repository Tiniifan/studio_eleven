uniform sampler2D unf_frg_txt_2d_0;
uniform sampler2D unf_frg_txt_2d_1;
uniform sampler2D unf_frg_txt_2d_2;
uniform samplerCube unf_frg_txt_cube;
uniform sampler2D unf_frg_txt_lut;
varying vec4 var_clr;
varying vec4 var_nrm;
varying vec4 var_tng;
varying vec4 var_tx0;
varying vec4 var_tx1;
varying vec4 var_tx2;
varying vec4 var_prm;
out vec4 outFragColor;

void main() {
    vec4 txt = texture2D(unf_frg_txt_2d_0, var_tx0.xy);
    outFragColor.x = 0.750300 * txt.x + 0.273600 * txt.y + 0.000000 * txt.z;
    outFragColor.y = 0.130700 * txt.x + 0.774600 * txt.y + 0.094700 * txt.z;
    outFragColor.z = 0.000000 * txt.x + 0.443000 * txt.y + 0.575200 * txt.z;
    outFragColor.w = 1.000000;
    outFragColor *= var_clr * 2.000000;
}
